package dev.lumina.performance;

/**
 * A frame that took much longer than the recent baseline. This records <em>that</em> a hitch happened
 * and how long it was; it does not say what caused it.
 */
public record StutterEvent(long timeMillis, double frameMs, double baselineMs) {
}
