package dev.lumina.performance;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.lumina.config.SafeJsonFile;
import dev.lumina.utils.Json;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * Local diagnostic report. It only describes what was measured and contains no player name, server
 * address, file paths or account data. Nothing is sent anywhere; the user exports and shares it manually.
 */
public final class PerformanceReport {
    private static final DateTimeFormatter FILE_STAMP =
            DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss", Locale.ROOT).withZone(ZoneOffset.UTC);

    /** Everything a report is built from. */
    public record Data(String clientName, String clientVersion, String minecraftVersion,
                       String javaVersion, String osName, int cpuCores, long generatedAtMillis,
                       String activeProfile, FrameSnapshot frames, List<StutterEvent> stutters,
                       MemorySample memory, long gcCount, long gcTimeMillis, List<ModuleCost> moduleCosts) {
    }

    private PerformanceReport() {
    }

    public static String toText(Data d) {
        StringBuilder sb = new StringBuilder();
        sb.append(d.clientName()).append(" performance report\n");
        sb.append("Generated (UTC): ").append(Instant.ofEpochMilli(d.generatedAtMillis())).append('\n');
        sb.append("Client: ").append(d.clientName()).append(' ').append(d.clientVersion())
                .append(" for Minecraft ").append(d.minecraftVersion()).append('\n');
        sb.append("Java: ").append(d.javaVersion()).append(" | OS: ").append(d.osName())
                .append(" | CPU threads: ").append(d.cpuCores()).append('\n');
        sb.append("Active profile: ").append(d.activeProfile()).append("\n\n");

        FrameSnapshot f = d.frames();
        sb.append("Frames (recent window, not the whole session)\n");
        if (f.isEmpty()) {
            sb.append("  no frames recorded\n");
        } else {
            sb.append(String.format(Locale.ROOT, "  Frames in window : %d%n", f.frames()));
            sb.append(String.format(Locale.ROOT, "  Average          : %.1f FPS (%.2f ms)%n", f.avgFps(), f.avgMs()));
            sb.append(String.format(Locale.ROOT, "  Frame time       : min %.2f ms / p95 %.2f ms / p99 %.2f ms / max %.2f ms%n",
                    f.minMs(), f.p95Ms(), f.p99Ms(), f.maxMs()));
            sb.append(String.format(Locale.ROOT, "  1%% low           : %.1f FPS%s%n", f.low1PercentFps(),
                    f.low1Reliable() ? "" : " (too few frames to be reliable)"));
            sb.append(String.format(Locale.ROOT, "  0.1%% low         : %.1f FPS%s%n", f.low01PercentFps(),
                    f.low01Reliable() ? "" : " (too few frames to be reliable)"));
            sb.append(String.format(Locale.ROOT, "  Hitches in window: %d%n", f.hitches()));
            sb.append(String.format(Locale.ROOT, "  Stability index  : %.0f / 100 (heuristic from frame-time variation and hitch rate)%n",
                    f.stability()));
        }
        sb.append('\n').append("Recent hitches (frame much longer than the recent baseline)\n");
        if (d.stutters().isEmpty()) {
            sb.append("  none\n");
        }
        int from = Math.max(0, d.stutters().size() - 20);
        for (StutterEvent e : d.stutters().subList(from, d.stutters().size())) {
            sb.append(String.format(Locale.ROOT, "  %s  %.1f ms (baseline %.1f ms)%n",
                    Instant.ofEpochMilli(e.timeMillis()), e.frameMs(), e.baselineMs()));
        }

        sb.append('\n').append("Memory\n");
        MemorySample m = d.memory();
        sb.append(String.format(Locale.ROOT, "  Heap used %.0f MB of max %.0f MB (committed %.0f MB)%n",
                m.usedMb(), m.maxMb(), m.committedMb()));
        sb.append("  Garbage collections since JVM start: ").append(d.gcCount() < 0 ? "n/a" : d.gcCount())
                .append(", time spent: ").append(d.gcTimeMillis() < 0 ? "n/a" : d.gcTimeMillis() + " ms").append("\n\n");

        sb.append("Module tick cost (measured duration of each module's tick code only)\n");
        if (d.moduleCosts().isEmpty()) {
            sb.append("  no ticking module has run yet\n");
        }
        for (ModuleCost c : d.moduleCosts()) {
            sb.append(String.format(Locale.ROOT, "  %-24s avg %8.1f us  max %9.1f us  ticks %d%n",
                    c.moduleId(), c.avgMicros(), c.maxMicros(), c.ticks()));
        }
        sb.append("\nNote: these figures describe what was measured. They do not show that any module caused a drop in FPS.\n");
        return sb.toString();
    }

    public static JsonObject toJson(Data d) {
        JsonObject o = new JsonObject();
        o.addProperty("client", d.clientName() + " " + d.clientVersion());
        o.addProperty("minecraft", d.minecraftVersion());
        o.addProperty("java", d.javaVersion());
        o.addProperty("os", d.osName());
        o.addProperty("cpuThreads", d.cpuCores());
        o.addProperty("generatedAt", d.generatedAtMillis());
        o.addProperty("activeProfile", d.activeProfile());
        FrameSnapshot f = d.frames();
        JsonObject fr = new JsonObject();
        fr.addProperty("frames", f.frames());
        fr.addProperty("avgFps", f.avgFps());
        fr.addProperty("avgMs", f.avgMs());
        fr.addProperty("minMs", f.minMs());
        fr.addProperty("maxMs", f.maxMs());
        fr.addProperty("p95Ms", f.p95Ms());
        fr.addProperty("p99Ms", f.p99Ms());
        fr.addProperty("low1Fps", f.low1PercentFps());
        fr.addProperty("low1Reliable", f.low1Reliable());
        fr.addProperty("low01Fps", f.low01PercentFps());
        fr.addProperty("low01Reliable", f.low01Reliable());
        fr.addProperty("hitches", f.hitches());
        fr.addProperty("stabilityIndex", f.stability());
        o.add("frameStats", fr);
        JsonArray st = new JsonArray();
        for (StutterEvent e : d.stutters()) {
            JsonObject s = new JsonObject();
            s.addProperty("time", e.timeMillis());
            s.addProperty("frameMs", e.frameMs());
            s.addProperty("baselineMs", e.baselineMs());
            st.add(s);
        }
        o.add("hitches", st);
        JsonObject mem = new JsonObject();
        mem.addProperty("usedMb", d.memory().usedMb());
        mem.addProperty("committedMb", d.memory().committedMb());
        mem.addProperty("maxMb", d.memory().maxMb());
        mem.addProperty("gcCount", d.gcCount());
        mem.addProperty("gcTimeMillis", d.gcTimeMillis());
        o.add("memory", mem);
        JsonArray costs = new JsonArray();
        for (ModuleCost c : d.moduleCosts()) {
            JsonObject co = new JsonObject();
            co.addProperty("module", c.moduleId());
            co.addProperty("ticks", c.ticks());
            co.addProperty("avgMicros", c.avgMicros());
            co.addProperty("maxMicros", c.maxMicros());
            costs.add(co);
        }
        o.add("moduleTickCost", costs);
        o.addProperty("note", "Measured values only; no module is shown to cause a drop in FPS.");
        return o;
    }

    /** Writes {@code report-<UTC stamp>.txt} and {@code .json} into {@code dir}; returns the text file. */
    public static Path export(Path dir, Data d) throws IOException {
        String stamp = FILE_STAMP.format(Instant.ofEpochMilli(d.generatedAtMillis()));
        Path text = dir.resolve("report-" + stamp + ".txt");
        SafeJsonFile.writeAtomically(text, toText(d));
        SafeJsonFile.writeAtomically(dir.resolve("report-" + stamp + ".json"), Json.GSON.toJson(toJson(d)));
        return text;
    }
}
