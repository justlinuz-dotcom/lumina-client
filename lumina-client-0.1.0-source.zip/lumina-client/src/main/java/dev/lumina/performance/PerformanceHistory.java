package dev.lumina.performance;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.Json;
import dev.lumina.utils.MathUtil;
import dev.lumina.utils.NameRules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Bounded, persistable history of {@link ProfileRun}s, keyed by profile id. */
public final class PerformanceHistory {
    public static final int MAX_RUNS_PER_PROFILE = 20;
    public static final int MAX_PROFILES = 64;

    private final Map<String, List<ProfileRun>> runs = new LinkedHashMap<>();

    public synchronized void record(ProfileRun run) {
        List<ProfileRun> list = runs.computeIfAbsent(run.profileId(), k -> new ArrayList<>());
        list.add(run);
        while (list.size() > MAX_RUNS_PER_PROFILE) {
            list.remove(0);
        }
        while (runs.size() > MAX_PROFILES) {
            String oldest = runs.keySet().iterator().next();
            runs.remove(oldest);
        }
    }

    public synchronized List<ProfileRun> runs(String profileId) {
        return List.copyOf(runs.getOrDefault(profileId, List.of()));
    }

    public synchronized ProfileRun latest(String profileId) {
        List<ProfileRun> list = runs.get(profileId);
        return list == null || list.isEmpty() ? null : list.get(list.size() - 1);
    }

    public synchronized List<String> profileIds() {
        return Collections.unmodifiableList(new ArrayList<>(runs.keySet()));
    }

    public synchronized void clear() {
        runs.clear();
    }

    public synchronized JsonObject toJson() {
        JsonObject root = new JsonObject();
        JsonObject profiles = new JsonObject();
        for (Map.Entry<String, List<ProfileRun>> e : runs.entrySet()) {
            JsonArray arr = new JsonArray();
            for (ProfileRun r : e.getValue()) {
                JsonObject o = new JsonObject();
                o.addProperty("time", r.timeMillis());
                o.addProperty("frames", r.frames());
                o.addProperty("avgFps", r.avgFps());
                o.addProperty("avgMs", r.avgMs());
                o.addProperty("low1Fps", r.low1Fps());
                o.addProperty("low1Reliable", r.low1Reliable());
                o.addProperty("stability", r.stability());
                arr.add(o);
            }
            profiles.add(e.getKey(), arr);
        }
        root.add("profiles", profiles);
        return root;
    }

    /** Loads history, skipping malformed entries; returns the number of entries that were skipped. */
    public synchronized int loadJson(JsonObject root) {
        runs.clear();
        int skipped = 0;
        for (Map.Entry<String, JsonElement> e : Json.object(root, "profiles").entrySet()) {
            if (NameRules.validate(e.getKey()) != null || !e.getValue().isJsonArray()) {
                skipped++;
                continue;
            }
            for (JsonElement item : e.getValue().getAsJsonArray()) {
                ProfileRun run = parse(e.getKey(), item);
                if (run == null) {
                    skipped++;
                } else {
                    record(run);
                }
            }
        }
        return skipped;
    }

    private static ProfileRun parse(String profileId, JsonElement item) {
        if (!item.isJsonObject()) {
            return null;
        }
        JsonObject o = item.getAsJsonObject();
        double avgFps = number(o, "avgFps");
        double avgMs = number(o, "avgMs");
        double low1 = number(o, "low1Fps");
        double stability = number(o, "stability");
        int frames = Json.integer(o, "frames", -1);
        if (frames < 0 || !MathUtil.isFinite(avgFps) || !MathUtil.isFinite(avgMs) || !MathUtil.isFinite(low1)
                || !MathUtil.isFinite(stability) || avgFps < 0 || avgMs < 0 || low1 < 0 || stability < 0 || stability > 100) {
            return null;
        }
        long time = o.has("time") && o.get("time").isJsonPrimitive() && o.get("time").getAsJsonPrimitive().isNumber()
                ? o.get("time").getAsLong() : 0L;
        return new ProfileRun(profileId, time, frames, avgFps, avgMs, low1, Json.bool(o, "low1Reliable", false), stability);
    }

    private static double number(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber() ? e.getAsDouble() : Double.NaN;
    }
}
