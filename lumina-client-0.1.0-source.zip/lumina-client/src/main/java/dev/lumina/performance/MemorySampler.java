package dev.lumina.performance;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.function.LongSupplier;

/**
 * Samples JVM heap usage. {@link #sample()} is cheap (three {@link Runtime} calls) and meant to be
 * called about once per second, not every frame. Garbage-collection totals are read from the JVM's
 * own beans and are cumulative.
 */
public final class MemorySampler {
    public static final int HISTORY = 120;

    private final LongSupplier wallClockMillis;
    private final Runtime runtime = Runtime.getRuntime();
    private final MemorySample[] ring = new MemorySample[HISTORY];
    private int head;
    private int size;

    public MemorySampler(LongSupplier wallClockMillis) {
        this.wallClockMillis = wallClockMillis;
    }

    public synchronized MemorySample sample() {
        long committed = runtime.totalMemory();
        MemorySample s = new MemorySample(wallClockMillis.getAsLong(), committed - runtime.freeMemory(),
                committed, runtime.maxMemory());
        ring[head] = s;
        head = (head + 1) % HISTORY;
        if (size < HISTORY) {
            size++;
        }
        return s;
    }

    /** Latest sample, or a fresh one when none was taken yet. */
    public synchronized MemorySample latest() {
        return size == 0 ? sample() : ring[(head - 1 + HISTORY) % HISTORY];
    }

    /** Oldest first. */
    public synchronized List<MemorySample> history() {
        List<MemorySample> out = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            out.add(ring[(head - size + i + HISTORY) % HISTORY]);
        }
        return out;
    }

    /** Cumulative number of collections since JVM start, or -1 when the JVM does not report it. */
    public static long gcCount() {
        long total = 0;
        try {
            for (GarbageCollectorMXBean bean : ManagementFactory.getGarbageCollectorMXBeans()) {
                if (bean.getCollectionCount() < 0) {
                    return -1;
                }
                total += bean.getCollectionCount();
            }
        } catch (RuntimeException | LinkageError e) {
            return -1;
        }
        return total;
    }

    /** Cumulative time spent collecting garbage in ms since JVM start, or -1 when not reported. */
    public static long gcTimeMillis() {
        long total = 0;
        try {
            for (GarbageCollectorMXBean bean : ManagementFactory.getGarbageCollectorMXBeans()) {
                if (bean.getCollectionTime() < 0) {
                    return -1;
                }
                total += bean.getCollectionTime();
            }
        } catch (RuntimeException | LinkageError e) {
            return -1;
        }
        return total;
    }
}
