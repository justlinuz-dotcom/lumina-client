package dev.lumina.performance;

/** Summary of one measured session of frames under a given profile, stored for later comparison. */
public record ProfileRun(String profileId, long timeMillis, int frames, double avgFps, double avgMs,
                         double low1Fps, boolean low1Reliable, double stability) {

    public static ProfileRun of(String profileId, long timeMillis, FrameSnapshot s) {
        return new ProfileRun(profileId, timeMillis, s.frames(), s.avgFps(), s.avgMs(), s.low1PercentFps(),
                s.low1Reliable(), s.stability());
    }
}
