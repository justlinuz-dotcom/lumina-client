package dev.lumina.performance;

import dev.lumina.module.ClientModule;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Measured duration of a module's {@code onTick}. This is the time the module's own tick code took; it
 * does not include its rendering or mixin work, and it is not proof that the module lowers FPS.
 */
public record ModuleCost(String moduleId, long ticks, double avgMicros, double maxMicros) {

    /** Costs of all modules that were ticked at least once, most expensive average first. */
    public static List<ModuleCost> measure(List<ClientModule> modules) {
        List<ModuleCost> out = new ArrayList<>();
        for (ClientModule m : modules) {
            if (m.measuredTicks() > 0) {
                out.add(new ModuleCost(m.id(), m.measuredTicks(), m.averageTickMicros(), m.maxTickMicros()));
            }
        }
        out.sort(Comparator.comparingDouble(ModuleCost::avgMicros).reversed());
        return out;
    }
}
