package dev.lumina.performance;

/** JVM heap usage at one moment (bytes). */
public record MemorySample(long timeMillis, long usedBytes, long committedBytes, long maxBytes) {

    private static final double MB = 1024.0 * 1024.0;

    public double usedMb() {
        return usedBytes / MB;
    }

    public double committedMb() {
        return committedBytes / MB;
    }

    public double maxMb() {
        return maxBytes / MB;
    }

    /** Used heap as a fraction of the maximum heap, in [0, 1]. */
    public double usedFraction() {
        return maxBytes <= 0 ? 0 : Math.max(0, Math.min(1.0, usedBytes / (double) maxBytes));
    }
}
