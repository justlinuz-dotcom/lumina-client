package dev.lumina.performance;

/**
 * Statistics over the frames currently held in {@link FrameStats}. All numbers are measured from
 * real frame times; "low" values are the average of the slowest 1% / 0.1% of frames, converted to FPS.
 *
 * @param low1Reliable  true when the window holds enough frames (>= 300) for the 1% low to mean something
 * @param low01Reliable true when the window holds enough frames (>= 1000) for the 0.1% low to mean something
 * @param stability     heuristic 0..100 index (frame-time variation and hitch rate); an index, not a measurement
 */
public record FrameSnapshot(int frames, double avgMs, double avgFps, double minMs, double maxMs,
                            double p95Ms, double p99Ms, double low1PercentFps, double low01PercentFps,
                            boolean low1Reliable, boolean low01Reliable, int hitches, double stability) {

    public static final FrameSnapshot EMPTY =
            new FrameSnapshot(0, 0, 0, 0, 0, 0, 0, 0, 0, false, false, 0, 0);

    public boolean isEmpty() {
        return frames == 0;
    }
}
