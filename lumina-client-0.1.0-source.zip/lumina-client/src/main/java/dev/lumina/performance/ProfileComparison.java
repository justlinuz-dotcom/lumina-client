package dev.lumina.performance;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Side-by-side comparison of two {@link ProfileRun}s. A verdict is only given when both runs hold
 * enough frames and the difference is at least {@link #SIGNIFICANT_PERCENT}; otherwise the result is
 * explicitly "no clear difference" or "inconclusive". Caveats are always attached.
 */
public final class ProfileComparison {
    public static final double SIGNIFICANT_PERCENT = 5.0;
    public static final int MIN_FRAMES = 300;

    public record Row(String metric, double a, double b, double deltaPercent) {
    }

    public record Result(ProfileRun a, ProfileRun b, List<Row> rows, String verdict, List<String> caveats) {
    }

    private ProfileComparison() {
    }

    public static Result compare(ProfileRun a, ProfileRun b) {
        List<Row> rows = new ArrayList<>();
        rows.add(row("Average FPS", a.avgFps(), b.avgFps()));
        rows.add(row("Average frame time (ms)", a.avgMs(), b.avgMs()));
        rows.add(row("1% low FPS", a.low1Fps(), b.low1Fps()));
        rows.add(row("Stability index", a.stability(), b.stability()));

        List<String> caveats = new ArrayList<>();
        caveats.add("Both runs must be taken in the same place and situation; different scenes are not comparable.");
        boolean enough = a.frames() >= MIN_FRAMES && b.frames() >= MIN_FRAMES;
        if (!enough) {
            caveats.add("At least " + MIN_FRAMES + " frames are needed per run (" + a.profileId() + ": " + a.frames()
                    + ", " + b.profileId() + ": " + b.frames() + ").");
        }
        if (!a.low1Reliable() || !b.low1Reliable()) {
            caveats.add("The 1% low of at least one run is based on too few frames.");
        }

        String verdict;
        if (!enough) {
            verdict = "Inconclusive: too few frames";
        } else if (a.avgFps() <= 0 || b.avgFps() <= 0) {
            verdict = "Inconclusive: a run has no valid FPS";
        } else {
            // "N% more" is always measured against the slower run, so the wording is symmetric.
            ProfileRun faster = a.avgFps() >= b.avgFps() ? a : b;
            ProfileRun slower = faster == a ? b : a;
            double morePercent = (faster.avgFps() / slower.avgFps() - 1.0) * 100.0;
            if (morePercent < SIGNIFICANT_PERCENT) {
                verdict = String.format(Locale.ROOT, "No clear difference (average FPS within %.0f%%)", SIGNIFICANT_PERCENT);
            } else {
                verdict = String.format(Locale.ROOT, "%s averaged %.1f%% more FPS than %s",
                        faster.profileId(), morePercent, slower.profileId());
            }
        }
        return new Result(a, b, List.copyOf(rows), verdict, List.copyOf(caveats));
    }

    private static Row row(String metric, double a, double b) {
        return new Row(metric, a, b, percentChange(a, b));
    }

    /** Change from {@code from} to {@code to} in percent; 0 when {@code from} is zero. */
    static double percentChange(double from, double to) {
        return from == 0 ? 0 : (to - from) / from * 100.0;
    }
}
