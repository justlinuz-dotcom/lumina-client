package dev.lumina.performance;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.LongSupplier;

/**
 * Lightweight frame-time recorder. Recording a frame is O(1) and allocation-free; the expensive
 * statistics (sorting for percentiles) are only computed when {@link #snapshot()} is called, which the
 * UI does a few times per second at most.
 *
 * <p>Hitch detection compares each frame with a slowly adapting baseline (exponential moving
 * average of non-hitch frames). A permanent change of speed is recognised after 10 consecutive slow
 * frames and becomes the new baseline instead of being reported as an endless stutter.
 */
public final class FrameStats {
    public static final int DEFAULT_CAPACITY = 2400;
    static final double MAX_VALID_FRAME_MS = 60_000.0;
    static final double HITCH_FACTOR = 2.5;
    static final double HITCH_FLOOR_MS = 25.0;
    static final int WARMUP_FRAMES = 30;
    static final int SUSTAINED_FRAMES = 10;
    private static final int MAX_EVENTS = 100;
    private static final long FPS_WINDOW_NANOS = 500_000_000L;
    private static final long FPS_CACHE_NANOS = 100_000_000L;

    private final float[] ring;
    private final boolean[] hitchRing;
    private int head;
    private int size;

    private double baselineMs;
    private int recorded;
    private int consecutiveHitches;
    private long rejected;
    private final List<StutterEvent> events = new ArrayList<>();

    private final LongSupplier nanoClock;
    private final LongSupplier wallClockMillis;
    private long lastFrameNanos = Long.MIN_VALUE;

    private long fpsComputedAtNanos = Long.MIN_VALUE;
    private double cachedFps;

    public FrameStats(int capacity, LongSupplier nanoClock, LongSupplier wallClockMillis) {
        if (capacity < 10) {
            throw new IllegalArgumentException("capacity must be >= 10");
        }
        this.ring = new float[capacity];
        this.hitchRing = new boolean[capacity];
        this.nanoClock = nanoClock;
        this.wallClockMillis = wallClockMillis;
    }

    public static FrameStats system() {
        return new FrameStats(DEFAULT_CAPACITY, System::nanoTime, System::currentTimeMillis);
    }

    /** Call once per rendered frame; the frame time is the time since the previous call. */
    public synchronized void onFrame() {
        long now = nanoClock.getAsLong();
        if (lastFrameNanos != Long.MIN_VALUE) {
            record((now - lastFrameNanos) / 1_000_000.0);
        }
        lastFrameNanos = now;
    }

    /** Forget the previous frame timestamp (after a pause, a loading screen, a resource reload). */
    public synchronized void markDiscontinuity() {
        lastFrameNanos = Long.MIN_VALUE;
        consecutiveHitches = 0;
    }

    /** Records one frame time. Invalid values (NaN, non-positive, absurdly long) are counted and ignored. */
    public synchronized void record(double frameMs) {
        if (!(frameMs > 0) || frameMs > MAX_VALID_FRAME_MS) {
            rejected++;
            return;
        }
        boolean hitch = false;
        if (recorded >= WARMUP_FRAMES) {
            hitch = frameMs > Math.max(baselineMs * HITCH_FACTOR, HITCH_FLOOR_MS);
        }
        if (hitch) {
            consecutiveHitches++;
            events.add(new StutterEvent(wallClockMillis.getAsLong(), frameMs, baselineMs));
            if (events.size() > MAX_EVENTS) {
                events.remove(0);
            }
            if (consecutiveHitches >= SUSTAINED_FRAMES) {
                baselineMs = frameMs; // sustained change of speed: this is the new normal
                consecutiveHitches = 0;
            }
        } else {
            consecutiveHitches = 0;
            baselineMs = recorded == 0 ? frameMs : baselineMs + 0.05 * (frameMs - baselineMs);
        }
        recorded++;
        ring[head] = (float) frameMs;
        hitchRing[head] = hitch;
        head = (head + 1) % ring.length;
        if (size < ring.length) {
            size++;
        }
    }

    public synchronized int frameCount() {
        return size;
    }

    public synchronized long rejectedCount() {
        return rejected;
    }

    public synchronized void clear() {
        head = 0;
        size = 0;
        recorded = 0;
        baselineMs = 0;
        consecutiveHitches = 0;
        events.clear();
        lastFrameNanos = Long.MIN_VALUE;
        fpsComputedAtNanos = Long.MIN_VALUE;
    }

    /** Most recent hitches, oldest first (at most 100). */
    public synchronized List<StutterEvent> stutters() {
        return List.copyOf(events);
    }

    /** The newest {@code count} frame times in ms, oldest first (for graphs). */
    public synchronized float[] recent(int count) {
        int n = Math.min(count, size);
        float[] out = new float[n];
        for (int i = 0; i < n; i++) {
            int idx = (head - n + i + ring.length * 2) % ring.length;
            out[i] = ring[idx];
        }
        return out;
    }

    /** FPS over roughly the last half second; recomputed at most every 100 ms. */
    public synchronized double currentFps() {
        long now = nanoClock.getAsLong();
        if (fpsComputedAtNanos != Long.MIN_VALUE && now - fpsComputedAtNanos < FPS_CACHE_NANOS) {
            return cachedFps;
        }
        fpsComputedAtNanos = now;
        double sumMs = 0;
        int n = 0;
        for (int i = 0; i < size; i++) {
            int idx = (head - 1 - i + ring.length * 2) % ring.length;
            sumMs += ring[idx];
            n++;
            if (sumMs * 1_000_000.0 >= FPS_WINDOW_NANOS) {
                break;
            }
        }
        cachedFps = n == 0 || sumMs <= 0 ? 0 : n * 1000.0 / sumMs;
        return cachedFps;
    }

    /** Full statistics over the window. Sorts a copy, so call it sparingly (a few times per second). */
    public synchronized FrameSnapshot snapshot() {
        if (size == 0) {
            return FrameSnapshot.EMPTY;
        }
        double[] sorted = new double[size];
        double sum = 0;
        int hitches = 0;
        for (int i = 0; i < size; i++) {
            int idx = (head - size + i + ring.length * 2) % ring.length;
            sorted[i] = ring[idx];
            sum += ring[idx];
            if (hitchRing[idx]) {
                hitches++;
            }
        }
        Arrays.sort(sorted);
        double mean = sum / size;
        double variance = 0;
        for (double v : sorted) {
            variance += (v - mean) * (v - mean);
        }
        double stdev = Math.sqrt(variance / size);

        double low1 = lowFps(sorted, 0.01);
        double low01 = lowFps(sorted, 0.001);
        double variation = Math.min(1.0, stdev / mean);
        double hitchRate = Math.min(1.0, (hitches / (double) size) * 20.0);
        double stability = 100.0 * (1.0 - variation) * (1.0 - hitchRate);

        return new FrameSnapshot(size, mean, 1000.0 / mean, sorted[0], sorted[size - 1],
                percentile(sorted, 0.95), percentile(sorted, 0.99), low1, low01,
                size >= 300, size >= 1000, hitches, Math.max(0, Math.min(100, stability)));
    }

    /** FPS corresponding to the mean of the slowest {@code fraction} of frames (at least one frame). */
    static double lowFps(double[] ascending, double fraction) {
        int n = ascending.length;
        int worst = Math.max(1, (int) Math.ceil(n * fraction));
        double sum = 0;
        for (int i = n - worst; i < n; i++) {
            sum += ascending[i];
        }
        return 1000.0 / (sum / worst);
    }

    /** Nearest-rank percentile over an ascending array. */
    static double percentile(double[] ascending, double p) {
        int rank = (int) Math.ceil(p * ascending.length);
        return ascending[Math.max(0, Math.min(ascending.length - 1, rank - 1))];
    }
}
