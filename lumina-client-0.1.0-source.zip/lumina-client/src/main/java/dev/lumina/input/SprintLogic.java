package dev.lumina.input;

/**
 * Decision logic of Toggle Sprint. Pure and tick based.
 *
 * <p>Sprinting only ever follows the <em>forward</em> key, exactly like holding the vanilla sprint key:
 * walking backwards or sideways never sprints, and sneaking always wins.
 */
public final class SprintLogic {

    public enum Mode {
        /** The sprint key switches sprint on and off; while on, sprint is held whenever forward is held. */
        TOGGLE,
        /** Sprint is held whenever forward is held. */
        WHILE_MOVING_FORWARD
    }

    private boolean latched;
    private boolean previousKey;

    /**
     * @param sprintKeyDown the physical sprint key is down this tick
     * @param forwardDown   the forward key is down
     * @param sneaking      the player is sneaking
     * @param allowed       whether the module may act at all (for example multiplayer opt-in)
     * @return true when the sprint key should be treated as held this tick; false means "leave the keys alone"
     */
    public boolean update(Mode mode, boolean sprintKeyDown, boolean forwardDown, boolean sneaking, boolean allowed) {
        boolean pressedNow = sprintKeyDown && !previousKey;
        previousKey = sprintKeyDown;
        if (!allowed) {
            latched = false;
            return false;
        }
        if (mode == Mode.TOGGLE && pressedNow) {
            latched = !latched;
        }
        if (sneaking || !forwardDown) {
            return false;
        }
        return mode == Mode.WHILE_MOVING_FORWARD || latched;
    }

    /** Whether toggle mode is currently switched on (for an indicator). */
    public boolean latched() {
        return latched;
    }

    public void reset() {
        latched = false;
        previousKey = false;
    }
}
