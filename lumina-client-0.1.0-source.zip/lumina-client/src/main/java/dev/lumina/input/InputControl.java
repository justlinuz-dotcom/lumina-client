package dev.lumina.input;

/**
 * What the core may ask the game to do with the player's inputs. Deliberately tiny: it can only act as
 * if a key the player already has were held, never produce actions the keyboard could not.
 */
public interface InputControl {

    /**
     * When true the sprint key counts as held for this tick; when false the physical key state is left
     * untouched (so a player really holding the key still sprints).
     */
    void holdSprint(boolean hold);
}
