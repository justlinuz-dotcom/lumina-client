package dev.lumina.input;

import dev.lumina.client.GameState;
import dev.lumina.client.GameState.TrackedKey;
import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.EnumSetting;

/**
 * Toggle Sprint: one press of the sprint key keeps you sprinting while you hold forward. It only
 * replaces holding a key; it never sprints backwards or sideways and never while sneaking.
 *
 * <p>On a multiplayer server it does nothing unless the player allows it in the settings, because some
 * servers have rules about input assistance; the module cannot know them.
 */
public final class ToggleSprintModule extends ClientModule {
    private final GameState state;
    private final InputControl input;
    private final SprintLogic logic = new SprintLogic();

    final EnumSetting<SprintLogic.Mode> mode = add(new EnumSetting<>("mode", "Mode",
            "TOGGLE: press the sprint key to switch sprinting on or off. WHILE_MOVING_FORWARD: sprint whenever you walk forward.",
            SprintLogic.Mode.TOGGLE));
    final BooleanSetting multiplayer = add(new BooleanSetting("allow_multiplayer", "Allow on servers",
            "Off by default: on multiplayer servers this module does nothing unless you turn this on. Check the server's rules first.",
            false));

    public ToggleSprintModule(GameState state, InputControl input) {
        super("toggle_sprint", "Toggle Sprint", "Press the sprint key once instead of holding it. Never sprints backwards or while sneaking.",
                Category.MOVEMENT);
        this.state = state;
        this.input = input;
    }

    @Override
    protected boolean wantsTick() {
        return true;
    }

    @Override
    protected void onDisable() {
        logic.reset();
        input.holdSprint(false);
    }

    @Override
    protected void onTick() {
        if (!state.inWorld()) {
            logic.reset();
            return;
        }
        boolean onServer = state.serverAddress() != null;
        boolean allowed = !onServer || multiplayer.isOn();
        boolean hold = logic.update(mode.get(), state.keyDown(TrackedKey.SPRINT), state.keyDown(TrackedKey.FORWARD),
                state.sneaking() || state.keyDown(TrackedKey.SNEAK), allowed);
        input.holdSprint(hold);
    }

    /** True while toggle mode is switched on, for an on-screen indicator. */
    public boolean isLatched() {
        return logic.latched();
    }
}
