package dev.lumina.module;

/** Criteria used by the module list and Click GUI. {@code null}/empty fields mean "no restriction". */
public record ModuleFilter(String text, Category category, boolean onlyEnabled, boolean onlyFavorites) {

    public static final ModuleFilter ALL = new ModuleFilter("", null, false, false);

    public ModuleFilter withText(String newText) {
        return new ModuleFilter(newText, category, onlyEnabled, onlyFavorites);
    }

    public ModuleFilter withCategory(Category newCategory) {
        return new ModuleFilter(text, newCategory, onlyEnabled, onlyFavorites);
    }
}
