package dev.lumina.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import dev.lumina.event.ClientEvents;
import dev.lumina.event.EventBus;
import dev.lumina.setting.LoadStatus;
import dev.lumina.setting.Setting;
import dev.lumina.utils.ErrorSink;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.Log;
import org.slf4j.Logger;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.IntPredicate;

/**
 * Registry and lifecycle manager for all modules.
 *
 * <ul>
 *   <li>enabling a module first enables its dependencies and refuses when a conflict exists;</li>
 *   <li>disabling a module first disables everything that depends on it;</li>
 *   <li>exceptions thrown by a module are contained: activation is rolled back, ticking modules are
 *       disabled, and the error is reported to the {@link ErrorSink};</li>
 *   <li>state, keys, favourites and settings serialise to / from JSON with a {@link LoadReport}.</li>
 * </ul>
 */
public final class ModuleManager {
    private static final Logger LOG = Log.of("module");
    /** Highest GLFW key code the client accepts from files (GLFW_KEY_LAST is 348). */
    private static final int MAX_KEY_CODE = 348;

    private final EventBus bus;
    private final ErrorSink errors;
    private final IntPredicate reservedKeys;
    private final Map<String, ClientModule> modules = new LinkedHashMap<>();
    private volatile Runnable changeListener = () -> {
    };

    /**
     * @param reservedKeys keys already used by the game; the manager refuses to bind modules to them
     */
    public ModuleManager(EventBus bus, ErrorSink errors, IntPredicate reservedKeys) {
        this.bus = Objects.requireNonNull(bus);
        this.errors = Objects.requireNonNull(errors);
        this.reservedKeys = Objects.requireNonNull(reservedKeys);
    }

    /** Invoked after any change worth persisting (enable state, key, favourite). Settings notify separately. */
    public void setChangeListener(Runnable listener) {
        this.changeListener = Objects.requireNonNull(listener);
    }

    /** For changes the manager cannot see itself, such as a favourite flag, so that they are saved. */
    public void notifyChanged() {
        changed();
    }

    private void changed() {
        changeListener.run();
    }

    // ---- registry ------------------------------------------------------------------------------

    public synchronized void register(ClientModule module) {
        Objects.requireNonNull(module, "module");
        if (modules.containsKey(module.id())) {
            throw new IllegalArgumentException("Duplicate module id: " + module.id());
        }
        modules.put(module.id(), module);
        for (Setting<?> s : module.settings()) {
            s.onChange(v -> changeListener.run());
        }
    }

    /** Removes a module after disabling it (and anything that depends on it). */
    public synchronized boolean unregister(String id) {
        ClientModule m = modules.get(id);
        if (m == null) {
            return false;
        }
        disable(m);
        modules.remove(id);
        changed();
        return true;
    }

    public synchronized Optional<ClientModule> get(String id) {
        return Optional.ofNullable(modules.get(id));
    }

    public synchronized List<ClientModule> all() {
        return List.copyOf(modules.values());
    }

    public synchronized List<ClientModule> byCategory(Category category) {
        List<ClientModule> out = new ArrayList<>();
        for (ClientModule m : modules.values()) {
            if (m.category() == category) {
                out.add(m);
            }
        }
        return out;
    }

    public synchronized List<ClientModule> enabled() {
        List<ClientModule> out = new ArrayList<>();
        for (ClientModule m : modules.values()) {
            if (m.isEnabled()) {
                out.add(m);
            }
        }
        return out;
    }

    public synchronized List<ClientModule> favorites() {
        List<ClientModule> out = new ArrayList<>();
        for (ClientModule m : modules.values()) {
            if (m.isFavorite()) {
                out.add(m);
            }
        }
        return out;
    }

    // ---- search --------------------------------------------------------------------------------

    /** Instant search by name (also id, description and category), best matches first. */
    public List<ClientModule> search(String text) {
        return query(ModuleFilter.ALL.withText(text));
    }

    public synchronized List<ClientModule> query(ModuleFilter filter) {
        String text = filter.text() == null ? "" : filter.text().trim().toLowerCase(Locale.ROOT);
        List<Scored> scored = new ArrayList<>();
        for (ClientModule m : modules.values()) {
            if (filter.category() != null && m.category() != filter.category()) {
                continue;
            }
            if (filter.onlyEnabled() && !m.isEnabled()) {
                continue;
            }
            if (filter.onlyFavorites() && !m.isFavorite()) {
                continue;
            }
            int score = text.isEmpty() ? 1 : score(m, text);
            if (score > 0) {
                scored.add(new Scored(m, score));
            }
        }
        if (!text.isEmpty()) {
            scored.sort(Comparator.<Scored>comparingInt(s -> -s.score).thenComparing(s -> s.module.name()));
        }
        List<ClientModule> out = new ArrayList<>(scored.size());
        for (Scored s : scored) {
            out.add(s.module);
        }
        return out;
    }

    private record Scored(ClientModule module, int score) {
    }

    private static int score(ClientModule m, String q) {
        String name = m.name().toLowerCase(Locale.ROOT);
        if (name.equals(q)) {
            return 100;
        }
        if (name.startsWith(q)) {
            return 90;
        }
        for (String word : name.split("[ _\\-]+")) {
            if (word.startsWith(q)) {
                return 80;
            }
        }
        if (name.contains(q)) {
            return 70;
        }
        if (m.id().contains(q)) {
            return 60;
        }
        if (m.description().toLowerCase(Locale.ROOT).contains(q)) {
            return 40;
        }
        if (m.category().displayName().toLowerCase(Locale.ROOT).contains(q)) {
            return 30;
        }
        return isSubsequence(q, name) ? 20 : 0;
    }

    private static boolean isSubsequence(String needle, String haystack) {
        int i = 0;
        for (int j = 0; j < haystack.length() && i < needle.length(); j++) {
            if (needle.charAt(i) == haystack.charAt(j)) {
                i++;
            }
        }
        return i == needle.length();
    }

    // ---- enable / disable ----------------------------------------------------------------------

    public synchronized ToggleResult toggle(ClientModule module) {
        return setEnabled(module, !module.isEnabled());
    }

    public synchronized ToggleResult setEnabled(ClientModule module, boolean on) {
        if (modules.get(module.id()) != module) {
            return ToggleResult.of(ToggleResult.Status.FAILED, "Module is not registered: " + module.id());
        }
        if (module.isEnabled() == on) {
            return ToggleResult.of(ToggleResult.Status.UNCHANGED, module.name() + " already " + (on ? "on" : "off"));
        }
        ToggleResult result = on ? enable(module) : disable(module);
        if (result.isSuccess()) {
            changed();
        }
        return result;
    }

    private ToggleResult enable(ClientModule m) {
        LinkedHashSet<ClientModule> chain = new LinkedHashSet<>();
        String problem = collectDependencies(m, chain, new ArrayDeque<>());
        if (problem != null) {
            return ToggleResult.of(ToggleResult.Status.MISSING_DEPENDENCY, problem);
        }
        chain.add(m);

        for (ClientModule planned : chain) {
            String conflict = findConflict(planned, chain);
            if (conflict != null) {
                return ToggleResult.of(ToggleResult.Status.BLOCKED_BY_CONFLICT, conflict);
            }
        }

        List<ClientModule> activated = new ArrayList<>();
        for (ClientModule next : chain) {
            if (!activate(next)) {
                for (int i = activated.size() - 1; i >= 0; i--) {
                    deactivate(activated.get(i));
                }
                return ToggleResult.of(ToggleResult.Status.FAILED, next.name() + " failed to start (see error history)");
            }
            activated.add(next);
        }
        List<String> also = new ArrayList<>();
        for (ClientModule c : chain) {
            if (c != m) {
                also.add(c.id());
            }
        }
        return new ToggleResult(ToggleResult.Status.CHANGED,
                m.name() + " enabled" + (also.isEmpty() ? "" : " (also enabled: " + String.join(", ", also) + ")"), also);
    }

    private ToggleResult disable(ClientModule m) {
        LinkedHashSet<ClientModule> dependents = new LinkedHashSet<>();
        collectDependents(m, dependents);
        List<String> also = new ArrayList<>();
        for (ClientModule d : dependents) {
            deactivate(d);
            also.add(d.id());
        }
        deactivate(m);
        return new ToggleResult(ToggleResult.Status.CHANGED,
                m.name() + " disabled" + (also.isEmpty() ? "" : " (also disabled: " + String.join(", ", also) + ")"), also);
    }

    /** Post-order walk: dependencies are added before the modules that need them. Returns an error or null. */
    private String collectDependencies(ClientModule m, LinkedHashSet<ClientModule> chain, Deque<String> path) {
        if (path.contains(m.id())) {
            return "Dependency cycle: " + String.join(" -> ", path) + " -> " + m.id();
        }
        path.addLast(m.id());
        for (String depId : m.dependencies()) {
            ClientModule dep = modules.get(depId);
            if (dep == null) {
                return "Missing dependency '" + depId + "' required by " + m.id();
            }
            if (dep.isEnabled() || chain.contains(dep)) {
                continue;
            }
            String problem = collectDependencies(dep, chain, path);
            if (problem != null) {
                return problem;
            }
            chain.add(dep);
        }
        path.removeLast();
        return null;
    }

    private void collectDependents(ClientModule target, LinkedHashSet<ClientModule> out) {
        for (ClientModule other : modules.values()) {
            if (other.isEnabled() && other.dependencies().contains(target.id()) && !out.contains(other)) {
                collectDependents(other, out);
                out.add(other);
            }
        }
    }

    /** Describes the first conflict between {@code candidate} and an enabled or co-planned module. */
    private String findConflict(ClientModule candidate, Set<ClientModule> planned) {
        for (ClientModule other : modules.values()) {
            if (other == candidate || !(other.isEnabled() || planned.contains(other))) {
                continue;
            }
            if (candidate.conflicts().contains(other.id()) || other.conflicts().contains(candidate.id())) {
                return candidate.name() + " conflicts with " + other.name()
                        + (other.isEnabled() ? " (disable it first)" : "");
            }
        }
        return null;
    }

    private boolean activate(ClientModule m) {
        try {
            m.onEnable();
        } catch (RuntimeException | LinkageError e) {
            LOG.error("Module {} failed to enable", m.id(), e);
            errors.report("module:" + m.id() + ":enable", e);
            try {
                m.onDisable();
            } catch (RuntimeException | LinkageError cleanup) {
                LOG.warn("Cleanup after failed enable of {} also failed: {}", m.id(), cleanup.toString());
            }
            return false;
        }
        m.setEnabledFlag(true);
        m.resetTimings();
        bus.post(new ClientEvents.ModuleToggled(m.id(), true));
        return true;
    }

    private void deactivate(ClientModule m) {
        if (!m.isEnabled()) {
            return;
        }
        try {
            m.onDisable();
        } catch (RuntimeException | LinkageError e) {
            LOG.error("Module {} failed to disable cleanly", m.id(), e);
            errors.report("module:" + m.id() + ":disable", e);
        }
        m.setEnabledFlag(false);
        bus.post(new ClientEvents.ModuleToggled(m.id(), false));
    }

    /** Runs {@code onTick} of every enabled module that asked for it. A failing module is disabled. */
    public void tick() {
        List<ClientModule> snapshot;
        synchronized (this) {
            snapshot = new ArrayList<>(modules.size());
            for (ClientModule m : modules.values()) {
                if (m.isEnabled()) {
                    snapshot.add(m);
                }
            }
        }
        for (ClientModule m : snapshot) {
            if (!m.wantsTick()) {
                continue;
            }
            long start = System.nanoTime();
            try {
                m.onTick();
            } catch (RuntimeException | LinkageError e) {
                LOG.error("Module {} crashed during tick and was disabled", m.id(), e);
                errors.report("module:" + m.id() + ":tick", e);
                synchronized (this) {
                    if (m.isEnabled()) {
                        disable(m);
                        changed();
                    }
                }
                continue;
            }
            m.recordTick(System.nanoTime() - start);
        }
    }

    /** Disables everything in a safe order (dependents first). State on disk is not modified. */
    public synchronized void shutdown() {
        List<ClientModule> list = new ArrayList<>(modules.values());
        Collections.reverse(list);
        for (ClientModule m : list) {
            m.setShuttingDown(true);
        }
        for (ClientModule m : list) {
            if (m.isEnabled()) {
                disable(m);
            }
        }
    }

    // ---- key bindings --------------------------------------------------------------------------

    public record KeyBindResult(boolean success, String detail) {
    }

    /** Binds a key to a module, refusing keys used by the game or by another module. */
    public synchronized KeyBindResult bindKey(ClientModule module, int key) {
        if (key == ClientModule.KEY_UNBOUND) {
            module.setKeyCode(ClientModule.KEY_UNBOUND);
            changed();
            return new KeyBindResult(true, "Unbound");
        }
        if (key < 0 || key > MAX_KEY_CODE) {
            return new KeyBindResult(false, "Invalid key code " + key);
        }
        if (reservedKeys.test(key)) {
            return new KeyBindResult(false, "Key is already used by the game");
        }
        for (ClientModule other : modules.values()) {
            if (other != module && other.keyCode() == key) {
                return new KeyBindResult(false, "Key is already bound to " + other.name());
            }
        }
        module.setKeyCode(key);
        changed();
        return new KeyBindResult(true, "Bound");
    }

    /** Keys bound to more than one module (possible after loading a hand-edited file). */
    public synchronized Map<Integer, List<ClientModule>> findKeyConflicts() {
        Map<Integer, List<ClientModule>> byKey = new HashMap<>();
        for (ClientModule m : modules.values()) {
            if (m.keyCode() != ClientModule.KEY_UNBOUND) {
                byKey.computeIfAbsent(m.keyCode(), k -> new ArrayList<>()).add(m);
            }
        }
        byKey.values().removeIf(list -> list.size() < 2);
        return byKey;
    }

    /** Toggles every module bound to {@code key}; call from the key handler when no screen is open. */
    public List<ToggleResult> handleKey(int key) {
        if (key == ClientModule.KEY_UNBOUND) {
            return List.of();
        }
        List<ClientModule> bound = new ArrayList<>();
        synchronized (this) {
            for (ClientModule m : modules.values()) {
                if (m.keyCode() == key) {
                    bound.add(m);
                }
            }
        }
        List<ToggleResult> results = new ArrayList<>();
        for (ClientModule m : bound) {
            results.add(toggle(m));
        }
        return results;
    }

    // ---- reset ---------------------------------------------------------------------------------

    /** Restores one module's settings and key and applies its default enabled state. */
    public synchronized void resetModule(ClientModule module) {
        module.resetSettings();
        setEnabled(module, module.isDefaultEnabled());
        changed();
    }

    /** Full reset: all settings, keys and enabled states return to defaults; favourites are cleared. */
    public synchronized void resetAll() {
        for (ClientModule m : modules.values()) {
            m.resetSettings();
            m.setFavorite(false);
        }
        applyEnabledStates(defaultStates(), new LoadReport());
        changed();
    }

    private Map<ClientModule, Boolean> defaultStates() {
        Map<ClientModule, Boolean> wanted = new LinkedHashMap<>();
        for (ClientModule m : modules.values()) {
            wanted.put(m, m.isDefaultEnabled());
        }
        return wanted;
    }

    // ---- consistency checks --------------------------------------------------------------------

    /** Static consistency check of the registry; an empty list means no problems. */
    public synchronized List<String> validate() {
        List<String> problems = new ArrayList<>();
        for (ClientModule m : modules.values()) {
            for (String dep : m.dependencies()) {
                if (!modules.containsKey(dep)) {
                    problems.add(m.id() + " depends on unknown module '" + dep + "'");
                }
            }
            for (String c : m.conflicts()) {
                if (!modules.containsKey(c)) {
                    problems.add(m.id() + " conflicts with unknown module '" + c + "'");
                }
            }
        }
        for (ClientModule m : modules.values()) {
            Set<String> closure = new LinkedHashSet<>();
            if (!dependencyClosure(m.id(), closure, new HashSet<>())) {
                problems.add("Dependency cycle involving " + m.id());
                continue;
            }
            for (String depId : closure) {
                ClientModule dep = modules.get(depId);
                if (dep != null && (m.conflicts().contains(depId) || dep.conflicts().contains(m.id()))) {
                    problems.add(m.id() + " requires " + depId + " but they conflict");
                }
            }
        }
        List<ClientModule> defaults = new ArrayList<>();
        for (ClientModule m : modules.values()) {
            if (m.isDefaultEnabled()) {
                defaults.add(m);
            }
        }
        for (int i = 0; i < defaults.size(); i++) {
            for (int j = i + 1; j < defaults.size(); j++) {
                ClientModule a = defaults.get(i);
                ClientModule b = defaults.get(j);
                if (a.conflicts().contains(b.id()) || b.conflicts().contains(a.id())) {
                    problems.add("Default-enabled modules conflict: " + a.id() + " / " + b.id());
                }
            }
        }
        return problems;
    }

    private boolean dependencyClosure(String id, Set<String> out, Set<String> path) {
        if (!path.add(id)) {
            return false;
        }
        ClientModule m = modules.get(id);
        if (m != null) {
            for (String dep : m.dependencies()) {
                out.add(dep);
                if (!dependencyClosure(dep, out, path)) {
                    return false;
                }
            }
        }
        path.remove(id);
        return true;
    }

    /** Tooltip text with dependency and conflict ids resolved to display names. */
    public synchronized String tooltip(ClientModule m) {
        StringBuilder sb = new StringBuilder(m.description());
        if (!m.dependencies().isEmpty()) {
            sb.append("\nRequires: ").append(names(m.dependencies()));
        }
        if (!m.conflicts().isEmpty()) {
            sb.append("\nConflicts with: ").append(names(m.conflicts()));
        }
        return sb.toString();
    }

    private String names(Set<String> ids) {
        List<String> out = new ArrayList<>();
        for (String id : ids) {
            ClientModule other = modules.get(id);
            out.add(other == null ? id : other.name());
        }
        return String.join(", ", out);
    }

    // ---- presets -------------------------------------------------------------------------------

    /** Applies a preset: settings first (so {@code onEnable} sees final values), then enabled states. */
    public synchronized LoadReport applyPreset(Preset preset) {
        LoadReport report = new LoadReport();
        for (Map.Entry<String, Map<String, Object>> byModule : preset.values().entrySet()) {
            ClientModule m = modules.get(byModule.getKey());
            if (m == null) {
                report.add("Preset " + preset.id() + ": unknown module '" + byModule.getKey() + "'");
                continue;
            }
            for (Map.Entry<String, Object> entry : byModule.getValue().entrySet()) {
                Optional<Setting<?>> setting = m.setting(entry.getKey());
                if (setting.isEmpty()) {
                    report.add("Preset " + preset.id() + ": unknown setting '" + m.id() + "." + entry.getKey() + "'");
                    continue;
                }
                JsonElement element = toJson(entry.getValue());
                LoadStatus status = element == null ? LoadStatus.INVALID : setting.get().loadJson(element);
                if (status != LoadStatus.OK) {
                    report.add("Preset " + preset.id() + ": value for '" + m.id() + "." + entry.getKey()
                            + "' was " + status.name().toLowerCase(Locale.ROOT));
                }
            }
        }
        for (Map.Entry<String, Boolean> entry : preset.enabled().entrySet()) {
            ClientModule m = modules.get(entry.getKey());
            if (m == null) {
                report.add("Preset " + preset.id() + ": unknown module '" + entry.getKey() + "'");
                continue;
            }
            ToggleResult r = setEnabled(m, entry.getValue());
            if (!r.isSuccess()) {
                report.add("Preset " + preset.id() + ": " + r.detail());
            }
        }
        changed();
        return report;
    }

    private static JsonElement toJson(Object value) {
        if (value instanceof Boolean b) {
            return new JsonPrimitive(b);
        }
        if (value instanceof Number n) {
            return new JsonPrimitive(n);
        }
        if (value instanceof String s) {
            return new JsonPrimitive(s);
        }
        return null;
    }

    // ---- persistence ---------------------------------------------------------------------------

    public synchronized JsonObject toJson() {
        JsonObject root = new JsonObject();
        JsonObject mods = new JsonObject();
        for (ClientModule m : modules.values()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.keyCode());
            o.addProperty("favorite", m.isFavorite());
            JsonObject settings = new JsonObject();
            for (Setting<?> s : m.settings()) {
                settings.add(s.id(), s.toJson());
            }
            o.add("settings", settings);
            mods.add(m.id(), o);
        }
        root.add("modules", mods);
        return root;
    }

    /**
     * Restores state from JSON. Modules missing from the file get their defaults. Invalid values are
     * replaced by defaults and reported; unknown modules and settings are reported and ignored.
     */
    public synchronized LoadReport loadJson(JsonObject root) {
        LoadReport report = new LoadReport();
        JsonObject mods = Json.object(root, "modules");
        Map<ClientModule, Boolean> wanted = new LinkedHashMap<>();

        for (ClientModule m : modules.values()) {
            JsonElement entry = mods.get(m.id());
            if (entry == null || !entry.isJsonObject()) {
                if (entry != null) {
                    report.add("Module '" + m.id() + "' has an invalid entry; defaults used");
                }
                m.resetSettings();
                m.setFavorite(false);
                wanted.put(m, m.isDefaultEnabled());
                continue;
            }
            JsonObject o = entry.getAsJsonObject();
            loadSettings(m, Json.object(o, "settings"), report);
            int key = Json.integer(o, "key", m.defaultKeyCode());
            if (key != ClientModule.KEY_UNBOUND && (key < 0 || key > MAX_KEY_CODE)) {
                report.add("Module '" + m.id() + "' has invalid key code " + key + "; unbound");
                key = ClientModule.KEY_UNBOUND;
            }
            m.setKeyCode(key);
            m.setFavorite(Json.bool(o, "favorite", false));
            wanted.put(m, Json.bool(o, "enabled", m.isDefaultEnabled()));
        }
        for (String id : mods.keySet()) {
            if (!modules.containsKey(id)) {
                report.add("Unknown module '" + id + "' ignored");
            }
        }

        Set<Integer> usedKeys = new HashSet<>();
        for (ClientModule m : modules.values()) {
            int key = m.keyCode();
            if (key == ClientModule.KEY_UNBOUND) {
                continue;
            }
            if (reservedKeys.test(key) || !usedKeys.add(key)) {
                report.add("Key conflict for module '" + m.id() + "'; key unbound");
                m.setKeyCode(ClientModule.KEY_UNBOUND);
            }
        }

        applyEnabledStates(wanted, report);
        return report;
    }

    private void loadSettings(ClientModule m, JsonObject settingsJson, LoadReport report) {
        for (Setting<?> s : m.settings()) {
            JsonElement value = settingsJson.get(s.id());
            if (value == null) {
                s.reset();
                continue;
            }
            LoadStatus status = s.loadJson(value);
            if (status == LoadStatus.INVALID) {
                s.reset();
                report.add("Invalid value for '" + m.id() + "." + s.id() + "'; default used");
            } else if (status == LoadStatus.ADJUSTED) {
                report.add("Value for '" + m.id() + "." + s.id() + "' was adjusted to " + s.display());
            }
        }
        for (String key : settingsJson.keySet()) {
            if (m.setting(key).isEmpty()) {
                report.add("Unknown setting '" + m.id() + "." + key + "' ignored");
            }
        }
    }

    private void applyEnabledStates(Map<ClientModule, Boolean> wanted, LoadReport report) {
        List<ClientModule> order = new ArrayList<>(modules.values());
        for (int i = order.size() - 1; i >= 0; i--) {
            ClientModule m = order.get(i);
            if (m.isEnabled() && !wanted.getOrDefault(m, false)) {
                disable(m);
            }
        }
        for (ClientModule m : order) {
            if (!m.isEnabled() && wanted.getOrDefault(m, false)) {
                ToggleResult r = enable(m);
                if (!r.isSuccess()) {
                    report.add("Could not enable '" + m.id() + "': " + r.detail());
                } else if (!r.alsoChanged().isEmpty()) {
                    report.add("'" + m.id() + "' needed " + r.alsoChanged() + "; enabled automatically");
                }
            }
        }
    }
}
