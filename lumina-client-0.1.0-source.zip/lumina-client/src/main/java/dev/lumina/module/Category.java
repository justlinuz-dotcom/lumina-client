package dev.lumina.module;

/** Module categories, in the order they appear in the UI. */
public enum Category {
    PERFORMANCE("Performance"),
    COMBAT("Combat"),
    VISUALS("Visuals"),
    HUD("HUD"),
    COSMETICS("Cosmetics"),
    MOVEMENT("Movement"),
    WORLD("World"),
    UTILITY("Utility"),
    SOCIAL("Social"),
    SETTINGS("Settings");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }
}
