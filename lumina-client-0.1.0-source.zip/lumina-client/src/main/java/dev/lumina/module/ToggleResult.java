package dev.lumina.module;

import java.util.List;

/** Outcome of enabling or disabling a module. */
public record ToggleResult(Status status, String detail, List<String> alsoChanged) {

    public enum Status {
        CHANGED,
        UNCHANGED,
        BLOCKED_BY_CONFLICT,
        MISSING_DEPENDENCY,
        FAILED
    }

    public boolean isSuccess() {
        return status == Status.CHANGED || status == Status.UNCHANGED;
    }

    static ToggleResult of(Status status, String detail) {
        return new ToggleResult(status, detail, List.of());
    }
}
