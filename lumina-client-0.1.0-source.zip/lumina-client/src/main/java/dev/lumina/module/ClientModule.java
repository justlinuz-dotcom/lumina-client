package dev.lumina.module;

import dev.lumina.setting.Setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Base class of every feature. A module has an identity, a category, an enabled flag, an optional
 * key, individual settings and optional dependencies / conflicts.
 *
 * <p>State changes go through {@link ModuleManager} so that dependencies, conflicts, events and
 * error handling are applied uniformly. Subclasses only override the lifecycle hooks.
 */
public abstract class ClientModule {
    public static final int KEY_UNBOUND = -1;
    private static final Pattern ID = Pattern.compile("[a-z][a-z0-9_]{0,47}");

    private final String id;
    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private final Set<String> dependencies = new LinkedHashSet<>();
    private final Set<String> conflicts = new LinkedHashSet<>();

    private boolean defaultEnabled;
    private int defaultKey = KEY_UNBOUND;

    private volatile boolean enabled;
    private volatile int keyCode = KEY_UNBOUND;
    private volatile boolean favorite;
    private volatile boolean shuttingDown;

    private volatile long tickCount;
    private volatile long tickNanosTotal;
    private volatile long tickNanosMax;

    protected ClientModule(String id, String name, String description, Category category) {
        if (id == null || !ID.matcher(id).matches()) {
            throw new IllegalArgumentException("Invalid module id: " + id);
        }
        this.id = id;
        this.name = Objects.requireNonNull(name, "name");
        this.description = Objects.requireNonNull(description, "description");
        this.category = Objects.requireNonNull(category, "category");
    }

    // ---- identity -------------------------------------------------------------------------------

    public final String id() {
        return id;
    }

    public final String name() {
        return name;
    }

    public final String description() {
        return description;
    }

    public final Category category() {
        return category;
    }

    // ---- declaration helpers (call from subclass constructors) ---------------------------------

    /** Registers a setting; ids must be unique inside the module. */
    protected final <S extends Setting<?>> S add(S setting) {
        for (Setting<?> existing : settings) {
            if (existing.id().equals(setting.id())) {
                throw new IllegalArgumentException("Duplicate setting '" + setting.id() + "' in module " + id);
            }
        }
        settings.add(setting);
        return setting;
    }

    /** Module ids that must be enabled while this module is enabled (enabled automatically). */
    protected final void requires(String... moduleIds) {
        for (String dep : moduleIds) {
            if (dep.equals(id)) {
                throw new IllegalArgumentException("Module " + id + " cannot depend on itself");
            }
            dependencies.add(dep);
        }
    }

    /** Module ids that cannot be enabled at the same time as this one. */
    protected final void conflictsWith(String... moduleIds) {
        for (String other : moduleIds) {
            if (other.equals(id)) {
                throw new IllegalArgumentException("Module " + id + " cannot conflict with itself");
            }
            conflicts.add(other);
        }
    }

    protected final void defaultEnabled(boolean value) {
        this.defaultEnabled = value;
    }

    protected final void defaultKey(int key) {
        this.defaultKey = key;
        this.keyCode = key;
    }

    // ---- state ---------------------------------------------------------------------------------

    public final boolean isEnabled() {
        return enabled;
    }

    final void setEnabledFlag(boolean value) {
        this.enabled = value;
    }

    public final boolean isDefaultEnabled() {
        return defaultEnabled;
    }

    public final int keyCode() {
        return keyCode;
    }

    /** True while the client is closing (as opposed to the player switching the module off). */
    protected final boolean isShuttingDown() {
        return shuttingDown;
    }

    final void setShuttingDown(boolean value) {
        this.shuttingDown = value;
    }

    final void setKeyCode(int key) {
        this.keyCode = key;
    }

    public final int defaultKeyCode() {
        return defaultKey;
    }

    public final boolean isFavorite() {
        return favorite;
    }

    public final void setFavorite(boolean value) {
        this.favorite = value;
    }

    public final List<Setting<?>> settings() {
        return Collections.unmodifiableList(settings);
    }

    public final Optional<Setting<?>> setting(String settingId) {
        for (Setting<?> s : settings) {
            if (s.id().equals(settingId)) {
                return Optional.of(s);
            }
        }
        return Optional.empty();
    }

    public final Set<String> dependencies() {
        return Collections.unmodifiableSet(dependencies);
    }

    public final Set<String> conflicts() {
        return Collections.unmodifiableSet(conflicts);
    }

    /** Restores every setting and the key binding to defaults (enabled state and favourite are kept). */
    public final void resetSettings() {
        for (Setting<?> s : settings) {
            s.reset();
        }
        keyCode = defaultKey;
    }

    // ---- diagnostics ---------------------------------------------------------------------------

    final void recordTick(long nanos) {
        tickCount++;
        tickNanosTotal += nanos;
        if (nanos > tickNanosMax) {
            tickNanosMax = nanos;
        }
    }

    /** Number of measured {@link #onTick()} calls. */
    public final long measuredTicks() {
        return tickCount;
    }

    /** Average duration of {@link #onTick()} in microseconds (measured, not estimated); 0 when never ticked. */
    public final double averageTickMicros() {
        long n = tickCount;
        return n == 0 ? 0.0 : (tickNanosTotal / (double) n) / 1000.0;
    }

    public final double maxTickMicros() {
        return tickNanosMax / 1000.0;
    }

    final void resetTimings() {
        tickCount = 0;
        tickNanosTotal = 0;
        tickNanosMax = 0;
    }

    // ---- lifecycle hooks -----------------------------------------------------------------------

    /** Called when the module is enabled. Throwing aborts the activation and leaves the module disabled. */
    protected void onEnable() {
    }

    /** Called when the module is disabled. Must release everything acquired in {@link #onEnable()}. */
    protected void onDisable() {
    }

    /** Called once per client tick while enabled. A throwing module is disabled automatically. */
    protected void onTick() {
    }

    /** Whether the manager should call {@link #onTick()} at all (avoids useless per-tick work). */
    protected boolean wantsTick() {
        return false;
    }

    @Override
    public final String toString() {
        return "Module[" + id + (enabled ? ", on" : ", off") + "]";
    }
}
