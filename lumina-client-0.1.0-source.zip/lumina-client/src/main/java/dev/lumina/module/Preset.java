package dev.lumina.module;

import java.util.Map;

/**
 * A named bundle of module states and setting values (for example the performance profiles).
 * Values may be {@link Boolean}, {@link Number} or {@link String}. Unknown modules or settings are
 * reported, never silently ignored.
 */
public record Preset(String id, String name, Map<String, Boolean> enabled, Map<String, Map<String, Object>> values) {

    public Preset {
        enabled = Map.copyOf(enabled);
        values = Map.copyOf(values);
    }
}
