package dev.lumina;

import com.google.gson.JsonObject;
import dev.lumina.client.ClientInfo;
import dev.lumina.client.GameState;
import dev.lumina.combat.CombatStats;
import dev.lumina.combat.ComboTracker;
import dev.lumina.combat.CpsCounter;
import dev.lumina.compat.CompatChecker;
import dev.lumina.config.AutoSaver;
import dev.lumina.config.ClientPaths;
import dev.lumina.config.DataStore;
import dev.lumina.config.GlobalConfigStore;
import dev.lumina.cosmetics.CosmeticCatalog;
import dev.lumina.cosmetics.CosmeticImporter;
import dev.lumina.cosmetics.CosmeticLoadout;
import dev.lumina.diagnostics.ErrorHistory;
import dev.lumina.event.ClientEvents;
import dev.lumina.event.EventBus;
import dev.lumina.hud.BuiltInHud;
import dev.lumina.hud.HudLayout;
import dev.lumina.hud.HudLayoutStore;
import dev.lumina.hud.HudModule;
import dev.lumina.hud.HudServices;
import dev.lumina.input.InputControl;
import dev.lumina.input.ToggleSprintModule;
import dev.lumina.module.ClientModule;
import dev.lumina.module.ModuleManager;
import dev.lumina.options.GameOptions;
import dev.lumina.options.PerformancePresets;
import dev.lumina.options.VideoModules;
import dev.lumina.options.VideoOriginals;
import dev.lumina.options.VideoTweakModule;
import dev.lumina.performance.FrameSnapshot;
import dev.lumina.performance.FrameStats;
import dev.lumina.performance.MemorySampler;
import dev.lumina.performance.PerformanceHistory;
import dev.lumina.performance.ProfileRun;
import dev.lumina.profile.ModulesSection;
import dev.lumina.profile.ProfileException;
import dev.lumina.profile.ProfileManager;
import dev.lumina.profile.ProfileParticipant;
import dev.lumina.profile.ThemeSettings;
import dev.lumina.profile.UiPreferences;
import dev.lumina.render.CustomCrosshairModule;
import dev.lumina.social.Friends;
import dev.lumina.social.NotificationCenter;
import dev.lumina.social.Notes;
import dev.lumina.social.ServerHistory;
import dev.lumina.tools.Timers;
import dev.lumina.tools.Waypoints;
import dev.lumina.utils.ErrorSink;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.Log;
import dev.lumina.world.SessionInfo;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Path;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

/**
 * Wires every part of the client together. It contains no Minecraft code: the game is reached only
 * through the {@link GameState}, {@link GameOptions} and {@link InputControl} given in the
 * {@link Environment}, so the whole client can be started and tested without the game.
 *
 * <p>The Minecraft layer calls {@link #onTick()}, {@link #onFrame()}, {@link #onKey(int)} and the event
 * methods; everything else (modules, profiles, saving, notifications) happens here.
 */
public final class ClientContext implements AutoCloseable {
    private static final Logger LOG = Log.of("context");

    /** What the host (the Minecraft adapter, or a test) provides. */
    public record Environment(Path gameDir, GameState game, GameOptions options, InputControl input, LongSupplier clock,
                              Set<String> loadedMods, String runningMinecraft, int javaFeature,
                              String homeDirectory, String userName, ZoneId zone) {
    }

    public final ClientInfo info = ClientInfo.get();
    public final Environment env;
    public final ClientPaths paths;
    public final GlobalConfigStore global;
    public final EventBus bus;
    public final ErrorHistory errors;
    public final NotificationCenter notifications = new NotificationCenter();

    public final ModuleManager modules;
    public final HudLayout hudLayout = new HudLayout();
    public final HudLayoutStore hudLayouts;
    public final ThemeSettings theme = new ThemeSettings();
    public final UiPreferences ui = new UiPreferences();
    public final ProfileManager profiles;

    public final CpsCounter cps = new CpsCounter();
    public final ComboTracker combo = new ComboTracker(2000);
    public final CombatStats combatStats = new CombatStats();
    public final FrameStats frames;
    public final MemorySampler memory;
    public final SessionInfo session;
    public final PerformanceHistory performanceHistory = new PerformanceHistory();
    public final HudServices hudServices;

    public final VideoOriginals videoOriginals = new VideoOriginals();
    public final List<VideoTweakModule> videoModules;
    public final List<HudModule> hudModules;
    public final CustomCrosshairModule crosshair = new CustomCrosshairModule();
    public final ToggleSprintModule toggleSprint;

    public final Friends friends = new Friends();
    public final Notes notes = new Notes();
    public final Waypoints waypoints = new Waypoints();
    public final ServerHistory serverHistory;
    public final Timers timers;

    public final CosmeticCatalog cosmeticCatalog = new CosmeticCatalog();
    public final CosmeticLoadout cosmetics = new CosmeticLoadout(cosmeticCatalog);
    public final CosmeticImporter cosmeticImporter;

    private final AutoSaver profileSaver;
    private final AutoSaver dataSaver;
    private final Map<String, DataFile> dataFiles = new LinkedHashMap<>();
    private final List<String> startupWarnings = new ArrayList<>();
    private final List<CompatChecker.Note> compatNotes;
    private ProfileRun lastLabRun;
    private boolean labRunning;
    private boolean closed;

    private record DataFile(DataStore store, Supplier<JsonObject> snapshot) {
    }

    private ClientContext(Environment env) {
        this.env = env;
        this.paths = ClientPaths.of(env.gameDir(), info.modId());
        LongSupplier clock = env.clock();

        this.errors = new ErrorHistory(() -> true, clock, env.homeDirectory(), env.userName());
        ErrorSink sink = errors;
        this.global = new GlobalConfigStore(paths, clock, sink);
        this.bus = new EventBus(sink);
        this.modules = new ModuleManager(bus, sink, key -> key == ui.clickGuiKey.getInt() || key == ui.hudEditorKey.getInt());
        this.frames = new FrameStats(2000, System::nanoTime, clock);
        this.memory = new MemorySampler(clock);
        this.session = new SessionInfo(clock);
        this.timers = new Timers(clock);
        this.serverHistory = new ServerHistory(() -> global.settings().keepServerHistory());
        this.hudServices = new HudServices(cps, combo, combatStats, frames, memory, session, clock, env.zone());
        this.hudLayouts = new HudLayoutStore(paths, clock, sink);
        this.cosmeticImporter = new CosmeticImporter(paths, cosmeticCatalog);

        this.profileSaver = new AutoSaver("profile", 1500, sink, this::saveProfileNow);
        this.dataSaver = new AutoSaver("data", 2500, sink, this::saveDataNow);

        this.videoModules = VideoModules.register(modules, env.options(), videoOriginals);
        this.hudModules = BuiltInHud.register(modules, hudLayout, hudServices);
        modules.register(crosshair);
        this.toggleSprint = new ToggleSprintModule(env.game(), env.input());
        modules.register(toggleSprint);

        List<ProfileParticipant> participants = List.of(new ModulesSection(modules), hudLayout, theme, ui, cosmetics);
        this.profiles = new ProfileManager(paths, global, participants, bus, sink, clock);

        this.compatNotes = CompatChecker.check(env.loadedMods(), env.javaFeature(), env.runningMinecraft(), info.targetMinecraft());
    }

    /**
     * Creates the folder structure, loads settings and data, applies the active profile and returns the
     * running context. Problems found while loading never stop the start; they are in {@link #startupWarnings()}.
     */
    public static ClientContext start(Environment env) {
        ClientContext c = new ClientContext(env);
        c.boot();
        return c;
    }

    private void boot() {
        try {
            paths.ensureCreated();
        } catch (IOException e) {
            errors.report("startup:folders", e);
            startupWarnings.add("Could not create the client folder; settings will not be saved: " + e.getMessage());
        }
        startupWarnings.addAll(global.load().warnings());

        registerData("video-originals.json", videoOriginals::toJson, videoOriginals::loadJson, videoOriginals::setChangeListener);
        registerData("friends.json", friends::toJson, friends::loadJson, friends::setChangeListener);
        registerData("notes.json", notes::toJson, notes::loadJson, notes::setChangeListener);
        registerData("waypoints.json", waypoints::toJson, waypoints::loadJson, waypoints::setChangeListener);
        registerData("server-history.json", serverHistory::toJson, serverHistory::loadJson, serverHistory::setChangeListener);
        registerData("cosmetics-index.json", cosmeticCatalog::toJson, cosmeticCatalog::loadJson, cosmeticCatalog::setChangeListener);
        registerData("combat-stats.json", combatStats::toJson, o -> {
            combatStats.loadJson(o);
            return new LoadReport();
        }, null);
        registerData("performance-history.json", performanceHistory::toJson, o -> {
            performanceHistory.loadJson(o);
            return new LoadReport();
        }, null);

        modules.setChangeListener(profileSaver::markDirty);
        hudLayout.setChangeListener(profileSaver::markDirty);
        theme.group().onAnyChange(profileSaver::markDirty);
        ui.group().onAnyChange(profileSaver::markDirty);
        cosmetics.setChangeListener(profileSaver::markDirty);
        errors.setListener(this::onError);

        // Modules start disabled; this applies the default enabled states (for example the FPS counter) before
        // the very first profile is written from the live state. Later starts overwrite it from the saved profile.
        modules.resetAll();
        startupWarnings.addAll(profiles.loadActive().warnings());
        VideoModules.restoreLeftovers(env.options(), videoOriginals, videoModules);

        for (CompatChecker.Note n : compatNotes) {
            if (n.level() == CompatChecker.Level.ERROR || n.level() == CompatChecker.Level.WARNING) {
                NotificationCenter.Level level = n.level() == CompatChecker.Level.ERROR
                        ? NotificationCenter.Level.ERROR : NotificationCenter.Level.WARNING;
                notifications.post(level, n.topic(), n.message(), env.clock().getAsLong());
            }
        }
        if (!startupWarnings.isEmpty()) {
            LOG.warn("{} setting(s) were repaired while loading", startupWarnings.size());
            notifications.post(NotificationCenter.Level.WARNING, info.name(),
                    startupWarnings.size() + " setting(s) were repaired while loading. See Diagnostics.", env.clock().getAsLong());
        }
    }

    private interface Loader {
        LoadReport load(JsonObject json);
    }

    private void registerData(String file, Supplier<JsonObject> snapshot, Loader loader,
                              java.util.function.Consumer<Runnable> listenerSetter) {
        DataStore store = new DataStore(paths, file, 1, env.clock(), errors);
        dataFiles.put(file, new DataFile(store, snapshot));
        LoadReport readReport = new LoadReport();
        JsonObject data = store.load(readReport);
        startupWarnings.addAll(readReport.warnings());
        startupWarnings.addAll(loader.load(data).warnings());
        if (listenerSetter != null) {
            listenerSetter.accept(dataSaver::markDirty);
        }
    }

    private void onError(ErrorHistory.Entry e) {
        if (ui.notifications.isOn() && e.source().startsWith("module:")) {
            notifications.post(NotificationCenter.Level.WARNING, "A module was turned off",
                    "It caused an error (" + e.type() + "). The game keeps running.", env.clock().getAsLong());
        }
    }

    // ---- information ---------------------------------------------------------------------------

    public List<String> startupWarnings() {
        return List.copyOf(startupWarnings);
    }

    public List<CompatChecker.Note> compatibility() {
        return compatNotes;
    }

    /** False when a requirement (Java version, Fabric API) is missing; the host should then stay passive. */
    public boolean isUsable() {
        return !CompatChecker.hasBlockingProblem(compatNotes);
    }

    public List<ClientModule> allModules() {
        return modules.all();
    }

    // ---- driven by the Minecraft layer ---------------------------------------------------------

    /** Once per client tick. */
    public void onTick() {
        if (closed) {
            return;
        }
        modules.tick();
        for (Timers.Timer t : timers.pollFinished()) {
            notifications.post(NotificationCenter.Level.SUCCESS, t.label(), "Timer finished", env.clock().getAsLong());
        }
    }

    /** Once per rendered frame. */
    public void onFrame() {
        if (!closed) {
            frames.onFrame();
        }
    }

    /** A key was pressed outside any screen. Returns true when a module key consumed it. */
    public boolean onKey(int key) {
        return !closed && !modules.handleKey(key).isEmpty();
    }

    public void onAttack() {
        long now = env.clock().getAsLong();
        combo.onAttack(now);
        combatStats.onAttack();
        combatStats.onCombo(combo.combo(now));
        bus.post(new ClientEvents.PlayerAttacked(now));
    }

    public void onDamaged(float amount) {
        long now = env.clock().getAsLong();
        combo.onDamageTaken();
        combatStats.onDamageTaken(amount);
        bus.post(new ClientEvents.PlayerDamaged(now, amount));
    }

    public void onMouseClick(int button) {
        long now = env.clock().getAsLong();
        if (button == CpsCounter.LEFT || button == CpsCounter.RIGHT) {
            cps.click(button, now);
            combatStats.onClick(button);
        }
        bus.post(new ClientEvents.MouseClicked(now, button));
    }

    /** Connected to a server (null or blank for singleplayer). May switch profile when the player set that up. */
    public void onWorldJoin(String serverAddress) {
        long now = env.clock().getAsLong();
        serverHistory.joined(serverAddress, now);
        frames.markDiscontinuity();
        if (serverAddress != null && !serverAddress.isBlank()) {
            String id = profiles.resolveForServer(serverAddress);
            if (id != null && !id.equals(global.settings().activeProfile())) {
                try {
                    profiles.switchTo(id);
                    notifications.post(NotificationCenter.Level.INFO, "Profile switched", "Using profile " + id, now);
                } catch (ProfileException e) {
                    errors.report("profile:auto-switch", e);
                }
            }
        }
    }

    public void onWorldLeave() {
        serverHistory.left(env.clock().getAsLong());
        frames.markDiscontinuity();
        cps.reset();
        combo.reset();
    }

    // ---- performance lab -----------------------------------------------------------------------

    /** Starts measuring: forgets earlier frames so the run only contains what happens from now on. */
    public void startLab() {
        frames.clear();
        labRunning = true;
    }

    public boolean isLabRunning() {
        return labRunning;
    }

    /** Stops measuring and stores the result under the active profile. Returns null when nothing was measured. */
    public ProfileRun finishLab() {
        labRunning = false;
        FrameSnapshot snapshot = frames.snapshot();
        if (snapshot.isEmpty()) {
            return null;
        }
        lastLabRun = ProfileRun.of(global.settings().activeProfile(), env.clock().getAsLong(), snapshot);
        performanceHistory.record(lastLabRun);
        dataSaver.markDirty();
        return lastLabRun;
    }

    public ProfileRun lastLabRun() {
        return lastLabRun;
    }

    /** Applies one of the performance presets and returns what could not be applied. */
    public LoadReport applyPerformancePreset(String presetId) {
        for (var p : PerformancePresets.all()) {
            if (p.id().equals(presetId)) {
                return modules.applyPreset(p);
            }
        }
        LoadReport r = new LoadReport();
        r.add("No performance preset called " + presetId);
        return r;
    }

    // ---- saving --------------------------------------------------------------------------------

    private void saveProfileNow() throws IOException {
        profiles.saveActive();
    }

    private void saveDataNow() {
        for (DataFile f : dataFiles.values()) {
            f.store().save(f.snapshot().get());
        }
    }

    /** Writes everything now. */
    public void flush() {
        try {
            profileSaver.flush();
            dataSaver.flush();
            global.save();
        } catch (RuntimeException e) {
            errors.report("shutdown:flush", e);
        }
    }

    /**
     * Saves everything while the modules are still enabled (so the enabled states are what gets stored),
     * then releases every module, which gives the game options back. Safe to call more than once.
     */
    @Override
    public void close() {
        if (closed) {
            return;
        }
        closed = true;
        try {
            serverHistory.left(env.clock().getAsLong());
            flush();
            profileSaver.close();
            modules.shutdown();
            dataSaver.flush();
        } finally {
            dataSaver.close();
        }
    }
}
