package dev.lumina;

import dev.lumina.compat.CompatChecker;
import dev.lumina.diagnostics.ErrorHistory;

import java.time.Instant;
import java.util.List;

/**
 * Plain-text diagnostics for bug reports. It contains versions, the list of loaded mods' presence checks,
 * repaired settings and recorded errors. It never contains the player name, chat, coordinates, server
 * addresses or file paths of the user's account (those are stripped by {@link ErrorHistory#sanitize}).
 */
public final class DiagnosticsReport {
    private DiagnosticsReport() {
    }

    public static String build(ClientContext c) {
        StringBuilder sb = new StringBuilder();
        sb.append(c.info.name()).append(" diagnostics\n");
        sb.append("Generated (UTC): ").append(Instant.ofEpochMilli(c.env.clock().getAsLong())).append('\n');
        sb.append("Client: ").append(c.info.displayName()).append(" (built for Minecraft ").append(c.info.targetMinecraft()).append(")\n");
        sb.append("Running Minecraft: ").append(c.env.runningMinecraft()).append('\n');
        sb.append("Java: ").append(System.getProperty("java.version", "?")).append(" | OS: ").append(System.getProperty("os.name", "?")).append('\n');
        sb.append("Active profile: ").append(c.global.settings().activeProfile()).append('\n');
        sb.append("Modules: ").append(c.modules.enabled().size()).append(" enabled of ").append(c.allModules().size()).append('\n');
        sb.append("Enabled: ");
        List<String> ids = c.modules.enabled().stream().map(m -> m.id()).toList();
        sb.append(ids.isEmpty() ? "none" : String.join(", ", ids)).append("\n\n");

        sb.append("Compatibility\n");
        for (CompatChecker.Note n : c.compatibility()) {
            sb.append("  [").append(n.level()).append("] ").append(n.topic()).append(": ").append(n.message()).append('\n');
        }
        sb.append("\nSettings repaired while loading: ").append(c.startupWarnings().size()).append('\n');
        for (String w : c.startupWarnings()) {
            sb.append("  - ").append(c.errors.sanitize(w)).append('\n');
        }
        sb.append("\nRecorded errors (newest first)\n");
        for (String line : c.errors.toText().split("\n")) {
            sb.append("  ").append(line).append('\n');
        }
        return sb.toString();
    }
}
