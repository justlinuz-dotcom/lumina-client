package dev.lumina.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.config.GlobalSettings;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;

/**
 * Which servers were played on and for how long, kept on this computer. <strong>Opt-in</strong>: while the
 * switch is off nothing is recorded, and turning it off does not delete what was recorded earlier (use
 * {@link #clear()}). Only the host name is stored, never chat, positions or other players.
 */
public final class ServerHistory {
    public static final int MAX_SERVERS = 100;

    public record Visit(String host, int visits, long totalSeconds, long lastPlayedMillis) {
    }

    private final BooleanSupplier enabled;
    private final Map<String, Visit> byHost = new LinkedHashMap<>();
    private String currentHost;
    private long currentStart;
    private Runnable changeListener = () -> {
    };

    public ServerHistory(BooleanSupplier enabled) {
        this.enabled = enabled;
    }

    public void setChangeListener(Runnable listener) {
        this.changeListener = listener == null ? () -> {
        } : listener;
    }

    /** Called when a server connection starts. A null or blank address means singleplayer and is ignored. */
    public synchronized void joined(String address, long nowMillis) {
        finishCurrent(nowMillis);
        if (!enabled.getAsBoolean() || address == null || address.isBlank()) {
            return;
        }
        String host = GlobalSettings.normaliseHost(address);
        if (host.isEmpty()) {
            return;
        }
        currentHost = host;
        currentStart = nowMillis;
        Visit old = byHost.get(host);
        byHost.put(host, new Visit(host, (old == null ? 0 : old.visits()) + 1, old == null ? 0 : old.totalSeconds(), nowMillis));
        trim();
        changeListener.run();
    }

    /** Called when the connection ends (or the game closes). */
    public synchronized void left(long nowMillis) {
        finishCurrent(nowMillis);
    }

    private void finishCurrent(long nowMillis) {
        if (currentHost == null) {
            return;
        }
        Visit v = byHost.get(currentHost);
        if (v != null) {
            long seconds = Math.max(0, (nowMillis - currentStart) / 1000);
            byHost.put(currentHost, new Visit(v.host(), v.visits(), v.totalSeconds() + seconds, Math.max(v.lastPlayedMillis(), nowMillis)));
            changeListener.run();
        }
        currentHost = null;
    }

    private void trim() {
        while (byHost.size() > MAX_SERVERS) {
            String oldest = null;
            long oldestTime = Long.MAX_VALUE;
            for (Visit v : byHost.values()) {
                if (!v.host().equals(currentHost) && v.lastPlayedMillis() < oldestTime) {
                    oldestTime = v.lastPlayedMillis();
                    oldest = v.host();
                }
            }
            if (oldest == null) {
                return;
            }
            byHost.remove(oldest);
        }
    }

    /** Most recently played first. */
    public synchronized List<Visit> list() {
        List<Visit> out = new ArrayList<>(byHost.values());
        out.sort((a, b) -> Long.compare(b.lastPlayedMillis(), a.lastPlayedMillis()));
        return Collections.unmodifiableList(out);
    }

    public synchronized void clear() {
        currentHost = null;
        if (!byHost.isEmpty()) {
            byHost.clear();
            changeListener.run();
        }
    }

    public synchronized JsonObject toJson() {
        JsonArray array = new JsonArray();
        for (Visit v : byHost.values()) {
            JsonObject o = new JsonObject();
            o.addProperty("host", v.host());
            o.addProperty("visits", v.visits());
            o.addProperty("seconds", v.totalSeconds());
            o.addProperty("last", v.lastPlayedMillis());
            array.add(o);
        }
        JsonObject root = new JsonObject();
        root.add("servers", array);
        return root;
    }

    public synchronized LoadReport loadJson(JsonObject root) {
        LoadReport report = new LoadReport();
        byHost.clear();
        currentHost = null;
        JsonElement el = root.get("servers");
        if (el == null) {
            return report;
        }
        if (!el.isJsonArray()) {
            report.add("server history: expected a list, starting empty");
            return report;
        }
        for (JsonElement item : el.getAsJsonArray()) {
            if (!item.isJsonObject() || byHost.size() >= MAX_SERVERS) {
                report.add("server history: skipped an entry");
                continue;
            }
            JsonObject o = item.getAsJsonObject();
            String host = GlobalSettings.normaliseHost(Json.string(o, "host", ""));
            if (host.isEmpty() || byHost.containsKey(host)) {
                report.add("server history: skipped an invalid or duplicate host");
                continue;
            }
            byHost.put(host, new Visit(host, Math.max(0, Json.integer(o, "visits", 0)), Math.max(0, longOf(o, "seconds")),
                    Math.max(0, longOf(o, "last"))));
        }
        return report;
    }

    private static long longOf(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber() ? e.getAsLong() : 0L;
    }
}
