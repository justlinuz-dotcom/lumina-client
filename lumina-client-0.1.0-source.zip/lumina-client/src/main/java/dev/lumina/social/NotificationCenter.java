package dev.lumina.social;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;

/**
 * In-game notifications (toasts) with a short history. Memory only. Identical messages posted within
 * {@link #DEDUPE_MILLIS} are merged instead of stacking up, and at most {@link #MAX_VISIBLE} are shown.
 */
public final class NotificationCenter {
    public static final int MAX_VISIBLE = 4;
    public static final int MAX_HISTORY = 50;
    public static final long DEDUPE_MILLIS = 2_000;

    public enum Level {
        INFO(4_000), SUCCESS(3_000), WARNING(7_000), ERROR(10_000);

        private final long durationMillis;

        Level(long durationMillis) {
            this.durationMillis = durationMillis;
        }

        public long durationMillis() {
            return durationMillis;
        }
    }

    public record Notification(long id, Level level, String title, String message, long postedMillis, int repeat) {
        public long expiresMillis() {
            return postedMillis + level.durationMillis();
        }
    }

    private final List<Notification> active = new ArrayList<>();
    private final Deque<Notification> history = new ArrayDeque<>();
    private long nextId = 1;
    private boolean muted;

    /** While muted nothing is shown (it is still kept in the history). */
    public synchronized void setMuted(boolean muted) {
        this.muted = muted;
    }

    public synchronized boolean isMuted() {
        return muted;
    }

    public synchronized void post(Level level, String title, String message, long nowMillis) {
        String t = clean(title, 60);
        String m = clean(message, 200);
        for (int i = 0; i < active.size(); i++) {
            Notification n = active.get(i);
            if (n.level() == level && n.title().equals(t) && n.message().equals(m) && nowMillis - n.postedMillis() < DEDUPE_MILLIS) {
                Notification merged = new Notification(n.id(), level, t, m, nowMillis, n.repeat() + 1);
                active.set(i, merged);
                replaceInHistory(merged);
                return;
            }
        }
        Notification n = new Notification(nextId++, level, t, m, nowMillis, 1);
        history.addFirst(n);
        while (history.size() > MAX_HISTORY) {
            history.removeLast();
        }
        if (!muted) {
            active.add(n);
        }
    }

    /** Notifications to draw now, oldest first, after dropping the expired ones. */
    public synchronized List<Notification> visible(long nowMillis) {
        active.removeIf(n -> nowMillis >= n.expiresMillis());
        int from = Math.max(0, active.size() - MAX_VISIBLE);
        return Collections.unmodifiableList(new ArrayList<>(active.subList(from, active.size())));
    }

    public synchronized void dismiss(long id) {
        active.removeIf(n -> n.id() == id);
    }

    public synchronized void dismissAll() {
        active.clear();
    }

    /** Newest first. */
    public synchronized List<Notification> history() {
        return List.copyOf(history);
    }

    public synchronized void clearHistory() {
        history.clear();
    }

    private void replaceInHistory(Notification merged) {
        List<Notification> copy = new ArrayList<>(history);
        history.clear();
        for (Notification n : copy) {
            history.addLast(n.id() == merged.id() ? merged : n);
        }
    }

    private static String clean(String s, int max) {
        String t = s == null ? "" : s.replaceAll("\\p{Cntrl}", " ").trim();
        return t.length() > max ? t.substring(0, max - 1) + "…" : t;
    }
}
