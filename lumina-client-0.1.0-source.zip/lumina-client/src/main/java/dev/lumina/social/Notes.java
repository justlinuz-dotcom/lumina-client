package dev.lumina.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Small private notes (coordinates, to-dos). Stored on this computer only. */
public final class Notes {
    public static final int MAX_NOTES = 200;
    public static final int MAX_TITLE = 60;
    public static final int MAX_TEXT = 2000;

    public record Note(int id, String title, String text, long createdMillis, long modifiedMillis) {
    }

    private final List<Note> notes = new ArrayList<>();
    private int nextId = 1;
    private Runnable changeListener = () -> {
    };

    public void setChangeListener(Runnable listener) {
        this.changeListener = listener == null ? () -> {
        } : listener;
    }

    /** @return the new note's id, or -1 when the list is full */
    public synchronized int add(String title, String text, long nowMillis) {
        if (notes.size() >= MAX_NOTES) {
            return -1;
        }
        int id = nextId++;
        notes.add(new Note(id, cleanTitle(title), cleanText(text), nowMillis, nowMillis));
        changeListener.run();
        return id;
    }

    public synchronized boolean update(int id, String title, String text, long nowMillis) {
        for (int i = 0; i < notes.size(); i++) {
            Note n = notes.get(i);
            if (n.id() == id) {
                notes.set(i, new Note(id, cleanTitle(title), cleanText(text), n.createdMillis(), nowMillis));
                changeListener.run();
                return true;
            }
        }
        return false;
    }

    public synchronized boolean remove(int id) {
        boolean removed = notes.removeIf(n -> n.id() == id);
        if (removed) {
            changeListener.run();
        }
        return removed;
    }

    /** Newest modification first. */
    public synchronized List<Note> list() {
        List<Note> copy = new ArrayList<>(notes);
        copy.sort((a, b) -> Long.compare(b.modifiedMillis(), a.modifiedMillis()));
        return Collections.unmodifiableList(copy);
    }

    public synchronized List<Note> search(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<Note> out = new ArrayList<>();
        for (Note n : list()) {
            if (q.isEmpty() || n.title().toLowerCase(Locale.ROOT).contains(q) || n.text().toLowerCase(Locale.ROOT).contains(q)) {
                out.add(n);
            }
        }
        return out;
    }

    public synchronized int size() {
        return notes.size();
    }

    private static String cleanTitle(String title) {
        String t = title == null ? "" : title.replaceAll("\\p{Cntrl}", " ").trim();
        if (t.isEmpty()) {
            t = "Untitled";
        }
        return t.length() > MAX_TITLE ? t.substring(0, MAX_TITLE) : t;
    }

    private static String cleanText(String text) {
        if (text == null) {
            return "";
        }
        String t = text.replaceAll("[\\p{Cntrl}&&[^\\n]]", " ");
        return t.length() > MAX_TEXT ? t.substring(0, MAX_TEXT) : t;
    }

    // ---- persistence ---------------------------------------------------------------------------

    public synchronized JsonObject toJson() {
        JsonArray array = new JsonArray();
        for (Note n : notes) {
            JsonObject o = new JsonObject();
            o.addProperty("id", n.id());
            o.addProperty("title", n.title());
            o.addProperty("text", n.text());
            o.addProperty("created", n.createdMillis());
            o.addProperty("modified", n.modifiedMillis());
            array.add(o);
        }
        JsonObject root = new JsonObject();
        root.add("notes", array);
        return root;
    }

    public synchronized LoadReport loadJson(JsonObject root) {
        LoadReport report = new LoadReport();
        notes.clear();
        nextId = 1;
        JsonElement el = root.get("notes");
        if (el == null) {
            return report;
        }
        if (!el.isJsonArray()) {
            report.add("notes: expected a list, starting empty");
            return report;
        }
        for (JsonElement item : el.getAsJsonArray()) {
            if (notes.size() >= MAX_NOTES) {
                report.add("notes: more than " + MAX_NOTES + " notes, the rest were dropped");
                break;
            }
            if (!item.isJsonObject()) {
                report.add("notes: skipped an entry that is not an object");
                continue;
            }
            JsonObject o = item.getAsJsonObject();
            int id = Json.integer(o, "id", -1);
            final int checkId = id;
            if (id < 1 || notes.stream().anyMatch(n -> n.id() == checkId)) {
                id = nextId;
            }
            long created = Math.max(0, longOf(o, "created"));
            long modified = Math.max(created, longOf(o, "modified"));
            notes.add(new Note(id, cleanTitle(Json.string(o, "title", "")), cleanText(Json.string(o, "text", "")), created, modified));
            nextId = Math.max(nextId, id + 1);
        }
        return report;
    }

    private static long longOf(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber() ? e.getAsLong() : 0L;
    }
}
