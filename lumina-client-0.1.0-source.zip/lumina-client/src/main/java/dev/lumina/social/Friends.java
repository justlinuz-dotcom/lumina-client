package dev.lumina.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * A private list of player names kept on this computer. Nothing is sent anywhere and no account lookup
 * is made: an entry is just a name and a short note typed by the player.
 */
public final class Friends {
    public static final int MAX_ENTRIES = 500;
    public static final int MAX_NOTE = 100;
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");

    public record Entry(String name, String note, long addedMillis) {
    }

    private final List<Entry> entries = new ArrayList<>();
    private Runnable changeListener = () -> {
    };

    public void setChangeListener(Runnable listener) {
        this.changeListener = listener == null ? () -> {
        } : listener;
    }

    public static boolean isValidName(String name) {
        return name != null && NAME.matcher(name).matches();
    }

    /** @return null on success, otherwise the reason it was refused */
    public synchronized String add(String name, String note, long nowMillis) {
        if (!isValidName(name)) {
            return "Player names have 3 to 16 letters, digits or underscores";
        }
        if (indexOf(name) >= 0) {
            return name + " is already in the list";
        }
        if (entries.size() >= MAX_ENTRIES) {
            return "The list is full (" + MAX_ENTRIES + " entries)";
        }
        entries.add(new Entry(name, cleanNote(note), nowMillis));
        changeListener.run();
        return null;
    }

    public synchronized boolean remove(String name) {
        int i = indexOf(name);
        if (i < 0) {
            return false;
        }
        entries.remove(i);
        changeListener.run();
        return true;
    }

    public synchronized boolean setNote(String name, String note) {
        int i = indexOf(name);
        if (i < 0) {
            return false;
        }
        Entry old = entries.get(i);
        entries.set(i, new Entry(old.name(), cleanNote(note), old.addedMillis()));
        changeListener.run();
        return true;
    }

    public synchronized boolean contains(String name) {
        return indexOf(name) >= 0;
    }

    public synchronized List<Entry> list() {
        List<Entry> sorted = new ArrayList<>(entries);
        sorted.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
        return Collections.unmodifiableList(sorted);
    }

    public synchronized int size() {
        return entries.size();
    }

    public synchronized void clear() {
        if (!entries.isEmpty()) {
            entries.clear();
            changeListener.run();
        }
    }

    private int indexOf(String name) {
        if (name == null) {
            return -1;
        }
        String key = name.toLowerCase(Locale.ROOT);
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).name().toLowerCase(Locale.ROOT).equals(key)) {
                return i;
            }
        }
        return -1;
    }

    private static String cleanNote(String note) {
        if (note == null) {
            return "";
        }
        String t = note.replaceAll("\\p{Cntrl}", " ").trim();
        return t.length() > MAX_NOTE ? t.substring(0, MAX_NOTE) : t;
    }

    // ---- persistence ---------------------------------------------------------------------------

    public synchronized JsonObject toJson() {
        JsonArray array = new JsonArray();
        for (Entry e : entries) {
            JsonObject o = new JsonObject();
            o.addProperty("name", e.name());
            o.addProperty("note", e.note());
            o.addProperty("added", e.addedMillis());
            array.add(o);
        }
        JsonObject root = new JsonObject();
        root.add("friends", array);
        return root;
    }

    public synchronized LoadReport loadJson(JsonObject root) {
        LoadReport report = new LoadReport();
        entries.clear();
        JsonElement el = root.get("friends");
        if (el == null) {
            return report;
        }
        if (!el.isJsonArray()) {
            report.add("friends: expected a list, starting empty");
            return report;
        }
        for (JsonElement item : el.getAsJsonArray()) {
            if (entries.size() >= MAX_ENTRIES) {
                report.add("friends: more than " + MAX_ENTRIES + " entries, the rest were dropped");
                break;
            }
            if (!item.isJsonObject()) {
                report.add("friends: skipped an entry that is not an object");
                continue;
            }
            JsonObject o = item.getAsJsonObject();
            String name = Json.string(o, "name", "");
            if (!isValidName(name) || indexOf(name) >= 0) {
                report.add("friends: skipped invalid or duplicate name '" + abbreviate(name) + "'");
                continue;
            }
            long added = o.has("added") && o.get("added").isJsonPrimitive() && o.get("added").getAsJsonPrimitive().isNumber()
                    ? Math.max(0, o.get("added").getAsLong()) : 0L;
            entries.add(new Entry(name, cleanNote(Json.string(o, "note", "")), added));
        }
        return report;
    }

    private static String abbreviate(String s) {
        String t = s.replaceAll("\\p{Cntrl}", "?");
        return t.length() > 20 ? t.substring(0, 20) + "..." : t;
    }
}
