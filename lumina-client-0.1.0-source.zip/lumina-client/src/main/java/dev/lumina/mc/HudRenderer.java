package dev.lumina.mc;

import dev.lumina.ClientContext;
import dev.lumina.hud.DrawOp;
import dev.lumina.hud.HudComposer;
import dev.lumina.hud.HudContent;
import dev.lumina.hud.HudElementState;
import dev.lumina.hud.HudModule;
import dev.lumina.hud.HudPlan;
import dev.lumina.render.Rect;
import dev.lumina.social.NotificationCenter;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/**
 * Draws the client's HUD (elements, custom crosshair, notifications) once per frame from Fabric's HUD
 * rendering hook. All layout decisions are made by the core ({@link HudComposer}); this class only
 * executes the resulting fill and draw-string commands.
 */
final class HudRenderer {
    private static final int TOAST_WIDTH = 170;
    private static final int TOAST_PAD = 4;

    private final ClientContext ctx;
    private long lastFrameNanos = System.nanoTime();

    HudRenderer(ClientContext ctx) {
        this.ctx = ctx;
    }

    /** The element callback registered with {@code HudElementRegistry}. */
    void render(GuiGraphics graphics, DeltaTracker tracker) {
        Minecraft mc = Minecraft.getInstance();
        long nowNanos = System.nanoTime();
        float dt = Math.min(0.25f, (nowNanos - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = nowNanos;

        LuminaRuntime.guard("frame", ctx::onFrame);
        LuminaRuntime.guard("mouse", () -> LuminaRuntime.pollMouse(mc));

        if (!ctx.isUsable() || mc.screen instanceof HudEditorScreen) {
            return; // the HUD editor draws the elements itself
        }
        McText text = new McText(mc.font);
        int w = graphics.guiWidth();
        int h = graphics.guiHeight();
        LuminaRuntime.guard("hud", () -> drawElements(graphics, mc, text, w, h));
        LuminaRuntime.guard("crosshair", () -> drawCrosshair(graphics, w, h, dt));
        LuminaRuntime.guard("notifications", () -> drawNotifications(graphics, mc, text, w, h));
    }

    private void drawElements(GuiGraphics graphics, Minecraft mc, McText text, int w, int h) {
        boolean inWorld = ctx.env.game().inWorld();
        long now = ctx.env.clock().getAsLong();
        int accent = ctx.theme.accent.argb();
        int panel = ctx.theme.background.argb();
        for (HudModule m : ctx.hudModules) {
            if (!m.isEnabled() || (m.requiresWorld() && !inWorld)) {
                continue;
            }
            HudElementState state = ctx.hudLayout.state(m.id());
            if (state == null || !state.visible()) {
                continue;
            }
            try {
                HudContent content = m.content(ctx.env.game(), now);
                HudPlan plan = HudComposer.compose(m.id(), content, state, text, w, h, accent, panel);
                if (plan != null) {
                    drawPlan(graphics, mc.font, plan);
                }
            } catch (RuntimeException e) {
                ctx.errors.report("hud:" + m.id(), e);
            }
        }
    }

    /** Executes one element's draw commands: translate, scale, then plain fills and strings. */
    static void drawPlan(GuiGraphics graphics, Font font, HudPlan plan) {
        var pose = graphics.pose();
        pose.pushMatrix();
        pose.translate(plan.x(), plan.y());
        pose.scale(plan.scale(), plan.scale());
        for (DrawOp op : plan.ops()) {
            if (op instanceof DrawOp.Fill f) {
                graphics.fill(f.x(), f.y(), f.x() + f.w(), f.y() + f.h(), f.argb());
            } else if (op instanceof DrawOp.Text t) {
                graphics.drawString(font, t.text(), t.x(), t.y(), t.argb(), true);
            }
        }
        pose.popMatrix();
    }

    private void drawCrosshair(GuiGraphics graphics, int w, int h, float dt) {
        if (!ctx.crosshair.isEnabled()) {
            return;
        }
        List<Rect> rects = ctx.crosshair.rects(ctx.env.game(), w / 2, h / 2, dt);
        for (Rect r : rects) {
            graphics.fill(r.x(), r.y(), r.right(), r.bottom(), r.argb());
        }
    }

    /** Toasts stack upwards from the bottom-right corner, above the hotbar line. */
    private void drawNotifications(GuiGraphics graphics, Minecraft mc, McText text, int w, int h) {
        if (!ctx.ui.notifications.isOn()) {
            return;
        }
        long now = ctx.env.clock().getAsLong();
        List<NotificationCenter.Notification> visible = ctx.notifications.visible(now);
        int lineH = mc.font.lineHeight;
        int boxH = TOAST_PAD * 2 + lineH * 2 + 1;
        int y = h - 44;
        for (NotificationCenter.Notification n : visible) {
            int x = w - TOAST_WIDTH - 6;
            y -= boxH + 3;
            graphics.fill(x, y, x + TOAST_WIDTH, y + boxH, ctx.theme.background.argb());
            graphics.fill(x, y, x + 2, y + boxH, levelColor(n.level()));
            String title = n.repeat() > 1 ? n.title() + " x" + n.repeat() : n.title();
            graphics.drawString(mc.font, text.fit(title, TOAST_WIDTH - 10), x + TOAST_PAD + 2, y + TOAST_PAD, 0xFFFFFFFF, true);
            graphics.drawString(mc.font, text.fit(n.message(), TOAST_WIDTH - 10), x + TOAST_PAD + 2,
                    y + TOAST_PAD + lineH + 1, 0xFFB8BCC4, false);
        }
    }

    static int levelColor(NotificationCenter.Level level) {
        return switch (level) {
            case INFO -> 0xFF5B8CFF;
            case SUCCESS -> 0xFF55D68A;
            case WARNING -> 0xFFE6C14D;
            case ERROR -> 0xFFE5594F;
        };
    }
}
