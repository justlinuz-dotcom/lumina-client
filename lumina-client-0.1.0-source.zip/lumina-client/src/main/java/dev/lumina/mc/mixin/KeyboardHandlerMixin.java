package dev.lumina.mc.mixin;

import dev.lumina.mc.LuminaRuntime;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The only mixin of the client. It observes raw key presses so the menu key, the HUD editor key and the
 * per-module key bindings work outside of screens. It never cancels or changes the event, so the game
 * handles every key exactly as before.
 *
 * <p>{@code require = 0}: if a future game version renames the method, the hook is skipped instead of
 * crashing the game. The per-module key bindings then stop working; the menu still opens through the
 * ordinary "Open menu" key binding registered in the game's Controls screen.
 */
@Mixin(KeyboardHandler.class)
public abstract class KeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At("HEAD"), require = 0)
    private void lumina$onKeyPress(long window, int action, KeyEvent event, CallbackInfo ci) {
        LuminaRuntime.onRawKey(action, event.key());
    }
}
