package dev.lumina.mc;

import dev.lumina.options.GameOptions;
import dev.lumina.options.VideoOption;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

/**
 * Reads and writes the vanilla video options through the game's own {@link OptionInstance} objects, so the
 * game keeps validating the values and the options screen shows the same numbers.
 *
 * <p>{@link VideoOption#GRAPHICS} is reported as unsupported: Minecraft 1.21.11 has both a graphics preset
 * and a graphics mode option and which one to drive could not be verified, so the modules that need it
 * refuse to enable instead of guessing.
 *
 * <p>Enumerated options (particles, clouds) are written by their position in the enum, which is the order
 * documented on {@link VideoOption}; the enum types themselves are not named here so a package move in
 * the game does not break the build.
 */
final class McGameOptions implements GameOptions {

    private static net.minecraft.client.Options o() {
        return Minecraft.getInstance().options;
    }

    @Override
    public boolean supports(VideoOption option) {
        return option != VideoOption.GRAPHICS;
    }

    @Override
    public int get(VideoOption option) {
        var o = o();
        return switch (option) {
            case RENDER_DISTANCE -> o.renderDistance().get();
            case SIMULATION_DISTANCE -> o.simulationDistance().get();
            case PARTICLES -> ordinal(o.particles());
            case CLOUDS -> ordinal(o.cloudStatus());
            case ENTITY_SHADOWS -> o.entityShadows().get() ? 1 : 0;
            case BIOME_BLEND -> o.biomeBlendRadius().get();
            case ENTITY_DISTANCE -> (int) Math.round(o.entityDistanceScaling().get() * 100.0);
            case FPS_LIMIT -> o.framerateLimit().get();
            case FOV -> o.fov().get();
            case VIEW_BOBBING -> o.bobView().get() ? 1 : 0;
            case BRIGHTNESS -> (int) Math.round(o.gamma().get() * 100.0);
            case GRAPHICS -> throw new UnsupportedOperationException("graphics is not supported on this version");
        };
    }

    @Override
    public void set(VideoOption option, int value) {
        var o = o();
        int v = option.clamp(value);
        switch (option) {
            case RENDER_DISTANCE -> o.renderDistance().set(v);
            case SIMULATION_DISTANCE -> o.simulationDistance().set(v);
            case PARTICLES -> setOrdinal(o.particles(), v);
            case CLOUDS -> setOrdinal(o.cloudStatus(), v);
            case ENTITY_SHADOWS -> o.entityShadows().set(v != 0);
            case BIOME_BLEND -> o.biomeBlendRadius().set(v);
            case ENTITY_DISTANCE -> o.entityDistanceScaling().set(v / 100.0);
            case FPS_LIMIT -> o.framerateLimit().set(v);
            case FOV -> o.fov().set(v);
            case VIEW_BOBBING -> o.bobView().set(v != 0);
            case BRIGHTNESS -> o.gamma().set(v / 100.0);
            case GRAPHICS -> throw new UnsupportedOperationException("graphics is not supported on this version");
        }
    }

    private static <T extends Enum<T>> int ordinal(OptionInstance<T> option) {
        return option.get().ordinal();
    }

    private static <T extends Enum<T>> void setOrdinal(OptionInstance<T> option, int position) {
        T[] values = option.get().getDeclaringClass().getEnumConstants();
        option.set(values[Math.max(0, Math.min(values.length - 1, position))]);
    }
}
