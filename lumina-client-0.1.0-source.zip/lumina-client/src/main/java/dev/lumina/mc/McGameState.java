package dev.lumina.mc;

import dev.lumina.client.ArmorPiece;
import dev.lumina.client.EffectInfo;
import dev.lumina.client.GameState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Read-only view of the running game for the core. Every call reads current client-side state; nothing
 * is cached, nothing is sent to the server and nothing is written to the game.
 *
 * <p><b>Not compiled in the authoring environment</b> (no access to the Minecraft jars): see
 * {@code docs/VERIFICATION.md} for the list of calls that were checked against the 1.21.11 Mojang-mapped
 * documentation and the ones that were not.
 */
final class McGameState implements GameState {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
            EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND};
    private static final String[] SLOT_NAMES = {"Helmet", "Chestplate", "Leggings", "Boots", "Main hand", "Off hand"};

    private static Minecraft mc() {
        return Minecraft.getInstance();
    }

    private static LocalPlayer player() {
        Minecraft m = mc();
        return m.level == null ? null : m.player;
    }

    @Override
    public boolean inWorld() {
        return player() != null;
    }

    @Override
    public int fps() {
        return mc().getFps();
    }

    @Override
    public double x() {
        LocalPlayer p = player();
        return p == null ? 0 : p.getX();
    }

    @Override
    public double y() {
        LocalPlayer p = player();
        return p == null ? 0 : p.getY();
    }

    @Override
    public double z() {
        LocalPlayer p = player();
        return p == null ? 0 : p.getZ();
    }

    @Override
    public float yaw() {
        LocalPlayer p = player();
        return p == null ? 0f : p.getYRot();
    }

    @Override
    public int pingMs() {
        Minecraft m = mc();
        LocalPlayer p = player();
        if (p == null || m.getCurrentServer() == null) {
            return -1; // singleplayer: the game has no measured latency
        }
        ClientPacketListener connection = m.getConnection();
        if (connection == null) {
            return -1;
        }
        PlayerInfo info = connection.getPlayerInfo(p.getUUID());
        return info == null ? -1 : info.getLatency();
    }

    @Override
    public double speedBlocksPerSecond() {
        LocalPlayer p = player();
        if (p == null) {
            return 0;
        }
        // Difference between this tick's and the previous tick's position, 20 ticks per second.
        return Math.hypot(p.getX() - p.xo, p.getZ() - p.zo) * 20.0;
    }

    @Override
    public boolean sprinting() {
        LocalPlayer p = player();
        return p != null && p.isSprinting();
    }

    @Override
    public boolean sneaking() {
        LocalPlayer p = player();
        return p != null && p.isShiftKeyDown();
    }

    @Override
    public boolean onGround() {
        LocalPlayer p = player();
        return p != null && p.onGround();
    }

    @Override
    public float fallDistance() {
        LocalPlayer p = player();
        return p == null ? 0f : (float) p.fallDistance; // float or double depending on the game version
    }

    /**
     * Not provided: Minecraft 1.21.11 reworked how the world clock is stored and the accessor could not be
     * verified, so the core is told "unknown" (-1) instead of an estimate. HUD elements show "n/a".
     */
    @Override
    public long timeOfDayTicks() {
        return -1;
    }

    @Override
    public float attackCooldown() {
        LocalPlayer p = player();
        return p == null ? -1f : p.getAttackStrengthScale(0.0f);
    }

    @Override
    public boolean keyDown(TrackedKey key) {
        var o = mc().options;
        return switch (key) {
            case FORWARD -> o.keyUp.isDown();
            case BACK -> o.keyDown.isDown();
            case LEFT -> o.keyLeft.isDown();
            case RIGHT -> o.keyRight.isDown();
            case JUMP -> o.keyJump.isDown();
            case SNEAK -> o.keyShift.isDown();
            case SPRINT -> o.keySprint.isDown();
            case ATTACK -> o.keyAttack.isDown();
            case USE -> o.keyUse.isDown();
        };
    }

    @Override
    public List<ArmorPiece> armor() {
        LocalPlayer p = player();
        if (p == null) {
            return List.of();
        }
        List<ArmorPiece> out = new ArrayList<>(SLOTS.length);
        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack stack = p.getItemBySlot(SLOTS[i]);
            if (stack.isEmpty()) {
                continue;
            }
            int max = stack.isDamageableItem() ? stack.getMaxDamage() : 0;
            int left = max > 0 ? max - stack.getDamageValue() : 0;
            out.add(new ArmorPiece(SLOT_NAMES[i], stack.getHoverName().getString(), left, max));
        }
        return out;
    }

    @Override
    public List<EffectInfo> effects() {
        LocalPlayer p = player();
        if (p == null) {
            return List.of();
        }
        List<EffectInfo> out = new ArrayList<>();
        for (MobEffectInstance e : p.getActiveEffects()) {
            int duration = e.getDuration();
            out.add(new EffectInfo(e.getEffect().value().getDisplayName().getString(), e.getAmplifier(),
                    Math.max(0, duration), duration < 0));
        }
        return out;
    }

    @Override
    public String serverAddress() {
        ServerData server = mc().getCurrentServer();
        return server == null ? null : server.ip;
    }

    /**
     * Short dimension name taken from the resource key's text form ("ResourceKey[minecraft:dimension /
     * minecraft:the_nether]"), which avoids depending on accessor names that changed with the 1.21.11
     * resource-location rename.
     */
    @Override
    public String dimension() {
        Minecraft m = mc();
        if (m.level == null) {
            return "overworld";
        }
        String text = String.valueOf(m.level.dimension());
        int slash = text.lastIndexOf('/');
        String name = (slash >= 0 ? text.substring(slash + 1) : text).replace("]", "").trim();
        int colon = name.indexOf(':');
        if (colon >= 0) {
            name = name.substring(colon + 1);
        }
        return name.isEmpty() ? "overworld" : name;
    }
}
