package dev.lumina.mc;

import dev.lumina.input.InputControl;
import net.minecraft.client.Minecraft;

/**
 * Lets the toggle-sprint module behave as if the player's own sprint key were held. It only ever sets the
 * state of the sprint key binding the player already has; it cannot press any other key or do anything the
 * keyboard could not.
 *
 * <p>Known limitation: when the module stops holding the key, the key is released even if the player is
 * physically still holding it (they press it again). The game only updates key states on key events.
 */
final class McInputControl implements InputControl {
    private boolean forced;

    @Override
    public void holdSprint(boolean hold) {
        var key = Minecraft.getInstance().options.keySprint;
        if (hold) {
            key.setDown(true);
            forced = true;
        } else if (forced) {
            key.setDown(false);
            forced = false;
        }
    }
}
