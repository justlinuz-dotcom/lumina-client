package dev.lumina.mc;

import dev.lumina.ClientContext;
import dev.lumina.combat.CpsCounter;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.HitResult;

/**
 * Glue between game events and the core. Holds the single {@link ClientContext}; every entry point is
 * guarded so that an error in the client is recorded in its own history and never reaches the game.
 */
public final class LuminaRuntime {
    private static volatile ClientContext context;
    private static boolean attackWasDown;
    private static boolean useWasDown;
    private static float lastHealth = -1f;
    private static KeyMapping menuKey;
    private static KeyMapping editorKey;

    private LuminaRuntime() {
    }

    static void init(ClientContext ctx) {
        context = ctx;
    }

    /** The ordinary key bindings (shown in the game's Controls screen) that open the menu and the HUD editor. */
    static void setKeyMappings(KeyMapping menu, KeyMapping editor) {
        menuKey = menu;
        editorKey = editor;
    }

    static ClientContext ctx() {
        return context;
    }

    /** Runs {@code r}; an exception is recorded in the client's error history instead of propagating. */
    static void guard(String source, Runnable r) {
        ClientContext c = context;
        try {
            r.run();
        } catch (RuntimeException | LinkageError e) {
            if (c != null) {
                c.errors.report(source, e);
            }
        }
    }

    // ---- events ---------------------------------------------------------------------------------

    static void onTick(Minecraft mc) {
        ClientContext c = context;
        if (c == null || !c.isUsable()) {
            return;
        }
        guard("tick", c::onTick);
        guard("keys", () -> pollKeyMappings(mc, c));
        guard("damage-poll", () -> pollHealth(mc, c));
        guard("mouse-poll", () -> pollMouse(mc));
    }

    static void onJoin(Minecraft mc) {
        ClientContext c = context;
        if (c != null && c.isUsable()) {
            guard("join", () -> c.onWorldJoin(c.env.game().serverAddress()));
        }
        lastHealth = -1f;
    }

    static void onLeave() {
        ClientContext c = context;
        if (c != null && c.isUsable()) {
            guard("leave", c::onWorldLeave);
        }
        lastHealth = -1f;
        attackWasDown = false;
        useWasDown = false;
    }

    static void onStopping() {
        ClientContext c = context;
        if (c != null) {
            guard("shutdown", c::close);
        }
    }

    /**
     * Raw key press from the keyboard mixin. Opens the menu and the HUD editor with their configured keys
     * and forwards every other key to the module key bindings. Ignored while any screen is open (chat,
     * menus, inventory), so typing never triggers anything.
     */
    public static void onRawKey(int action, int key) {
        ClientContext c = context;
        Minecraft mc = Minecraft.getInstance();
        if (c == null || !c.isUsable() || action != 1 || mc.screen != null || mc.player == null) {
            return;
        }
        guard("key", () -> {
            if (key == c.ui.clickGuiKey.getInt()) {
                mc.setScreen(new LuminaScreen(c, key));
            } else if (key == c.ui.hudEditorKey.getInt()) {
                mc.setScreen(new HudEditorScreen(c, key));
            } else {
                c.onKey(key);
            }
        });
    }

    // ---- polling --------------------------------------------------------------------------------

    /**
     * Click counting for the CPS display and combat statistics: the attack and use key bindings are polled
     * every frame and every tick, and a press is counted when the state changes from up to down. The client
     * only observes; it never presses anything.
     */
    static void pollMouse(Minecraft mc) {
        ClientContext c = context;
        if (c == null || !c.isUsable()) {
            return;
        }
        boolean active = mc.screen == null && mc.player != null;
        boolean attack = active && mc.options.keyAttack.isDown();
        boolean use = active && mc.options.keyUse.isDown();
        if (attack && !attackWasDown) {
            c.onMouseClick(CpsCounter.LEFT);
            HitResult hit = mc.hitResult;
            if (hit != null && hit.getType() == HitResult.Type.ENTITY) {
                c.onAttack();
            }
        }
        if (use && !useWasDown) {
            c.onMouseClick(CpsCounter.RIGHT);
        }
        attackWasDown = attack;
        useWasDown = use;
    }

    private static void pollKeyMappings(Minecraft mc, ClientContext c) {
        while (menuKey != null && menuKey.consumeClick()) {
            if (mc.screen == null && mc.player != null) {
                mc.setScreen(new LuminaScreen(c));
            }
        }
        while (editorKey != null && editorKey.consumeClick()) {
            if (mc.screen == null && mc.player != null) {
                mc.setScreen(new HudEditorScreen(c));
            }
        }
    }

    private static void pollHealth(Minecraft mc, ClientContext c) {
        if (mc.player == null) {
            lastHealth = -1f;
            return;
        }
        float health = mc.player.getHealth();
        if (lastHealth >= 0f && health < lastHealth - 0.01f) {
            c.onDamaged(lastHealth - health);
        }
        lastHealth = health;
    }
}
