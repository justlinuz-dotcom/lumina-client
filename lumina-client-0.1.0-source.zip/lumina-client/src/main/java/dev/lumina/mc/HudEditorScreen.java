package dev.lumina.mc;

import dev.lumina.ClientContext;
import dev.lumina.hud.HudComposer;
import dev.lumina.hud.HudContent;
import dev.lumina.hud.HudElementState;
import dev.lumina.hud.HudGeometry;
import dev.lumina.hud.HudModule;
import dev.lumina.hud.HudPlan;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * HUD editor: drag elements, scroll to scale, shift-click to select several and align them, optional grid
 * and snapping. Elements that are switched off or hidden are shown as ghosts so they can still be placed.
 * All position maths lives in the core ({@link HudGeometry}); this screen only draws and forwards input.
 */
final class HudEditorScreen extends Screen {
    private static final int[] PALETTE = {0xFFFFFFFF, 0xFFFF5555, 0xFFFFAA00, 0xFFFFFF55, 0xFF55FF55,
            0xFF55FFFF, 0xFF5B8CFF, 0xFFAA55FF, 0xFFFF77CC};
    /** GLFW_MOD_SHIFT: the modifier bit the game reports in its key and mouse events. */
    private static final int SHIFT_MODIFIER = 1;
    private static final int BTN = 0xFF2B303B;
    private static final int BTN_ON = 0xFF3E5FA8;

    private record Btn(int x, int y, int w, int h, String label, boolean active, Runnable action) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final ClientContext ctx;
    private final int openedByKey;
    private boolean openKeyReleased;

    private final Set<String> selected = new LinkedHashSet<>();
    private final Map<String, HudPlan> plans = new LinkedHashMap<>();
    private final Map<String, HudModule> modulesById = new LinkedHashMap<>();
    private final List<Btn> buttons = new ArrayList<>();
    private String dragging;
    private double dragOffsetX;
    private double dragOffsetY;
    private boolean moved;

    HudEditorScreen(ClientContext ctx) {
        this(ctx, -1);
    }

    HudEditorScreen(ClientContext ctx, int openedByKey) {
        super(Component.literal(ctx.info.displayName() + " HUD editor"));
        this.ctx = ctx;
        this.openedByKey = openedByKey;
        this.openKeyReleased = openedByKey < 0;
        for (HudModule m : ctx.hudModules) {
            modulesById.put(m.id(), m);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ---- plans ----------------------------------------------------------------------------------

    /** Recomputes every element's on-screen box. Elements without content use their preview text. */
    private void buildPlans() {
        plans.clear();
        McText text = new McText(font);
        boolean inWorld = ctx.env.game().inWorld();
        long now = ctx.env.clock().getAsLong();
        int accent = ctx.theme.accent.argb();
        int panel = ctx.theme.background.argb();
        for (HudModule m : ctx.hudModules) {
            HudElementState state = ctx.hudLayout.state(m.id());
            if (state == null) {
                continue;
            }
            HudContent content = null;
            boolean live = inWorld && m.isEnabled() && state.visible();
            if (live) {
                try {
                    content = m.content(ctx.env.game(), now);
                } catch (RuntimeException e) {
                    ctx.errors.report("hud-editor:" + m.id(), e);
                }
            }
            HudElementState drawState = state;
            if (content == null || !live) {
                content = m.previewContent();
                drawState = state.copy();
                drawState.setOpacity(Math.min(state.opacity(), 0.4f));
            }
            HudPlan plan = HudComposer.compose(m.id(), content, drawState, text, width, height, accent, panel);
            if (plan != null) {
                plans.put(m.id(), plan);
            }
        }
    }

    // ---- drawing --------------------------------------------------------------------------------

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0x55000000);
        drawGrid(g);
        buildPlans();
        int accent = ctx.theme.accent.argb();
        for (HudPlan plan : plans.values()) {
            HudRenderer.drawPlan(g, font, plan);
            boolean isSelected = selected.contains(plan.id());
            outline(g, plan, isSelected ? accent : 0x66FFFFFF);
            HudModule m = modulesById.get(plan.id());
            HudElementState st = ctx.hudLayout.state(plan.id());
            if (m != null && st != null && (!m.isEnabled() || !st.visible())) {
                String tag = !m.isEnabled() ? "off" : "hidden";
                g.drawString(font, tag, Math.round(plan.x()) + 2, Math.round(plan.y()) - font.lineHeight - 1, 0xFFE6C14D, true);
            }
        }
        buildToolbar();
        for (Btn b : buttons) {
            boolean hover = b.contains(mouseX, mouseY);
            g.fill(b.x, b.y, b.x + b.w, b.y + b.h, b.active ? BTN_ON : hover ? 0xFF3A404E : BTN);
            g.drawString(font, b.label, b.x + 4, b.y + (b.h - font.lineHeight) / 2 + 1, 0xFFFFFFFF, false);
        }
        String hint = "Drag to move  |  scroll to scale  |  shift+click to select several  |  right click: show/hide"
                + "  |  arrows: nudge (shift = 10 px)";
        g.drawString(font, hint, 6, height - 12, 0xFFB8BCC4, true);
    }

    private void outline(GuiGraphics g, HudPlan p, int color) {
        int x1 = Math.round(p.x());
        int y1 = Math.round(p.y());
        int x2 = Math.round(p.x() + p.w());
        int y2 = Math.round(p.y() + p.h());
        g.fill(x1 - 1, y1 - 1, x2 + 1, y1, color);
        g.fill(x1 - 1, y2, x2 + 1, y2 + 1, color);
        g.fill(x1 - 1, y1, x1, y2, color);
        g.fill(x2, y1, x2 + 1, y2, color);
    }

    private void drawGrid(GuiGraphics g) {
        if (ctx.hudLayout.gridEnabled()) {
            int step = Math.max(2, ctx.hudLayout.gridSize());
            for (int x = 0; x < width; x += step) {
                g.fill(x, 0, x + 1, height, 0x14FFFFFF);
            }
            for (int y = 0; y < height; y += step) {
                g.fill(0, y, width, y + 1, 0x14FFFFFF);
            }
        }
        g.fill(width / 2, 0, width / 2 + 1, height, 0x22FFFFFF);
        g.fill(0, height / 2, width, height / 2 + 1, 0x22FFFFFF);
    }

    // ---- toolbar --------------------------------------------------------------------------------

    private void buildToolbar() {
        buttons.clear();
        int[] cursor = {6, 6};
        add(cursor, "Done", false, this::onClose);
        add(cursor, "Grid: " + (ctx.hudLayout.gridEnabled() ? "on" : "off"), ctx.hudLayout.gridEnabled(),
                () -> change(() -> ctx.hudLayout.setGridEnabled(!ctx.hudLayout.gridEnabled())));
        add(cursor, "Snap: " + (ctx.hudLayout.snapToGrid() ? "on" : "off"), ctx.hudLayout.snapToGrid(),
                () -> change(() -> ctx.hudLayout.setSnapToGrid(!ctx.hudLayout.snapToGrid())));
        add(cursor, "Grid -", false, () -> change(() -> ctx.hudLayout.setGridSize(ctx.hudLayout.gridSize() - 2)));
        add(cursor, "Grid " + ctx.hudLayout.gridSize() + " px", false, () -> { });
        add(cursor, "Grid +", false, () -> change(() -> ctx.hudLayout.setGridSize(ctx.hudLayout.gridSize() + 2)));
        add(cursor, "Reset all", false, () -> change(ctx.hudLayout::resetAll));

        if (selected.isEmpty()) {
            return;
        }
        cursor[0] = 6;
        cursor[1] += 20;
        String label = selected.size() == 1 ? nameOf(selected.iterator().next()) : selected.size() + " selected";
        add(cursor, label, true, () -> { });
        add(cursor, "Scale -", false, () -> forSelected(s -> s.setScale(s.scale() - 0.1f)));
        add(cursor, "Scale +", false, () -> forSelected(s -> s.setScale(s.scale() + 0.1f)));
        add(cursor, "Opacity -", false, () -> forSelected(s -> s.setOpacity(s.opacity() - 0.1f)));
        add(cursor, "Opacity +", false, () -> forSelected(s -> s.setOpacity(s.opacity() + 0.1f)));
        add(cursor, "Colour", false, () -> forSelected(s -> s.setTextColor(nextColor(s.textColor()))));
        add(cursor, "Background", false, () -> forSelected(s -> s.setBackground(!s.background())));
        add(cursor, "Visible", false, () -> forSelected(s -> s.setVisible(!s.visible())));
        add(cursor, "Reset", false, () -> change(() -> {
            for (String id : selected) {
                ctx.hudLayout.reset(id);
            }
        }));
        if (selected.size() >= 2) {
            cursor[0] = 6;
            cursor[1] += 20;
            add(cursor, "Align left", false, () -> align(HudGeometry.AlignMode.LEFT));
            add(cursor, "Align right", false, () -> align(HudGeometry.AlignMode.RIGHT));
            add(cursor, "Align top", false, () -> align(HudGeometry.AlignMode.TOP));
            add(cursor, "Align bottom", false, () -> align(HudGeometry.AlignMode.BOTTOM));
            add(cursor, "Centre H", false, () -> align(HudGeometry.AlignMode.CENTER_HORIZONTAL));
            add(cursor, "Centre V", false, () -> align(HudGeometry.AlignMode.CENTER_VERTICAL));
        }
    }

    /** Adds a button at the cursor, wrapping to a new line when it would leave the screen. */
    private void add(int[] cursor, String label, boolean active, Runnable action) {
        int w = font.width(label) + 8;
        if (cursor[0] + w > width - 6) {
            cursor[0] = 6;
            cursor[1] += 20;
        }
        buttons.add(new Btn(cursor[0], cursor[1], w, 16, label, active, action));
        cursor[0] += w + 4;
    }

    private String nameOf(String id) {
        HudModule m = modulesById.get(id);
        return m == null ? id : m.name();
    }

    private static int nextColor(int current) {
        int rgb = current | 0xFF000000;
        for (int i = 0; i < PALETTE.length; i++) {
            if (PALETTE[i] == rgb) {
                return PALETTE[(i + 1) % PALETTE.length];
            }
        }
        return PALETTE[0];
    }

    private void change(Runnable r) {
        r.run();
        ctx.hudLayout.notifyChanged();
    }

    private void forSelected(java.util.function.Consumer<HudElementState> action) {
        for (String id : selected) {
            HudElementState s = ctx.hudLayout.state(id);
            if (s != null) {
                action.accept(s);
            }
        }
        ctx.hudLayout.notifyChanged();
    }

    private void align(HudGeometry.AlignMode mode) {
        List<HudGeometry.Placed> group = new ArrayList<>();
        for (String id : selected) {
            HudPlan plan = plans.get(id);
            HudElementState s = ctx.hudLayout.state(id);
            if (plan != null && s != null) {
                group.add(new HudGeometry.Placed(s, plan.box()));
            }
        }
        HudGeometry.align(group, mode, width, height, ctx.hudLayout.effectiveSnap());
        ctx.hudLayout.notifyChanged();
    }

    // ---- input ----------------------------------------------------------------------------------

    /** Top-most element under the point (the one drawn last), or null. */
    private String elementAt(double mx, double my) {
        String found = null;
        for (HudPlan plan : plans.values()) {
            if (plan.box().contains((float) mx, (float) my)) {
                found = plan.id();
            }
        }
        return found;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        if (event.button() == 0) {
            for (Btn b : buttons) {
                if (b.contains(mx, my)) {
                    b.action.run();
                    return true;
                }
            }
        }
        String id = elementAt(mx, my);
        boolean shift = (event.modifiers() & SHIFT_MODIFIER) != 0;
        if (id == null) {
            if (!shift) {
                selected.clear();
            }
            return false;
        }
        if (event.button() == 1) {
            HudElementState s = ctx.hudLayout.state(id);
            if (s != null) {
                s.setVisible(!s.visible());
                ctx.hudLayout.notifyChanged();
            }
            return true;
        }
        if (event.button() != 0) {
            return false;
        }
        if (shift) {
            if (!selected.remove(id)) {
                selected.add(id);
            }
        } else if (!selected.contains(id)) {
            selected.clear();
            selected.add(id);
        }
        HudPlan plan = plans.get(id);
        dragging = id;
        dragOffsetX = mx - plan.x();
        dragOffsetY = my - plan.y();
        moved = false;
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging == null) {
            return false;
        }
        HudPlan plan = plans.get(dragging);
        HudElementState state = ctx.hudLayout.state(dragging);
        if (plan == null || state == null) {
            return false;
        }
        HudGeometry.moveTo(state, plan.w(), plan.h(), (float) (event.x() - dragOffsetX),
                (float) (event.y() - dragOffsetY), width, height, ctx.hudLayout.effectiveSnap());
        moved = true;
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null && moved) {
            ctx.hudLayout.notifyChanged();
        }
        dragging = null;
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        String id = elementAt(mouseX, mouseY);
        HudElementState s = id == null ? null : ctx.hudLayout.state(id);
        if (s == null) {
            return false;
        }
        s.setScale(s.scale() + (float) vertical * 0.1f);
        ctx.hudLayout.notifyChanged();
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == openedByKey && !openKeyReleased) {
            return true; // the press that opened the editor must not close it again
        }
        if (key == 256 || key == ctx.ui.hudEditorKey.getInt()) {
            onClose();
            return true;
        }
        int step = (event.modifiers() & SHIFT_MODIFIER) != 0 ? 10 : 1;
        int dx = key == 263 ? -step : key == 262 ? step : 0;
        int dy = key == 265 ? -step : key == 264 ? step : 0;
        if ((dx != 0 || dy != 0) && !selected.isEmpty()) {
            for (String id : selected) {
                HudPlan plan = plans.get(id);
                HudElementState s = ctx.hudLayout.state(id);
                if (plan != null && s != null) {
                    HudGeometry.moveTo(s, plan.w(), plan.h(), plan.x() + dx, plan.y() + dy, width, height, 0);
                }
            }
            ctx.hudLayout.notifyChanged();
            return true;
        }
        return false;
    }

    @Override
    public boolean keyReleased(KeyEvent event) {
        if (event.key() == openedByKey) {
            openKeyReleased = true;
        }
        return false;
    }
}
