package dev.lumina.mc;

import dev.lumina.ClientContext;
import dev.lumina.ui.Row;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiHost;
import dev.lumina.render.Rect;
import dev.lumina.render.RoundedRect;
import dev.lumina.ui.UiLayout;
import dev.lumina.ui.UiLayout.Placed;
import dev.lumina.ui.UiPage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * The client menu (home, modules, profiles, performance, cosmetics, social, tools, settings). The pages are
 * plain data built by the core ({@link UiApp}); this screen only draws the rows and forwards the mouse
 * and keyboard, which is why every page is covered by tests that need no game.
 */
final class LuminaScreen extends Screen implements UiHost {
    private static final int TEXT = 0xFFE6E8EC;
    private static final int DIM = 0xFF9AA0AA;
    private static final int OFF_TRACK = 0xFF3A3F4A;
    private static final int BUTTON = 0xFF2B303B;
    private static final int BUTTON_OFF = 0xFF22252C;
    private static final int SIDEBAR_W = 104;
    private static final int INDENT_PX = 10;

    private final ClientContext ctx;
    private final UiApp app;
    private final int openedByKey;
    private boolean openKeyReleased;

    // Layout in "virtual" pixels (screen pixels divided by the menu scale); recomputed on every frame/input.
    private double scale = 1.0;
    private int px;
    private int py;
    private int pw;
    private int ph;
    private int contentX;
    private int contentY;
    private int contentW;
    private int contentH;

    LuminaScreen(ClientContext ctx) {
        this(ctx, -1);
    }

    /** @param openedByKey the key that opened the menu, so the same key press is not also used to close it */
    LuminaScreen(ClientContext ctx, int openedByKey) {
        super(Component.literal(ctx.info.displayName()));
        this.ctx = ctx;
        this.app = new UiApp(ctx, this);
        this.openedByKey = openedByKey;
        this.openKeyReleased = openedByKey < 0;
    }

    // ---- UiHost ---------------------------------------------------------------------------------

    @Override
    public void openHudEditor() {
        Minecraft.getInstance().setScreen(new HudEditorScreen(ctx));
    }

    @Override
    public void closeScreen() {
        onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ---- layout ---------------------------------------------------------------------------------

    private void computeLayout() {
        scale = Math.max(0.75, Math.min(2.0, ctx.theme.uiScale.getDouble()));
        int vw = (int) (width / scale);
        int vh = (int) (height / scale);
        pw = Math.min(vw - 16, 580);
        ph = Math.min(vh - 16, 350);
        px = (vw - pw) / 2;
        py = (vh - ph) / 2;
        contentX = px + SIDEBAR_W + 10;
        contentY = py + 32;
        contentW = pw - SIDEBAR_W - 20;
        contentH = ph - 40;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private List<Placed> placed() {
        return app.layout(contentX, contentY, contentW - 8, contentH);
    }

    // ---- drawing --------------------------------------------------------------------------------

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        computeLayout();
        g.fill(0, 0, width, height, 0x99000000);
        double mx = mouseX / scale;
        double my = mouseY / scale;
        int accent = ctx.theme.accent.argb();
        var pose = g.pose();
        pose.pushMatrix();
        pose.scale((float) scale, (float) scale);

        int radius = RoundedRect.effectiveRadius(pw, ph, ctx.theme.cornerRadius.getInt());
        for (Rect band : RoundedRect.bands(px, py, pw, ph, radius, ctx.theme.background.argb())) {
            g.fill(band.x(), band.y(), band.right(), band.bottom(), band.argb());
        }
        g.fill(px + radius, py, px + pw - radius, py + 1, accent);
        g.drawString(font, ctx.info.displayName(), px + 10, py + 9, accent, true);
        g.drawString(font, app.page().title(), px + SIDEBAR_W + 10, py + 9, DIM, false);
        boolean closeHover = inside(mx, my, px + pw - 18, py + 6, 12, 12);
        g.drawString(font, "x", px + pw - 15, py + 9, closeHover ? 0xFFE5594F : DIM, false);

        drawSidebar(g, mx, my, accent);
        Row hoveredRow = drawContent(g, mx, my, accent);
        g.drawString(font, ctx.info.version(), px + 10, py + ph - 12, 0xFF5E636D, false);
        pose.popMatrix();

        if (hoveredRow != null && ctx.ui.showTooltips.isOn() && !hoveredRow.tip().isEmpty()) {
            g.setTooltipForNextFrame(font.split(Component.literal(hoveredRow.tip()), 220), mouseX, mouseY);
        }
    }

    private void drawSidebar(GuiGraphics g, double mx, double my, int accent) {
        g.fill(px, py + 26, px + SIDEBAR_W, py + ph, 0x33000000);
        List<UiPage> pages = app.pages();
        for (int i = 0; i < pages.size(); i++) {
            int y = py + 32 + i * 18;
            boolean selected = i == app.state.pageIndex();
            boolean hover = inside(mx, my, px + 6, y, SIDEBAR_W - 12, 16);
            if (selected) {
                g.fill(px + 6, y, px + SIDEBAR_W - 6, y + 16, withAlpha(accent, 0x55));
                g.fill(px + 6, y, px + 8, y + 16, accent);
            } else if (hover) {
                g.fill(px + 6, y, px + SIDEBAR_W - 6, y + 16, 0x22FFFFFF);
            }
            g.drawString(font, pages.get(i).title(), px + 14, y + 4, selected ? 0xFFFFFFFF : TEXT, false);
        }
    }

    /** @return the row under the mouse (for its tooltip), or null */
    private Row drawContent(GuiGraphics g, double mx, double my, int accent) {
        List<Placed> placed = placed();
        Row hovered = null;
        g.enableScissor(contentX, contentY, contentX + contentW, contentY + contentH);
        for (Placed p : placed) {
            if (p.y() + p.h() < contentY || p.y() > contentY + contentH) {
                continue;
            }
            boolean hover = inside(mx, my, contentX, contentY, contentW, contentH) && p.contains(mx, my);
            if (hover && !(p.row() instanceof Row.Label) && !(p.row() instanceof Row.Spacer)
                    && !(p.row() instanceof Row.Heading)) {
                hovered = p.row();
            }
            drawRow(g, p, hover, accent);
        }
        g.disableScissor();
        drawScrollbar(g, accent);
        return hovered;
    }

    private void drawScrollbar(GuiGraphics g, int accent) {
        int total = app.contentHeight();
        if (total <= contentH) {
            return;
        }
        int trackX = contentX + contentW - 4;
        int thumbH = Math.max(14, contentH * contentH / total);
        int range = Math.max(1, total - contentH);
        int thumbY = contentY + (contentH - thumbH) * app.state.scroll() / range;
        g.fill(trackX, contentY, trackX + 3, contentY + contentH, 0x22FFFFFF);
        g.fill(trackX, thumbY, trackX + 3, thumbY + thumbH, withAlpha(accent, 0xCC));
    }

    private void drawRow(GuiGraphics g, Placed p, boolean hover, int accent) {
        Row row = p.row();
        int x = p.x();
        int y = p.y();
        int w = p.w();
        int h = p.h();
        int textY = y + (h - font.lineHeight) / 2;
        switch (row) {
            case Row.Heading hd -> {
                g.drawString(font, hd.text(), x + 2, y + 6, accent, true);
                g.fill(x, y + h - 2, x + w, y + h - 1, 0x33FFFFFF);
            }
            case Row.Label l -> g.drawString(font, new McText(font).fit(l.text(), w - 4), x + 2, y + 2,
                    l.argb() == 0 ? TEXT : l.argb(), false);
            case Row.Spacer s -> {
            }
            case Row.Button b -> {
                int fill = !b.enabled() ? BUTTON_OFF : hover ? withAlpha(accent, 0x99) : BUTTON;
                g.fill(x, y, x + w, y + h, fill);
                int labelColor = b.enabled() ? 0xFFFFFFFF : 0xFF666B75;
                g.drawString(font, b.label(), x + 6, textY, labelColor, false);
                if (!b.hint().isEmpty()) {
                    g.drawString(font, b.hint(), x + w - 6 - font.width(b.hint()), textY, DIM, false);
                }
            }
            case Row.Toggle t -> {
                rowBackground(g, x, y, w, h, hover);
                g.drawString(font, t.label(), x + 4 + t.indent() * INDENT_PX, textY, TEXT, false);
                int tx = x + w - 30;
                g.fill(tx, y + 4, tx + 22, y + 14, t.on() ? accent : OFF_TRACK);
                g.fill(t.on() ? tx + 13 : tx + 1, y + 5, t.on() ? tx + 21 : tx + 9, y + 13, 0xFFFFFFFF);
                if (t.secondary() != null) {
                    g.drawString(font, ">", tx - 10, textY, DIM, false);
                }
            }
            case Row.Slider s -> {
                rowBackground(g, x, y, w, h, hover);
                g.drawString(font, s.label(), x + 4 + s.indent() * INDENT_PX, textY, TEXT, false);
                int trackX = p.trackX();
                int trackW = p.trackWidth();
                int fillW = (int) Math.round(Math.max(0.0, Math.min(1.0, s.fraction())) * trackW);
                g.fill(trackX, y + 7, trackX + trackW, y + 11, OFF_TRACK);
                g.fill(trackX, y + 7, trackX + fillW, y + 11, accent);
                g.fill(trackX + fillW - 2, y + 4, trackX + fillW + 2, y + 14, 0xFFFFFFFF);
                g.drawString(font, s.valueText(), trackX - 6 - font.width(s.valueText()), textY, DIM, false);
            }
            case Row.Choice c -> {
                rowBackground(g, x, y, w, h, hover);
                g.drawString(font, c.label(), x + 4 + c.indent() * INDENT_PX, textY, TEXT, false);
                String value = "< " + c.value() + " >";
                g.drawString(font, value, x + w - 6 - font.width(value), textY, hover ? 0xFFFFFFFF : DIM, false);
            }
            case Row.ColorChoice c -> {
                rowBackground(g, x, y, w, h, hover);
                g.drawString(font, c.label(), x + 4 + c.indent() * INDENT_PX, textY, TEXT, false);
                g.fill(x + w - 26, y + 3, x + w - 6, y + 15, 0xFFFFFFFF);
                g.fill(x + w - 25, y + 4, x + w - 7, y + 14, c.argb() | 0xFF000000);
            }
            case Row.Input in -> {
                rowBackground(g, x, y, w, h, hover);
                g.drawString(font, in.label(), x + 4, textY, TEXT, false);
                int bx = p.trackX() - 40;
                int bw = x + w - 6 - bx;
                boolean focused = in.id().equals(app.state.focusedInput());
                g.fill(bx, y + 1, bx + bw, y + h - 1, focused ? accent : 0xFF4A505C);
                g.fill(bx + 1, y + 2, bx + bw - 1, y + h - 2, 0xFF14161B);
                String value = app.state.input(in.id());
                if (value.isEmpty() && !focused) {
                    g.drawString(font, new McText(font).fit(in.placeholder(), bw - 8), bx + 4, textY, 0xFF5E636D, false);
                } else {
                    String shown = value + (focused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                    g.drawString(font, tail(shown, bw - 8), bx + 4, textY, 0xFFFFFFFF, false);
                }
            }
        }
    }

    private void rowBackground(GuiGraphics g, int x, int y, int w, int h, boolean hover) {
        if (hover) {
            g.fill(x, y, x + w, y + h, 0x22FFFFFF);
        }
    }

    /** Keeps the end of a long text (where the caret is) visible. */
    private String tail(String text, int maxWidth) {
        String t = text;
        while (t.length() > 1 && font.width(t) > maxWidth) {
            t = t.substring(1);
        }
        return t;
    }

    private static int withAlpha(int argb, int alpha) {
        return (alpha << 24) | (argb & 0x00FFFFFF);
    }

    // ---- input ----------------------------------------------------------------------------------

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        computeLayout();
        double mx = event.x() / scale;
        double my = event.y() / scale;
        if (inside(mx, my, px + pw - 18, py + 6, 12, 12)) {
            onClose();
            return true;
        }
        List<UiPage> pages = app.pages();
        for (int i = 0; i < pages.size(); i++) {
            if (inside(mx, my, px + 6, py + 32 + i * 18, SIDEBAR_W - 12, 16)) {
                app.state.setPage(i);
                return true;
            }
        }
        if (inside(mx, my, contentX, contentY, contentW, contentH)) {
            return app.controller.click(placed(), mx, my, event.button());
        }
        app.state.focus(null);
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        computeLayout();
        return app.controller.drag(event.x() / scale);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        app.controller.release();
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        computeLayout();
        app.controller.scroll(vertical, app.contentHeight(), contentH);
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == openedByKey && !openKeyReleased) {
            return true; // the press that opened the menu must not close it again
        }
        if (app.controller.key(key)) {
            return true;
        }
        if (key == 256 /* Esc */ || (key == ctx.ui.clickGuiKey.getInt() && !app.controller.isTyping())) {
            onClose();
            return true;
        }
        return false;
    }

    @Override
    public boolean keyReleased(KeyEvent event) {
        if (event.key() == openedByKey) {
            openKeyReleased = true;
        }
        return false;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        return app.controller.character(event.codepoint());
    }
}
