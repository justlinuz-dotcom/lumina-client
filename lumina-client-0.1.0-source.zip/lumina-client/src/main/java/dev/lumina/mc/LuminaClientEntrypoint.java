package dev.lumina.mc;

import com.mojang.blaze3d.platform.InputConstants;
import dev.lumina.ClientContext;
import dev.lumina.social.NotificationCenter;
import dev.lumina.utils.Log;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;

import java.time.ZoneId;
import java.util.HashSet;
import java.util.Set;

/**
 * Client entrypoint: builds the core, then registers the few hooks it needs (HUD layer, client tick, world
 * join/leave, shutdown). If anything fails here the client stays inactive and the game starts normally.
 *
 * <p>Compiled in the authoring environment only against hand-written stubs of the Minecraft/Fabric API,
 * not against the real jars; see {@code docs/VERIFICATION.md}.
 */
public final class LuminaClientEntrypoint implements ClientModInitializer {
    private static final Logger LOG = Log.of("entrypoint");

    @Override
    public void onInitializeClient() {
        try {
            start();
        } catch (RuntimeException | LinkageError e) {
            LOG.error("The client failed to start and stays inactive; the game itself is not affected", e);
        }
    }

    /**
     * Ordinary key bindings so the menu can always be opened and rebound from the game's Controls screen,
     * even if the raw key hook of the mixin is not active. They do not replace the keys configured in the
     * client's own settings, which keep working through the mixin.
     */
    private static void registerKeyMappings(ClientContext ctx) {
        String id = ctx.info.modId();
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(id, "main"));
        KeyMapping menu = KeyBindingHelper.registerKeyBinding(new KeyMapping("key." + id + ".open_menu",
                InputConstants.Type.KEYSYM, ctx.ui.clickGuiKey.getInt(), category));
        KeyMapping editor = KeyBindingHelper.registerKeyBinding(new KeyMapping("key." + id + ".hud_editor",
                InputConstants.Type.KEYSYM, ctx.ui.hudEditorKey.getInt(), category));
        LuminaRuntime.setKeyMappings(menu, editor);
    }

    private void start() {
        FabricLoader loader = FabricLoader.getInstance();
        Set<String> mods = new HashSet<>();
        for (ModContainer container : loader.getAllMods()) {
            mods.add(container.getMetadata().getId());
        }
        String minecraft = loader.getModContainer("minecraft")
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("unknown");

        ClientContext.Environment env = new ClientContext.Environment(
                loader.getGameDir(), new McGameState(), new McGameOptions(), new McInputControl(),
                System::currentTimeMillis, Set.copyOf(mods), minecraft, Runtime.version().feature(),
                System.getProperty("user.home", ""), System.getProperty("user.name", ""), ZoneId.systemDefault());

        ClientContext ctx = ClientContext.start(env);
        LuminaRuntime.init(ctx);
        if (!ctx.isUsable()) {
            LOG.warn("The client context is not usable; HUD and menus are disabled");
            return;
        }

        HudRenderer hud = new HudRenderer(ctx);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(ctx.info.modId(), "hud"), hud::render);
        // Hide the vanilla crosshair only while the custom one is enabled and asks for it.
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (graphics, tracker) -> {
            ClientContext c = LuminaRuntime.ctx();
            if (c != null && c.isUsable() && c.crosshair.replacesVanilla()) {
                return;
            }
            original.render(graphics, tracker);
        });

        registerKeyMappings(ctx);
        ClientTickEvents.END_CLIENT_TICK.register(LuminaRuntime::onTick);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> LuminaRuntime.onJoin(client));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> LuminaRuntime.onLeave());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> LuminaRuntime.onStopping());

        long now = env.clock().getAsLong();
        for (String warning : ctx.startupWarnings()) {
            ctx.notifications.post(NotificationCenter.Level.WARNING, ctx.info.displayName(), warning, now);
        }
        LOG.info("{} {} started ({} modules)", ctx.info.displayName(), ctx.info.version(), ctx.allModules().size());
    }
}
