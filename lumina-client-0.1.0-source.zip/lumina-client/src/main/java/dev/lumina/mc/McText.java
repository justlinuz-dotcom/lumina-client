package dev.lumina.mc;

import dev.lumina.hud.TextMeasurer;
import net.minecraft.client.gui.Font;

/** Font metrics of the running game for the HUD layout. */
final class McText implements TextMeasurer {
    private final Font font;

    McText(Font font) {
        this.font = font;
    }

    @Override
    public int width(String text) {
        return font.width(text);
    }

    @Override
    public int lineHeight() {
        return font.lineHeight;
    }

    /** Cuts the text so it fits in {@code maxWidth} pixels, adding "..." when something was removed. */
    String fit(String text, int maxWidth) {
        if (font.width(text) <= maxWidth) {
            return text;
        }
        int end = text.length();
        while (end > 0 && font.width(text.substring(0, end) + "...") > maxWidth) {
            end--;
        }
        return text.substring(0, end) + "...";
    }
}
