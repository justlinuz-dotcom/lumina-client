package dev.lumina.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Central logging access so every subsystem logs under one organised hierarchy. */
public final class Log {
    private static final String ROOT = "Lumina";

    private Log() {
    }

    /** Returns a logger named {@code Lumina/<area>} (for example {@code Lumina/config}). */
    public static Logger of(String area) {
        return LoggerFactory.getLogger(ROOT + "/" + area);
    }
}
