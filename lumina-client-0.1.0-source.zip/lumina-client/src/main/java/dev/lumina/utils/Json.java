package dev.lumina.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Hardened JSON helpers. Imported or on-disk JSON is untrusted: size and nesting depth are bounded
 * before parsing, and the root must be an object. JSON is only ever read as data, never executed.
 */
public final class Json {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    public static final int MAX_DEPTH = 48;
    public static final long MAX_CONFIG_BYTES = 4L * 1024 * 1024;
    public static final long MAX_IMPORT_BYTES = 1024L * 1024;

    private Json() {
    }

    /** Parses text whose root must be an object, rejecting excessive nesting. */
    public static JsonObject parseObject(String text, int maxDepth) {
        if (text == null || text.isBlank()) {
            throw new JsonParseException("Empty JSON document");
        }
        checkDepth(text, maxDepth);
        JsonElement element = JsonParser.parseString(text);
        if (!element.isJsonObject()) {
            throw new JsonParseException("JSON root must be an object");
        }
        return element.getAsJsonObject();
    }

    /** Throws if bracket nesting (outside string literals) exceeds {@code maxDepth}. */
    public static void checkDepth(String text, int maxDepth) {
        int depth = 0;
        boolean inString = false;
        boolean escaped = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                if (escaped) {
                    escaped = false;
                } else if (c == '\\') {
                    escaped = true;
                } else if (c == '"') {
                    inString = false;
                }
                continue;
            }
            if (c == '"') {
                inString = true;
            } else if (c == '{' || c == '[') {
                if (++depth > maxDepth) {
                    throw new JsonParseException("JSON nesting deeper than " + maxDepth);
                }
            } else if (c == '}' || c == ']') {
                depth--;
            }
        }
    }

    /** Reads a UTF-8 file, refusing anything larger than {@code maxBytes}. */
    public static String readLimited(Path path, long maxBytes) throws IOException {
        long size = Files.size(path);
        if (size > maxBytes) {
            throw new IOException("File too large: " + size + " bytes (limit " + maxBytes + ")");
        }
        return new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
    }

    public static String string(JsonObject obj, String key, String fallback) {
        JsonElement e = obj.get(key);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isString() ? e.getAsString() : fallback;
    }

    public static int integer(JsonObject obj, String key, int fallback) {
        JsonElement e = obj.get(key);
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) {
            return e.getAsInt();
        }
        return fallback;
    }

    public static boolean bool(JsonObject obj, String key, boolean fallback) {
        JsonElement e = obj.get(key);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean() ? e.getAsBoolean() : fallback;
    }

    public static JsonObject object(JsonObject obj, String key) {
        JsonElement e = obj.get(key);
        return e != null && e.isJsonObject() ? e.getAsJsonObject() : new JsonObject();
    }
}
