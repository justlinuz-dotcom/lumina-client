package dev.lumina.utils;

import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Validation for user-provided names (profiles, layouts). A name is turned into a file id, so the
 * rules also protect against path traversal and reserved Windows device names.
 */
public final class NameRules {
    public static final int MAX_LENGTH = 32;
    private static final Pattern ALLOWED = Pattern.compile("[A-Za-z0-9][A-Za-z0-9 _.\\-]*");
    private static final Set<String> RESERVED = Set.of(
            "con", "prn", "aux", "nul", "com1", "com2", "com3", "com4", "com5", "com6", "com7", "com8", "com9",
            "lpt1", "lpt2", "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9");

    private NameRules() {
    }

    /** Returns null when the name is valid, otherwise a human-readable reason. */
    public static String validate(String name) {
        if (name == null) {
            return "Name is required";
        }
        String trimmed = name.trim();
        if (trimmed.isEmpty()) {
            return "Name is empty";
        }
        if (!trimmed.equals(name)) {
            return "Name must not start or end with spaces";
        }
        if (trimmed.length() > MAX_LENGTH) {
            return "Name is longer than " + MAX_LENGTH + " characters";
        }
        if (!ALLOWED.matcher(trimmed).matches()) {
            return "Use letters, digits, space, '_', '-' or '.' (must start with a letter or digit)";
        }
        if (trimmed.contains("..") || trimmed.endsWith(".")) {
            return "Name must not contain '..' or end with '.'";
        }
        String base = trimmed.toLowerCase(Locale.ROOT);
        int dot = base.indexOf('.');
        if (RESERVED.contains(dot < 0 ? base : base.substring(0, dot))) {
            return "Reserved name";
        }
        return null;
    }

    /** File-system id for a valid name: lower case, spaces replaced by '_'. */
    public static String toId(String name) {
        return name.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
    }
}
