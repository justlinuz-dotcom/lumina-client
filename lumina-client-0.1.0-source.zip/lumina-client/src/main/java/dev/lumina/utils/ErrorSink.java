package dev.lumina.utils;

/**
 * Receives recoverable errors from any subsystem. The core never lets an exception from a module
 * or listener escape into the game loop: it is reported here instead.
 */
@FunctionalInterface
public interface ErrorSink {
    ErrorSink NOOP = (source, error) -> {
    };

    void report(String source, Throwable error);
}
