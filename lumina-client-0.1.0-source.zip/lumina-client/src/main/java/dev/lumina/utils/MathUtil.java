package dev.lumina.utils;

/** Small numeric helpers shared by HUD, performance and setting code. */
public final class MathUtil {
    private MathUtil() {
    }

    public static double clamp(double v, double min, double max) {
        return v < min ? min : Math.min(v, max);
    }

    public static int clamp(int v, int min, int max) {
        return v < min ? min : Math.min(v, max);
    }

    public static float clamp(float v, float min, float max) {
        return v < min ? min : Math.min(v, max);
    }

    /** Rounds {@code value} to the nearest multiple of {@code step}; a non-positive step returns the value. */
    public static double snap(double value, double step) {
        if (step <= 0) {
            return value;
        }
        return Math.round(value / step) * step;
    }

    public static boolean isFinite(double v) {
        return !Double.isNaN(v) && !Double.isInfinite(v);
    }

    /** Wraps degrees into [0, 360). */
    public static float wrapDegrees360(float degrees) {
        float r = degrees % 360f;
        return r < 0 ? r + 360f : r;
    }

    /** Formats a duration in milliseconds as {@code HH:MM:SS} (hours may exceed 24). */
    public static String formatDuration(long millis) {
        long totalSeconds = Math.max(0, millis) / 1000;
        long h = totalSeconds / 3600;
        long m = (totalSeconds % 3600) / 60;
        long s = totalSeconds % 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }
}
