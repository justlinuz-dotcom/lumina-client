package dev.lumina.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Collects non-fatal problems found while loading configuration, presets or profiles. */
public final class LoadReport {
    private final List<String> warnings = new ArrayList<>();

    public void add(String warning) {
        warnings.add(warning);
    }

    public void addAll(LoadReport other) {
        warnings.addAll(other.warnings);
    }

    public List<String> warnings() {
        return Collections.unmodifiableList(warnings);
    }

    public boolean isClean() {
        return warnings.isEmpty();
    }

    @Override
    public String toString() {
        return isClean() ? "clean" : warnings.size() + " warning(s): " + warnings;
    }
}
