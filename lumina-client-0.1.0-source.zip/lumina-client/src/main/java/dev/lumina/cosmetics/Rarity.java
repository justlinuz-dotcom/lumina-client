package dev.lumina.cosmetics;

/** Label used to group and colour cosmetics in the menu. It has no effect on gameplay. */
public enum Rarity {
    COMMON("Common", 0xFFB0B7C3),
    UNCOMMON("Uncommon", 0xFF55D68A),
    RARE("Rare", 0xFF5B8CFF),
    EPIC("Epic", 0xFFB06BFF),
    LEGENDARY("Legendary", 0xFFFFB347);

    private final String label;
    private final int argb;

    Rarity(String label, int argb) {
        this.label = label;
        this.argb = argb;
    }

    public String label() {
        return label;
    }

    public int argb() {
        return argb;
    }
}
