package dev.lumina.cosmetics;

/**
 * One cosmetic the player can wear. Built-in items are described by two colours (no art files are
 * bundled); imported items point at a validated PNG copy inside the client's own folder.
 */
public record CosmeticItem(String id, String name, Slot slot, Rarity rarity, Origin origin,
                           int primaryArgb, int secondaryArgb, String file) {

    public enum Origin { BUILT_IN, IMPORTED }

    public boolean isImported() {
        return origin == Origin.IMPORTED;
    }
}
