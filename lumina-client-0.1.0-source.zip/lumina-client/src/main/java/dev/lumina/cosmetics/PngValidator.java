package dev.lumina.cosmetics;

import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/**
 * Structural validation of an untrusted PNG file <em>without decoding it into an image</em>: the signature,
 * every chunk length and CRC, the header values, the absence of animation, and that the compressed pixel
 * data inflates to exactly the size the header promises (with a hard output limit, so a decompression bomb
 * is rejected instead of expanded). Nothing from the file is executed or interpreted beyond these checks;
 * the game decodes the pixels later only when the file passed.
 */
public final class PngValidator {
    public static final int MAX_FILE_BYTES = 512 * 1024;
    public static final int MAX_DIMENSION = 1024;
    private static final int MAX_CHUNKS = 1000;
    private static final byte[] SIGNATURE = {(byte) 0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'};

    public record Result(boolean valid, String problem, int width, int height) {
        static Result ok(int w, int h) {
            return new Result(true, "", w, h);
        }

        static Result bad(String problem) {
            return new Result(false, problem, 0, 0);
        }
    }

    private PngValidator() {
    }

    public static Result validate(byte[] data) {
        if (data == null || data.length < 8 + 25 + 12) {
            return Result.bad("The file is too small to be a PNG image");
        }
        if (data.length > MAX_FILE_BYTES) {
            return Result.bad("The file is larger than " + MAX_FILE_BYTES / 1024 + " KB");
        }
        for (int i = 0; i < SIGNATURE.length; i++) {
            if (data[i] != SIGNATURE[i]) {
                return Result.bad("This is not a PNG file (wrong signature)");
            }
        }
        int pos = 8;
        int width = 0;
        int height = 0;
        int bitDepth = 0;
        int colorType = 0;
        int channels = 0;
        boolean sawHeader = false;
        boolean sawEnd = false;
        int chunks = 0;
        java.io.ByteArrayOutputStream idat = new java.io.ByteArrayOutputStream();

        while (pos < data.length) {
            if (++chunks > MAX_CHUNKS) {
                return Result.bad("The file has too many chunks");
            }
            if (pos + 12 > data.length) {
                return Result.bad("The file is truncated");
            }
            long length = readInt(data, pos) & 0xFFFFFFFFL;
            if (length > data.length - pos - 12L) {
                return Result.bad("A chunk is longer than the file");
            }
            String type = new String(data, pos + 4, 4, java.nio.charset.StandardCharsets.ISO_8859_1);
            if (!type.chars().allMatch(c -> (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))) {
                return Result.bad("A chunk has an invalid name");
            }
            int dataStart = pos + 8;
            int len = (int) length;
            CRC32 crc = new CRC32();
            crc.update(data, pos + 4, 4 + len);
            if ((crc.getValue() & 0xFFFFFFFFL) != (readInt(data, dataStart + len) & 0xFFFFFFFFL)) {
                return Result.bad("The file is corrupt (checksum mismatch in " + type + ")");
            }
            if (!sawHeader) {
                if (!type.equals("IHDR") || len != 13) {
                    return Result.bad("The image header is missing or malformed");
                }
                width = readInt(data, dataStart);
                height = readInt(data, dataStart + 4);
                bitDepth = data[dataStart + 8] & 0xFF;
                colorType = data[dataStart + 9] & 0xFF;
                int compression = data[dataStart + 10] & 0xFF;
                int filter = data[dataStart + 11] & 0xFF;
                int interlace = data[dataStart + 12] & 0xFF;
                if (width < 1 || height < 1 || width > MAX_DIMENSION || height > MAX_DIMENSION) {
                    return Result.bad("The image must be between 1 and " + MAX_DIMENSION + " pixels on each side");
                }
                if (compression != 0 || filter != 0) {
                    return Result.bad("Unsupported PNG compression or filter method");
                }
                if (interlace != 0) {
                    return Result.bad("Interlaced PNG files are not supported; save without interlacing");
                }
                if (bitDepth != 8) {
                    return Result.bad("Only 8-bit PNG files are supported");
                }
                channels = switch (colorType) {
                    case 2 -> 3;
                    case 3 -> 1;
                    case 6 -> 4;
                    default -> 0;
                };
                if (channels == 0) {
                    return Result.bad("Only RGB, RGBA and palette PNG files are supported");
                }
                sawHeader = true;
            } else {
                switch (type) {
                    case "IHDR" -> {
                        return Result.bad("The file has more than one header");
                    }
                    case "acTL", "fcTL", "fdAT" -> {
                        return Result.bad("Animated PNG files are not supported");
                    }
                    case "IDAT" -> idat.write(data, dataStart, len);
                    case "IEND" -> {
                        if (len != 0) {
                            return Result.bad("The end marker is malformed");
                        }
                        sawEnd = true;
                    }
                    default -> {
                        boolean critical = Character.isUpperCase(type.charAt(0));
                        if (critical && !type.equals("PLTE")) {
                            return Result.bad("Unsupported critical chunk " + type);
                        }
                    }
                }
            }
            pos = dataStart + len + 4;
            if (sawEnd) {
                break;
            }
        }
        if (!sawHeader) {
            return Result.bad("The image header is missing");
        }
        if (!sawEnd) {
            return Result.bad("The file is truncated (no end marker)");
        }
        if (pos != data.length) {
            return Result.bad("There is extra data after the end of the image");
        }
        long expected = (long) height * (1L + (long) width * channels);
        String pixelProblem = checkPixelData(idat.toByteArray(), expected);
        return pixelProblem == null ? Result.ok(width, height) : Result.bad(pixelProblem);
    }

    private static String checkPixelData(byte[] compressed, long expected) {
        if (compressed.length == 0) {
            return "The image has no pixel data";
        }
        Inflater inflater = new Inflater();
        try {
            inflater.setInput(compressed);
            byte[] buffer = new byte[8192];
            long total = 0;
            while (!inflater.finished()) {
                int n = inflater.inflate(buffer);
                if (n == 0 && (inflater.needsInput() || inflater.needsDictionary())) {
                    return "The pixel data is truncated or corrupt";
                }
                total += n;
                if (total > expected) {
                    return "The pixel data is larger than the image header says";
                }
            }
            return total == expected ? null : "The pixel data is smaller than the image header says";
        } catch (DataFormatException e) {
            return "The pixel data is corrupt";
        } finally {
            inflater.end();
        }
    }

    private static int readInt(byte[] b, int off) {
        return ((b[off] & 0xFF) << 24) | ((b[off + 1] & 0xFF) << 16) | ((b[off + 2] & 0xFF) << 8) | (b[off + 3] & 0xFF);
    }
}
