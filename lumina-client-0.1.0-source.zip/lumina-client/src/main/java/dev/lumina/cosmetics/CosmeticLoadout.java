package dev.lumina.cosmetics;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.profile.ProfileParticipant;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.NameRules;

import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * What the player wears and the named loadouts they saved. Part of every profile.
 *
 * <p>Cosmetics are <strong>local</strong>: they are drawn by this client for the player who installed it.
 * Other players do not see them, and this client does not contain any service that would show them to
 * others. Cosmetics are only appearance; they never change reach, speed, damage, hitboxes or any other
 * gameplay value.
 */
public final class CosmeticLoadout implements ProfileParticipant {
    public static final String KEY = "cosmetics";
    public static final int MAX_PRESETS = 20;
    public static final String NOTICE = "Cosmetics are only visible to you. Other players will not see them, "
            + "and they never change gameplay.";

    private final CosmeticCatalog catalog;
    private final Map<Slot, String> worn = new EnumMap<>(Slot.class);
    private final Map<String, Map<Slot, String>> presets = new LinkedHashMap<>();
    private boolean visible = true;
    private Runnable changeListener = () -> {
    };

    public CosmeticLoadout(CosmeticCatalog catalog) {
        this.catalog = catalog;
    }

    public void setChangeListener(Runnable listener) {
        this.changeListener = listener == null ? () -> {
        } : listener;
    }

    public synchronized boolean visible() {
        return visible;
    }

    public synchronized void setVisible(boolean value) {
        if (visible != value) {
            visible = value;
            changeListener.run();
        }
    }

    /** @return null when equipped, otherwise the reason */
    public synchronized String equip(Slot slot, String itemId) {
        Optional<CosmeticItem> item = catalog.get(itemId);
        if (item.isEmpty()) {
            return "That cosmetic does not exist";
        }
        if (item.get().slot() != slot) {
            return item.get().name() + " is worn on the " + item.get().slot().label().toLowerCase() + ", not the " + slot.label().toLowerCase();
        }
        worn.put(slot, itemId);
        changeListener.run();
        return null;
    }

    public synchronized void unequip(Slot slot) {
        if (worn.remove(slot) != null) {
            changeListener.run();
        }
    }

    /** The item worn in a slot, or empty (also when it was removed from the catalog since). */
    public synchronized Optional<CosmeticItem> worn(Slot slot) {
        return catalog.get(worn.get(slot));
    }

    /** Items to draw now: empty while cosmetics are switched off. */
    public synchronized Map<Slot, CosmeticItem> toRender() {
        Map<Slot, CosmeticItem> out = new EnumMap<>(Slot.class);
        if (!visible) {
            return out;
        }
        for (Map.Entry<Slot, String> e : worn.entrySet()) {
            catalog.get(e.getValue()).ifPresent(i -> out.put(e.getKey(), i));
        }
        return out;
    }

    // ---- named loadouts ------------------------------------------------------------------------

    /** @return null when saved, otherwise the reason */
    public synchronized String savePreset(String name) {
        String problem = NameRules.validate(name);
        if (problem != null) {
            return problem;
        }
        if (!presets.containsKey(name) && presets.size() >= MAX_PRESETS) {
            return "You can keep at most " + MAX_PRESETS + " saved loadouts";
        }
        presets.put(name, new EnumMap<>(worn));
        changeListener.run();
        return null;
    }

    /** @return null when applied; items that no longer exist are skipped and named in the message of a non-null result */
    public synchronized String applyPreset(String name) {
        Map<Slot, String> preset = presets.get(name);
        if (preset == null) {
            return "No saved loadout called " + name;
        }
        worn.clear();
        int missing = 0;
        for (Map.Entry<Slot, String> e : preset.entrySet()) {
            Optional<CosmeticItem> item = catalog.get(e.getValue());
            if (item.isPresent() && item.get().slot() == e.getKey()) {
                worn.put(e.getKey(), e.getValue());
            } else {
                missing++;
            }
        }
        changeListener.run();
        return missing == 0 ? null : missing + " item(s) of this loadout are no longer available and were skipped";
    }

    public synchronized boolean deletePreset(String name) {
        boolean removed = presets.remove(name) != null;
        if (removed) {
            changeListener.run();
        }
        return removed;
    }

    public synchronized Map<String, Map<Slot, String>> presets() {
        Map<String, Map<Slot, String>> copy = new LinkedHashMap<>();
        presets.forEach((k, v) -> copy.put(k, Collections.unmodifiableMap(new EnumMap<>(v))));
        return Collections.unmodifiableMap(copy);
    }

    // ---- profile section -----------------------------------------------------------------------

    @Override
    public String sectionKey() {
        return KEY;
    }

    @Override
    public synchronized JsonObject save() {
        JsonObject o = new JsonObject();
        o.addProperty("visible", visible);
        o.add("worn", slotMap(worn));
        JsonObject all = new JsonObject();
        presets.forEach((name, map) -> all.add(name, slotMap(map)));
        o.add("presets", all);
        return o;
    }

    @Override
    public synchronized LoadReport load(JsonObject section) {
        LoadReport report = new LoadReport();
        worn.clear();
        presets.clear();
        visible = Json.bool(section, "visible", true);
        readSlots(Json.object(section, "worn"), worn, report, "worn");
        for (Map.Entry<String, JsonElement> e : Json.object(section, "presets").entrySet()) {
            if (NameRules.validate(e.getKey()) != null || presets.size() >= MAX_PRESETS || !e.getValue().isJsonObject()) {
                report.add("cosmetics: skipped saved loadout '" + abbreviate(e.getKey()) + "'");
                continue;
            }
            Map<Slot, String> map = new EnumMap<>(Slot.class);
            readSlots(e.getValue().getAsJsonObject(), map, report, "loadout " + e.getKey());
            presets.put(e.getKey(), map);
        }
        return report;
    }

    private void readSlots(JsonObject json, Map<Slot, String> into, LoadReport report, String where) {
        for (Map.Entry<String, JsonElement> e : json.entrySet()) {
            Slot slot = null;
            for (Slot s : Slot.values()) {
                if (s.name().equals(e.getKey())) {
                    slot = s;
                }
            }
            String id = e.getValue().isJsonPrimitive() && e.getValue().getAsJsonPrimitive().isString() ? e.getValue().getAsString() : null;
            Optional<CosmeticItem> item = catalog.get(id);
            if (slot == null || item.isEmpty() || item.get().slot() != slot) {
                report.add("cosmetics (" + where + "): skipped '" + abbreviate(e.getKey()) + "' because the item is unknown or does not fit");
                continue;
            }
            into.put(slot, id);
        }
    }

    private static JsonObject slotMap(Map<Slot, String> map) {
        JsonObject o = new JsonObject();
        map.forEach((slot, id) -> o.addProperty(slot.name(), id));
        return o;
    }

    private static String abbreviate(String s) {
        String t = s.replaceAll("\\p{Cntrl}", "?");
        return t.length() > 24 ? t.substring(0, 24) + "..." : t;
    }
}
