package dev.lumina.cosmetics;

import dev.lumina.config.ClientPaths;
import dev.lumina.utils.NameRules;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Imports a PNG from the client's {@code imports/} folder as a local cosmetic.
 *
 * <ul>
 *   <li>Only a plain file name is accepted; paths, {@code ..}, symbolic links and other folders are refused.</li>
 *   <li>The file is read with a hard size limit and validated by {@link PngValidator} before anything is stored.</li>
 *   <li>The validated bytes are copied into the client's own {@code cosmetics/} folder under a name derived
 *       from the display name, never the original file name.</li>
 *   <li>Nothing is downloaded, executed or sent anywhere.</li>
 * </ul>
 */
public final class CosmeticImporter {
    private static final Pattern FILE_NAME = Pattern.compile("[A-Za-z0-9][A-Za-z0-9 _.\\-]{0,62}\\.[Pp][Nn][Gg]");

    public record ImportResult(boolean ok, String message, CosmeticItem item) {
        static ImportResult fail(String message) {
            return new ImportResult(false, message, null);
        }
    }

    private final ClientPaths paths;
    private final CosmeticCatalog catalog;

    public CosmeticImporter(ClientPaths paths, CosmeticCatalog catalog) {
        this.paths = paths;
        this.catalog = catalog;
    }

    public ImportResult importPng(String fileName, String displayName, Slot slot, Rarity rarity) {
        if (fileName == null || !FILE_NAME.matcher(fileName).matches() || fileName.contains("..")) {
            return ImportResult.fail("Use the plain name of a .png file placed in the imports folder (no folders or paths)");
        }
        String nameProblem = NameRules.validate(displayName);
        if (nameProblem != null) {
            return ImportResult.fail(nameProblem);
        }
        if (slot == null) {
            return ImportResult.fail("Choose where the cosmetic is worn");
        }
        String id = NameRules.toId(displayName);
        if (catalog.get(id).isPresent()) {
            return ImportResult.fail("There is already a cosmetic with that name");
        }
        Path source = paths.imports().resolve(fileName);
        if (!source.getParent().equals(paths.imports())) {
            return ImportResult.fail("The file must be directly inside the imports folder");
        }
        byte[] bytes;
        try {
            BasicFileAttributes attrs = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
            if (!attrs.isRegularFile()) {
                return ImportResult.fail("Only regular files are accepted (links and folders are refused)");
            }
            if (attrs.size() > PngValidator.MAX_FILE_BYTES) {
                return ImportResult.fail("The file is larger than " + PngValidator.MAX_FILE_BYTES / 1024 + " KB");
            }
            bytes = readLimited(source);
        } catch (java.nio.file.NoSuchFileException e) {
            return ImportResult.fail("File not found in the imports folder: " + fileName);
        } catch (IOException e) {
            return ImportResult.fail("The file could not be read");
        }
        PngValidator.Result check = PngValidator.validate(bytes);
        if (!check.valid()) {
            return ImportResult.fail(check.problem());
        }
        if (!slot.acceptsSize(check.width(), check.height())) {
            return ImportResult.fail(slot.label() + " textures must be one of: " + slot.sizeHint()
                    + " (this image is " + check.width() + "x" + check.height() + ")");
        }
        String stored = id + ".png";
        CosmeticItem item = new CosmeticItem(id, displayName, slot, rarity == null ? Rarity.COMMON : rarity,
                CosmeticItem.Origin.IMPORTED, 0xFFFFFFFF, 0xFFFFFFFF, stored);
        String refused = catalog.addImported(item);
        if (refused != null) {
            return ImportResult.fail(refused);
        }
        try {
            store(bytes, paths.cosmetics().resolve(stored));
        } catch (IOException e) {
            catalog.removeImported(id);
            return ImportResult.fail("The cosmetic could not be saved: " + e.getClass().getSimpleName());
        }
        return new ImportResult(true, "Imported " + displayName + " (" + check.width() + "x" + check.height() + ")", item);
    }

    /** Removes an imported cosmetic and its stored copy. The original file in imports/ is left alone. */
    public boolean remove(String id) {
        return catalog.removeImported(id).map(item -> {
            try {
                Files.deleteIfExists(paths.cosmetics().resolve(item.file()));
            } catch (IOException ignored) {
                // the entry is gone from the catalog; a leftover file is harmless and is overwritten on re-import
            }
            return true;
        }).orElse(false);
    }

    /** Path of an imported item's stored texture, or null for built-in items. */
    public Path textureFile(CosmeticItem item) {
        return item.isImported() ? paths.cosmetics().resolve(item.file()) : null;
    }

    private static byte[] readLimited(Path file) throws IOException {
        try (InputStream in = Files.newInputStream(file, LinkOption.NOFOLLOW_LINKS)) {
            byte[] data = in.readNBytes(PngValidator.MAX_FILE_BYTES + 1);
            if (data.length > PngValidator.MAX_FILE_BYTES) {
                throw new IOException("too large");
            }
            return data;
        }
    }

    private static void store(byte[] bytes, Path target) throws IOException {
        Files.createDirectories(target.getParent());
        Path tmp = Files.createTempFile(target.getParent(), ".import-", ".tmp");
        try {
            Files.write(tmp, bytes);
            try {
                Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    /** Lower-case extension check used by screens that list candidate files. */
    public static boolean looksLikePng(String fileName) {
        return fileName != null && fileName.toLowerCase(Locale.ROOT).endsWith(".png");
    }
}
