package dev.lumina.cosmetics;

/**
 * Where a cosmetic is worn, with the texture shape this client accepts for imports. These size rules are
 * this client's own conventions (they keep imports small and predictable); they are not a Minecraft
 * specification.
 */
public enum Slot {
    /** Texture of a cape: 64x32 scaled by 1, 2, 4 or 8. */
    CAPE("Cape", 64, 32, 8),
    /** Texture of a hat layer: 64x64 scaled by 1, 2 or 4. */
    HAT("Hat", 64, 64, 4),
    /** Texture of a back accessory: 64x64 scaled by 1, 2 or 4. */
    BACK("Back", 64, 64, 4);

    private final String label;
    private final int baseWidth;
    private final int baseHeight;
    private final int maxScale;

    Slot(String label, int baseWidth, int baseHeight, int maxScale) {
        this.label = label;
        this.baseWidth = baseWidth;
        this.baseHeight = baseHeight;
        this.maxScale = maxScale;
    }

    public String label() {
        return label;
    }

    /** True when {@code width x height} is the base size multiplied by 1, 2, 4 ... up to the maximum. */
    public boolean acceptsSize(int width, int height) {
        for (int k = 1; k <= maxScale; k *= 2) {
            if (width == baseWidth * k && height == baseHeight * k) {
                return true;
            }
        }
        return false;
    }

    public String sizeHint() {
        StringBuilder sb = new StringBuilder();
        for (int k = 1; k <= maxScale; k *= 2) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(baseWidth * k).append('x').append(baseHeight * k);
        }
        return sb.toString();
    }
}
