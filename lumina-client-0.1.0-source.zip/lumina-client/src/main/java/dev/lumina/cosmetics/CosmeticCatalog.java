package dev.lumina.cosmetics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.NameRules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/** Every cosmetic this client knows: a few built-in colour styles plus the player's validated imports. */
public final class CosmeticCatalog {
    public static final int MAX_IMPORTED = 50;

    private final Map<String, CosmeticItem> items = new LinkedHashMap<>();
    private Runnable changeListener = () -> {
    };

    public CosmeticCatalog() {
        builtIn("slate", "Slate", Rarity.COMMON, 0xFF4A5568, 0xFF2D3748);
        builtIn("forest", "Forest", Rarity.UNCOMMON, 0xFF2F6B4F, 0xFF1B3D2E);
        builtIn("midnight", "Midnight", Rarity.RARE, 0xFF1B2A4A, 0xFF0B1220);
        builtIn("ember", "Ember", Rarity.EPIC, 0xFFD9480F, 0xFF7C2D12);
        builtIn("aurora", "Aurora", Rarity.LEGENDARY, 0xFF5B8CFF, 0xFF55D68A);
    }

    private void builtIn(String id, String name, Rarity rarity, int a, int b) {
        items.put(id, new CosmeticItem(id, name + " cape", Slot.CAPE, rarity, CosmeticItem.Origin.BUILT_IN, a, b, ""));
    }

    public void setChangeListener(Runnable listener) {
        this.changeListener = listener == null ? () -> {
        } : listener;
    }

    public synchronized Optional<CosmeticItem> get(String id) {
        return Optional.ofNullable(id == null ? null : items.get(id));
    }

    public synchronized List<CosmeticItem> all() {
        return Collections.unmodifiableList(new ArrayList<>(items.values()));
    }

    public synchronized List<CosmeticItem> forSlot(Slot slot) {
        List<CosmeticItem> out = new ArrayList<>();
        for (CosmeticItem i : items.values()) {
            if (i.slot() == slot) {
                out.add(i);
            }
        }
        return out;
    }

    public synchronized int importedCount() {
        int n = 0;
        for (CosmeticItem i : items.values()) {
            if (i.isImported()) {
                n++;
            }
        }
        return n;
    }

    /** @return null when added, otherwise the reason */
    synchronized String addImported(CosmeticItem item) {
        if (!item.isImported()) {
            return "Only imported items can be added";
        }
        if (items.containsKey(item.id())) {
            return "There is already a cosmetic with that name";
        }
        if (importedCount() >= MAX_IMPORTED) {
            return "You can import at most " + MAX_IMPORTED + " cosmetics";
        }
        items.put(item.id(), item);
        changeListener.run();
        return null;
    }

    /** Removes an imported item from the catalog (built-in items cannot be removed). */
    synchronized Optional<CosmeticItem> removeImported(String id) {
        CosmeticItem item = items.get(id);
        if (item == null || !item.isImported()) {
            return Optional.empty();
        }
        items.remove(id);
        changeListener.run();
        return Optional.of(item);
    }

    // ---- persistence of the imported list ------------------------------------------------------

    public synchronized JsonObject toJson() {
        JsonArray array = new JsonArray();
        for (CosmeticItem i : items.values()) {
            if (!i.isImported()) {
                continue;
            }
            JsonObject o = new JsonObject();
            o.addProperty("id", i.id());
            o.addProperty("name", i.name());
            o.addProperty("slot", i.slot().name());
            o.addProperty("rarity", i.rarity().name());
            o.addProperty("file", i.file());
            array.add(o);
        }
        JsonObject root = new JsonObject();
        root.add("imported", array);
        return root;
    }

    /** Re-reads the imported list. Entries with unsafe ids or file names are dropped and reported. */
    public synchronized LoadReport loadJson(JsonObject root) {
        LoadReport report = new LoadReport();
        items.values().removeIf(CosmeticItem::isImported);
        JsonElement el = root.get("imported");
        if (el == null) {
            return report;
        }
        if (!el.isJsonArray()) {
            report.add("cosmetics: expected a list, starting without imports");
            return report;
        }
        for (JsonElement item : el.getAsJsonArray()) {
            if (!item.isJsonObject() || importedCount() >= MAX_IMPORTED) {
                report.add("cosmetics: skipped an entry");
                continue;
            }
            JsonObject o = item.getAsJsonObject();
            String id = Json.string(o, "id", "");
            String name = Json.string(o, "name", "");
            String file = Json.string(o, "file", "");
            Slot slot = parse(Slot.class, Json.string(o, "slot", ""));
            Rarity rarity = parse(Rarity.class, Json.string(o, "rarity", ""));
            boolean idOk = NameRules.validate(id) == null && id.equals(NameRules.toId(id));
            if (!idOk || NameRules.validate(name) != null || slot == null || !file.equals(id + ".png") || items.containsKey(id)) {
                report.add("cosmetics: skipped an invalid or duplicate imported item");
                continue;
            }
            items.put(id, new CosmeticItem(id, name, slot, rarity == null ? Rarity.COMMON : rarity,
                    CosmeticItem.Origin.IMPORTED, 0xFFFFFFFF, 0xFFFFFFFF, file));
        }
        return report;
    }

    private static <E extends Enum<E>> E parse(Class<E> type, String text) {
        for (E e : type.getEnumConstants()) {
            if (e.name().equals(text.toUpperCase(Locale.ROOT))) {
                return e;
            }
        }
        return null;
    }
}
