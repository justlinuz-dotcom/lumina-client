package dev.lumina.cosmetics;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Small least-recently-used cache for things that are expensive to keep (textures). When an entry is
 * evicted or cleared the release callback runs, so GPU resources are given back instead of leaking.
 */
public final class ResourceCache<K, V> {
    private final int capacity;
    private final Consumer<V> release;
    private final LinkedHashMap<K, V> map;

    public ResourceCache(int capacity, Consumer<V> release) {
        if (capacity < 1) {
            throw new IllegalArgumentException("capacity must be at least 1");
        }
        this.capacity = capacity;
        this.release = release;
        this.map = new LinkedHashMap<>(16, 0.75f, true);
    }

    /** Returns the cached value or loads it. A loader that returns null caches nothing. */
    public synchronized V get(K key, Function<K, V> loader) {
        V existing = map.get(key);
        if (existing != null) {
            return existing;
        }
        V loaded = loader.apply(key);
        if (loaded == null) {
            return null;
        }
        map.put(key, loaded);
        while (map.size() > capacity) {
            Map.Entry<K, V> eldest = map.entrySet().iterator().next();
            map.remove(eldest.getKey());
            releaseQuietly(eldest.getValue());
        }
        return loaded;
    }

    public synchronized void invalidate(K key) {
        V v = map.remove(key);
        if (v != null) {
            releaseQuietly(v);
        }
    }

    public synchronized void clear() {
        for (V v : map.values()) {
            releaseQuietly(v);
        }
        map.clear();
    }

    public synchronized int size() {
        return map.size();
    }

    private void releaseQuietly(V value) {
        try {
            release.accept(value);
        } catch (RuntimeException ignored) {
            // a failing release must never break rendering; the entry is gone either way
        }
    }
}
