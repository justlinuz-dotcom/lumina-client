package dev.lumina.hud;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Locale;

/** Text formatting for HUD values. All formatting is locale-independent so output is predictable. */
public final class HudFormat {
    private static final String[] COMPASS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private HudFormat() {
    }

    /** Fixed number of decimals, e.g. {@code decimal(3.14159, 2)} = {@code "3.14"}. */
    public static String decimal(double value, int decimals) {
        return String.format(Locale.ROOT, "%." + Math.max(0, Math.min(6, decimals)) + "f", value);
    }

    /** Compass heading in degrees (north = 0, east = 90) from a Minecraft yaw (south = 0, west = 90). */
    public static float heading(float yaw) {
        float h = (yaw + 180f) % 360f;
        return h < 0 ? h + 360f : h;
    }

    /** Eight-point compass direction for a Minecraft yaw. */
    public static String cardinal(float yaw) {
        int index = Math.round(heading(yaw) / 45f) % 8;
        return COMPASS[index];
    }

    /** In-game clock: tick 0 is 06:00, and 1000 ticks are one in-game hour. */
    public static String gameClock(long timeOfDayTicks, boolean use24h) {
        if (timeOfDayTicks < 0) {
            return "--:--";
        }
        long t = timeOfDayTicks % 24000;
        int hour = (int) ((t / 1000 + 6) % 24);
        int minute = (int) ((t % 1000) * 60 / 1000);
        return clock(hour, minute, use24h);
    }

    public static String realClock(long epochMillis, ZoneId zone, boolean use24h) {
        ZonedDateTime time = Instant.ofEpochMilli(epochMillis).atZone(zone);
        return clock(time.getHour(), time.getMinute(), use24h);
    }

    private static String clock(int hour, int minute, boolean use24h) {
        if (use24h) {
            return String.format(Locale.ROOT, "%02d:%02d", hour, minute);
        }
        int h12 = hour % 12 == 0 ? 12 : hour % 12;
        return String.format(Locale.ROOT, "%d:%02d %s", h12, minute, hour < 12 ? "AM" : "PM");
    }

    /** {@code m:ss} below one hour, {@code h:mm:ss} above. */
    public static String duration(int totalSeconds) {
        int s = Math.max(0, totalSeconds);
        if (s >= 3600) {
            return String.format(Locale.ROOT, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
        }
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    /** Roman numeral for effect levels 1..10, otherwise the plain number. */
    public static String roman(int level) {
        return level >= 1 && level < ROMAN.length ? ROMAN[level] : Integer.toString(level);
    }

    /** {@code percent(37, 100)} = {@code "37%"}; returns "--" when the maximum is not positive. */
    public static String percent(int value, int max) {
        if (max <= 0) {
            return "--";
        }
        return Math.round(100f * Math.max(0, Math.min(value, max)) / max) + "%";
    }

    /** Title-cases a registry-style name: {@code "fire_resistance"} -> {@code "Fire Resistance"}. */
    public static String prettyName(String raw) {
        StringBuilder sb = new StringBuilder();
        boolean upper = true;
        for (char c : raw.toCharArray()) {
            if (c == '_' || c == ' ') {
                sb.append(' ');
                upper = true;
            } else {
                sb.append(upper ? Character.toUpperCase(c) : c);
                upper = false;
            }
        }
        return sb.toString();
    }
}
