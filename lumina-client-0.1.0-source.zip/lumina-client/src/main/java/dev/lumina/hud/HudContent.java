package dev.lumina.hud;

import java.util.List;

/** What a HUD element wants to show this frame. Pure data; the composer turns it into draw commands. */
public sealed interface HudContent {

    /** Lines of text. */
    record Text(List<String> lines) implements HudContent {
    }

    /** A bar graph; {@code values} are drawn oldest to newest, scaled against {@code maxValue}. */
    record Graph(String title, float[] values, float maxValue) implements HudContent {
    }

    /** A grid of key caps (keystrokes display). */
    record Keys(List<KeyCell> cells) implements HudContent {
    }

    /** One key cap on a grid of fixed-size cells. */
    record KeyCell(String label, int col, int row, int colSpan, boolean pressed) {
    }
}
