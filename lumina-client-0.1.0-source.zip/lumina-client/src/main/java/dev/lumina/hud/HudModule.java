package dev.lumina.hud;

import dev.lumina.client.GameState;
import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;

/**
 * A module that shows one HUD element. The module owns the <em>content</em> (and its settings such as
 * decimals or which lines to show); the element's position, scale, colour and opacity live in the
 * {@link HudLayout} entry with the same id, so the HUD editor can change them independently.
 */
public abstract class HudModule extends ClientModule {
    private final Anchor defaultAnchor;
    private final float defaultX;
    private final float defaultY;

    protected HudModule(String id, String name, String description, Anchor defaultAnchor, float defaultX, float defaultY) {
        super(id, name, description, Category.HUD);
        this.defaultAnchor = defaultAnchor;
        this.defaultX = defaultX;
        this.defaultY = defaultY;
    }

    public final Anchor defaultAnchor() {
        return defaultAnchor;
    }

    public final float defaultX() {
        return defaultX;
    }

    public final float defaultY() {
        return defaultY;
    }

    /** True when the element only makes sense while a world is loaded (most do). */
    public boolean requiresWorld() {
        return true;
    }

    /**
     * Content for this frame, or null to draw nothing. Must be cheap: it runs every frame and must not
     * allocate large structures or do I/O.
     */
    public abstract HudContent content(GameState state, long nowMillis);

    /** Content used by the HUD editor preview when the game has no world (so elements can still be placed). */
    public HudContent previewContent() {
        return new HudContent.Text(java.util.List.of(name()));
    }
}
