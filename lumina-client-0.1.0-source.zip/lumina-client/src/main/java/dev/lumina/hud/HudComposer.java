package dev.lumina.hud;

import dev.lumina.render.Colors;

import java.util.ArrayList;
import java.util.List;

/** Turns {@link HudContent} plus an element's {@link HudElementState} into a {@link HudPlan}. */
public final class HudComposer {
    static final int PADDING = 3;
    static final int LINE_GAP = 1;
    static final int GRAPH_W = 100;
    static final int GRAPH_H = 32;
    static final int KEY_SIZE = 20;
    static final int KEY_GAP = 2;
    private static final float FAST_FRAME_MS = 1000f / 60f;
    private static final float SLOW_FRAME_MS = 1000f / 30f;
    private static final int GOOD = 0xFF55D68A;
    private static final int OK = 0xFFE6C14D;
    private static final int BAD = 0xFFE5594F;
    private static final int KEY_IDLE = 0x66000000;

    /** Unscaled content size in pixels. */
    public record Size(int w, int h) {
    }

    private HudComposer() {
    }

    public static Size measure(HudContent content, TextMeasurer tm) {
        if (content instanceof HudContent.Text t) {
            int w = 0;
            for (String line : t.lines()) {
                w = Math.max(w, tm.width(line));
            }
            int n = t.lines().size();
            return new Size(w + 2 * PADDING, n * tm.lineHeight() + Math.max(0, n - 1) * LINE_GAP + 2 * PADDING);
        }
        if (content instanceof HudContent.Graph g) {
            int w = Math.max(GRAPH_W, tm.width(g.title()));
            return new Size(w + 2 * PADDING, PADDING + tm.lineHeight() + 2 + GRAPH_H + PADDING);
        }
        HudContent.Keys k = (HudContent.Keys) content;
        int cols = 0;
        int rows = 0;
        for (HudContent.KeyCell c : k.cells()) {
            cols = Math.max(cols, c.col() + c.colSpan());
            rows = Math.max(rows, c.row() + 1);
        }
        return new Size(2 * PADDING + cols * KEY_SIZE + Math.max(0, cols - 1) * KEY_GAP,
                2 * PADDING + rows * KEY_SIZE + Math.max(0, rows - 1) * KEY_GAP);
    }

    private static boolean isEmpty(HudContent content) {
        if (content instanceof HudContent.Text t) {
            return t.lines().isEmpty();
        }
        if (content instanceof HudContent.Graph g) {
            return g.values().length == 0;
        }
        return ((HudContent.Keys) content).cells().isEmpty();
    }

    /**
     * @param accentArgb colour used for pressed keys
     * @param panelArgb  colour of the background panel
     * @return the plan, or null when the content is empty
     */
    public static HudPlan compose(String id, HudContent content, HudElementState state, TextMeasurer tm,
                                  int screenW, int screenH, int accentArgb, int panelArgb) {
        if (content == null || isEmpty(content)) {
            return null;
        }
        Size size = measure(content, tm);
        HudGeometry.Box box = HudGeometry.place(state, size.w(), size.h(), screenW, screenH);
        float opacity = state.opacity();
        int text = Colors.scaleAlpha(state.textColor(), opacity);
        int panel = Colors.scaleAlpha(panelArgb, opacity);
        List<DrawOp> ops = new ArrayList<>();
        if (state.background()) {
            ops.add(new DrawOp.Fill(0, 0, size.w(), size.h(), panel));
        }

        if (content instanceof HudContent.Text t) {
            int y = PADDING;
            for (String line : t.lines()) {
                ops.add(new DrawOp.Text(PADDING, y, line, text));
                y += tm.lineHeight() + LINE_GAP;
            }
        } else if (content instanceof HudContent.Graph g) {
            composeGraph(g, tm, ops, text, opacity);
        } else {
            composeKeys((HudContent.Keys) content, tm, ops, text, Colors.scaleAlpha(accentArgb, opacity), opacity);
        }
        return new HudPlan(id, box.x(), box.y(), state.scale(), box.w(), box.h(), List.copyOf(ops));
    }

    private static void composeGraph(HudContent.Graph g, TextMeasurer tm, List<DrawOp> ops, int text, float opacity) {
        ops.add(new DrawOp.Text(PADDING, PADDING, g.title(), text));
        int top = PADDING + tm.lineHeight() + 2;
        float[] values = g.values();
        int bars = Math.min(values.length, GRAPH_W);
        int barWidth = Math.max(1, GRAPH_W / bars);
        float max = g.maxValue() > 0 ? g.maxValue() : 1f;
        for (int b = 0; b < bars; b++) {
            int from = b * values.length / bars;
            int to = Math.max(from + 1, (b + 1) * values.length / bars);
            float worst = 0f;
            for (int i = from; i < to && i < values.length; i++) {
                worst = Math.max(worst, values[i]);
            }
            int h = Math.max(1, Math.round(Math.min(1f, worst / max) * GRAPH_H));
            int colour = worst <= FAST_FRAME_MS ? GOOD : (worst <= SLOW_FRAME_MS ? OK : BAD);
            ops.add(new DrawOp.Fill(PADDING + b * barWidth, top + GRAPH_H - h, barWidth, h,
                    Colors.scaleAlpha(colour, opacity)));
        }
    }

    private static void composeKeys(HudContent.Keys keys, TextMeasurer tm, List<DrawOp> ops, int text,
                                    int accent, float opacity) {
        int idle = Colors.scaleAlpha(KEY_IDLE, opacity);
        for (HudContent.KeyCell c : keys.cells()) {
            int x = PADDING + c.col() * (KEY_SIZE + KEY_GAP);
            int y = PADDING + c.row() * (KEY_SIZE + KEY_GAP);
            int w = c.colSpan() * KEY_SIZE + (c.colSpan() - 1) * KEY_GAP;
            ops.add(new DrawOp.Fill(x, y, w, KEY_SIZE, c.pressed() ? accent : idle));
            ops.add(new DrawOp.Text(x + (w - tm.width(c.label())) / 2, y + (KEY_SIZE - tm.lineHeight()) / 2,
                    c.label(), text));
        }
    }
}
