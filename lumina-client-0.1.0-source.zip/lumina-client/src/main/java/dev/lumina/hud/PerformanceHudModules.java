package dev.lumina.hud;

import dev.lumina.client.GameState;
import dev.lumina.setting.NumberSetting;

/** HUD elements that visualise performance. */
public final class PerformanceHudModules {
    private PerformanceHudModules() {
    }

    /** Bar graph of recent frame times. */
    public static final class FrameGraph extends HudModule {
        final NumberSetting samples = add(NumberSetting.ofInt("samples", "Frames shown",
                "How many of the most recent frames the graph covers.", 120, 30, 240));
        final NumberSetting maxMs = add(new NumberSetting("max_ms", "Graph height (ms)",
                "Frame time that fills the full height of the graph.", 34, 10, 100, 1, true, "ms"));
        private final HudServices services;

        public FrameGraph(HudServices services) {
            super("performance_graph", "Performance Graph", "Draws the frame time of the most recent frames.",
                    Anchor.TOP_RIGHT, -4, 46);
            this.services = services;
        }

        @Override
        public boolean requiresWorld() {
            return false;
        }

        @Override
        public HudContent content(GameState s, long now) {
            float[] frames = services.frames().recent(samples.getInt());
            if (frames.length == 0) {
                return null;
            }
            double sum = 0;
            for (float f : frames) {
                sum += f;
            }
            String title = "Frame time  avg " + HudFormat.decimal(sum / frames.length, 1) + " ms";
            return new HudContent.Graph(title, frames, maxMs.getFloat());
        }

        @Override
        public HudContent previewContent() {
            float[] demo = new float[60];
            for (int i = 0; i < demo.length; i++) {
                demo[i] = 8f + (i % 9) * 1.5f;
            }
            return new HudContent.Graph("Frame time  avg 13.4 ms", demo, maxMs.getFloat());
        }
    }
}
