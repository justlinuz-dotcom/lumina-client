package dev.lumina.hud;

import dev.lumina.client.ArmorPiece;
import dev.lumina.client.EffectInfo;
import dev.lumina.client.GameState;
import dev.lumina.client.GameState.TrackedKey;
import dev.lumina.combat.CombatStats;
import dev.lumina.combat.CpsCounter;
import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.EnumSetting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * HUD elements about combat and the player's equipment and state. Everything shown is read from the
 * game or counted locally; nothing is estimated and nothing influences the game.
 */
public final class CombatHudModules {
    private static final Set<String> ARMOR_SLOTS = Set.of("head", "chest", "legs", "feet");

    private CombatHudModules() {
    }

    private static HudContent line(String text) {
        return new HudContent.Text(List.of(text));
    }

    private static HudContent lines(List<String> lines) {
        return lines.isEmpty() ? null : new HudContent.Text(List.copyOf(lines));
    }

    static String slotLabel(String slot) {
        return switch (slot) {
            case "head" -> "Helmet";
            case "chest" -> "Chestplate";
            case "legs" -> "Leggings";
            case "feet" -> "Boots";
            case "mainhand" -> "Main hand";
            case "offhand" -> "Off hand";
            default -> HudFormat.prettyName(slot);
        };
    }

    private static String durabilityLine(ArmorPiece p, boolean showPercent) {
        String text = slotLabel(p.slot()) + ": " + HudFormat.prettyName(p.itemName()) + " " + p.durability() + "/" + p.maxDurability();
        return showPercent ? text + " (" + HudFormat.percent(p.durability(), p.maxDurability()) + ")" : text;
    }

    /** Clicks per second. */
    public static final class Cps extends HudModule {
        final BooleanSetting showRight = add(new BooleanSetting("show_right", "Show right button",
                "Also show right-click CPS.", false));
        private final HudServices services;

        public Cps(HudServices services) {
            super("cps_counter", "CPS Counter", "Shows how many times per second you click.", Anchor.TOP_LEFT, 4, 18);
            this.services = services;
        }

        @Override
        public boolean requiresWorld() {
            return false;
        }

        @Override
        public HudContent content(GameState s, long now) {
            int left = services.cps().cps(CpsCounter.LEFT, now);
            if (showRight.isOn()) {
                return line("CPS: " + left + " | " + services.cps().cps(CpsCounter.RIGHT, now));
            }
            return line("CPS: " + left);
        }

        @Override
        public HudContent previewContent() {
            return line("CPS: 8");
        }
    }

    /** Attack cooldown, combo and local statistics. */
    public static final class CombatInfo extends HudModule {
        final BooleanSetting showCooldown = add(new BooleanSetting("show_cooldown", "Attack cooldown",
                "Show how charged your next attack is (from the game).", true));
        final BooleanSetting showCombo = add(new BooleanSetting("show_combo", "Combo",
                "Show consecutive attacks sent without taking damage.", true));
        final BooleanSetting showAttacks = add(new BooleanSetting("show_attacks", "Attacks sent",
                "Show how many attacks you sent this session (not confirmed damage).", true));
        final BooleanSetting showDamageTaken = add(new BooleanSetting("show_damage_taken", "Damage taken",
                "Show health you lost this session, in hearts.", false));
        private final HudServices services;

        public CombatInfo(HudServices services) {
            super("combat_info", "Combat Info", "Shows attack cooldown, combo and session statistics.", Anchor.MIDDLE_LEFT, 4, 0);
            this.services = services;
        }

        @Override
        public HudContent content(GameState s, long now) {
            List<String> out = new ArrayList<>();
            CombatStats.Counters c = services.stats().session();
            if (showCooldown.isOn() && s.attackCooldown() >= 0f) {
                out.add("Attack: " + Math.round(Math.min(1f, s.attackCooldown()) * 100) + "%");
            }
            if (showCombo.isOn()) {
                out.add("Combo: " + services.combo().combo(now));
            }
            if (showAttacks.isOn()) {
                out.add("Attacks: " + c.attacks());
            }
            if (showDamageTaken.isOn()) {
                out.add("Damage taken: " + HudFormat.decimal(c.damageTaken() / 2.0, 1) + " hearts");
            }
            return lines(out);
        }

        @Override
        public HudContent previewContent() {
            return new HudContent.Text(List.of("Attack: 100%", "Combo: 3", "Attacks: 24"));
        }
    }

    /** Equipped armour with durability. */
    public static final class Armor extends HudModule {
        final BooleanSetting showPercent = add(new BooleanSetting("show_percent", "Show percentage",
                "Show remaining durability as a percentage.", true));

        public Armor() {
            super("armor_status", "Armor Status", "Shows durability of the armour you wear.", Anchor.BOTTOM_RIGHT, -4, -60);
        }

        @Override
        public HudContent content(GameState s, long now) {
            List<String> out = new ArrayList<>();
            for (ArmorPiece p : s.armor()) {
                if (ARMOR_SLOTS.contains(p.slot()) && p.damageable()) {
                    out.add(durabilityLine(p, showPercent.isOn()));
                }
            }
            return lines(out);
        }

        @Override
        public HudContent previewContent() {
            return new HudContent.Text(List.of("Helmet: Diamond Helmet 300/363 (83%)", "Boots: Iron Boots 120/195 (62%)"));
        }
    }

    /** Durability of held tools and weapons. */
    public static final class ItemDurability extends HudModule {
        final BooleanSetting showPercent = add(new BooleanSetting("show_percent", "Show percentage",
                "Show remaining durability as a percentage.", true));

        public ItemDurability() {
            super("item_durability", "Item Durability", "Shows durability of the items in your hands.", Anchor.BOTTOM_RIGHT, -4, -30);
        }

        @Override
        public HudContent content(GameState s, long now) {
            List<String> out = new ArrayList<>();
            for (ArmorPiece p : s.armor()) {
                if (("mainhand".equals(p.slot()) || "offhand".equals(p.slot())) && p.damageable()) {
                    out.add(durabilityLine(p, showPercent.isOn()));
                }
            }
            return lines(out);
        }

        @Override
        public HudContent previewContent() {
            return line("Main hand: Diamond Sword 1200/1561 (77%)");
        }
    }

    /** Active potion effects with remaining time. */
    public static final class Effects extends HudModule {
        final BooleanSetting showLevel = add(new BooleanSetting("show_level", "Show level",
                "Show the effect level as a roman numeral.", true));
        final BooleanSetting shortestFirst = add(new BooleanSetting("shortest_first", "Shortest first",
                "Sort effects so the one that ends soonest is on top.", true));

        public Effects() {
            super("potion_effects", "Potion Effects", "Lists your active effects and their remaining time.", Anchor.MIDDLE_RIGHT, -4, 0);
        }

        @Override
        public HudContent content(GameState s, long now) {
            List<EffectInfo> effects = new ArrayList<>(s.effects());
            if (shortestFirst.isOn()) {
                effects.sort(Comparator.comparingInt((EffectInfo e) -> e.infinite() ? Integer.MAX_VALUE : e.remainingSeconds()));
            }
            List<String> out = new ArrayList<>();
            for (EffectInfo e : effects) {
                String name = HudFormat.prettyName(e.name());
                if (showLevel.isOn() && e.amplifier() > 0) {
                    name += " " + HudFormat.roman(e.amplifier() + 1);
                }
                out.add(name + "  " + (e.infinite() ? "inf" : HudFormat.duration(e.remainingSeconds())));
            }
            return lines(out);
        }

        @Override
        public HudContent previewContent() {
            return new HudContent.Text(List.of("Speed II  1:23", "Strength  0:45"));
        }
    }

    /** Pressed movement keys and mouse buttons. */
    public static final class Keystrokes extends HudModule {
        final BooleanSetting showJump = add(new BooleanSetting("show_jump", "Show jump key",
                "Show a wide cap for the jump key.", true));
        final BooleanSetting showMouse = add(new BooleanSetting("show_mouse", "Show mouse buttons",
                "Show left and right mouse button caps.", true));

        public Keystrokes() {
            super("keystrokes", "Keystrokes", "Shows which movement keys and mouse buttons are held.", Anchor.BOTTOM_LEFT, 4, -4);
        }

        @Override
        public HudContent content(GameState s, long now) {
            List<HudContent.KeyCell> cells = new ArrayList<>();
            cells.add(new HudContent.KeyCell("W", 1, 0, 1, s.keyDown(TrackedKey.FORWARD)));
            cells.add(new HudContent.KeyCell("A", 0, 1, 1, s.keyDown(TrackedKey.LEFT)));
            cells.add(new HudContent.KeyCell("S", 1, 1, 1, s.keyDown(TrackedKey.BACK)));
            cells.add(new HudContent.KeyCell("D", 2, 1, 1, s.keyDown(TrackedKey.RIGHT)));
            int row = 2;
            if (showJump.isOn()) {
                cells.add(new HudContent.KeyCell("SPACE", 0, row++, 3, s.keyDown(TrackedKey.JUMP)));
            }
            if (showMouse.isOn()) {
                cells.add(new HudContent.KeyCell("LMB", 0, row, 1, s.keyDown(TrackedKey.ATTACK)));
                cells.add(new HudContent.KeyCell("RMB", 2, row, 1, s.keyDown(TrackedKey.USE)));
            }
            return new HudContent.Keys(List.copyOf(cells));
        }

        @Override
        public HudContent previewContent() {
            return new HudContent.Keys(List.of(new HudContent.KeyCell("W", 1, 0, 1, true),
                    new HudContent.KeyCell("A", 0, 1, 1, false), new HudContent.KeyCell("S", 1, 1, 1, false),
                    new HudContent.KeyCell("D", 2, 1, 1, false)));
        }
    }

    /** Sprint and sneak state. */
    public static final class SprintIndicator extends HudModule {
        final BooleanSetting showWalking = add(new BooleanSetting("show_walking", "Show when walking",
                "Also show 'Walking' / 'Standing' when neither sprinting nor sneaking.", false));

        public SprintIndicator() {
            super("sprint_indicator", "Sprint Indicator", "Shows whether you are sprinting or sneaking.", Anchor.BOTTOM_CENTER, 0, -60);
        }

        @Override
        public HudContent content(GameState s, long now) {
            if (s.sneaking()) {
                return line("Sneaking");
            }
            if (s.sprinting()) {
                return line("Sprinting");
            }
            if (showWalking.isOn()) {
                return line(s.speedBlocksPerSecond() > 0.5 ? "Walking" : "Standing");
            }
            return null;
        }

        @Override
        public HudContent previewContent() {
            return line("Sprinting");
        }
    }

    /** A configurable session counter. */
    public static final class Counter extends HudModule {
        public enum Source { ATTACKS, HITS_TAKEN, LEFT_CLICKS, RIGHT_CLICKS, MAX_COMBO }

        final EnumSetting<Source> source = add(new EnumSetting<>("source", "Count",
                "What the counter counts during this session.", Source.ATTACKS));
        private final HudServices services;

        public Counter(HudServices services) {
            super("counter", "Counter", "Shows a session counter of your choice.", Anchor.TOP_CENTER, 0, 4);
            this.services = services;
        }

        @Override
        public boolean requiresWorld() {
            return false;
        }

        @Override
        public HudContent content(GameState s, long now) {
            CombatStats.Counters c = services.stats().session();
            return switch (source.get()) {
                case ATTACKS -> line("Attacks: " + c.attacks());
                case HITS_TAKEN -> line("Times hurt: " + c.hitsTaken());
                case LEFT_CLICKS -> line("Left clicks: " + c.leftClicks());
                case RIGHT_CLICKS -> line("Right clicks: " + c.rightClicks());
                case MAX_COMBO -> line("Best combo: " + c.maxCombo());
            };
        }

        @Override
        public HudContent previewContent() {
            return line("Attacks: 24");
        }
    }
}
