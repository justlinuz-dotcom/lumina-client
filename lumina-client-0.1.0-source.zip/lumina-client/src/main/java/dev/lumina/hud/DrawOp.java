package dev.lumina.hud;

/**
 * Drawing command in an element's local (unscaled) coordinates. The Minecraft layer executes these
 * with plain fill and draw-string calls, so the whole HUD logic is testable without the game.
 */
public sealed interface DrawOp {

    record Fill(int x, int y, int w, int h, int argb) implements DrawOp {
    }

    record Text(int x, int y, String text, int argb) implements DrawOp {
    }
}
