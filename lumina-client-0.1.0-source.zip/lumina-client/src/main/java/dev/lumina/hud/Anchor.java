package dev.lumina.hud;

/**
 * Screen reference point of a HUD element. Positions are stored as an offset from an anchor, so an
 * element anchored to the right edge stays at the right edge at any resolution or GUI scale.
 */
public enum Anchor {
    TOP_LEFT(0f, 0f),
    TOP_CENTER(0.5f, 0f),
    TOP_RIGHT(1f, 0f),
    MIDDLE_LEFT(0f, 0.5f),
    CENTER(0.5f, 0.5f),
    MIDDLE_RIGHT(1f, 0.5f),
    BOTTOM_LEFT(0f, 1f),
    BOTTOM_CENTER(0.5f, 1f),
    BOTTOM_RIGHT(1f, 1f);

    private final float fx;
    private final float fy;

    Anchor(float fx, float fy) {
        this.fx = fx;
        this.fy = fy;
    }

    /** Horizontal fraction of the screen (0 = left, 1 = right). */
    public float fx() {
        return fx;
    }

    /** Vertical fraction of the screen (0 = top, 1 = bottom). */
    public float fy() {
        return fy;
    }

    /** Anchor of the screen third (3x3 grid) that contains the point. */
    public static Anchor nearest(float x, float y, int screenW, int screenH) {
        int col = x < screenW / 3f ? 0 : (x > screenW * 2f / 3f ? 2 : 1);
        int row = y < screenH / 3f ? 0 : (y > screenH * 2f / 3f ? 2 : 1);
        return values()[row * 3 + col];
    }
}
