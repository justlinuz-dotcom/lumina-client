package dev.lumina.hud;

import java.util.List;

/**
 * Everything needed to draw one element: translate to {@code (x, y)}, scale by {@code scale}, execute
 * {@code ops}. {@code w}/{@code h} are the final on-screen size (already scaled), used for hit-testing
 * in the HUD editor.
 */
public record HudPlan(String id, float x, float y, float scale, float w, float h, List<DrawOp> ops) {

    public HudGeometry.Box box() {
        return new HudGeometry.Box(x, y, w, h);
    }
}
