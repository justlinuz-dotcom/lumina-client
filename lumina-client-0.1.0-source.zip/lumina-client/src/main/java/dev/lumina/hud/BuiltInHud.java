package dev.lumina.hud;

import dev.lumina.module.ModuleManager;

import java.util.ArrayList;
import java.util.List;

/** Creates and registers every built-in HUD module together with its layout entry. */
public final class BuiltInHud {
    private BuiltInHud() {
    }

    public static List<HudModule> create(HudServices services) {
        List<HudModule> all = new ArrayList<>();
        all.add(new InfoHudModules.Fps());
        all.add(new CombatHudModules.Cps(services));
        all.add(new InfoHudModules.Coordinates());
        all.add(new InfoHudModules.Ping());
        all.add(new InfoHudModules.Direction());
        all.add(new InfoHudModules.Clock(services));
        all.add(new InfoHudModules.Session(services));
        all.add(new InfoHudModules.Memory(services));
        all.add(new PerformanceHudModules.FrameGraph(services));
        all.add(new CombatHudModules.CombatInfo(services));
        all.add(new CombatHudModules.Armor());
        all.add(new CombatHudModules.ItemDurability());
        all.add(new CombatHudModules.Effects());
        all.add(new CombatHudModules.Keystrokes());
        all.add(new CombatHudModules.SprintIndicator());
        all.add(new CombatHudModules.Counter(services));
        return all;
    }

    /** Registers the modules with the manager and their default positions with the layout. */
    public static List<HudModule> register(ModuleManager manager, HudLayout layout, HudServices services) {
        List<HudModule> modules = create(services);
        for (HudModule m : modules) {
            manager.register(m);
            layout.register(m.id(), m.defaultAnchor(), m.defaultX(), m.defaultY());
        }
        return modules;
    }
}
