package dev.lumina.hud;

import com.google.gson.JsonObject;
import dev.lumina.config.ClientPaths;
import dev.lumina.config.SafeJsonFile;
import dev.lumina.utils.ErrorSink;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.NameRules;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.function.LongSupplier;
import java.util.stream.Stream;

/**
 * Named HUD layouts stored under {@code layouts/}. A layout is only positions, scales, colours and
 * visibility of HUD elements; it does not change which modules are enabled.
 */
public final class HudLayoutStore {
    public static final int MAX_LAYOUTS = 20;
    public static final String FORMAT = "lumina-hud-layout";
    private static final int SCHEMA = 1;

    public record Outcome(boolean ok, String message, LoadReport report) {
        static Outcome ok(String message, LoadReport report) {
            return new Outcome(true, message, report);
        }

        static Outcome fail(String message) {
            return new Outcome(false, message, new LoadReport());
        }
    }

    private final ClientPaths paths;
    private final LongSupplier clock;
    private final ErrorSink errors;

    public HudLayoutStore(ClientPaths paths, LongSupplier clock, ErrorSink errors) {
        this.paths = paths;
        this.clock = clock;
        this.errors = errors;
    }

    private SafeJsonFile file(String id) {
        return new SafeJsonFile(paths.layouts().resolve(id + ".json"), paths.backups(), SCHEMA, 3, 10 * 60_000L, clock);
    }

    /** Saved layout ids, sorted. */
    public synchronized List<String> list() {
        List<String> ids = new ArrayList<>();
        if (!Files.isDirectory(paths.layouts())) {
            return ids;
        }
        try (Stream<Path> stream = Files.list(paths.layouts())) {
            stream.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".json"))
                    .map(n -> n.substring(0, n.length() - 5))
                    .filter(id -> NameRules.validate(id) == null && id.equals(NameRules.toId(id)))
                    .sorted()
                    .forEach(ids::add);
        } catch (IOException e) {
            errors.report("layouts:list", e);
        }
        return ids;
    }

    public synchronized Outcome save(String name, HudLayout layout) {
        String problem = NameRules.validate(name);
        if (problem != null) {
            return Outcome.fail(problem);
        }
        String id = NameRules.toId(name);
        List<String> existing = list();
        if (!existing.contains(id) && existing.size() >= MAX_LAYOUTS) {
            return Outcome.fail("You can keep at most " + MAX_LAYOUTS + " saved layouts");
        }
        JsonObject root = new JsonObject();
        root.addProperty("format", FORMAT);
        root.addProperty("name", name);
        root.add("hud", layout.save());
        try {
            Files.createDirectories(paths.layouts());
            file(id).write(root);
        } catch (IOException e) {
            errors.report("layouts:save", e);
            return Outcome.fail("The layout could not be saved");
        }
        return Outcome.ok("Saved layout " + name, new LoadReport());
    }

    public synchronized Outcome load(String name, HudLayout layout) {
        String problem = NameRules.validate(name);
        if (problem != null) {
            return Outcome.fail(problem);
        }
        SafeJsonFile.ReadResult result = file(NameRules.toId(name)).read();
        switch (result.status()) {
            case MISSING:
                return Outcome.fail("No saved layout called " + name);
            case CORRUPT_DEFAULTED:
            case INCOMPATIBLE:
                return Outcome.fail("That layout cannot be used: " + result.detail());
            default:
                break;
        }
        if (!FORMAT.equals(result.data().has("format") && result.data().get("format").isJsonPrimitive()
                ? result.data().get("format").getAsString() : "")) {
            return Outcome.fail("That file is not a layout");
        }
        LoadReport report = layout.load(dev.lumina.utils.Json.object(result.data(), "hud"));
        layout.notifyChanged();
        return Outcome.ok("Loaded layout " + name, report);
    }

    /** Moves the layout file into the backups folder so a mistaken delete can be undone by hand. */
    public synchronized Outcome delete(String name) {
        String problem = NameRules.validate(name);
        if (problem != null) {
            return Outcome.fail(problem);
        }
        String id = NameRules.toId(name);
        Path source = paths.layouts().resolve(id + ".json");
        if (!Files.isRegularFile(source)) {
            return Outcome.fail("No saved layout called " + name);
        }
        try {
            Path target = paths.backups().resolve("deleted-layout-" + id + "-" + clock.getAsLong() + ".json");
            Files.createDirectories(paths.backups());
            Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            errors.report("layouts:delete", e);
            return Outcome.fail("The layout could not be deleted");
        }
        return Outcome.ok("Deleted layout " + name + " (a copy is kept in the backups folder)", new LoadReport());
    }
}
