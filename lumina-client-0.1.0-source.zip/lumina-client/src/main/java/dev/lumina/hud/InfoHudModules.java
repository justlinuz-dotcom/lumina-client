package dev.lumina.hud;

import dev.lumina.client.GameState;
import dev.lumina.performance.MemorySample;
import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.EnumSetting;
import dev.lumina.setting.NumberSetting;

import java.util.List;

/** HUD elements that show general information: FPS, ping, position, direction, clocks, session, memory. */
public final class InfoHudModules {
    private InfoHudModules() {
    }

    private static HudContent line(String text) {
        return new HudContent.Text(List.of(text));
    }

    /** Current FPS as reported by the game. */
    public static final class Fps extends HudModule {
        final BooleanSetting showFrameTime = add(new BooleanSetting("show_frametime", "Show frame time",
                "Also show how long the last frames took, in milliseconds.", false));

        public Fps() {
            super("fps_counter", "FPS Counter", "Shows the current frames per second.", Anchor.TOP_LEFT, 4, 4);
            defaultEnabled(true);
        }

        @Override
        public boolean requiresWorld() {
            return false;
        }

        @Override
        public HudContent content(GameState s, long now) {
            int fps = s.fps();
            if (fps <= 0) {
                return line("FPS: --");
            }
            return line(showFrameTime.isOn()
                    ? "FPS: " + fps + " (" + HudFormat.decimal(1000.0 / fps, 1) + " ms)"
                    : "FPS: " + fps);
        }

        @Override
        public HudContent previewContent() {
            return line("FPS: 144");
        }
    }

    /** Latency to the server as measured by the game. */
    public static final class Ping extends HudModule {
        public Ping() {
            super("ping_display", "Ping", "Shows your latency to the server in milliseconds.", Anchor.TOP_LEFT, 4, 46);
        }

        @Override
        public HudContent content(GameState s, long now) {
            int ping = s.pingMs();
            return line(ping < 0 ? "Ping: n/a" : "Ping: " + ping + " ms");
        }

        @Override
        public HudContent previewContent() {
            return line("Ping: 32 ms");
        }
    }

    /** XYZ position. */
    public static final class Coordinates extends HudModule {
        final NumberSetting decimals = add(NumberSetting.ofInt("decimals", "Decimals",
                "Digits shown after the decimal point.", 1, 0, 3));
        final BooleanSetting multiline = add(new BooleanSetting("multiline", "One axis per line",
                "Show X, Y and Z on separate lines.", false));

        public Coordinates() {
            super("coordinates", "Coordinates", "Shows your X, Y and Z position.", Anchor.TOP_LEFT, 4, 32);
        }

        @Override
        public HudContent content(GameState s, long now) {
            int d = decimals.getInt();
            String x = HudFormat.decimal(s.x(), d);
            String y = HudFormat.decimal(s.y(), d);
            String z = HudFormat.decimal(s.z(), d);
            if (multiline.isOn()) {
                return new HudContent.Text(List.of("X: " + x, "Y: " + y, "Z: " + z));
            }
            return line("XYZ: " + x + " / " + y + " / " + z);
        }

        @Override
        public HudContent previewContent() {
            return line("XYZ: 128.5 / 64.0 / -302.2");
        }
    }

    /** Compass direction the player is facing. */
    public static final class Direction extends HudModule {
        final BooleanSetting showDegrees = add(new BooleanSetting("show_degrees", "Show degrees",
                "Also show the heading in degrees (north = 0).", true));

        public Direction() {
            super("direction_display", "Direction", "Shows the compass direction you are facing.", Anchor.TOP_LEFT, 4, 60);
        }

        @Override
        public HudContent content(GameState s, long now) {
            String card = HudFormat.cardinal(s.yaw());
            return line(showDegrees.isOn()
                    ? "Facing: " + card + " (" + Math.round(HudFormat.heading(s.yaw())) + "°)"
                    : "Facing: " + card);
        }

        @Override
        public HudContent previewContent() {
            return line("Facing: N (0°)");
        }
    }

    /** Real-world or in-game time. */
    public static final class Clock extends HudModule {
        public enum Source { REAL, GAME }

        final EnumSetting<Source> source = add(new EnumSetting<>("source", "Time source",
                "REAL shows your computer's time, GAME shows the in-game day time.", Source.REAL));
        final BooleanSetting use24h = add(new BooleanSetting("use_24h", "24-hour format",
                "Use 24-hour time instead of AM/PM.", true));
        private final HudServices services;

        public Clock(HudServices services) {
            super("clock_display", "Clock", "Shows the real or in-game time.", Anchor.TOP_RIGHT, -4, 4);
            this.services = services;
        }

        @Override
        public boolean requiresWorld() {
            return false;
        }

        @Override
        public HudContent content(GameState s, long now) {
            if (source.get() == Source.GAME) {
                return line("Day time: " + HudFormat.gameClock(s.timeOfDayTicks(), use24h.isOn()));
            }
            return line("Time: " + HudFormat.realClock(services.clockMillis().getAsLong(), services.zone(), use24h.isOn()));
        }

        @Override
        public HudContent previewContent() {
            return line("Time: 14:32");
        }
    }

    /** Play time of this session and, optionally, the server address. */
    public static final class Session extends HudModule {
        final BooleanSetting showServer = add(new BooleanSetting("show_server", "Show server address",
                "Show the address of the server you are connected to. Off by default so it does not leak in screenshots.", false));
        private final HudServices services;

        public Session(HudServices services) {
            super("session_info", "Session Info", "Shows how long this game session has been running.", Anchor.TOP_RIGHT, -4, 18);
            this.services = services;
        }

        @Override
        public boolean requiresWorld() {
            return false;
        }

        @Override
        public HudContent content(GameState s, long now) {
            String time = "Session: " + HudFormat.duration(services.session().elapsedSeconds());
            String server = s.serverAddress();
            if (showServer.isOn() && server != null) {
                return new HudContent.Text(List.of(time, "Server: " + server));
            }
            return line(time);
        }

        @Override
        public HudContent previewContent() {
            return line("Session: 12:34");
        }
    }

    /** JVM heap usage. */
    public static final class Memory extends HudModule {
        private final HudServices services;

        public Memory(HudServices services) {
            super("memory_usage", "Memory Usage", "Shows how much of the Java heap is in use.", Anchor.TOP_RIGHT, -4, 32);
            this.services = services;
        }

        @Override
        public boolean requiresWorld() {
            return false;
        }

        @Override
        public HudContent content(GameState s, long now) {
            MemorySample m = services.memory().latest();
            return line("Mem: " + Math.round(m.usedMb()) + " / " + Math.round(m.maxMb()) + " MB ("
                    + Math.round(m.usedFraction() * 100) + "%)");
        }

        @Override
        public HudContent previewContent() {
            return line("Mem: 1024 / 4096 MB (25%)");
        }
    }
}
