package dev.lumina.hud;

import dev.lumina.combat.CombatStats;
import dev.lumina.combat.ComboTracker;
import dev.lumina.combat.CpsCounter;
import dev.lumina.performance.FrameStats;
import dev.lumina.performance.MemorySampler;
import dev.lumina.world.SessionInfo;

import java.time.ZoneId;
import java.util.function.LongSupplier;

/** Shared services HUD modules read from. Everything here is local, in-memory state. */
public record HudServices(CpsCounter cps, ComboTracker combo, CombatStats stats, FrameStats frames,
                          MemorySampler memory, SessionInfo session, LongSupplier clockMillis, ZoneId zone) {
}
