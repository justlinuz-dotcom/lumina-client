package dev.lumina.hud;

/** Font metrics supplied by the game (or a fake in tests). */
public interface TextMeasurer {

    /** Width of the string in GUI pixels. */
    int width(String text);

    /** Height of one line of text in GUI pixels. */
    int lineHeight();
}
