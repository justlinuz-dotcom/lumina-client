package dev.lumina.hud;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.setting.ColorSetting;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.MathUtil;

import java.util.Locale;

/**
 * Persistent layout state of one HUD element: where it sits, how big it is, how it looks and whether
 * it is shown. Every element owns its own state, so elements are fully independent.
 */
public final class HudElementState {
    public static final float MIN_SCALE = 0.5f;
    public static final float MAX_SCALE = 3.0f;
    public static final float MAX_OFFSET = 10_000f;

    private final String id;
    private volatile Anchor anchor;
    private volatile float offsetX;
    private volatile float offsetY;
    private volatile float scale = 1f;
    private volatile int textColor = 0xFFFFFFFF;
    private volatile float opacity = 1f;
    private volatile boolean visible = true;
    private volatile boolean background = true;

    public HudElementState(String id, Anchor anchor, float offsetX, float offsetY) {
        this.id = id;
        this.anchor = anchor;
        this.offsetX = clampOffset(offsetX);
        this.offsetY = clampOffset(offsetY);
    }

    public HudElementState copy() {
        HudElementState c = new HudElementState(id, anchor, offsetX, offsetY);
        c.copyFrom(this);
        return c;
    }

    public void copyFrom(HudElementState o) {
        this.anchor = o.anchor;
        this.offsetX = o.offsetX;
        this.offsetY = o.offsetY;
        this.scale = o.scale;
        this.textColor = o.textColor;
        this.opacity = o.opacity;
        this.visible = o.visible;
        this.background = o.background;
    }

    private static float clampOffset(float v) {
        return Float.isFinite(v) ? MathUtil.clamp(v, -MAX_OFFSET, MAX_OFFSET) : 0f;
    }

    public String id() {
        return id;
    }

    public Anchor anchor() {
        return anchor;
    }

    public float offsetX() {
        return offsetX;
    }

    public float offsetY() {
        return offsetY;
    }

    public void setPosition(Anchor newAnchor, float x, float y) {
        this.anchor = newAnchor;
        this.offsetX = clampOffset(x);
        this.offsetY = clampOffset(y);
    }

    public float scale() {
        return scale;
    }

    public void setScale(float value) {
        this.scale = Float.isFinite(value) ? MathUtil.clamp(value, MIN_SCALE, MAX_SCALE) : 1f;
    }

    /** Text colour as ARGB; the alpha channel is combined with {@link #opacity()} when drawing. */
    public int textColor() {
        return textColor;
    }

    public void setTextColor(int argb) {
        this.textColor = argb;
    }

    /** Overall opacity in [0.1, 1]. */
    public float opacity() {
        return opacity;
    }

    public void setOpacity(float value) {
        this.opacity = Float.isFinite(value) ? MathUtil.clamp(value, 0.1f, 1f) : 1f;
    }

    public boolean visible() {
        return visible;
    }

    public void setVisible(boolean value) {
        this.visible = value;
    }

    public boolean background() {
        return background;
    }

    public void setBackground(boolean value) {
        this.background = value;
    }

    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("visible", visible);
        o.addProperty("anchor", anchor.name());
        o.addProperty("x", offsetX);
        o.addProperty("y", offsetY);
        o.addProperty("scale", scale);
        o.addProperty("color", ColorSetting.format(textColor));
        o.addProperty("opacity", opacity);
        o.addProperty("background", background);
        return o;
    }

    /** Loads from JSON; each invalid field keeps its current value and is reported. */
    public void loadJson(JsonObject o, LoadReport report) {
        visible = Json.bool(o, "visible", visible);
        background = Json.bool(o, "background", background);

        String anchorName = Json.string(o, "anchor", null);
        if (anchorName != null) {
            Anchor parsed = parseAnchor(anchorName);
            if (parsed == null) {
                report.add("HUD '" + id + "': unknown anchor '" + anchorName + "'");
            } else {
                anchor = parsed;
            }
        }
        offsetX = number(o, "x", offsetX, -MAX_OFFSET, MAX_OFFSET, report);
        offsetY = number(o, "y", offsetY, -MAX_OFFSET, MAX_OFFSET, report);
        scale = number(o, "scale", scale, MIN_SCALE, MAX_SCALE, report);
        opacity = number(o, "opacity", opacity, 0.1f, 1f, report);

        String color = Json.string(o, "color", null);
        if (color != null) {
            Integer parsed = ColorSetting.parse(color);
            if (parsed == null) {
                report.add("HUD '" + id + "': invalid colour '" + color + "'");
            } else {
                textColor = parsed;
            }
        }
    }

    private static Anchor parseAnchor(String name) {
        try {
            return Anchor.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private float number(JsonObject o, String key, float current, float min, float max, LoadReport report) {
        JsonElement e = o.get(key);
        if (e == null) {
            return current;
        }
        if (!e.isJsonPrimitive() || !e.getAsJsonPrimitive().isNumber()) {
            report.add("HUD '" + id + "': '" + key + "' must be a number");
            return current;
        }
        double v = e.getAsDouble();
        if (!MathUtil.isFinite(v)) {
            report.add("HUD '" + id + "': '" + key + "' is not finite");
            return current;
        }
        float clamped = (float) MathUtil.clamp(v, min, max);
        if (clamped != (float) v) {
            report.add("HUD '" + id + "': '" + key + "' adjusted to " + clamped);
        }
        return clamped;
    }
}
