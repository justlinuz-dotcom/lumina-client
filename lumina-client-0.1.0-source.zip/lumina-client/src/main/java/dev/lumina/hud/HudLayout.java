package dev.lumina.hud;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.profile.ProfileParticipant;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.MathUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Layout of all HUD elements plus the editor's grid options. Part of every profile (section "hud").
 * Elements are registered with their default position; {@link #resetAll()} restores those defaults.
 */
public final class HudLayout implements ProfileParticipant {
    public static final String KEY = "hud";
    public static final int MIN_GRID = 2;
    public static final int MAX_GRID = 64;

    private final Map<String, HudElementState> states = new LinkedHashMap<>();
    private final Map<String, HudElementState> defaults = new LinkedHashMap<>();
    private volatile boolean gridEnabled;
    private volatile boolean snapToGrid;
    private volatile int gridSize = 8;
    private volatile Runnable changeListener = () -> {
    };

    /** Called after editor operations that change the layout (used to trigger auto-save). */
    public void setChangeListener(Runnable listener) {
        this.changeListener = Objects.requireNonNull(listener);
    }

    public void notifyChanged() {
        changeListener.run();
    }

    public synchronized HudElementState register(String id, Anchor anchor, float dx, float dy) {
        if (states.containsKey(id)) {
            throw new IllegalArgumentException("HUD element already registered: " + id);
        }
        HudElementState state = new HudElementState(id, anchor, dx, dy);
        states.put(id, state);
        defaults.put(id, state.copy());
        return state;
    }

    public synchronized HudElementState state(String id) {
        HudElementState s = states.get(id);
        if (s == null) {
            throw new IllegalArgumentException("Unknown HUD element: " + id);
        }
        return s;
    }

    public synchronized boolean has(String id) {
        return states.containsKey(id);
    }

    public synchronized List<String> ids() {
        return Collections.unmodifiableList(new ArrayList<>(states.keySet()));
    }

    public synchronized void reset(String id) {
        HudElementState d = defaults.get(id);
        if (d != null) {
            states.get(id).copyFrom(d);
            changeListener.run();
        }
    }

    /** Restores the default position, size and look of every element and the default grid options. */
    public synchronized void resetAll() {
        resetQuietly();
        changeListener.run();
    }

    private void resetQuietly() {
        for (Map.Entry<String, HudElementState> e : states.entrySet()) {
            e.getValue().copyFrom(defaults.get(e.getKey()));
        }
        gridEnabled = false;
        snapToGrid = false;
        gridSize = 8;
    }

    public boolean gridEnabled() {
        return gridEnabled;
    }

    public void setGridEnabled(boolean value) {
        this.gridEnabled = value;
        changeListener.run();
    }

    public boolean snapToGrid() {
        return snapToGrid;
    }

    public void setSnapToGrid(boolean value) {
        this.snapToGrid = value;
        changeListener.run();
    }

    public int gridSize() {
        return gridSize;
    }

    public void setGridSize(int value) {
        this.gridSize = MathUtil.clamp(value, MIN_GRID, MAX_GRID);
        changeListener.run();
    }

    /** Grid step to snap to, or 0 when snapping is off. */
    public int effectiveSnap() {
        return snapToGrid ? gridSize : 0;
    }

    // ---- ProfileParticipant --------------------------------------------------------------------

    @Override
    public String sectionKey() {
        return KEY;
    }

    @Override
    public synchronized JsonObject save() {
        JsonObject root = new JsonObject();
        JsonObject grid = new JsonObject();
        grid.addProperty("enabled", gridEnabled);
        grid.addProperty("snap", snapToGrid);
        grid.addProperty("size", gridSize);
        root.add("grid", grid);
        JsonObject elements = new JsonObject();
        for (Map.Entry<String, HudElementState> e : states.entrySet()) {
            elements.add(e.getKey(), e.getValue().toJson());
        }
        root.add("elements", elements);
        return root;
    }

    @Override
    public synchronized LoadReport load(JsonObject section) {
        LoadReport report = new LoadReport();
        resetQuietly();
        JsonObject grid = Json.object(section, "grid");
        gridEnabled = Json.bool(grid, "enabled", false);
        snapToGrid = Json.bool(grid, "snap", false);
        int size = Json.integer(grid, "size", 8);
        if (size < MIN_GRID || size > MAX_GRID) {
            report.add("HUD grid size " + size + " adjusted");
        }
        gridSize = MathUtil.clamp(size, MIN_GRID, MAX_GRID);

        JsonObject elements = Json.object(section, "elements");
        for (Map.Entry<String, HudElementState> e : states.entrySet()) {
            JsonElement saved = elements.get(e.getKey());
            if (saved == null) {
                continue;
            }
            if (!saved.isJsonObject()) {
                report.add("HUD '" + e.getKey() + "': invalid entry; default layout used");
                continue;
            }
            e.getValue().loadJson(saved.getAsJsonObject(), report);
        }
        for (String key : elements.keySet()) {
            if (!states.containsKey(key)) {
                report.add("Unknown HUD element '" + key + "' ignored");
            }
        }
        return report;
    }
}
