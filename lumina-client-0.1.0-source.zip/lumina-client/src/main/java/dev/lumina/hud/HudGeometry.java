package dev.lumina.hud;

import dev.lumina.utils.MathUtil;

import java.util.List;

/** Position maths for the HUD and its editor: placement, dragging, snapping and alignment. */
public final class HudGeometry {

    /** Axis-aligned box in GUI pixels (top-left origin). */
    public record Box(float x, float y, float w, float h) {
        public float right() {
            return x + w;
        }

        public float bottom() {
            return y + h;
        }

        public float centerX() {
            return x + w / 2f;
        }

        public float centerY() {
            return y + h / 2f;
        }

        public boolean contains(float px, float py) {
            return px >= x && px < x + w && py >= y && py < y + h;
        }
    }

    public enum AlignMode { LEFT, RIGHT, TOP, BOTTOM, CENTER_HORIZONTAL, CENTER_VERTICAL }

    /** An element together with its current on-screen box. */
    public record Placed(HudElementState state, Box box) {
    }

    private HudGeometry() {
    }

    /**
     * Top-left of the element's box on a screen of the given size. The element's own anchor point
     * (e.g. its right edge for TOP_RIGHT) is placed at the screen anchor point plus the stored offset,
     * then the box is clamped to stay fully visible.
     *
     * @param contentW unscaled content width
     * @param contentH unscaled content height
     */
    public static Box place(HudElementState s, float contentW, float contentH, int screenW, int screenH) {
        float w = contentW * s.scale();
        float h = contentH * s.scale();
        Anchor a = s.anchor();
        float x = a.fx() * screenW + s.offsetX() - a.fx() * w;
        float y = a.fy() * screenH + s.offsetY() - a.fy() * h;
        return new Box(clampPosition(x, w, screenW), clampPosition(y, h, screenH), w, h);
    }

    private static float clampPosition(float pos, float size, int screen) {
        float max = Math.max(0f, screen - size);
        return MathUtil.clamp(pos, 0f, max);
    }

    /**
     * Moves the element so that its top-left is at {@code (x, y)} (after optional grid snapping and
     * clamping to the screen), choosing the nearest anchor so the element keeps its place when the
     * window is resized.
     *
     * @param snap grid step in pixels, or 0 for none
     */
    public static void moveTo(HudElementState s, float boxW, float boxH, float x, float y,
                              int screenW, int screenH, int snap) {
        float sx = snap > 0 ? (float) MathUtil.snap(x, snap) : x;
        float sy = snap > 0 ? (float) MathUtil.snap(y, snap) : y;
        sx = clampPosition(sx, boxW, screenW);
        sy = clampPosition(sy, boxH, screenH);
        Anchor a = Anchor.nearest(sx + boxW / 2f, sy + boxH / 2f, screenW, screenH);
        float offsetX = sx - (a.fx() * screenW - a.fx() * boxW);
        float offsetY = sy - (a.fy() * screenH - a.fy() * boxH);
        s.setPosition(a, offsetX, offsetY);
    }

    /** Aligns the given elements to the extreme edge / centre of the group, then re-anchors them. */
    public static void align(List<Placed> group, AlignMode mode, int screenW, int screenH, int snap) {
        if (group.size() < 2) {
            return;
        }
        float minX = Float.MAX_VALUE;
        float maxRight = -Float.MAX_VALUE;
        float minY = Float.MAX_VALUE;
        float maxBottom = -Float.MAX_VALUE;
        for (Placed p : group) {
            minX = Math.min(minX, p.box().x());
            maxRight = Math.max(maxRight, p.box().right());
            minY = Math.min(minY, p.box().y());
            maxBottom = Math.max(maxBottom, p.box().bottom());
        }
        float midX = (minX + maxRight) / 2f;
        float midY = (minY + maxBottom) / 2f;
        for (Placed p : group) {
            Box b = p.box();
            float x = b.x();
            float y = b.y();
            switch (mode) {
                case LEFT -> x = minX;
                case RIGHT -> x = maxRight - b.w();
                case TOP -> y = minY;
                case BOTTOM -> y = maxBottom - b.h();
                case CENTER_HORIZONTAL -> x = midX - b.w() / 2f;
                case CENTER_VERTICAL -> y = midY - b.h() / 2f;
            }
            moveTo(p.state(), b.w(), b.h(), x, y, screenW, screenH, snap);
        }
    }
}
