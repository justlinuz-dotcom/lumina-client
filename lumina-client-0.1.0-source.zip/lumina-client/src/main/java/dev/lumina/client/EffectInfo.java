package dev.lumina.client;

/** An active mob effect as exposed to the HUD. */
public record EffectInfo(String name, int amplifier, int durationTicks, boolean infinite) {

    /** Remaining seconds, rounded up; {@code -1} for infinite effects. */
    public int remainingSeconds() {
        return infinite ? -1 : (Math.max(0, durationTicks) + 19) / 20;
    }
}
