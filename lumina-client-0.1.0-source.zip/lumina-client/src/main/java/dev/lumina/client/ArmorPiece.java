package dev.lumina.client;

/**
 * One equipped or held item as exposed to the HUD. {@code maxDurability <= 0} means the item has no
 * durability (not damageable).
 */
public record ArmorPiece(String slot, String itemName, int durability, int maxDurability) {

    public boolean damageable() {
        return maxDurability > 0;
    }

    /** Remaining durability as a fraction in [0, 1]; 1 for items without durability. */
    public float fraction() {
        if (!damageable()) {
            return 1f;
        }
        return Math.max(0f, Math.min(1f, (float) durability / (float) maxDurability));
    }
}
