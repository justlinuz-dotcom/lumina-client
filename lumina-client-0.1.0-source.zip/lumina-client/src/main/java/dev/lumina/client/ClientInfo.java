package dev.lumina.client;

import dev.lumina.utils.Log;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Client identity. Everything here comes from {@code lumina-client.properties}, which Gradle fills from
 * {@code gradle.properties} (client_name, client_tagline, ...). Renaming the client therefore means
 * editing one value; no Java source references the display name directly.
 */
public final class ClientInfo {
    private static final String RESOURCE = "/lumina-client.properties";

    private static final String DEFAULT_NAME = "Lumina";
    private static final String DEFAULT_TAGLINE = "Modular client";
    private static final String DEFAULT_ID = "lumina";
    private static final String DEFAULT_VERSION = "dev";
    private static final String DEFAULT_MC = "1.21.11";

    private static final ClientInfo INSTANCE = load();

    private final String name;
    private final String tagline;
    private final String modId;
    private final String version;
    private final String targetMinecraft;

    ClientInfo(String name, String tagline, String modId, String version, String targetMinecraft) {
        this.name = name;
        this.tagline = tagline;
        this.modId = modId;
        this.version = version;
        this.targetMinecraft = targetMinecraft;
    }

    public static ClientInfo get() {
        return INSTANCE;
    }

    /** Builds an instance from properties; unexpanded {@code ${...}} placeholders fall back to defaults. */
    static ClientInfo from(Properties p) {
        return new ClientInfo(
                value(p, "name", DEFAULT_NAME),
                value(p, "tagline", DEFAULT_TAGLINE),
                value(p, "mod.id", DEFAULT_ID),
                value(p, "version", DEFAULT_VERSION),
                value(p, "target.minecraft", DEFAULT_MC));
    }

    private static String value(Properties p, String key, String fallback) {
        String v = p.getProperty(key);
        if (v == null || v.isBlank() || v.contains("${")) {
            return fallback;
        }
        return v.trim();
    }

    private static ClientInfo load() {
        Properties props = new Properties();
        try (InputStream in = ClientInfo.class.getResourceAsStream(RESOURCE)) {
            if (in != null) {
                props.load(in);
            }
        } catch (IOException e) {
            Log.of("client").warn("Could not read {}: {}", RESOURCE, e.toString());
        }
        return from(props);
    }

    public String name() {
        return name;
    }

    public String tagline() {
        return tagline;
    }

    public String modId() {
        return modId;
    }

    public String version() {
        return version;
    }

    public String targetMinecraft() {
        return targetMinecraft;
    }

    /** Name and version, for example {@code Lumina 0.1.0}. */
    public String displayName() {
        return name + " " + version;
    }
}
