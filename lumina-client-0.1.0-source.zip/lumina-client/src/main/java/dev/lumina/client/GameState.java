package dev.lumina.client;

import java.util.List;

/**
 * Read-only view of the running game. The core never touches Minecraft classes directly: the
 * Minecraft layer ({@code dev.lumina.mc}) implements this interface, and HUD calculations,
 * statistics and tests work against it. Values the game cannot provide return {@code -1}
 * or an empty list rather than an estimate.
 */
public interface GameState {

    /** Named keys the HUD can query (see {@link #keyDown(TrackedKey)}). */
    enum TrackedKey { FORWARD, BACK, LEFT, RIGHT, JUMP, SNEAK, SPRINT, ATTACK, USE }

    boolean inWorld();

    int fps();

    double x();

    double y();

    double z();

    /** Yaw in degrees as used by Minecraft (0 = south, 90 = west, 180 = north, 270 = east). */
    float yaw();

    /** Latency to the server in ms, or -1 when unknown (singleplayer without a measured latency). */
    int pingMs();

    /** Horizontal speed in blocks per second computed from client-side positions. */
    double speedBlocksPerSecond();

    boolean sprinting();

    boolean sneaking();

    boolean onGround();

    float fallDistance();

    /** Time of day in ticks (0..23999), or -1 when no world is loaded. */
    long timeOfDayTicks();

    /** Attack cooldown progress in [0, 1], or -1 when no player. */
    float attackCooldown();

    boolean keyDown(TrackedKey key);

    /** Equipped armour plus held items, in a stable order. */
    List<ArmorPiece> armor();

    List<EffectInfo> effects();

    /** Server address the client is connected to, or {@code null} in singleplayer / no connection. */
    String serverAddress();

    /** Short name of the current dimension (for example {@code overworld}, {@code the_nether}). */
    default String dimension() {
        return "overworld";
    }
}
