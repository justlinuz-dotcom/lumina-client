package dev.lumina.diagnostics;

import dev.lumina.utils.ErrorSink;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

/**
 * Collects recoverable errors for the diagnostics screen and bug reports. Memory only.
 *
 * <p>Privacy: messages are bounded, control characters are removed, and the user's home folder and
 * account name are replaced before anything is stored, so a report can be shared without exposing them.
 * No stack traces are kept. When the "keep error history" switch is off nothing is recorded.
 */
public final class ErrorHistory implements ErrorSink {
    public static final int MAX_ENTRIES = 50;
    public static final long MERGE_WINDOW_MILLIS = 5_000;
    private static final int MAX_MESSAGE = 300;

    public record Entry(long timeMillis, String source, String type, String message, int count) {
    }

    private final BooleanSupplier enabled;
    private final LongSupplier clock;
    private final String home;
    private final String user;
    private final Deque<Entry> entries = new ArrayDeque<>();
    private Consumer<Entry> listener = e -> {
    };

    public ErrorHistory(BooleanSupplier enabled, LongSupplier clock, String homeDirectory, String userName) {
        this.enabled = enabled;
        this.clock = clock;
        this.home = homeDirectory == null ? "" : homeDirectory;
        this.user = userName == null ? "" : userName;
    }

    /** Receives every recorded entry (used to show a notification). Runs on the reporting thread. */
    public synchronized void setListener(Consumer<Entry> listener) {
        this.listener = listener == null ? e -> {
        } : listener;
    }

    @Override
    public void report(String source, Throwable error) {
        if (!enabled.getAsBoolean()) {
            return;
        }
        long now = clock.getAsLong();
        String type = error == null ? "Unknown" : error.getClass().getSimpleName();
        String message = sanitize(error == null ? "" : String.valueOf(error.getMessage()));
        String src = sanitize(source == null ? "?" : source);
        Entry stored;
        Consumer<Entry> toNotify;
        synchronized (this) {
            Entry last = entries.peekFirst();
            if (last != null && last.source().equals(src) && last.type().equals(type) && last.message().equals(message)
                    && now - last.timeMillis() < MERGE_WINDOW_MILLIS) {
                entries.removeFirst();
                stored = new Entry(now, src, type, message, last.count() + 1);
            } else {
                stored = new Entry(now, src, type, message, 1);
            }
            entries.addFirst(stored);
            while (entries.size() > MAX_ENTRIES) {
                entries.removeLast();
            }
            toNotify = listener;
        }
        try {
            toNotify.accept(stored);
        } catch (RuntimeException ignored) {
            // reporting an error must never raise another one
        }
    }

    /** Newest first. */
    public synchronized List<Entry> entries() {
        return List.copyOf(entries);
    }

    public synchronized void clear() {
        entries.clear();
    }

    /** Plain text for the diagnostics export. */
    public synchronized String toText() {
        if (entries.isEmpty()) {
            return "No errors recorded.\n";
        }
        StringBuilder sb = new StringBuilder();
        for (Entry e : entries) {
            sb.append(e.timeMillis()).append("  ").append(e.source()).append("  ").append(e.type());
            if (!e.message().isEmpty()) {
                sb.append(": ").append(e.message());
            }
            if (e.count() > 1) {
                sb.append("  (x").append(e.count()).append(')');
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    /** Removes the home folder, account name and control characters from text that may be shared. */
    public String sanitize(String text) {
        String t = text.replaceAll("\\p{Cntrl}", " ");
        if (!home.isEmpty()) {
            t = t.replace(home, "~");
            t = t.replace(home.replace('\\', '/'), "~");
        }
        t = t.replaceAll("(?i)([A-Z]:[\\\\/]+Users[\\\\/]+)[^\\\\/\\s]+", "$1<user>");
        t = t.replaceAll("(/home/|/Users/)[^/\\s]+", "$1<user>");
        if (user.length() >= 3) {
            t = t.replace(user, "<user>");
        }
        t = t.trim();
        return t.length() > MAX_MESSAGE ? t.substring(0, MAX_MESSAGE - 1) + "…" : t;
    }

}
