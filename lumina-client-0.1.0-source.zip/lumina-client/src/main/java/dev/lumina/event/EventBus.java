package dev.lumina.event;

import dev.lumina.utils.ErrorSink;
import dev.lumina.utils.Log;
import org.slf4j.Logger;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Minimal internal event bus. Events are dispatched to subscribers of the event's exact class, in
 * subscription order. A failing listener never breaks the others or the caller: the exception is
 * reported to the {@link ErrorSink} and dispatch continues.
 */
public final class EventBus {
    private static final Logger LOG = Log.of("event");

    /** Handle returned by {@link #subscribe}; call {@link #cancel()} to unsubscribe. */
    public final class Subscription {
        private final Class<?> type;
        private final Consumer<Object> handler;

        private Subscription(Class<?> type, Consumer<Object> handler) {
            this.type = type;
            this.handler = handler;
        }

        public void cancel() {
            CopyOnWriteArrayList<Subscription> list = handlers.get(type);
            if (list != null) {
                list.remove(this);
            }
        }
    }

    private final Map<Class<?>, CopyOnWriteArrayList<Subscription>> handlers = new ConcurrentHashMap<>();
    private final ErrorSink errors;

    public EventBus(ErrorSink errors) {
        this.errors = Objects.requireNonNull(errors, "errors");
    }

    @SuppressWarnings("unchecked")
    public <E> Subscription subscribe(Class<E> type, Consumer<? super E> handler) {
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(handler, "handler");
        Subscription sub = new Subscription(type, event -> handler.accept((E) event));
        handlers.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>()).add(sub);
        return sub;
    }

    /** Dispatches the event and returns it so callers can inspect what listeners changed. */
    public <E> E post(E event) {
        Objects.requireNonNull(event, "event");
        CopyOnWriteArrayList<Subscription> list = handlers.get(event.getClass());
        if (list == null) {
            return event;
        }
        for (Subscription sub : list) {
            try {
                sub.handler.accept(event);
            } catch (RuntimeException | LinkageError e) {
                LOG.warn("Listener for {} failed: {}", event.getClass().getSimpleName(), e.toString());
                errors.report("event:" + event.getClass().getSimpleName(), e);
            }
        }
        return event;
    }

    public int listenerCount(Class<?> type) {
        CopyOnWriteArrayList<Subscription> list = handlers.get(type);
        return list == null ? 0 : list.size();
    }
}
