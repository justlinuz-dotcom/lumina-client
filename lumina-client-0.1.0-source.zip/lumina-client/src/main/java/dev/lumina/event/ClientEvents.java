package dev.lumina.event;

/**
 * Internal events posted on the {@link EventBus}. Plain immutable records with no dependency on
 * other client packages, so {@code event} stays at the bottom of the dependency graph.
 */
public final class ClientEvents {
    private ClientEvents() {
    }

    /** A module changed state through the module manager. */
    public record ModuleToggled(String moduleId, boolean enabled) {
    }

    /** The local player attacked an entity (informational; fired by the Minecraft layer). */
    public record PlayerAttacked(long timeMillis) {
    }

    /** The local player lost health (amount in half-hearts, as observed client-side). */
    public record PlayerDamaged(long timeMillis, float amount) {
    }

    /** A mouse button was pressed (0 = left, 1 = right); used for click statistics. */
    public record MouseClicked(long timeMillis, int button) {
    }

    /** The active profile changed. */
    public record ProfileSwitched(String previousId, String newId) {
    }
}
