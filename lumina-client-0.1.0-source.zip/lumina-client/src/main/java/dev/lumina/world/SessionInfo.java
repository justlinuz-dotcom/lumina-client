package dev.lumina.world;

import java.util.function.LongSupplier;

/** Information about the current play session (since the game was started). Held in memory only. */
public final class SessionInfo {
    private final LongSupplier clockMillis;
    private final long startMillis;

    public SessionInfo(LongSupplier clockMillis) {
        this.clockMillis = clockMillis;
        this.startMillis = clockMillis.getAsLong();
    }

    public long startMillis() {
        return startMillis;
    }

    public long elapsedMillis() {
        return Math.max(0, clockMillis.getAsLong() - startMillis);
    }

    public int elapsedSeconds() {
        return (int) Math.min(Integer.MAX_VALUE, elapsedMillis() / 1000);
    }
}
