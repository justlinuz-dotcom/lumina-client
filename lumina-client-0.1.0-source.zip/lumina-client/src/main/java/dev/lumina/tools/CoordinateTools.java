package dev.lumina.tools;

import dev.lumina.utils.MathUtil;

/** Coordinate arithmetic for the utility screen and waypoint arrows. Pure functions. */
public final class CoordinateTools {
    private CoordinateTools() {
    }

    /** Nether coordinates are 1/8 of overworld coordinates on the horizontal axes. */
    public static double overworldToNether(double coordinate) {
        return coordinate / 8.0;
    }

    public static double netherToOverworld(double coordinate) {
        return coordinate * 8.0;
    }

    public static int chunkOf(double blockCoordinate) {
        return (int) Math.floor(blockCoordinate / 16.0);
    }

    /** Position inside the chunk, 0..15. */
    public static int offsetInChunk(double blockCoordinate) {
        return Math.floorMod((int) Math.floor(blockCoordinate), 16);
    }

    /** Horizontal distance in blocks. */
    public static double distance(double x1, double z1, double x2, double z2) {
        return Math.hypot(x2 - x1, z2 - z1);
    }

    public static double distance3d(double x1, double y1, double z1, double x2, double y2, double z2) {
        return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1) + (z2 - z1) * (z2 - z1));
    }

    /**
     * Minecraft yaw (degrees, 0 = south/+Z, 90 = west/-X) that points from the origin towards ({@code dx}, {@code dz}),
     * in [0, 360). Returns 0 when both are 0.
     */
    public static float yawTowards(double dx, double dz) {
        if (dx == 0 && dz == 0) {
            return 0f;
        }
        return MathUtil.wrapDegrees360((float) Math.toDegrees(Math.atan2(-dx, dz)));
    }

    /**
     * Signed angle in (-180, 180] to turn from {@code playerYaw} to face {@code targetYaw}; positive means
     * turn right (clockwise seen from above).
     */
    public static float turnToFace(float playerYaw, float targetYaw) {
        float d = MathUtil.wrapDegrees360(targetYaw - playerYaw);
        return d > 180f ? d - 360f : d;
    }

    /** Formats a block position, for example {@code 12, 64, -30}. */
    public static String format(double x, double y, double z) {
        return Math.round(Math.floor(x)) + ", " + Math.round(Math.floor(y)) + ", " + Math.round(Math.floor(z));
    }

    /** Items as stacks and a remainder, for example 150 items of stack size 64 -> "2 stacks + 22". */
    public static String stacks(long items, int stackSize) {
        if (items < 0 || stackSize < 1) {
            return "--";
        }
        long full = items / stackSize;
        long rest = items % stackSize;
        if (full == 0) {
            return rest + (rest == 1 ? " item" : " items");
        }
        String stacks = full + (full == 1 ? " stack" : " stacks");
        return rest == 0 ? stacks : stacks + " + " + rest;
    }
}
