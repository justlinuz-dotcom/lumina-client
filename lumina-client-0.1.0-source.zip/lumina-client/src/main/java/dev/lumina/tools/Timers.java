package dev.lumina.tools;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.LongSupplier;

/**
 * Stopwatches and countdowns driven by an injectable clock (wall-clock milliseconds). Memory only.
 * A paused timer keeps its value; a countdown that reaches zero stays at zero and is reported once as
 * finished.
 */
public final class Timers {
    public static final int MAX_TIMERS = 10;

    public enum Kind { STOPWATCH, COUNTDOWN }

    public static final class Timer {
        private final int id;
        private final String label;
        private final Kind kind;
        private final long countdownMillis;
        private long accumulated;
        private long runningSince = -1;
        private boolean finishedReported;

        private Timer(int id, String label, Kind kind, long countdownMillis) {
            this.id = id;
            this.label = label;
            this.kind = kind;
            this.countdownMillis = countdownMillis;
        }

        public int id() {
            return id;
        }

        public String label() {
            return label;
        }

        public Kind kind() {
            return kind;
        }

        public boolean running() {
            return runningSince >= 0;
        }

        private long elapsed(long now) {
            return accumulated + (runningSince >= 0 ? Math.max(0, now - runningSince) : 0);
        }

        /** Stopwatch: elapsed time. Countdown: time left (never negative). */
        public long displayMillis(long now) {
            long e = elapsed(now);
            return kind == Kind.STOPWATCH ? e : Math.max(0, countdownMillis - e);
        }

        public boolean finished(long now) {
            return kind == Kind.COUNTDOWN && elapsed(now) >= countdownMillis;
        }
    }

    private final LongSupplier clock;
    private final List<Timer> timers = new ArrayList<>();
    private int nextId = 1;

    public Timers(LongSupplier clock) {
        this.clock = clock;
    }

    /** @return the new timer, or null when the limit is reached; the timer starts running immediately */
    public synchronized Timer start(Kind kind, String label, long countdownMillis) {
        if (timers.size() >= MAX_TIMERS) {
            return null;
        }
        long length = kind == Kind.COUNTDOWN ? Math.max(1000, Math.min(countdownMillis, 24L * 3600_000)) : 0;
        String name = label == null ? "" : label.replaceAll("\\p{Cntrl}", " ").trim();
        if (name.isEmpty()) {
            name = kind == Kind.STOPWATCH ? "Stopwatch" : "Timer";
        }
        if (name.length() > 24) {
            name = name.substring(0, 24);
        }
        Timer t = new Timer(nextId++, name, kind, length);
        t.runningSince = clock.getAsLong();
        timers.add(t);
        return t;
    }

    public synchronized void pause(int id) {
        Timer t = find(id);
        if (t != null && t.running()) {
            t.accumulated = t.elapsed(clock.getAsLong());
            t.runningSince = -1;
        }
    }

    public synchronized void resume(int id) {
        Timer t = find(id);
        if (t != null && !t.running() && !t.finished(clock.getAsLong())) {
            t.runningSince = clock.getAsLong();
        }
    }

    public synchronized void reset(int id) {
        Timer t = find(id);
        if (t != null) {
            t.accumulated = 0;
            t.runningSince = clock.getAsLong();
            t.finishedReported = false;
        }
    }

    public synchronized boolean remove(int id) {
        return timers.removeIf(t -> t.id == id);
    }

    public synchronized List<Timer> list() {
        return Collections.unmodifiableList(new ArrayList<>(timers));
    }

    /** Countdowns that finished since the last call; each one is returned exactly once. */
    public synchronized List<Timer> pollFinished() {
        long now = clock.getAsLong();
        List<Timer> done = new ArrayList<>();
        for (Timer t : timers) {
            if (t.finished(now) && !t.finishedReported) {
                t.finishedReported = true;
                t.accumulated = t.countdownMillis;
                t.runningSince = -1;
                done.add(t);
            }
        }
        return done;
    }

    private Timer find(int id) {
        for (Timer t : timers) {
            if (t.id == id) {
                return t;
            }
        }
        return null;
    }
}
