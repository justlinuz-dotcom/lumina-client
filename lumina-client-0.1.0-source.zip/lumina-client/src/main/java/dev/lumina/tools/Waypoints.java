package dev.lumina.tools;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.MathUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Private named positions ("home", "mine"). Stored on this computer; they are never shared and never
 * affect the game. The distance and direction helpers only compute numbers for the HUD and the screens.
 */
public final class Waypoints {
    public static final int MAX_WAYPOINTS = 100;
    public static final int MAX_NAME = 24;
    private static final double LIMIT = 30_000_000.0;

    public record Waypoint(String name, String dimension, int x, int y, int z, int argb) {
    }

    private final List<Waypoint> points = new ArrayList<>();
    private Runnable changeListener = () -> {
    };

    public void setChangeListener(Runnable listener) {
        this.changeListener = listener == null ? () -> {
        } : listener;
    }

    /** @return null on success, otherwise the reason it was refused */
    public synchronized String add(String name, String dimension, double x, double y, double z, int argb) {
        String clean = cleanName(name);
        if (clean.isEmpty()) {
            return "Give the waypoint a name";
        }
        if (indexOf(clean) >= 0) {
            return "There is already a waypoint called " + clean;
        }
        if (points.size() >= MAX_WAYPOINTS) {
            return "Too many waypoints (" + MAX_WAYPOINTS + ")";
        }
        if (!inRange(x) || !inRange(z) || !MathUtil.isFinite(y) || Math.abs(y) > 4096) {
            return "That position is outside the world";
        }
        points.add(new Waypoint(clean, cleanDimension(dimension), (int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z),
                argb | 0xFF000000));
        changeListener.run();
        return null;
    }

    public synchronized boolean remove(String name) {
        int i = indexOf(name);
        if (i < 0) {
            return false;
        }
        points.remove(i);
        changeListener.run();
        return true;
    }

    public synchronized List<Waypoint> list() {
        List<Waypoint> sorted = new ArrayList<>(points);
        sorted.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
        return Collections.unmodifiableList(sorted);
    }

    /** Waypoints of one dimension ordered by horizontal distance from the given position. */
    public synchronized List<Waypoint> nearest(String dimension, double x, double z, int limit) {
        List<Waypoint> out = new ArrayList<>();
        for (Waypoint w : points) {
            if (w.dimension().equals(dimension)) {
                out.add(w);
            }
        }
        out.sort((a, b) -> Double.compare(CoordinateTools.distance(x, z, a.x(), a.z()), CoordinateTools.distance(x, z, b.x(), b.z())));
        return out.size() > limit ? new ArrayList<>(out.subList(0, Math.max(0, limit))) : out;
    }

    private int indexOf(String name) {
        if (name == null) {
            return -1;
        }
        String key = name.trim().toLowerCase(Locale.ROOT);
        for (int i = 0; i < points.size(); i++) {
            if (points.get(i).name().toLowerCase(Locale.ROOT).equals(key)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean inRange(double v) {
        return MathUtil.isFinite(v) && Math.abs(v) <= LIMIT;
    }

    private static String cleanName(String name) {
        String t = name == null ? "" : name.replaceAll("\\p{Cntrl}", " ").trim();
        return t.length() > MAX_NAME ? t.substring(0, MAX_NAME).trim() : t;
    }

    private static String cleanDimension(String dimension) {
        String d = dimension == null ? "" : dimension.trim().toLowerCase(Locale.ROOT);
        return d.matches("[a-z0-9_.\\-]+:[a-z0-9_./\\-]+|[a-z0-9_.\\-]+") && d.length() <= 64 ? d : "overworld";
    }

    // ---- persistence ---------------------------------------------------------------------------

    public synchronized JsonObject toJson() {
        JsonArray array = new JsonArray();
        for (Waypoint w : points) {
            JsonObject o = new JsonObject();
            o.addProperty("name", w.name());
            o.addProperty("dimension", w.dimension());
            o.addProperty("x", w.x());
            o.addProperty("y", w.y());
            o.addProperty("z", w.z());
            o.addProperty("color", w.argb());
            array.add(o);
        }
        JsonObject root = new JsonObject();
        root.add("waypoints", array);
        return root;
    }

    public synchronized LoadReport loadJson(JsonObject root) {
        LoadReport report = new LoadReport();
        points.clear();
        JsonElement el = root.get("waypoints");
        if (el == null) {
            return report;
        }
        if (!el.isJsonArray()) {
            report.add("waypoints: expected a list, starting empty");
            return report;
        }
        for (JsonElement item : el.getAsJsonArray()) {
            if (!item.isJsonObject()) {
                report.add("waypoints: skipped an entry that is not an object");
                continue;
            }
            JsonObject o = item.getAsJsonObject();
            String problem = add(Json.string(o, "name", ""), Json.string(o, "dimension", "overworld"),
                    num(o, "x"), num(o, "y"), num(o, "z"), Json.integer(o, "color", 0xFFFFFFFF));
            if (problem != null) {
                report.add("waypoints: skipped '" + cleanName(Json.string(o, "name", "?")) + "': " + problem);
            }
        }
        return report;
    }

    private static double num(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber() ? e.getAsDouble() : Double.NaN;
    }
}
