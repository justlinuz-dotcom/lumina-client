package dev.lumina.tools;

import java.util.Locale;

/**
 * A small arithmetic calculator for the utility screen. It is a hand written parser: the text is never
 * evaluated as code, input length and nesting are bounded, and the result is always a finite number or a
 * clear error message.
 *
 * <p>Supported: {@code + - * / % ^}, parentheses, unary minus, {@code pi}, {@code e} and the functions
 * {@code sqrt abs floor ceil round min max}.
 */
public final class Calculator {
    public static final int MAX_LENGTH = 200;
    private static final int MAX_DEPTH = 40;

    public record Result(boolean ok, double value, String error) {
        static Result of(double v) {
            return new Result(true, v, "");
        }

        static Result fail(String message) {
            return new Result(false, Double.NaN, message);
        }

        /** Short text for the screen: whole numbers without decimals, others with up to 6 significant decimals. */
        public String display() {
            if (!ok) {
                return error;
            }
            if (value == Math.rint(value) && Math.abs(value) < 1e15) {
                return Long.toString((long) value);
            }
            String s = String.format(Locale.ROOT, "%.6f", value);
            s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
            return s;
        }
    }

    private static final class ParseException extends Exception {
        private static final long serialVersionUID = 1L;

        ParseException(String message) {
            super(message, null, false, false);
        }
    }

    private final String text;
    private int pos;
    private int depth;

    private Calculator(String text) {
        this.text = text;
    }

    public static Result evaluate(String input) {
        if (input == null || input.isBlank()) {
            return Result.fail("Type an expression");
        }
        if (input.length() > MAX_LENGTH) {
            return Result.fail("Expression is too long (max " + MAX_LENGTH + " characters)");
        }
        Calculator c = new Calculator(input.toLowerCase(Locale.ROOT));
        try {
            double v = c.expression();
            c.skipSpaces();
            if (c.pos < c.text.length()) {
                throw new ParseException("Unexpected '" + c.text.charAt(c.pos) + "'");
            }
            if (Double.isNaN(v) || Double.isInfinite(v)) {
                return Result.fail("Result is not a finite number");
            }
            return Result.of(v);
        } catch (ParseException e) {
            return Result.fail(e.getMessage());
        }
    }

    // expression := term (('+' | '-') term)*
    private double expression() throws ParseException {
        double v = term();
        while (true) {
            skipSpaces();
            if (accept('+')) {
                v += term();
            } else if (accept('-')) {
                v -= term();
            } else {
                return v;
            }
        }
    }

    // term := unary (('*' | '/' | '%') unary)*
    private double term() throws ParseException {
        double v = unary();
        while (true) {
            skipSpaces();
            if (accept('*')) {
                v *= unary();
            } else if (accept('/')) {
                double d = unary();
                if (d == 0) {
                    throw new ParseException("Division by zero");
                }
                v /= d;
            } else if (accept('%')) {
                double d = unary();
                if (d == 0) {
                    throw new ParseException("Division by zero");
                }
                v %= d;
            } else {
                return v;
            }
        }
    }

    // unary := ('-' | '+') unary | power      (so -2^2 is -(2^2), as in mathematics)
    private double unary() throws ParseException {
        skipSpaces();
        if (accept('-')) {
            enter();
            double v = -unary();
            depth--;
            return v;
        }
        if (accept('+')) {
            enter();
            double v = unary();
            depth--;
            return v;
        }
        return power();
    }

    // power := primary ('^' unary)?           (right associative; the exponent may be negative: 2^-1)
    private double power() throws ParseException {
        double base = primary();
        skipSpaces();
        if (accept('^')) {
            enter();
            double exp = unary();
            depth--;
            return Math.pow(base, exp);
        }
        return base;
    }

    private double primary() throws ParseException {
        skipSpaces();
        if (pos >= text.length()) {
            throw new ParseException("Expression ends too early");
        }
        char c = text.charAt(pos);
        if (c == '(') {
            pos++;
            enter();
            double v = expression();
            skipSpaces();
            if (!accept(')')) {
                throw new ParseException("Missing ')'");
            }
            depth--;
            return v;
        }
        if (Character.isDigit(c) || c == '.') {
            return number();
        }
        if (Character.isLetter(c)) {
            return nameOrCall();
        }
        throw new ParseException("Unexpected '" + c + "'");
    }

    private double number() throws ParseException {
        int start = pos;
        while (pos < text.length() && (Character.isDigit(text.charAt(pos)) || text.charAt(pos) == '.')) {
            pos++;
        }
        String s = text.substring(start, pos);
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            throw new ParseException("Bad number '" + s + "'");
        }
    }

    private double nameOrCall() throws ParseException {
        int start = pos;
        while (pos < text.length() && Character.isLetter(text.charAt(pos))) {
            pos++;
        }
        String name = text.substring(start, pos);
        skipSpaces();
        if (!accept('(')) {
            return switch (name) {
                case "pi" -> Math.PI;
                case "e" -> Math.E;
                default -> throw new ParseException("Unknown name '" + name + "'");
            };
        }
        enter();
        double a = expression();
        double b = Double.NaN;
        skipSpaces();
        boolean two = accept(',');
        if (two) {
            b = expression();
        }
        skipSpaces();
        if (!accept(')')) {
            throw new ParseException("Missing ')'");
        }
        depth--;
        switch (name) {
            case "min", "max" -> {
                if (!two) {
                    throw new ParseException(name + " needs two values");
                }
                return name.equals("min") ? Math.min(a, b) : Math.max(a, b);
            }
            case "sqrt" -> {
                requireOne(name, two);
                if (a < 0) {
                    throw new ParseException("Square root of a negative number");
                }
                return Math.sqrt(a);
            }
            case "abs" -> {
                requireOne(name, two);
                return Math.abs(a);
            }
            case "floor" -> {
                requireOne(name, two);
                return Math.floor(a);
            }
            case "ceil" -> {
                requireOne(name, two);
                return Math.ceil(a);
            }
            case "round" -> {
                requireOne(name, two);
                return Math.rint(a);
            }
            default -> throw new ParseException("Unknown function '" + name + "'");
        }
    }

    private static void requireOne(String name, boolean two) throws ParseException {
        if (two) {
            throw new ParseException(name + " takes one value");
        }
    }

    private void enter() throws ParseException {
        if (++depth > MAX_DEPTH) {
            throw new ParseException("Expression is nested too deeply");
        }
    }

    private boolean accept(char c) {
        if (pos < text.length() && text.charAt(pos) == c) {
            pos++;
            return true;
        }
        return false;
    }

    private void skipSpaces() {
        while (pos < text.length() && Character.isWhitespace(text.charAt(pos))) {
            pos++;
        }
    }
}
