package dev.lumina.options;

/**
 * Read/write access to the game's own video and input options. Implemented by the Minecraft adapter;
 * the core never touches the game directly. Implementations must be called from the client thread.
 */
public interface GameOptions {

    /** False when the running game version does not expose this option (the module then refuses to enable). */
    boolean supports(VideoOption option);

    /** Current value, already in the encoding documented on {@link VideoOption}. */
    int get(VideoOption option);

    /**
     * Sets the value. The game may adjust it (for example to its own limits); callers read it back with
     * {@link #get(VideoOption)} when they need the effective value.
     */
    void set(VideoOption option, int value);
}
