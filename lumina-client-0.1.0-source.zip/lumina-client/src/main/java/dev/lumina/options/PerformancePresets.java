package dev.lumina.options;

import dev.lumina.module.Preset;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Starting points for the video modules. They are plain value bundles, not promises: how much a preset
 * helps depends on the machine, the world and the other mods. Measure with the Performance Lab.
 *
 * <p>Every preset names every module it manages, so switching from one preset to another never leaves
 * a module of the previous one behind.
 */
public final class PerformancePresets {
    public static final String LOW_END = "low_end";
    public static final String BALANCED = "balanced";
    public static final String QUALITY = "quality";
    public static final String VANILLA = "vanilla";

    /** Modules managed by the presets (the performance-category video modules except the FPS limit). */
    public static final List<String> MANAGED = List.of("render_distance", "simulation_distance", "particles_level",
            "cloud_mode", "entity_shadows", "biome_blend", "entity_distance", "graphics_mode");

    private PerformancePresets() {
    }

    public static List<Preset> all() {
        return List.of(lowEnd(), balanced(), quality(), vanilla());
    }

    public static Preset lowEnd() {
        return build(LOW_END, "Low-end", 8, 6, "MINIMAL", "OFF", false, 0, 50, "FAST");
    }

    public static Preset balanced() {
        return build(BALANCED, "Balanced", 12, 10, "DECREASED", "FAST", true, 2, 100, "FANCY");
    }

    public static Preset quality() {
        return build(QUALITY, "Quality", 16, 12, "ALL", "FANCY", true, 5, 100, "FANCY");
    }

    /** Switches every managed module off, which gives back the player's own values. */
    public static Preset vanilla() {
        Map<String, Boolean> enabled = new HashMap<>();
        for (String id : MANAGED) {
            enabled.put(id, false);
        }
        return new Preset(VANILLA, "Vanilla (restore my settings)", enabled, Map.of());
    }

    private static Preset build(String id, String name, int render, int simulation, String particles, String clouds,
                                boolean shadows, int biomeBlend, int entityDistance, String graphics) {
        Map<String, Boolean> enabled = new HashMap<>();
        for (String module : MANAGED) {
            enabled.put(module, true);
        }
        Map<String, Map<String, Object>> values = new HashMap<>();
        values.put("render_distance", Map.of("value", render));
        values.put("simulation_distance", Map.of("value", simulation));
        values.put("particles_level", Map.of("value", particles));
        values.put("cloud_mode", Map.of("value", clouds));
        values.put("entity_shadows", Map.of("value", shadows));
        values.put("biome_blend", Map.of("value", biomeBlend));
        values.put("entity_distance", Map.of("value", entityDistance));
        values.put("graphics_mode", Map.of("value", graphics));
        return new Preset(id, name, enabled, values);
    }
}
