package dev.lumina.options;

import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.module.ModuleManager;
import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.EnumSetting;
import dev.lumina.setting.NumberSetting;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Modules that hold one of the game's own options at a chosen value. They change nothing the vanilla
 * video settings screen could not change; they exist so the values can be switched on and off with one
 * key, saved per profile and bundled into presets.
 *
 * <p>These modules do not make the game faster by themselves. What a lower render distance or fewer
 * particles is worth depends on the machine; use the Performance Lab to measure it.
 */
public final class VideoModules {
    private VideoModules() {
    }

    public enum ParticleLevel { ALL, DECREASED, MINIMAL }

    public enum CloudMode { OFF, FAST, FANCY }

    public enum GraphicsMode { FAST, FANCY, FABULOUS }

    public static List<VideoTweakModule> create(GameOptions game, VideoOriginals originals) {
        List<VideoTweakModule> all = new ArrayList<>();
        all.add(new IntTweak("render_distance", "Render Distance", "Holds the render distance (in chunks) at the chosen value.",
                Category.PERFORMANCE, VideoOption.RENDER_DISTANCE, 12, "chunks", game, originals));
        all.add(new IntTweak("simulation_distance", "Simulation Distance",
                "Holds the simulation distance (in chunks) at the chosen value. Entities and blocks farther away stop ticking.",
                Category.PERFORMANCE, VideoOption.SIMULATION_DISTANCE, 8, "chunks", game, originals));
        all.add(new EnumTweak<>("particles_level", "Particles", "Holds the particle setting at the chosen level.",
                Category.PERFORMANCE, VideoOption.PARTICLES, ParticleLevel.DECREASED, game, originals));
        all.add(new EnumTweak<>("cloud_mode", "Clouds", "Holds the cloud setting at the chosen mode.",
                Category.PERFORMANCE, VideoOption.CLOUDS, CloudMode.FAST, game, originals));
        all.add(new BoolTweak("entity_shadows", "Entity Shadows", "Turns the shadows under entities on or off.",
                Category.PERFORMANCE, VideoOption.ENTITY_SHADOWS, false, game, originals));
        all.add(new IntTweak("biome_blend", "Biome Blend", "Holds the biome blend radius at the chosen value (0 = off).",
                Category.PERFORMANCE, VideoOption.BIOME_BLEND, 2, "", game, originals));
        all.add(new IntTweak("entity_distance", "Entity Distance",
                "Holds the entity render distance at the chosen percentage of the default.",
                Category.PERFORMANCE, VideoOption.ENTITY_DISTANCE, 75, "%", game, originals));
        all.add(new IntTweak("fps_limit", "FPS Limit",
                "Holds the frame rate limit at the chosen value (the maximum means unlimited, like in the video settings).",
                Category.PERFORMANCE, VideoOption.FPS_LIMIT, 144, "fps", game, originals));
        all.add(new EnumTweak<>("graphics_mode", "Graphics Mode", "Holds the graphics mode at the chosen setting.",
                Category.PERFORMANCE, VideoOption.GRAPHICS, GraphicsMode.FAST, game, originals));
        all.add(new IntTweak("fov_changer", "FOV", "Holds the field of view at the chosen value, within the vanilla range.",
                Category.VISUALS, VideoOption.FOV, 90, "°", game, originals));
        all.add(new BoolTweak("view_bobbing", "View Bobbing", "Turns the camera bobbing while walking on or off.",
                Category.VISUALS, VideoOption.VIEW_BOBBING, false, game, originals));
        all.add(new IntTweak("brightness", "Brightness",
                "Holds the brightness at the chosen value. Limited to the vanilla maximum; it never goes beyond 'Bright'.",
                Category.VISUALS, VideoOption.BRIGHTNESS, 100, "%", game, originals));
        return all;
    }

    public static List<VideoTweakModule> register(ModuleManager manager, GameOptions game, VideoOriginals originals) {
        List<VideoTweakModule> modules = create(game, originals);
        for (VideoTweakModule m : modules) {
            manager.register(m);
        }
        return modules;
    }

    /**
     * Gives back the original value of every option that still has a record but whose module is not
     * enabled (the previous session ended while it was active and the module is now off). Call once at
     * startup, after the saved module states were applied.
     *
     * @return the options that were restored
     */
    public static Set<VideoOption> restoreLeftovers(GameOptions game, VideoOriginals originals,
                                                     Iterable<? extends VideoTweakModule> modules) {
        Set<VideoOption> active = EnumSet.noneOf(VideoOption.class);
        for (VideoTweakModule m : modules) {
            if (m.isEnabled()) {
                active.add(m.option());
            }
        }
        Set<VideoOption> restored = EnumSet.noneOf(VideoOption.class);
        for (VideoOption option : VideoOption.values()) {
            Integer saved = originals.get(option);
            if (saved == null || active.contains(option)) {
                continue;
            }
            if (game.supports(option)) {
                game.set(option, saved);
                restored.add(option);
            }
            originals.remove(option);
        }
        return restored;
    }

    // ---- implementations -----------------------------------------------------------------------

    private static final class IntTweak extends VideoTweakModule {
        private final NumberSetting value;

        IntTweak(String id, String name, String description, Category category, VideoOption option,
                 int defaultValue, String unit, GameOptions game, VideoOriginals originals) {
            super(id, name, description, category, option, game, originals);
            this.value = add(new NumberSetting("value", "Value", "The value to hold while this module is enabled.",
                    Math.max(option.min(), Math.min(option.max(), defaultValue)), option.min(), option.max(), 1, true, unit));
            watch(value);
        }

        @Override
        protected int desired() {
            return value.getInt();
        }
    }

    private static final class BoolTweak extends VideoTweakModule {
        private final BooleanSetting value;

        BoolTweak(String id, String name, String description, Category category, VideoOption option,
                  boolean defaultValue, GameOptions game, VideoOriginals originals) {
            super(id, name, description, category, option, game, originals);
            this.value = add(new BooleanSetting("value", "On", "Whether the option is on while this module is enabled.", defaultValue));
            watch(value);
        }

        @Override
        protected int desired() {
            return value.isOn() ? 1 : 0;
        }
    }

    private static final class EnumTweak<E extends Enum<E>> extends VideoTweakModule {
        private final EnumSetting<E> value;

        EnumTweak(String id, String name, String description, Category category, VideoOption option,
                  E defaultValue, GameOptions game, VideoOriginals originals) {
            super(id, name, description, category, option, game, originals);
            this.value = add(new EnumSetting<>("value", "Mode", "The mode to hold while this module is enabled.", defaultValue));
            watch(value);
        }

        @Override
        protected int desired() {
            return value.get().ordinal();
        }
    }

    /** Convenience for tests and presets. */
    public static boolean isVideoModule(ClientModule m) {
        return m instanceof VideoTweakModule;
    }
}
