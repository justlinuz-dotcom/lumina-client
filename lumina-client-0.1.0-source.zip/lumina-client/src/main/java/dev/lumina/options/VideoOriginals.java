package dev.lumina.options;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.LoadReport;

import java.util.EnumMap;
import java.util.Map;

/**
 * Remembers the value an option had <em>before</em> a module changed it, so that disabling the module
 * restores it. The values are persisted: if the game is closed or crashes while a tweak is active,
 * vanilla's own {@code options.txt} contains the tweaked value, and without this record the next session
 * would mistake it for the player's real setting.
 */
public final class VideoOriginals {
    private final Map<VideoOption, Integer> values = new EnumMap<>(VideoOption.class);
    private Runnable changeListener = () -> {
    };

    public void setChangeListener(Runnable listener) {
        this.changeListener = listener == null ? () -> {
        } : listener;
    }

    public synchronized Integer get(VideoOption option) {
        return values.get(option);
    }

    public synchronized void put(VideoOption option, int value) {
        values.put(option, value);
        changeListener.run();
    }

    public synchronized void remove(VideoOption option) {
        if (values.remove(option) != null) {
            changeListener.run();
        }
    }

    public synchronized int size() {
        return values.size();
    }

    public synchronized JsonObject toJson() {
        JsonObject o = new JsonObject();
        for (Map.Entry<VideoOption, Integer> e : values.entrySet()) {
            o.addProperty(e.getKey().name(), e.getValue());
        }
        return o;
    }

    /** Loads the record; unknown option names and values outside the option's range are dropped and reported. */
    public synchronized LoadReport loadJson(JsonObject json) {
        LoadReport report = new LoadReport();
        values.clear();
        for (Map.Entry<String, JsonElement> e : json.entrySet()) {
            VideoOption option;
            try {
                option = VideoOption.valueOf(e.getKey());
            } catch (IllegalArgumentException unknown) {
                report.add("video-originals: unknown option '" + e.getKey() + "' ignored");
                continue;
            }
            JsonElement v = e.getValue();
            if (!v.isJsonPrimitive() || !v.getAsJsonPrimitive().isNumber()) {
                report.add("video-originals: '" + e.getKey() + "' is not a number, ignored");
                continue;
            }
            double raw = v.getAsDouble();
            if (raw != Math.rint(raw) || raw < option.min() || raw > option.max()) {
                report.add("video-originals: '" + e.getKey() + "' out of range, ignored");
                continue;
            }
            values.put(option, (int) raw);
        }
        return report;
    }
}
