package dev.lumina.options;

import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.setting.Setting;

/**
 * A module that holds one game option at a value chosen by the player while it is enabled and gives the
 * original value back when it is disabled.
 *
 * <ul>
 *   <li>The original value is recorded (and persisted) before the first change.</li>
 *   <li>On disable the original is restored only if the option still has the value this module wrote; if the
 *       player changed it by hand in the meantime, their choice wins.</li>
 *   <li>On client shutdown the record is kept, so a session that ends while the module is active still knows
 *       the real original value on the next start.</li>
 * </ul>
 */
public abstract class VideoTweakModule extends ClientModule {
    private final VideoOption option;
    private final GameOptions game;
    private final VideoOriginals originals;

    private boolean active;
    private int original;
    private int applied;

    protected VideoTweakModule(String id, String name, String description, Category category,
                               VideoOption option, GameOptions game, VideoOriginals originals) {
        super(id, name, description, category);
        this.option = option;
        this.game = game;
        this.originals = originals;
    }

    public final VideoOption option() {
        return option;
    }

    /** The raw value (in the encoding of {@link VideoOption}) the settings currently ask for. */
    protected abstract int desired();

    /** Re-applies the value whenever the given setting changes while the module is enabled. */
    protected final void watch(Setting<?> setting) {
        setting.onChange(ignored -> {
            if (active) {
                write();
            }
        });
    }

    @Override
    protected final void onEnable() {
        if (!game.supports(option)) {
            throw new IllegalStateException("This game version does not expose the option '" + option + "'");
        }
        Integer saved = originals.get(option);
        int current = game.get(option);
        boolean recorded = false;
        if (saved == null) {
            originals.put(option, current);
            recorded = true;
            original = current;
        } else {
            original = saved;
        }
        try {
            write();
        } catch (RuntimeException e) {
            if (recorded) {
                originals.remove(option);
            }
            throw e;
        }
        active = true;
    }

    private void write() {
        game.set(option, option.clamp(desired()));
        applied = game.get(option);
    }

    @Override
    protected final void onDisable() {
        if (!active) {
            return;
        }
        active = false;
        if (game.get(option) == applied) {
            game.set(option, original);
        }
        if (!isShuttingDown()) {
            originals.remove(option);
        }
    }
}
