package dev.lumina.options;

/**
 * The game options the client may change, with the numeric range of the vanilla slider for each one.
 * Values are always integers so that the Minecraft adapter is a single get/set pair; choices are
 * encoded by position:
 *
 * <ul>
 *   <li>{@link #PARTICLES}: 0 = all, 1 = decreased, 2 = minimal</li>
 *   <li>{@link #CLOUDS}: 0 = off, 1 = fast, 2 = fancy</li>
 *   <li>{@link #GRAPHICS}: 0 = fast, 1 = fancy, 2 = fabulous</li>
 *   <li>on/off options: 0 = off, 1 = on</li>
 *   <li>{@link #BRIGHTNESS}: percent, 0 = moody ... 100 = bright (never above vanilla's maximum)</li>
 *   <li>{@link #ENTITY_DISTANCE}: percent of the default entity render distance</li>
 *   <li>{@link #FPS_LIMIT}: frames per second, 260 means "unlimited" like in the vanilla menu</li>
 * </ul>
 *
 * <p>The ranges are the ones of the vanilla video settings screen as the author knows them; the adapter
 * must still clamp to whatever the running game accepts, and the module reads the value back after
 * writing it.
 */
public enum VideoOption {
    RENDER_DISTANCE(2, 32),
    SIMULATION_DISTANCE(5, 32),
    PARTICLES(0, 2),
    CLOUDS(0, 2),
    ENTITY_SHADOWS(0, 1),
    BIOME_BLEND(0, 7),
    ENTITY_DISTANCE(50, 500),
    FPS_LIMIT(10, 260),
    GRAPHICS(0, 2),
    FOV(30, 110),
    VIEW_BOBBING(0, 1),
    BRIGHTNESS(0, 100);

    private final int min;
    private final int max;

    VideoOption(int min, int max) {
        this.min = min;
        this.max = max;
    }

    public int min() {
        return min;
    }

    public int max() {
        return max;
    }

    public int clamp(int value) {
        return Math.max(min, Math.min(max, value));
    }
}
