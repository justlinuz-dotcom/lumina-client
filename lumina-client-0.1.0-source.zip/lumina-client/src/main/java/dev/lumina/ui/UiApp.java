package dev.lumina.ui;

import dev.lumina.ClientContext;
import dev.lumina.module.ClientModule;
import dev.lumina.social.NotificationCenter;
import dev.lumina.ui.UiLayout.Placed;
import dev.lumina.ui.pages.CosmeticsPage;
import dev.lumina.ui.pages.HomePage;
import dev.lumina.ui.pages.ModulesPage;
import dev.lumina.ui.pages.PerformancePage;
import dev.lumina.ui.pages.ProfilesPage;
import dev.lumina.ui.pages.SettingsPage;
import dev.lumina.ui.pages.SocialPage;
import dev.lumina.ui.pages.ToolsPage;

import java.util.List;

/** The client menu as data: pages, the state of the open menu, and the input controller. */
public final class UiApp {
    public final ClientContext ctx;
    public final UiHost host;
    public final UiState state = new UiState();
    public final UiController controller;
    private final List<UiPage> pages;

    public UiApp(ClientContext ctx, UiHost host) {
        this.ctx = ctx;
        this.host = host;
        this.controller = new UiController(state, this::captureKey);
        this.pages = List.of(new HomePage(), new ModulesPage(), new ProfilesPage(), new PerformancePage(),
                new CosmeticsPage(), new SocialPage(), new ToolsPage(), new SettingsPage());
    }

    public List<UiPage> pages() {
        return pages;
    }

    public UiPage page() {
        return pages.get(state.pageIndex());
    }

    public void goTo(String title) {
        for (int i = 0; i < pages.size(); i++) {
            if (pages.get(i).title().equals(title)) {
                state.setPage(i);
                return;
            }
        }
    }

    public List<Row> rows() {
        return page().rows(this);
    }

    /** Rows placed inside a content area, ready to draw or to hit-test. */
    public List<Placed> layout(int x, int y, int w, int h) {
        List<Row> rows = rows();
        state.clampScroll(UiLayout.contentHeight(rows, gap()), h);
        return UiLayout.place(rows, x, y, w, state.scroll(), gap());
    }

    /** Pixels between rows: tighter when the player turned on "Compact lists". */
    public int gap() {
        return ctx.ui.compactLists.isOn() ? UiLayout.COMPACT_GAP : Row.GAP;
    }

    /** Total height of the current page's rows, for scrolling. */
    public int contentHeight() {
        return UiLayout.contentHeight(rows(), gap());
    }

    public void notify(NotificationCenter.Level level, String title, String message) {
        ctx.notifications.post(level, title, message, ctx.env.clock().getAsLong());
    }

    /**
     * Two-step confirmation for destructive actions. The first call remembers the key and returns false;
     * a second call with the same key returns true. Any other action resets it.
     */
    public boolean confirm(String key) {
        if (key.equals(state.pendingConfirm)) {
            state.pendingConfirm = null;
            return true;
        }
        state.pendingConfirm = key;
        return false;
    }

    public boolean isPendingConfirm(String key) {
        return key.equals(state.pendingConfirm);
    }

    /** Called with the key code while a module waits for its key binding. */
    private void captureKey(int key) {
        String id = state.listeningModule;
        state.listeningModule = null;
        if (id == null || key == UiController.KEY_ESCAPE) {
            return;
        }
        ClientModule m = ctx.modules.get(id).orElse(null);
        if (m == null) {
            return;
        }
        int wanted = key == UiController.KEY_BACKSPACE || key == UiController.KEY_DELETE ? ClientModule.KEY_UNBOUND : key;
        var result = ctx.modules.bindKey(m, wanted);
        if (!result.success()) {
            notify(NotificationCenter.Level.WARNING, m.name(), result.detail());
        }
    }
}
