package dev.lumina.ui;

import java.util.HashMap;
import java.util.Map;

/** Everything about a screen session that is not saved: scroll, typed text, what is expanded. */
public final class UiState {
    public static final int MAX_INPUT = 48;

    private final Map<String, String> inputs = new HashMap<>();
    private final Map<String, Integer> choices = new HashMap<>();
    private String focusedInput;
    private int scroll;
    private int pageIndex;

    /** Module whose settings are shown inside the Modules page. */
    public String expandedModule;
    /** Module waiting for the next key press to become its key binding. */
    public String listeningModule;
    /** Position in the module filter choices (All, Enabled, Favorites, then each category). */
    public int filterIndex;
    /** An action that needs a second click to confirm, for example {@code "delete:pvp"}. */
    public String pendingConfirm;

    public String input(String id) {
        return inputs.getOrDefault(id, "");
    }

    public void setInput(String id, String text) {
        inputs.put(id, text == null ? "" : text.length() > MAX_INPUT ? text.substring(0, MAX_INPUT) : text);
    }

    /** Position of a choice that is only remembered while the menu is open (for example the slot to import as). */
    public int choice(String id) {
        return choices.getOrDefault(id, 0);
    }

    public void setChoice(String id, int value) {
        choices.put(id, value);
    }

    public String focusedInput() {
        return focusedInput;
    }

    public void focus(String id) {
        this.focusedInput = id;
    }

    public int scroll() {
        return scroll;
    }

    public void setScroll(int value) {
        this.scroll = Math.max(0, value);
    }

    /** Keeps the scroll offset inside the content. */
    public void clampScroll(int contentHeight, int viewHeight) {
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - viewHeight)));
    }

    public int pageIndex() {
        return pageIndex;
    }

    /** Changes page and resets what belongs to the old one. */
    public void setPage(int index) {
        if (index != pageIndex) {
            pageIndex = index;
            scroll = 0;
            focusedInput = null;
            listeningModule = null;
            pendingConfirm = null;
        }
    }
}
