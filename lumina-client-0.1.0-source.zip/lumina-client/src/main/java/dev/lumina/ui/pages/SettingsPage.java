package dev.lumina.ui.pages;

import dev.lumina.ClientContext;
import dev.lumina.DiagnosticsReport;
import dev.lumina.config.SafeJsonFile;
import dev.lumina.diagnostics.ErrorHistory;
import dev.lumina.setting.Setting;
import dev.lumina.social.NotificationCenter.Level;
import dev.lumina.ui.Row;
import dev.lumina.ui.SettingRows;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiPage;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Appearance, interface, privacy and diagnostics. */
public final class SettingsPage implements UiPage {
    private static final int GREY = 0xFF9AA3B2;
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss", Locale.ROOT).withZone(ZoneOffset.UTC);

    @Override
    public String title() {
        return "Settings";
    }

    @Override
    public List<Row> rows(UiApp app) {
        ClientContext c = app.ctx;
        List<Row> rows = new ArrayList<>();
        rows.add(new Row.Heading("Appearance"));
        for (Setting<?> s : c.theme.group().settings()) {
            SettingRows.add(rows, s, 0);
        }
        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Interface"));
        for (Setting<?> s : c.ui.group().settings()) {
            SettingRows.add(rows, s, 0);
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Privacy"));
        rows.add(new Row.Label("This client has no telemetry, no update checker and no cosmetic sync service.", GREY));
        rows.add(new Row.Label("Everything it stores is in the '" + c.info.modId() + "' folder inside your game folder.", GREY));
        rows.add(new Row.Toggle("Keep a local error history", c.global.settings().keepErrorHistory(),
                "Errors are kept in memory for the diagnostics below. Nothing leaves your computer.",
                () -> {
                    c.global.settings().setKeepErrorHistory(!c.global.settings().keepErrorHistory());
                    c.global.save();
                }));

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Diagnostics"));
        rows.add(new Row.Label("Settings repaired at startup: " + c.startupWarnings().size()
                + "   Errors recorded: " + c.errors.entries().size()));
        for (int i = 0; i < Math.min(5, c.startupWarnings().size()); i++) {
            rows.add(new Row.Label("    " + c.errors.sanitize(c.startupWarnings().get(i)), GREY));
        }
        List<ErrorHistory.Entry> errors = c.errors.entries();
        for (int i = 0; i < Math.min(5, errors.size()); i++) {
            ErrorHistory.Entry e = errors.get(i);
            rows.add(new Row.Label("    " + e.source() + ": " + e.type() + (e.message().isEmpty() ? "" : " – " + e.message()), 0xFFE6C14D));
        }
        rows.add(new Row.Button("Export a diagnostics file", "", true,
                "Writes a text file to the diagnostics folder. It contains no player name, chat, coordinates or server address.",
                () -> export(app)));
        rows.add(new Row.Button("Clear error history", c.errors::clear));

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("About"));
        rows.add(new Row.Label(c.info.displayName() + " for Minecraft " + c.info.targetMinecraft() + " (Fabric)"));
        rows.add(new Row.Label("MIT licence. Sodium, Lithium and other mods are separate projects and are not included.", GREY));
        return rows;
    }

    private static void export(UiApp app) {
        ClientContext c = app.ctx;
        Path file = c.paths.diagnostics().resolve("diagnostics-" + STAMP.format(Instant.ofEpochMilli(c.env.clock().getAsLong())) + ".txt");
        try {
            SafeJsonFile.writeAtomically(file, DiagnosticsReport.build(c));
            app.notify(Level.SUCCESS, "Diagnostics exported", "Saved as " + file.getFileName() + " in the diagnostics folder");
        } catch (IOException e) {
            app.notify(Level.ERROR, "Export failed", e.getClass().getSimpleName());
        }
    }
}
