package dev.lumina.ui;

/** What the pages may ask the screen to do. Implemented by the Minecraft layer (and by tests). */
public interface UiHost {
    void openHudEditor();

    void closeScreen();
}
