package dev.lumina.ui.pages;

import dev.lumina.ClientContext;
import dev.lumina.cosmetics.CosmeticImporter;
import dev.lumina.cosmetics.CosmeticItem;
import dev.lumina.cosmetics.CosmeticLoadout;
import dev.lumina.cosmetics.Rarity;
import dev.lumina.cosmetics.Slot;
import dev.lumina.social.NotificationCenter.Level;
import dev.lumina.ui.Row;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiPage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Cosmetics: what you wear, saved loadouts and importing your own textures. Everything is local. */
public final class CosmeticsPage implements UiPage {
    public static final String LOADOUT_ID = "cosmetic_loadout";
    public static final String NAME_ID = "cosmetic_name";
    private static final String SLOT_CHOICE = "import_slot";
    private static final String RARITY_CHOICE = "import_rarity";
    private static final int GREY = 0xFF9AA3B2;

    @Override
    public String title() {
        return "Cosmetics";
    }

    @Override
    public List<Row> rows(UiApp app) {
        ClientContext c = app.ctx;
        CosmeticLoadout loadout = c.cosmetics;
        List<Row> rows = new ArrayList<>();
        rows.add(new Row.Heading("Cosmetics"));
        rows.add(new Row.Label(CosmeticLoadout.NOTICE, GREY));
        rows.add(new Row.Toggle("Show my cosmetics", loadout.visible(), "Turns every cosmetic off without forgetting what you chose.",
                () -> loadout.setVisible(!loadout.visible())));

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Wearing"));
        for (Slot slot : Slot.values()) {
            List<CosmeticItem> options = c.cosmeticCatalog.forSlot(slot);
            String current = loadout.worn(slot).map(CosmeticItem::name).orElse("None");
            rows.add(new Row.Choice(slot.label(), current, "Left click: next. Right click: previous.",
                    () -> cycle(app, slot, options, 1), () -> cycle(app, slot, options, -1), 0));
        }
        for (CosmeticItem item : loadout.toRender().values()) {
            rows.add(new Row.Label("    " + item.name() + " · " + item.rarity().label(), item.rarity().argb()));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Saved loadouts"));
        rows.add(new Row.Input("Name", LOADOUT_ID, "name for the loadout", "Saves what you are wearing now."));
        rows.add(new Row.Button("Save what I am wearing", () -> {
            String problem = loadout.savePreset(app.state.input(LOADOUT_ID));
            if (problem != null) {
                app.notify(Level.WARNING, "Loadout", problem);
            }
        }));
        for (Map.Entry<String, Map<Slot, String>> e : loadout.presets().entrySet()) {
            String name = e.getKey();
            rows.add(new Row.Button("Wear: " + name, () -> {
                String warning = loadout.applyPreset(name);
                if (warning != null) {
                    app.notify(Level.WARNING, name, warning);
                }
            }));
            String key = "delete_loadout:" + name;
            rows.add(new Row.Button(app.isPendingConfirm(key) ? "    Click again to delete " + name : "    Delete: " + name, () -> {
                if (app.confirm(key)) {
                    loadout.deletePreset(name);
                }
            }));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Import your own texture"));
        rows.add(new Row.Label("Put a .png in the imports folder. Only the plain file is read, it is checked, and a copy is stored.", GREY));
        rows.add(new Row.Label("Expected sizes: cape " + Slot.CAPE.sizeHint() + "; hat and back " + Slot.HAT.sizeHint() + ".", GREY));
        Slot[] slots = Slot.values();
        Rarity[] rarities = Rarity.values();
        int slotIndex = app.state.choice(SLOT_CHOICE) % slots.length;
        int rarityIndex = app.state.choice(RARITY_CHOICE) % rarities.length;
        rows.add(new Row.Input("Name", NAME_ID, "name for the cosmetic", "Letters, digits, spaces, '_', '-' and '.'."));
        rows.add(new Row.Choice("Worn on", slots[slotIndex].label(), "", () -> advance(app, SLOT_CHOICE, slotIndex, 1, slots.length),
                () -> advance(app, SLOT_CHOICE, slotIndex, -1, slots.length), 0));
        rows.add(new Row.Choice("Label", rarities[rarityIndex].label(), "Only used to group items in the menu.",
                () -> advance(app, RARITY_CHOICE, rarityIndex, 1, rarities.length),
                () -> advance(app, RARITY_CHOICE, rarityIndex, -1, rarities.length), 0));
        List<String> files = c.paths.importFiles(".png");
        if (files.isEmpty()) {
            rows.add(new Row.Label("No .png files found in the imports folder."));
        }
        for (String f : files) {
            rows.add(new Row.Button("Import " + f, "", true, "Uses the name, slot and label chosen above.", () -> {
                CosmeticImporter.ImportResult r = c.cosmeticImporter.importPng(f, app.state.input(NAME_ID), slots[slotIndex], rarities[rarityIndex]);
                app.notify(r.ok() ? Level.SUCCESS : Level.WARNING, "Import", r.message());
            }));
        }
        for (CosmeticItem item : c.cosmeticCatalog.all()) {
            if (!item.isImported()) {
                continue;
            }
            String key = "remove_cosmetic:" + item.id();
            rows.add(new Row.Button(app.isPendingConfirm(key) ? "Click again to remove " + item.name() : "Remove imported: " + item.name(), () -> {
                if (app.confirm(key)) {
                    boolean wornNow = loadout.worn(item.slot()).map(w -> w.id().equals(item.id())).orElse(false);
                    c.cosmeticImporter.remove(item.id());
                    if (wornNow) {
                        loadout.unequip(item.slot());
                    }
                }
            }));
        }
        return rows;
    }

    private static void cycle(UiApp app, Slot slot, List<CosmeticItem> options, int delta) {
        CosmeticLoadout loadout = app.ctx.cosmetics;
        // position 0 means "nothing"; 1..n are the items
        int current = loadout.worn(slot).map(w -> options.indexOf(w) + 1).orElse(0);
        int next = Math.floorMod(current + delta, options.size() + 1);
        if (next == 0) {
            loadout.unequip(slot);
        } else {
            loadout.equip(slot, options.get(next - 1).id());
        }
    }

    private static void advance(UiApp app, String id, int current, int delta, int size) {
        app.state.setChoice(id, Math.floorMod(current + delta, size));
    }
}
