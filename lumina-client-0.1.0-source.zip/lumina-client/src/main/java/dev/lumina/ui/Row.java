package dev.lumina.ui;

import java.util.function.DoubleConsumer;

/**
 * One line of a screen page. Pages describe what to show as a list of rows; the Minecraft screen only
 * draws them and forwards the mouse and keyboard. Because rows are plain data with callbacks, every page
 * can be exercised in tests without the game.
 */
public sealed interface Row {
    int GAP = 2;

    int height();

    /** Tooltip text shown while the row is hovered, or empty. */
    default String tip() {
        return "";
    }

    record Heading(String text) implements Row {
        @Override
        public int height() {
            return 22;
        }
    }

    /** A line of text. {@code argb == 0} means the theme's normal text colour. */
    record Label(String text, int argb) implements Row {
        public Label(String text) {
            this(text, 0);
        }

        @Override
        public int height() {
            return 13;
        }
    }

    record Spacer(int pixels) implements Row {
        @Override
        public int height() {
            return Math.max(1, pixels);
        }
    }

    record Button(String label, String hint, boolean enabled, String tip, Runnable action) implements Row {
        public Button(String label, Runnable action) {
            this(label, "", true, "", action);
        }

        @Override
        public int height() {
            return 18;
        }
    }

    /** On/off switch. A right click runs {@code secondary} (for example "expand settings") when set. */
    record Toggle(String label, boolean on, String tip, Runnable action, Runnable secondary, int indent) implements Row {
        public Toggle(String label, boolean on, String tip, Runnable action) {
            this(label, on, tip, action, null, 0);
        }

        @Override
        public int height() {
            return 18;
        }
    }

    /** Value between 0 and 1 mapped by the page to a real range. */
    record Slider(String label, double fraction, String valueText, String tip, DoubleConsumer onChange, int indent) implements Row {
        @Override
        public int height() {
            return 18;
        }
    }

    /** Pick one of several values: left click goes forward, right click goes back. */
    record Choice(String label, String value, String tip, Runnable next, Runnable previous, int indent) implements Row {
        @Override
        public int height() {
            return 18;
        }
    }

    /** A colour swatch that cycles through a palette like {@link Choice}. */
    record ColorChoice(String label, int argb, String tip, Runnable next, Runnable previous, int indent) implements Row {
        @Override
        public int height() {
            return 18;
        }
    }

    /** Single line text field. The text itself lives in {@link UiState#input(String)}. */
    record Input(String label, String id, String placeholder, String tip) implements Row {
        @Override
        public int height() {
            return 18;
        }
    }
}
