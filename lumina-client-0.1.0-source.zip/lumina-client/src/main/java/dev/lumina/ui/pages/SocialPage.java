package dev.lumina.ui.pages;

import dev.lumina.ClientContext;
import dev.lumina.social.Friends;
import dev.lumina.social.NotificationCenter;
import dev.lumina.social.NotificationCenter.Level;
import dev.lumina.social.Notes;
import dev.lumina.social.ServerHistory;
import dev.lumina.ui.Row;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiPage;
import dev.lumina.utils.MathUtil;

import java.util.ArrayList;
import java.util.List;

/** Friends, notes, server history and notifications. All of it stays on this computer. */
public final class SocialPage implements UiPage {
    public static final String FRIEND_ID = "friend_name";
    public static final String FRIEND_NOTE_ID = "friend_note";
    public static final String NOTE_TITLE_ID = "note_title";
    public static final String NOTE_TEXT_ID = "note_text";
    private static final int GREY = 0xFF9AA3B2;

    @Override
    public String title() {
        return "Social";
    }

    @Override
    public List<Row> rows(UiApp app) {
        ClientContext c = app.ctx;
        List<Row> rows = new ArrayList<>();
        rows.add(new Row.Heading("Friends"));
        rows.add(new Row.Label("A private list kept on this computer. Nothing is sent anywhere and names are not looked up.", GREY));
        rows.add(new Row.Input("Player name", FRIEND_ID, "3 to 16 letters, digits or _", ""));
        rows.add(new Row.Input("Note", FRIEND_NOTE_ID, "optional", ""));
        rows.add(new Row.Button("Add friend", () -> {
            String problem = c.friends.add(app.state.input(FRIEND_ID), app.state.input(FRIEND_NOTE_ID), c.env.clock().getAsLong());
            if (problem != null) {
                app.notify(Level.WARNING, "Friends", problem);
            } else {
                app.state.setInput(FRIEND_ID, "");
                app.state.setInput(FRIEND_NOTE_ID, "");
            }
        }));
        for (Friends.Entry f : c.friends.list()) {
            rows.add(new Row.Button(f.name() + (f.note().isEmpty() ? "" : "  ·  " + f.note()), "remove", true,
                    "Click to remove from the list.", () -> c.friends.remove(f.name())));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Notes"));
        rows.add(new Row.Input("Title", NOTE_TITLE_ID, "title", ""));
        rows.add(new Row.Input("Text", NOTE_TEXT_ID, "short text", "Notes are stored on this computer only."));
        rows.add(new Row.Button("Add note", () -> {
            int id = c.notes.add(app.state.input(NOTE_TITLE_ID), app.state.input(NOTE_TEXT_ID), c.env.clock().getAsLong());
            if (id < 0) {
                app.notify(Level.WARNING, "Notes", "You can keep at most " + Notes.MAX_NOTES + " notes");
            } else {
                app.state.setInput(NOTE_TITLE_ID, "");
                app.state.setInput(NOTE_TEXT_ID, "");
            }
        }));
        for (Notes.Note n : c.notes.list()) {
            String text = n.text().replace('\n', ' ');
            rows.add(new Row.Button(n.title() + (text.isEmpty() ? "" : "  ·  " + shorten(text, 40)), "remove", true,
                    "Click to delete this note.", () -> c.notes.remove(n.id())));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Server history"));
        rows.add(new Row.Toggle("Remember the servers I play on", c.global.settings().keepServerHistory(),
                "Off by default. Only the server address and play time are stored, on this computer.",
                () -> {
                    c.global.settings().setKeepServerHistory(!c.global.settings().keepServerHistory());
                    c.global.save();
                }));
        for (ServerHistory.Visit v : c.serverHistory.list()) {
            rows.add(new Row.Label("    " + v.host() + "  ·  " + v.visits() + (v.visits() == 1 ? " visit" : " visits")
                    + "  ·  " + MathUtil.formatDuration(v.totalSeconds() * 1000)));
        }
        String clearKey = "clear_history";
        rows.add(new Row.Button(app.isPendingConfirm(clearKey) ? "Click again to clear the history" : "Clear server history", "", true, "",
                () -> {
                    if (app.confirm(clearKey)) {
                        c.serverHistory.clear();
                    }
                }));

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Notifications"));
        rows.add(new Row.Toggle("Show notifications", c.ui.notifications.isOn(), "", () -> c.ui.notifications.set(!c.ui.notifications.isOn())));
        rows.add(new Row.Toggle("Mute for now", c.notifications.isMuted(), "Hides pop-ups; they are still listed below.",
                () -> c.notifications.setMuted(!c.notifications.isMuted())));
        List<NotificationCenter.Notification> history = c.notifications.history();
        for (int i = 0; i < Math.min(5, history.size()); i++) {
            NotificationCenter.Notification n = history.get(i);
            rows.add(new Row.Label("    " + n.title() + (n.message().isEmpty() ? "" : ": " + n.message()), GREY));
        }
        return rows;
    }

    private static String shorten(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}
