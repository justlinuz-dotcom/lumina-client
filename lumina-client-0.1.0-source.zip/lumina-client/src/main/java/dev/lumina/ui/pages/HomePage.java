package dev.lumina.ui.pages;

import dev.lumina.ClientContext;
import dev.lumina.compat.CompatChecker;
import dev.lumina.ui.Row;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiPage;
import dev.lumina.utils.MathUtil;

import java.util.ArrayList;
import java.util.List;

/** Welcome page: status at a glance and shortcuts. */
public final class HomePage implements UiPage {
    private static final int WARNING = 0xFFE6C14D;
    private static final int ERROR = 0xFFE5594F;

    @Override
    public String title() {
        return "Home";
    }

    @Override
    public List<Row> rows(UiApp app) {
        ClientContext c = app.ctx;
        List<Row> rows = new ArrayList<>();
        rows.add(new Row.Heading(c.info.displayName()));
        rows.add(new Row.Label(c.info.tagline() + " · Minecraft " + c.info.targetMinecraft()));
        rows.add(new Row.Spacer(6));
        rows.add(new Row.Label("Profile: " + c.global.settings().activeProfile()));
        rows.add(new Row.Label("Modules on: " + c.modules.enabled().size() + " of " + c.allModules().size()));
        rows.add(new Row.Label("FPS: " + (int) Math.round(c.frames.currentFps())
                + "   Session: " + MathUtil.formatDuration(c.session.elapsedMillis())));

        boolean anyNote = false;
        for (CompatChecker.Note n : c.compatibility()) {
            if (n.level() == CompatChecker.Level.ERROR || n.level() == CompatChecker.Level.WARNING) {
                if (!anyNote) {
                    rows.add(new Row.Spacer(6));
                    rows.add(new Row.Heading("Attention"));
                    anyNote = true;
                }
                rows.add(new Row.Label(n.message(), n.level() == CompatChecker.Level.ERROR ? ERROR : WARNING));
            }
        }
        if (!c.startupWarnings().isEmpty()) {
            rows.add(new Row.Label(c.startupWarnings().size() + " setting(s) were repaired at startup (see Settings › Diagnostics).", WARNING));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Shortcuts"));
        rows.add(new Row.Button("Browse modules", () -> app.goTo("Modules")));
        rows.add(new Row.Button("Edit HUD layout", app.host::openHudEditor));
        rows.add(new Row.Button("Performance Lab", () -> app.goTo("Performance")));
        rows.add(new Row.Button("Profiles", () -> app.goTo("Profiles")));
        rows.add(new Row.Button("Cosmetics", () -> app.goTo("Cosmetics")));
        rows.add(new Row.Spacer(6));
        rows.add(new Row.Label("Press " + dev.lumina.ui.KeyNames.of(c.ui.clickGuiKey.getInt()) + " to open this menu."));
        return rows;
    }
}
