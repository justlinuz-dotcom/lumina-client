package dev.lumina.ui.pages;

import dev.lumina.ClientContext;
import dev.lumina.client.GameState;
import dev.lumina.social.NotificationCenter.Level;
import dev.lumina.tools.Calculator;
import dev.lumina.tools.CoordinateTools;
import dev.lumina.tools.Timers;
import dev.lumina.tools.Waypoints;
import dev.lumina.ui.Row;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiPage;
import dev.lumina.utils.MathUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Utilities: calculator, coordinates, waypoints, timers and a stack counter. */
public final class ToolsPage implements UiPage {
    public static final String CALC_ID = "calc_expression";
    public static final String WAYPOINT_ID = "waypoint_name";
    public static final String TIMER_ID = "timer_minutes";
    public static final String ITEMS_ID = "stack_items";
    private static final int GREY = 0xFF9AA3B2;

    @Override
    public String title() {
        return "Tools";
    }

    @Override
    public List<Row> rows(UiApp app) {
        ClientContext c = app.ctx;
        GameState g = c.env.game();
        List<Row> rows = new ArrayList<>();

        rows.add(new Row.Heading("Calculator"));
        rows.add(new Row.Input("Expression", CALC_ID, "for example (64*9)+12", "+ - * / % ^, parentheses, sqrt abs floor ceil round min max, pi, e"));
        String expression = app.state.input(CALC_ID);
        if (!expression.isBlank()) {
            Calculator.Result r = Calculator.evaluate(expression);
            rows.add(new Row.Label("= " + r.display(), r.ok() ? 0 : 0xFFE5594F));
        }
        rows.add(new Row.Input("Items", ITEMS_ID, "a number of items", "Shows stacks of 64 and of 16."));
        String items = app.state.input(ITEMS_ID).trim();
        if (!items.isEmpty()) {
            try {
                long n = Long.parseLong(items);
                rows.add(new Row.Label("= " + CoordinateTools.stacks(n, 64) + "  (stacks of 16: " + CoordinateTools.stacks(n, 16) + ")"));
            } catch (NumberFormatException e) {
                rows.add(new Row.Label("Type a whole number", 0xFFE5594F));
            }
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Coordinates"));
        if (!g.inWorld()) {
            rows.add(new Row.Label("Join a world to see your coordinates.", GREY));
        } else {
            rows.add(new Row.Label("You: " + CoordinateTools.format(g.x(), g.y(), g.z()) + "  ·  " + g.dimension()));
            rows.add(new Row.Label("Chunk: " + CoordinateTools.chunkOf(g.x()) + ", " + CoordinateTools.chunkOf(g.z())
                    + "  (inside it: " + CoordinateTools.offsetInChunk(g.x()) + ", " + CoordinateTools.offsetInChunk(g.z()) + ")"));
            rows.add(new Row.Label(String.format(Locale.ROOT, "Same place in the Nether: %.0f, %.0f   In the Overworld (if you are in the Nether): %.0f, %.0f",
                    CoordinateTools.overworldToNether(g.x()), CoordinateTools.overworldToNether(g.z()),
                    CoordinateTools.netherToOverworld(g.x()), CoordinateTools.netherToOverworld(g.z())), GREY));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Waypoints"));
        rows.add(new Row.Input("Name", WAYPOINT_ID, "name for this place", "Waypoints stay on this computer."));
        rows.add(new Row.Button("Save my position", "", g.inWorld(), "Needs a loaded world.", () -> {
            String problem = c.waypoints.add(app.state.input(WAYPOINT_ID), g.dimension(), g.x(), g.y(), g.z(), 0xFF5B8CFF);
            if (problem != null) {
                app.notify(Level.WARNING, "Waypoints", problem);
            } else {
                app.state.setInput(WAYPOINT_ID, "");
            }
        }));
        List<Waypoints.Waypoint> here = g.inWorld() ? c.waypoints.nearest(g.dimension(), g.x(), g.z(), 20) : List.of();
        for (Waypoints.Waypoint w : here) {
            double distance = CoordinateTools.distance(g.x(), g.z(), w.x(), w.z());
            float turn = CoordinateTools.turnToFace(g.yaw(), CoordinateTools.yawTowards(w.x() - g.x(), w.z() - g.z()));
            String direction = Math.abs(turn) < 10 ? "ahead" : turn > 0 ? String.format(Locale.ROOT, "%.0f° right", turn)
                    : String.format(Locale.ROOT, "%.0f° left", -turn);
            rows.add(new Row.Button(String.format(Locale.ROOT, "%s  ·  %.0f blocks  ·  %s", w.name(), distance, direction), "remove", true,
                    CoordinateTools.format(w.x(), w.y(), w.z()) + ". Click to delete.", () -> c.waypoints.remove(w.name())));
        }
        if (here.isEmpty() && !c.waypoints.list().isEmpty()) {
            rows.add(new Row.Label("None in this dimension (" + c.waypoints.list().size() + " saved elsewhere).", GREY));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Timers"));
        rows.add(new Row.Input("Minutes", TIMER_ID, "length of a countdown", "For example 5 or 0.5."));
        rows.add(new Row.Button("Start countdown", () -> startCountdown(app)));
        rows.add(new Row.Button("Start stopwatch", () -> {
            if (c.timers.start(Timers.Kind.STOPWATCH, "Stopwatch", 0) == null) {
                app.notify(Level.WARNING, "Timers", "At most " + Timers.MAX_TIMERS + " timers");
            }
        }));
        long now = c.env.clock().getAsLong();
        for (Timers.Timer t : c.timers.list()) {
            String time = MathUtil.formatDuration(t.displayMillis(now));
            String state = t.running() ? "running" : t.finished(now) ? "finished" : "paused";
            rows.add(new Row.Toggle(t.label() + "  " + time + "  (" + state + ")", t.running(), "Click to pause or resume. Right click to remove.",
                    () -> {
                        if (t.running()) {
                            c.timers.pause(t.id());
                        } else {
                            c.timers.resume(t.id());
                        }
                    }, () -> c.timers.remove(t.id()), 0));
        }
        return rows;
    }

    private static void startCountdown(UiApp app) {
        String text = app.state.input(TIMER_ID).trim().replace(',', '.');
        double minutes;
        try {
            minutes = Double.parseDouble(text);
        } catch (NumberFormatException e) {
            app.notify(Level.WARNING, "Timers", "Type the length in minutes, for example 5");
            return;
        }
        if (!MathUtil.isFinite(minutes) || minutes <= 0) {
            app.notify(Level.WARNING, "Timers", "The length must be above zero");
            return;
        }
        if (app.ctx.timers.start(Timers.Kind.COUNTDOWN, "Timer", (long) (minutes * 60_000)) == null) {
            app.notify(Level.WARNING, "Timers", "At most " + Timers.MAX_TIMERS + " timers");
        }
    }
}
