package dev.lumina.ui;

import java.util.HashMap;
import java.util.Map;

/** Readable names for GLFW key codes (the numbers Minecraft uses for keyboard keys). */
public final class KeyNames {
    private static final Map<Integer, String> NAMES = new HashMap<>();

    static {
        for (int c = 'A'; c <= 'Z'; c++) {
            NAMES.put(c, String.valueOf((char) c));
        }
        for (int c = '0'; c <= '9'; c++) {
            NAMES.put(c, String.valueOf((char) c));
        }
        for (int i = 1; i <= 12; i++) {
            NAMES.put(289 + i, "F" + i);
        }
        NAMES.put(32, "Space");
        NAMES.put(39, "'");
        NAMES.put(44, ",");
        NAMES.put(45, "-");
        NAMES.put(46, ".");
        NAMES.put(47, "/");
        NAMES.put(59, ";");
        NAMES.put(61, "=");
        NAMES.put(91, "[");
        NAMES.put(92, "\\");
        NAMES.put(93, "]");
        NAMES.put(96, "`");
        NAMES.put(256, "Esc");
        NAMES.put(257, "Enter");
        NAMES.put(258, "Tab");
        NAMES.put(259, "Backspace");
        NAMES.put(260, "Insert");
        NAMES.put(261, "Delete");
        NAMES.put(262, "Right");
        NAMES.put(263, "Left");
        NAMES.put(264, "Down");
        NAMES.put(265, "Up");
        NAMES.put(266, "Page Up");
        NAMES.put(267, "Page Down");
        NAMES.put(268, "Home");
        NAMES.put(269, "End");
        NAMES.put(280, "Caps Lock");
        for (int i = 0; i <= 9; i++) {
            NAMES.put(320 + i, "Numpad " + i);
        }
        NAMES.put(340, "Left Shift");
        NAMES.put(341, "Left Ctrl");
        NAMES.put(342, "Left Alt");
        NAMES.put(344, "Right Shift");
        NAMES.put(345, "Right Ctrl");
        NAMES.put(346, "Right Alt");
    }

    private KeyNames() {
    }

    public static String of(int keyCode) {
        if (keyCode < 0) {
            return "None";
        }
        return NAMES.getOrDefault(keyCode, "Key " + keyCode);
    }
}
