package dev.lumina.ui;

import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.ColorSetting;
import dev.lumina.setting.EnumSetting;
import dev.lumina.setting.NumberSetting;
import dev.lumina.setting.Setting;

import java.util.List;

/** Turns settings into rows. Used by the module list and the settings page. */
public final class SettingRows {
    /** Colours a colour setting cycles through when clicked. */
    public static final int[] PALETTE = {
            0xFFFFFFFF, 0xFFE5594F, 0xFFFF9F43, 0xFFE6C14D, 0xFF55D68A, 0xFF4FD1D9, 0xFF5B8CFF, 0xFFB06BFF, 0xFFFF7EB6, 0xFF000000};

    private SettingRows() {
    }

    public static void add(List<Row> out, Setting<?> setting, int indent) {
        if (!setting.isVisible()) {
            return;
        }
        String tip = setting.description();
        switch (setting) {
            case BooleanSetting b -> out.add(new Row.Toggle(b.name(), b.isOn(), tip, () -> b.set(!b.isOn()), null, indent));
            case NumberSetting n -> {
                double range = n.max() - n.min();
                double fraction = range <= 0 ? 0 : (n.getDouble() - n.min()) / range;
                out.add(new Row.Slider(n.name(), fraction, n.display(), tip,
                        f -> n.set(n.min() + f * range), indent));
            }
            case EnumSetting<?> e -> out.add(enumRow(e, tip, indent));
            case ColorSetting c -> out.add(new Row.ColorChoice(c.name(), c.argb(), tip,
                    () -> c.set(step(c.argb(), 1)), () -> c.set(step(c.argb(), -1)), indent));
            default -> out.add(new Row.Label(setting.name() + ": " + setting.display()));
        }
    }

    private static <E extends Enum<E>> Row enumRow(EnumSetting<E> e, String tip, int indent) {
        return new Row.Choice(e.name(), pretty(e.get().name()), tip, () -> shift(e, 1), () -> shift(e, -1), indent);
    }

    private static <E extends Enum<E>> void shift(EnumSetting<E> e, int delta) {
        E[] all = e.options();
        e.set(all[Math.floorMod(e.get().ordinal() + delta, all.length)]);
    }

    private static int step(int current, int delta) {
        int index = -1;
        for (int i = 0; i < PALETTE.length; i++) {
            if ((PALETTE[i] & 0x00FFFFFF) == (current & 0x00FFFFFF)) {
                index = i;
            }
        }
        int next = index < 0 ? 0 : Math.floorMod(index + delta, PALETTE.length);
        // keep the alpha the setting already had (panel backgrounds are translucent)
        return (current & 0xFF000000) | (PALETTE[next] & 0x00FFFFFF);
    }

    /** {@code WHILE_MOVING_FORWARD} becomes {@code While moving forward}. */
    public static String pretty(String constant) {
        String t = constant.toLowerCase(java.util.Locale.ROOT).replace('_', ' ');
        return t.isEmpty() ? t : Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }
}
