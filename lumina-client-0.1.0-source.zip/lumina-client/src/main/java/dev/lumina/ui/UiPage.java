package dev.lumina.ui;

import java.util.List;

/** One page of the client menu. {@link #rows(UiApp)} is called whenever the screen is drawn, so it must be cheap. */
public interface UiPage {
    String title();

    List<Row> rows(UiApp app);
}
