package dev.lumina.ui.pages;

import dev.lumina.ClientContext;
import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.module.ModuleFilter;
import dev.lumina.module.ToggleResult;
import dev.lumina.setting.Setting;
import dev.lumina.social.NotificationCenter;
import dev.lumina.ui.KeyNames;
import dev.lumina.ui.Row;
import dev.lumina.ui.SettingRows;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiPage;

import java.util.ArrayList;
import java.util.List;

/** The Click GUI: search, filter, switch modules on and off, and edit their settings and keys. */
public final class ModulesPage implements UiPage {
    public static final String SEARCH_ID = "module_search";

    @Override
    public String title() {
        return "Modules";
    }

    /** Filter choices: All, Enabled, Favorites, then each category. */
    static List<String> filterNames() {
        List<String> names = new ArrayList<>(List.of("All", "Enabled", "Favorites"));
        for (Category c : Category.values()) {
            names.add(c.displayName());
        }
        return names;
    }

    static ModuleFilter filterFor(int index, String text) {
        ModuleFilter f = ModuleFilter.ALL.withText(text);
        if (index == 1) {
            return new ModuleFilter(text, null, true, false);
        }
        if (index == 2) {
            return new ModuleFilter(text, null, false, true);
        }
        if (index >= 3) {
            return f.withCategory(Category.values()[index - 3]);
        }
        return f;
    }

    @Override
    public List<Row> rows(UiApp app) {
        ClientContext c = app.ctx;
        List<Row> rows = new ArrayList<>();
        List<String> names = filterNames();
        rows.add(new Row.Input("Search", SEARCH_ID, "type to filter modules", "Matches name, description and category."));
        rows.add(new Row.Choice("Show", names.get(app.state.filterIndex % names.size()), "Left click: next filter. Right click: previous.",
                () -> app.state.filterIndex = Math.floorMod(app.state.filterIndex + 1, names.size()),
                () -> app.state.filterIndex = Math.floorMod(app.state.filterIndex - 1, names.size()), 0));
        rows.add(new Row.Label("Left click a module to switch it. Right click to open its settings."));
        rows.add(new Row.Spacer(4));

        List<ClientModule> list = c.modules.query(filterFor(app.state.filterIndex, app.state.input(SEARCH_ID)));
        if (list.isEmpty()) {
            rows.add(new Row.Label("No module matches."));
        }
        for (ClientModule m : list) {
            boolean open = m.id().equals(app.state.expandedModule);
            String label = (m.isFavorite() ? "★ " : "") + m.name() + "  ·  " + m.category().displayName();
            rows.add(new Row.Toggle(label, m.isEnabled(), c.modules.tooltip(m),
                    () -> toggle(app, m),
                    () -> app.state.expandedModule = open ? null : m.id(), 0));
            if (open) {
                addDetails(app, rows, m);
            }
        }
        return rows;
    }

    private static void toggle(UiApp app, ClientModule m) {
        ToggleResult r = app.ctx.modules.toggle(m);
        if (!r.isSuccess()) {
            app.notify(NotificationCenter.Level.WARNING, m.name(), r.detail());
        }
    }

    private static void addDetails(UiApp app, List<Row> rows, ClientModule m) {
        rows.add(new Row.Label("    " + m.description()));
        for (Setting<?> s : m.settings()) {
            SettingRows.add(rows, s, 1);
        }
        boolean listening = m.id().equals(app.state.listeningModule);
        String key = m.keyCode() == ClientModule.KEY_UNBOUND ? "None" : KeyNames.of(m.keyCode());
        rows.add(new Row.Button(listening ? "Press a key… (Esc cancels, Backspace clears)" : "Key: " + key, "", true,
                "Click, then press the key that switches this module.", () -> app.state.listeningModule = listening ? null : m.id()));
        rows.add(new Row.Toggle("Favorite", m.isFavorite(), "Favorites can be shown with the filter above.",
                () -> {
                    m.setFavorite(!m.isFavorite());
                    app.ctx.modules.notifyChanged();
                }));
        String resetKey = "reset_module:" + m.id();
        rows.add(new Row.Button(app.isPendingConfirm(resetKey) ? "Click again to reset this module" : "Reset this module to defaults",
                "", true, "Restores its settings and key. The on/off state returns to the default.", () -> {
                    if (app.confirm(resetKey)) {
                        app.ctx.modules.resetModule(m);
                    }
                }));
        rows.add(new Row.Spacer(4));
    }
}
