package dev.lumina.ui;

import dev.lumina.ui.UiLayout.Placed;

import java.util.List;
import java.util.function.IntConsumer;

/**
 * Turns mouse and keyboard input into row actions. It knows nothing about Minecraft: coordinates are
 * plain numbers and keys use GLFW key codes (the numbers Minecraft itself uses).
 */
public final class UiController {
    public static final int KEY_ESCAPE = 256;
    public static final int KEY_ENTER = 257;
    public static final int KEY_BACKSPACE = 259;
    public static final int KEY_DELETE = 261;

    public static final int LEFT = 0;
    public static final int RIGHT = 1;

    private final UiState state;
    private final IntConsumer keyCapture;
    private Placed draggingSlider;

    /**
     * @param keyCapture receives the key code when a module is waiting for a key binding
     *                   ({@link UiState#listeningModule}); it is called instead of normal key handling
     */
    public UiController(UiState state, IntConsumer keyCapture) {
        this.state = state;
        this.keyCapture = keyCapture;
    }

    /** @return true when the click hit an interactive row */
    public boolean click(List<Placed> placed, double mx, double my, int button) {
        draggingSlider = null;
        Placed hit = null;
        for (Placed p : placed) {
            if (p.contains(mx, my)) {
                hit = p;
                break;
            }
        }
        if (hit == null) {
            state.focus(null);
            return false;
        }
        Row row = hit.row();
        if (!(row instanceof Row.Input)) {
            state.focus(null);
        }
        switch (row) {
            case Row.Button b -> {
                if (button == LEFT && b.enabled()) {
                    b.action().run();
                    return true;
                }
            }
            case Row.Toggle t -> {
                if (button == LEFT) {
                    t.action().run();
                    return true;
                }
                if (button == RIGHT && t.secondary() != null) {
                    t.secondary().run();
                    return true;
                }
            }
            case Row.Choice c -> {
                if (button == LEFT) {
                    c.next().run();
                    return true;
                }
                if (button == RIGHT) {
                    c.previous().run();
                    return true;
                }
            }
            case Row.ColorChoice c -> {
                if (button == LEFT) {
                    c.next().run();
                    return true;
                }
                if (button == RIGHT) {
                    c.previous().run();
                    return true;
                }
            }
            case Row.Slider s -> {
                if (button == LEFT) {
                    draggingSlider = hit;
                    applySlider(hit, s, mx);
                    return true;
                }
            }
            case Row.Input in -> {
                if (button == LEFT) {
                    state.focus(in.id());
                    return true;
                }
            }
            default -> {
            }
        }
        return false;
    }

    public boolean drag(double mx) {
        if (draggingSlider == null) {
            return false;
        }
        applySlider(draggingSlider, (Row.Slider) draggingSlider.row(), mx);
        return true;
    }

    public void release() {
        draggingSlider = null;
    }

    private static void applySlider(Placed p, Row.Slider s, double mx) {
        double f = (mx - p.trackX()) / p.trackWidth();
        s.onChange().accept(Math.max(0.0, Math.min(1.0, f)));
    }

    /** Mouse wheel over the content: one notch scrolls three rows. */
    public void scroll(double wheel, int contentHeight, int viewHeight) {
        state.setScroll(state.scroll() - (int) Math.round(wheel * 3 * 20));
        state.clampScroll(contentHeight, viewHeight);
    }

    /** @return true when the key was used */
    public boolean key(int keyCode) {
        if (state.listeningModule != null) {
            keyCapture.accept(keyCode);
            return true;
        }
        String id = state.focusedInput();
        if (id == null) {
            return false;
        }
        switch (keyCode) {
            case KEY_BACKSPACE -> {
                String t = state.input(id);
                if (!t.isEmpty()) {
                    state.setInput(id, t.substring(0, t.length() - 1));
                }
                return true;
            }
            case KEY_ENTER, KEY_ESCAPE -> {
                state.focus(null);
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    /** A typed character (Unicode code point). Only printable characters are accepted. */
    public boolean character(int codePoint) {
        String id = state.focusedInput();
        if (id == null || Character.isISOControl(codePoint) || !Character.isDefined(codePoint)) {
            return false;
        }
        String t = state.input(id);
        if (t.length() >= UiState.MAX_INPUT) {
            return true;
        }
        state.setInput(id, t + new String(Character.toChars(codePoint)));
        return true;
    }

    /** True when text is being typed, so global shortcuts (for example the menu key) must not fire. */
    public boolean isTyping() {
        return state.focusedInput() != null || state.listeningModule != null;
    }
}
