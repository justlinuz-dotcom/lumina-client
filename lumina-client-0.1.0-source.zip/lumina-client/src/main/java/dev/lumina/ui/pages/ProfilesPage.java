package dev.lumina.ui.pages;

import dev.lumina.ClientContext;
import dev.lumina.hud.HudLayoutStore;
import dev.lumina.profile.ProfileException;
import dev.lumina.profile.ProfileManager;
import dev.lumina.social.NotificationCenter.Level;
import dev.lumina.ui.Row;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiPage;
import dev.lumina.utils.LoadReport;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Profiles: switch, create, duplicate, rename, delete, export, import, bind to servers, and named HUD layouts. */
public final class ProfilesPage implements UiPage {
    public static final String NAME_ID = "profile_name";
    public static final String SERVER_ID = "profile_server";
    public static final String LAYOUT_ID = "layout_name";

    @FunctionalInterface
    private interface ProfileAction {
        String run() throws ProfileException;
    }

    @Override
    public String title() {
        return "Profiles";
    }

    @Override
    public List<Row> rows(UiApp app) {
        ClientContext c = app.ctx;
        String active = c.global.settings().activeProfile();
        List<Row> rows = new ArrayList<>();
        rows.add(new Row.Heading("Profiles"));
        rows.add(new Row.Label("A profile keeps module states, settings, HUD layout, theme and cosmetics together."));
        List<ProfileManager.ProfileInfo> all = c.profiles.list();
        for (ProfileManager.ProfileInfo p : all) {
            boolean isActive = p.id().equals(active);
            String label = (isActive ? "● " : "") + p.name() + (p.damaged() ? "  (damaged, cannot be used)" : "");
            rows.add(new Row.Button(label, isActive ? "active" : "", !isActive && !p.damaged(),
                    "Click to switch to this profile. The current one is saved first.", () -> switchTo(app, p.id())));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Manage"));
        rows.add(new Row.Input("Name", NAME_ID, "name for the new or renamed profile", "Letters, digits, spaces, '_', '-' and '.'."));
        String name = app.state.input(NAME_ID);
        rows.add(new Row.Button("Create from current settings", () -> run(app, "Profile created", () -> c.profiles.create(name, true))));
        rows.add(new Row.Button("Create with default settings", () -> run(app, "Profile created", () -> c.profiles.create(name, false))));
        rows.add(new Row.Button("Duplicate the active profile", () -> run(app, "Profile duplicated", () -> c.profiles.duplicate(active, name))));
        rows.add(new Row.Button("Rename the active profile", () -> run(app, "Profile renamed", () -> c.profiles.rename(active, name))));
        String deleteKey = "delete_profile:" + active;
        rows.add(new Row.Button(app.isPendingConfirm(deleteKey) ? "Click again to delete the active profile" : "Delete the active profile",
                "", all.size() > 1, "A copy is kept in the backups folder.", () -> {
                    if (app.confirm(deleteKey)) {
                        deleteActive(app, active, all);
                    }
                }));
        rows.add(new Row.Button("Export the active profile to a file", () -> {
            try {
                var path = c.profiles.export(active);
                app.notify(Level.SUCCESS, "Exported", "Saved as " + path.getFileName() + " in the exports folder");
            } catch (ProfileException e) {
                app.notify(Level.ERROR, "Export failed", e.getMessage());
            }
        }));
        String resetKey = "reset_profile";
        rows.add(new Row.Button(app.isPendingConfirm(resetKey) ? "Click again to reset the active profile" : "Reset the active profile to defaults",
                "", true, "Every module, setting and layout of this profile returns to its default.", () -> {
                    if (app.confirm(resetKey)) {
                        try {
                            report(app, "Profile reset", c.profiles.resetActiveToDefaults());
                        } catch (ProfileException e) {
                            app.notify(Level.ERROR, "Reset failed", e.getMessage());
                        }
                    }
                }));

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("HUD layouts"));
        rows.add(new Row.Label("A layout keeps only where the HUD elements are and how they look. Loading one changes the active profile's HUD."));
        rows.add(new Row.Input("Layout name", LAYOUT_ID, "name for the layout", "Letters, digits, spaces, '_', '-' and '.'."));
        String layoutName = app.state.input(LAYOUT_ID);
        rows.add(new Row.Button("Save the current HUD as a layout", () -> layoutOutcome(app, c.hudLayouts.save(layoutName, c.hudLayout))));
        for (String layout : c.hudLayouts.list()) {
            rows.add(new Row.Button("Load layout: " + layout, "", true, "Replaces the HUD positions, sizes and colours of the active profile.",
                    () -> layoutOutcome(app, c.hudLayouts.load(layout, c.hudLayout))));
            String deleteLayoutKey = "delete_layout:" + layout;
            rows.add(new Row.Button(app.isPendingConfirm(deleteLayoutKey) ? "Click again to delete layout: " + layout : "Delete layout: " + layout,
                    "", true, "A copy is kept in the backups folder.", () -> {
                        if (app.confirm(deleteLayoutKey)) {
                            layoutOutcome(app, c.hudLayouts.delete(layout));
                        }
                    }));
        }

        List<String> files = c.paths.importFiles(".json");
        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Import"));
        rows.add(new Row.Label(files.isEmpty()
                ? "Put a profile .json file in the imports folder to import it. Imported files are only read as data."
                : "Files found in the imports folder:"));
        for (String f : files) {
            rows.add(new Row.Button("Import " + f, "", true, "The file is checked and only known settings are kept.",
                    () -> run(app, "Profile imported", () -> c.profiles.importFile(f))));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Servers"));
        rows.add(new Row.Toggle("Switch profile automatically by server", c.global.settings().autoSwitchProfiles(),
                "When you join a server that has a profile assigned, that profile is applied.",
                () -> {
                    c.global.settings().setAutoSwitchProfiles(!c.global.settings().autoSwitchProfiles());
                    c.global.save();
                }));
        rows.add(new Row.Input("Server", SERVER_ID, "server address, e.g. play.example.com", "The port is ignored."));
        rows.add(new Row.Button("Use the active profile on this server", () -> {
            String host = app.state.input(SERVER_ID);
            if (host.isBlank()) {
                app.notify(Level.WARNING, "Server", "Type a server address first");
                return;
            }
            c.global.settings().bindServer(host, active);
            c.global.save();
        }));
        for (Map.Entry<String, String> e : c.global.settings().serverProfiles().entrySet()) {
            rows.add(new Row.Button(e.getKey() + "  →  " + e.getValue(), "remove", true, "Click to remove this assignment.", () -> {
                c.global.settings().unbindServer(e.getKey());
                c.global.save();
            }));
        }
        return rows;
    }

    private static void layoutOutcome(UiApp app, HudLayoutStore.Outcome outcome) {
        app.notify(outcome.ok() ? Level.SUCCESS : Level.ERROR, "HUD layout", outcome.message());
    }

    private static void switchTo(UiApp app, String id) {
        try {
            report(app, "Profile switched", app.ctx.profiles.switchTo(id));
        } catch (ProfileException e) {
            app.notify(Level.ERROR, "Could not switch", e.getMessage());
        }
    }

    private static void deleteActive(UiApp app, String active, List<ProfileManager.ProfileInfo> all) {
        try {
            String other = all.stream().map(ProfileManager.ProfileInfo::id).filter(id -> !id.equals(active)).findFirst().orElse(null);
            if (other == null) {
                return;
            }
            app.ctx.profiles.switchTo(other);
            app.ctx.profiles.delete(active);
            app.notify(Level.SUCCESS, "Profile deleted", "Now using " + other);
        } catch (ProfileException e) {
            app.notify(Level.ERROR, "Could not delete", e.getMessage());
        }
    }

    private static void run(UiApp app, String success, ProfileAction action) {
        try {
            String id = action.run();
            app.notify(Level.SUCCESS, success, id == null ? "" : id);
        } catch (ProfileException e) {
            app.notify(Level.ERROR, "Profile", e.getMessage());
        }
    }

    private static void report(UiApp app, String title, LoadReport r) {
        app.notify(r.isClean() ? Level.SUCCESS : Level.WARNING, title,
                r.isClean() ? "" : r.warnings().size() + " setting(s) were repaired");
    }
}
