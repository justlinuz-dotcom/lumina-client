package dev.lumina.ui;

import java.util.ArrayList;
import java.util.List;

/** Stacks rows vertically. Pure arithmetic, shared by the renderer and the click handling. */
public final class UiLayout {
    private UiLayout() {
    }

    public record Placed(Row row, int x, int y, int w, int h) {
        public boolean contains(double px, double py) {
            return px >= x && px < x + w && py >= y && py < y + h;
        }

        /** Left edge of the slider track inside a slider row. */
        public int trackX() {
            return x + (int) (w * 0.5);
        }

        public int trackWidth() {
            return Math.max(1, x + w - 6 - trackX());
        }
    }

    /** Space between rows when the "Compact lists" preference is on. */
    public static final int COMPACT_GAP = 0;

    /** @param scroll how many pixels the content is scrolled up */
    public static List<Placed> place(List<Row> rows, int x, int y, int w, int scroll) {
        return place(rows, x, y, w, scroll, Row.GAP);
    }

    /** @param gap pixels between two rows ({@link Row#GAP} normally, {@link #COMPACT_GAP} in compact lists) */
    public static List<Placed> place(List<Row> rows, int x, int y, int w, int scroll, int gap) {
        List<Placed> out = new ArrayList<>(rows.size());
        int cursor = y - scroll;
        for (Row r : rows) {
            out.add(new Placed(r, x, cursor, w, r.height()));
            cursor += r.height() + gap;
        }
        return out;
    }

    public static int contentHeight(List<Row> rows) {
        return contentHeight(rows, Row.GAP);
    }

    public static int contentHeight(List<Row> rows, int gap) {
        int total = 0;
        for (Row r : rows) {
            total += r.height() + gap;
        }
        return total;
    }
}
