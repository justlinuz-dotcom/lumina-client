package dev.lumina.ui.pages;

import dev.lumina.ClientContext;
import dev.lumina.compat.CompatChecker;
import dev.lumina.module.Preset;
import dev.lumina.options.PerformancePresets;
import dev.lumina.performance.FrameSnapshot;
import dev.lumina.performance.MemorySample;
import dev.lumina.performance.MemorySampler;
import dev.lumina.performance.ModuleCost;
import dev.lumina.performance.PerformanceReport;
import dev.lumina.performance.ProfileComparison;
import dev.lumina.performance.ProfileRun;
import dev.lumina.social.NotificationCenter.Level;
import dev.lumina.ui.Row;
import dev.lumina.ui.UiApp;
import dev.lumina.ui.UiPage;
import dev.lumina.utils.LoadReport;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Performance Lab: presets, measured frame statistics, before/after comparison and report export. */
public final class PerformancePage implements UiPage {
    private static final int GREY = 0xFF9AA3B2;

    @Override
    public String title() {
        return "Performance";
    }

    @Override
    public List<Row> rows(UiApp app) {
        ClientContext c = app.ctx;
        List<Row> rows = new ArrayList<>();
        rows.add(new Row.Heading("Presets"));
        rows.add(new Row.Label("Presets change the game's own video options. How much they help depends on your computer;", GREY));
        rows.add(new Row.Label("measure below to see the effect. They do not promise any FPS gain.", GREY));
        for (Preset p : PerformancePresets.all()) {
            rows.add(new Row.Button("Apply: " + p.name(), "", true, "Changes video options and can be undone with the Vanilla preset.", () -> {
                LoadReport r = c.applyPerformancePreset(p.id());
                app.notify(r.isClean() ? Level.SUCCESS : Level.WARNING, p.name(), r.isClean() ? "Applied" : r.warnings().get(0));
            }));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Measure"));
        rows.add(new Row.Label("Stand in the same place and situation before and after a change, then measure each time.", GREY));
        if (c.isLabRunning()) {
            rows.add(new Row.Label("Measuring: " + c.frames.frameCount() + " frames so far (at least " + ProfileComparison.MIN_FRAMES + " are needed)."));
            rows.add(new Row.Button("Stop and save this run", () -> {
                ProfileRun run = c.finishLab();
                app.notify(run == null ? Level.WARNING : Level.SUCCESS, "Performance Lab", run == null ? "Nothing was measured" : "Run saved");
            }));
        } else {
            rows.add(new Row.Button("Start measuring", c::startLab));
        }

        FrameSnapshot s = c.frames.snapshot();
        rows.add(new Row.Spacer(4));
        rows.add(new Row.Heading("Current frames"));
        if (s.isEmpty()) {
            rows.add(new Row.Label("No frames recorded yet."));
        } else {
            rows.add(new Row.Label(String.format(Locale.ROOT, "Average %.0f FPS (%.1f ms) over %d frames", s.avgFps(), s.avgMs(), s.frames())));
            rows.add(new Row.Label(s.low1Reliable()
                    ? String.format(Locale.ROOT, "1%% low: %.0f FPS", s.low1PercentFps())
                    : "1% low: not enough frames yet"));
            rows.add(new Row.Label(String.format(Locale.ROOT, "Slowest frame %.1f ms · hitches %d · stability index %.0f/100",
                    s.maxMs(), s.hitches(), s.stability())));
        }
        MemorySample m = c.memory.sample();
        rows.add(new Row.Label(String.format(Locale.ROOT, "Memory: %.0f of %.0f MB used", m.usedMb(), m.maxMb())));

        List<ProfileRun> runs = c.performanceHistory.runs(c.global.settings().activeProfile());
        rows.add(new Row.Spacer(4));
        rows.add(new Row.Heading("Saved runs (this profile)"));
        if (runs.isEmpty()) {
            rows.add(new Row.Label("No runs saved yet."));
        } else {
            ProfileRun last = runs.get(runs.size() - 1);
            rows.add(new Row.Label(String.format(Locale.ROOT, "Latest: %.0f FPS average, %d frames%s", last.avgFps(), last.frames(),
                    last.low1Reliable() ? String.format(Locale.ROOT, ", 1%% low %.0f", last.low1Fps()) : "")));
        }
        if (runs.size() >= 2) {
            ProfileRun previous = relabel(runs.get(runs.size() - 2), "The previous run");
            ProfileRun latest = relabel(runs.get(runs.size() - 1), "The latest run");
            ProfileComparison.Result r = ProfileComparison.compare(previous, latest);
            rows.add(new Row.Label(r.verdict()));
            for (ProfileComparison.Row row : r.rows()) {
                rows.add(new Row.Label(String.format(Locale.ROOT, "    %s: %.1f → %.1f (%+.1f%%)", row.metric(), row.a(), row.b(), row.deltaPercent()), GREY));
            }
            for (String caveat : r.caveats()) {
                rows.add(new Row.Label("    " + caveat, GREY));
            }
        }

        List<ModuleCost> costs = ModuleCost.measure(c.allModules());
        rows.add(new Row.Spacer(4));
        rows.add(new Row.Heading("Module tick cost"));
        rows.add(new Row.Label("Time each module's own tick code took. It does not include drawing, and it is not proof of lost FPS.", GREY));
        if (costs.isEmpty()) {
            rows.add(new Row.Label("No module with tick work is enabled."));
        }
        for (int i = 0; i < Math.min(5, costs.size()); i++) {
            ModuleCost k = costs.get(i);
            rows.add(new Row.Label(String.format(Locale.ROOT, "    %s: %.1f µs average, %.0f µs worst", k.moduleId(), k.avgMicros(), k.maxMicros())));
        }

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Button("Export a report (no personal data)", () -> export(app)));

        rows.add(new Row.Spacer(6));
        rows.add(new Row.Heading("Compatibility"));
        for (CompatChecker.Note n : c.compatibility()) {
            rows.add(new Row.Label(prefix(n.level()) + n.message(), n.level() == CompatChecker.Level.ERROR ? 0xFFE5594F
                    : n.level() == CompatChecker.Level.WARNING ? 0xFFE6C14D : 0));
        }
        return rows;
    }

    private static String prefix(CompatChecker.Level level) {
        return switch (level) {
            case OK -> "✓ ";
            case INFO -> "• ";
            case WARNING -> "! ";
            case ERROR -> "✗ ";
        };
    }

    private static ProfileRun relabel(ProfileRun r, String label) {
        return new ProfileRun(label, r.timeMillis(), r.frames(), r.avgFps(), r.avgMs(), r.low1Fps(), r.low1Reliable(), r.stability());
    }

    private static void export(UiApp app) {
        ClientContext c = app.ctx;
        PerformanceReport.Data data = new PerformanceReport.Data(c.info.name(), c.info.version(), c.env.runningMinecraft(),
                System.getProperty("java.version", "?"), System.getProperty("os.name", "?"), Runtime.getRuntime().availableProcessors(),
                c.env.clock().getAsLong(), c.global.settings().activeProfile(), c.frames.snapshot(), c.frames.stutters(),
                c.memory.sample(), MemorySampler.gcCount(), MemorySampler.gcTimeMillis(), ModuleCost.measure(c.allModules()));
        try {
            var file = PerformanceReport.export(c.paths.diagnostics(), data);
            app.notify(Level.SUCCESS, "Report exported", "Saved as " + file.getFileName() + " in the diagnostics folder");
        } catch (IOException e) {
            app.notify(Level.ERROR, "Export failed", e.getClass().getSimpleName());
        }
    }
}
