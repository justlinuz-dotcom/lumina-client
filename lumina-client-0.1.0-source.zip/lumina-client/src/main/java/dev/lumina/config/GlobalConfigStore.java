package dev.lumina.config;

import dev.lumina.utils.ErrorSink;
import dev.lumina.utils.LoadReport;

import java.io.IOException;
import java.util.function.LongSupplier;

/** Loads and saves {@link GlobalSettings} ({@code client.json}) with the usual safety net. */
public final class GlobalConfigStore {
    private final GlobalSettings settings = new GlobalSettings();
    private final SafeJsonFile file;
    private final ErrorSink errors;
    private SafeJsonFile.Status lastStatus = SafeJsonFile.Status.MISSING;

    public GlobalConfigStore(ClientPaths paths, LongSupplier clock, ErrorSink errors) {
        this.file = new SafeJsonFile(paths.globalConfig(), paths.backups(), GlobalSettings.SCHEMA, 5, 10 * 60_000L, clock);
        this.errors = errors;
    }

    public GlobalSettings settings() {
        return settings;
    }

    public SafeJsonFile.Status lastStatus() {
        return lastStatus;
    }

    /** Reads {@code client.json}; on corruption or version mismatch defaults are used and the report says so. */
    public synchronized LoadReport load() {
        SafeJsonFile.ReadResult result = file.read();
        lastStatus = result.status();
        LoadReport report = settings.loadJson(result.data());
        if (result.status() != SafeJsonFile.Status.LOADED && result.status() != SafeJsonFile.Status.MISSING) {
            report.add("client.json: " + result.detail());
        }
        return report;
    }

    public synchronized void save() {
        try {
            file.write(settings.toJson());
        } catch (IOException e) {
            errors.report("config:client.json", e);
        }
    }
}
