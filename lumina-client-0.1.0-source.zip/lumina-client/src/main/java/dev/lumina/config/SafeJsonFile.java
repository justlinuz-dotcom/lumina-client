package dev.lumina.config;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.lumina.utils.Json;
import dev.lumina.utils.Log;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.function.LongSupplier;
import java.util.stream.Stream;

/**
 * One JSON configuration file with the safety net the client promises:
 *
 * <ul>
 *   <li><b>atomic writes</b> (temp file + atomic move), so a crash never leaves a half-written file;</li>
 *   <li><b>rolling backups</b> of the previous version, pruned to {@code maxBackups};</li>
 *   <li><b>corruption recovery</b>: an unreadable file is quarantined and the newest valid backup is
 *       restored; if none is valid the caller gets {@link Status#CORRUPT_DEFAULTED} and starts clean;</li>
 *   <li><b>version detection</b>: a file written by a newer client is quarantined untouched
 *       ({@link Status#INCOMPATIBLE}) rather than overwritten.</li>
 * </ul>
 */
public final class SafeJsonFile {
    private static final Logger LOG = Log.of("config");
    public static final String SCHEMA_KEY = "schemaVersion";

    public enum Status {
        /** File read and valid. */
        LOADED,
        /** File does not exist yet (first run). */
        MISSING,
        /** File was corrupt; the newest valid backup was restored. */
        RECOVERED_FROM_BACKUP,
        /** File was corrupt and no valid backup existed; defaults must be used. */
        CORRUPT_DEFAULTED,
        /** File was written by a newer schema; it was preserved aside and defaults must be used. */
        INCOMPATIBLE
    }

    public record ReadResult(Status status, JsonObject data, String detail) {
    }

    private final Path file;
    private final Path backupDir;
    private final Path quarantineDir;
    private final int currentSchema;
    private final int maxBackups;
    private final long backupIntervalMillis;
    private final LongSupplier clock;
    private final String stem;
    private long lastBackupAt = Long.MIN_VALUE;
    private int uniqueCounter;

    public SafeJsonFile(Path file, Path backupDir, int currentSchema, int maxBackups,
                        long backupIntervalMillis, LongSupplier clock) {
        this.file = file;
        this.backupDir = backupDir;
        this.quarantineDir = backupDir.resolve("quarantine");
        this.currentSchema = currentSchema;
        this.maxBackups = Math.max(1, maxBackups);
        this.backupIntervalMillis = backupIntervalMillis;
        this.clock = clock;
        String name = file.getFileName().toString();
        this.stem = name.endsWith(".json") ? name.substring(0, name.length() - 5) : name;
    }

    public Path path() {
        return file;
    }

    // ---- read ----------------------------------------------------------------------------------

    public synchronized ReadResult read() {
        if (!Files.exists(file)) {
            return new ReadResult(Status.MISSING, new JsonObject(), "No file yet");
        }
        try {
            JsonObject data = parseFile(file);
            int version = Json.integer(data, SCHEMA_KEY, 1);
            if (version > currentSchema) {
                Path aside = quarantine("newer-schema-v" + version);
                LOG.warn("{} uses schema v{} but this client supports v{}; preserved as {}",
                        file.getFileName(), version, currentSchema, aside);
                return new ReadResult(Status.INCOMPATIBLE, new JsonObject(),
                        "Written by a newer client (schema " + version + "); kept as " + aside.getFileName());
            }
            return new ReadResult(Status.LOADED, data, "OK");
        } catch (IOException | JsonParseException | IllegalStateException | UnsupportedOperationException e) {
            return recover(e);
        }
    }

    private ReadResult recover(Exception cause) {
        LOG.warn("{} is unreadable ({}); trying backups", file.getFileName(), cause.toString());
        try {
            quarantine("corrupt");
        } catch (IOException e) {
            LOG.warn("Could not quarantine {}: {}", file.getFileName(), e.toString());
        }
        for (Path backup : listBackups()) {
            try {
                JsonObject data = parseFile(backup);
                if (Json.integer(data, SCHEMA_KEY, 1) > currentSchema) {
                    continue;
                }
                writeAtomically(file, Json.GSON.toJson(data));
                LOG.info("Restored {} from backup {}", file.getFileName(), backup.getFileName());
                return new ReadResult(Status.RECOVERED_FROM_BACKUP, data,
                        "Restored from " + backup.getFileName());
            } catch (IOException | JsonParseException | IllegalStateException | UnsupportedOperationException skip) {
                LOG.warn("Backup {} is not usable: {}", backup.getFileName(), skip.toString());
            }
        }
        return new ReadResult(Status.CORRUPT_DEFAULTED, new JsonObject(),
                "File was corrupt and no valid backup exists: " + cause.getMessage());
    }

    private JsonObject parseFile(Path path) throws IOException {
        return Json.parseObject(Json.readLimited(path, Json.MAX_CONFIG_BYTES), Json.MAX_DEPTH);
    }

    // ---- write ---------------------------------------------------------------------------------

    /** Writes {@code data} atomically, stamping the schema version and backing up the previous file. */
    public synchronized void write(JsonObject data) throws IOException {
        JsonObject stamped = new JsonObject();
        stamped.addProperty(SCHEMA_KEY, currentSchema);
        for (var entry : data.entrySet()) {
            if (!SCHEMA_KEY.equals(entry.getKey())) {
                stamped.add(entry.getKey(), entry.getValue());
            }
        }
        maybeBackup();
        writeAtomically(file, Json.GSON.toJson(stamped));
    }

    private void maybeBackup() {
        long now = clock.getAsLong();
        if (!Files.isRegularFile(file) || (lastBackupAt != Long.MIN_VALUE && now - lastBackupAt < backupIntervalMillis)) {
            return;
        }
        try {
            parseFile(file); // never back up a file that is itself corrupt
            Files.createDirectories(backupDir);
            Files.copy(file, backupDir.resolve(stem + "-" + stamp(now) + ".json"), StandardCopyOption.REPLACE_EXISTING);
            lastBackupAt = now;
            prune();
        } catch (IOException | JsonParseException | IllegalStateException e) {
            LOG.warn("Backup of {} skipped: {}", file.getFileName(), e.toString());
        }
    }

    private String stamp(long millis) {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd-HHmmssSSS", Locale.ROOT);
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
        return fmt.format(new Date(millis)) + "-" + (uniqueCounter++ % 1000);
    }

    /** Newest first. */
    List<Path> listBackups() {
        if (!Files.isDirectory(backupDir)) {
            return List.of();
        }
        List<Path> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(backupDir)) {
            s.filter(p -> {
                String n = p.getFileName().toString();
                return n.startsWith(stem + "-") && n.endsWith(".json") && Files.isRegularFile(p);
            }).forEach(out::add);
        } catch (IOException e) {
            LOG.warn("Cannot list backups: {}", e.toString());
        }
        out.sort((a, b) -> b.getFileName().toString().compareTo(a.getFileName().toString()));
        return Collections.unmodifiableList(out);
    }

    private void prune() {
        List<Path> backups = listBackups();
        for (int i = maxBackups; i < backups.size(); i++) {
            try {
                Files.deleteIfExists(backups.get(i));
            } catch (IOException e) {
                LOG.warn("Could not delete old backup {}: {}", backups.get(i).getFileName(), e.toString());
            }
        }
    }

    private Path quarantine(String reason) throws IOException {
        Files.createDirectories(quarantineDir);
        Path target = quarantineDir.resolve(stem + "." + reason + "." + stamp(clock.getAsLong()) + ".json");
        Files.move(file, target, StandardCopyOption.REPLACE_EXISTING);
        return target;
    }

    /** Writes text to {@code target} through a temp file and an atomic move. */
    public static void writeAtomically(Path target, String content) throws IOException {
        Path dir = target.toAbsolutePath().getParent();
        Files.createDirectories(dir);
        Path tmp = dir.resolve(target.getFileName() + ".tmp");
        try (FileChannel ch = FileChannel.open(tmp, StandardOpenOption.CREATE, StandardOpenOption.WRITE,
                StandardOpenOption.TRUNCATE_EXISTING)) {
            ByteBuffer buf = ByteBuffer.wrap(content.getBytes(StandardCharsets.UTF_8));
            while (buf.hasRemaining()) {
                ch.write(buf);
            }
            ch.force(true);
        }
        try {
            Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
