package dev.lumina.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Every file the client writes lives under one folder of its own ({@code <gameDir>/<modId>/}); it never
 * touches Minecraft's files or the configuration of other mods.
 */
public record ClientPaths(Path root) {

    public static ClientPaths of(Path gameDir, String modId) {
        return new ClientPaths(gameDir.resolve(modId));
    }

    public Path globalConfig() {
        return root.resolve("client.json");
    }

    public Path profiles() {
        return root.resolve("profiles");
    }

    public Path layouts() {
        return root.resolve("layouts");
    }

    public Path backups() {
        return root.resolve("backups");
    }

    public Path data() {
        return root.resolve("data");
    }

    public Path cosmetics() {
        return root.resolve("cosmetics");
    }

    /** Folder from which profiles and cosmetics are imported; nothing outside it is ever read. */
    public Path imports() {
        return root.resolve("imports");
    }

    public Path exports() {
        return root.resolve("exports");
    }

    public Path diagnostics() {
        return root.resolve("diagnostics");
    }

    /**
     * Plain file names in the imports folder with the given extension (lower-case, with the dot), sorted.
     * Sub-folders and links are not listed.
     */
    public java.util.List<String> importFiles(String extension) {
        java.util.List<String> out = new java.util.ArrayList<>();
        if (!Files.isDirectory(imports())) {
            return out;
        }
        try (java.util.stream.Stream<Path> stream = Files.list(imports())) {
            stream.filter(p -> Files.isRegularFile(p, java.nio.file.LinkOption.NOFOLLOW_LINKS))
                    .map(p -> p.getFileName().toString())
                    .filter(n -> n.toLowerCase(java.util.Locale.ROOT).endsWith(extension))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .forEach(out::add);
        } catch (IOException e) {
            // an unreadable folder simply shows no files
        }
        return out;
    }

    public void ensureCreated() throws IOException {
        for (Path p : new Path[]{root, profiles(), layouts(), backups(), data(), cosmetics(), imports(), exports(),
                diagnostics()}) {
            Files.createDirectories(p);
        }
    }
}
