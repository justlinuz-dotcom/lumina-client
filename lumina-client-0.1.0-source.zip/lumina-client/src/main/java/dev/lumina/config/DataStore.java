package dev.lumina.config;

import com.google.gson.JsonObject;
import dev.lumina.utils.ErrorSink;
import dev.lumina.utils.LoadReport;

import java.io.IOException;
import java.util.function.LongSupplier;

/**
 * One JSON file under {@code data/} (statistics, history, notes, ...). Same safety net as every other
 * file: atomic writes, rolling backups, quarantine of unreadable files. A damaged or newer-version file
 * never stops the game; the caller simply gets an empty object and a warning.
 */
public final class DataStore {
    private final SafeJsonFile file;
    private final ErrorSink errors;
    private final String label;

    public DataStore(ClientPaths paths, String fileName, int schema, LongSupplier clock, ErrorSink errors) {
        this.file = new SafeJsonFile(paths.data().resolve(fileName), paths.backups(), schema, 3, 30 * 60_000L, clock);
        this.errors = errors;
        this.label = "data/" + fileName;
    }

    /** Reads the file; returns an empty object when missing or unusable (and adds a warning in the latter case). */
    public synchronized JsonObject load(LoadReport report) {
        SafeJsonFile.ReadResult result = file.read();
        if (result.status() != SafeJsonFile.Status.LOADED && result.status() != SafeJsonFile.Status.MISSING) {
            report.add(label + ": " + result.detail());
        }
        return result.data();
    }

    public synchronized void save(JsonObject data) {
        try {
            file.write(data);
        } catch (IOException e) {
            errors.report("data:" + label, e);
        }
    }

    public String label() {
        return label;
    }
}
