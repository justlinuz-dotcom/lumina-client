package dev.lumina.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.NameRules;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Settings that belong to the installation rather than to a profile: which profile is active,
 * automatic profile switching, privacy switches and the last version whose news were seen.
 * Privacy defaults are the most restrictive ones (nothing leaves the machine).
 */
public final class GlobalSettings {
    public static final int SCHEMA = 1;
    public static final String DEFAULT_PROFILE_ID = "default";

    private volatile String activeProfile = DEFAULT_PROFILE_ID;
    private volatile boolean autoSwitchProfiles;
    private volatile String lastSeenVersion = "";
    private volatile boolean keepErrorHistory = true;
    private volatile boolean keepServerHistory;
    private final Map<String, String> serverProfiles = new LinkedHashMap<>();

    public String activeProfile() {
        return activeProfile;
    }

    public void setActiveProfile(String id) {
        this.activeProfile = id;
    }

    public boolean autoSwitchProfiles() {
        return autoSwitchProfiles;
    }

    public void setAutoSwitchProfiles(boolean value) {
        this.autoSwitchProfiles = value;
    }

    public String lastSeenVersion() {
        return lastSeenVersion;
    }

    public void setLastSeenVersion(String version) {
        this.lastSeenVersion = version == null ? "" : version;
    }

    /** Opt-in: synchronise cosmetics through an authorised service. Off by default; no service is bundled. */
    /** Opt-in: ask the user whether a newer version exists. Off by default; never downloads anything silently. */
    public boolean keepErrorHistory() {
        return keepErrorHistory;
    }

    public void setKeepErrorHistory(boolean value) {
        this.keepErrorHistory = value;
    }

    /** Opt-in: remember which servers were visited and for how long, on this computer only. Off by default. */
    public boolean keepServerHistory() {
        return keepServerHistory;
    }

    public void setKeepServerHistory(boolean value) {
        this.keepServerHistory = value;
    }

    public synchronized Map<String, String> serverProfiles() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(serverProfiles));
    }

    /** Associates a server host with a profile id. */
    public synchronized void bindServer(String host, String profileId) {
        String key = normaliseHost(host);
        if (key.isEmpty()) {
            throw new IllegalArgumentException("Empty host");
        }
        serverProfiles.put(key, profileId);
    }

    public synchronized void unbindServer(String host) {
        serverProfiles.remove(normaliseHost(host));
    }

    /** Profile bound to the server address ({@code host} or {@code host:port}), or null. */
    public synchronized String profileForServer(String address) {
        String key = normaliseHost(address);
        return key.isEmpty() ? null : serverProfiles.get(key);
    }

    public static String normaliseHost(String address) {
        if (address == null) {
            return "";
        }
        String a = address.trim().toLowerCase(Locale.ROOT);
        if (a.startsWith("[")) {
            int end = a.indexOf(']');
            return end > 0 ? a.substring(1, end) : a;
        }
        int colon = a.lastIndexOf(':');
        if (colon > 0 && a.indexOf(':') == colon) {
            a = a.substring(0, colon);
        }
        return a.endsWith(".") ? a.substring(0, a.length() - 1) : a;
    }

    public synchronized JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("activeProfile", activeProfile);
        o.addProperty("autoSwitchProfiles", autoSwitchProfiles);
        o.addProperty("lastSeenVersion", lastSeenVersion);
        JsonObject privacy = new JsonObject();
        privacy.addProperty("keepErrorHistory", keepErrorHistory);
        privacy.addProperty("keepServerHistory", keepServerHistory);
        o.add("privacy", privacy);
        JsonObject servers = new JsonObject();
        serverProfiles.forEach(servers::addProperty);
        o.add("serverProfiles", servers);
        return o;
    }

    public synchronized LoadReport loadJson(JsonObject o) {
        LoadReport report = new LoadReport();
        String active = Json.string(o, "activeProfile", DEFAULT_PROFILE_ID);
        if (NameRules.validate(active) != null || !active.equals(NameRules.toId(active))) {
            report.add("Invalid active profile id '" + active + "'; using '" + DEFAULT_PROFILE_ID + "'");
            active = DEFAULT_PROFILE_ID;
        }
        activeProfile = active;
        autoSwitchProfiles = Json.bool(o, "autoSwitchProfiles", false);
        lastSeenVersion = Json.string(o, "lastSeenVersion", "");
        JsonObject privacy = Json.object(o, "privacy");
        keepErrorHistory = Json.bool(privacy, "keepErrorHistory", true);
        keepServerHistory = Json.bool(privacy, "keepServerHistory", false);
        serverProfiles.clear();
        for (Map.Entry<String, JsonElement> e : Json.object(o, "serverProfiles").entrySet()) {
            String host = normaliseHost(e.getKey());
            JsonElement v = e.getValue();
            if (host.isEmpty() || !v.isJsonPrimitive() || !v.getAsJsonPrimitive().isString()) {
                report.add("Ignored invalid server binding '" + e.getKey() + "'");
                continue;
            }
            serverProfiles.put(host, v.getAsString());
        }
        return report;
    }
}
