package dev.lumina.config;

import dev.lumina.utils.ErrorSink;
import dev.lumina.utils.Log;
import org.slf4j.Logger;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Debounced background saver. {@link #markDirty()} is cheap and may be called from any thread on
 * every change; the actual save runs at most once per {@code delayMillis} on a single daemon thread.
 * {@link #flush()} saves synchronously (used on profile switch and shutdown).
 */
public final class AutoSaver implements AutoCloseable {
    private static final Logger LOG = Log.of("autosave");

    @FunctionalInterface
    public interface SaveAction {
        void save() throws Exception;
    }

    private final SaveAction action;
    private final ErrorSink errors;
    private final long delayMillis;
    private final String name;
    private final AtomicBoolean dirty = new AtomicBoolean();
    private final AtomicBoolean scheduled = new AtomicBoolean();
    private final AtomicInteger saves = new AtomicInteger();
    private final ScheduledExecutorService executor;
    private volatile boolean closed;

    public AutoSaver(String name, long delayMillis, ErrorSink errors, SaveAction action) {
        this.name = name;
        this.delayMillis = delayMillis;
        this.errors = errors;
        this.action = action;
        this.executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "Lumina-AutoSave-" + name);
            t.setDaemon(true);
            return t;
        });
    }

    public void markDirty() {
        dirty.set(true);
        if (closed) {
            return;
        }
        if (scheduled.compareAndSet(false, true)) {
            try {
                executor.schedule(() -> {
                    scheduled.set(false);
                    saveIfDirty();
                }, delayMillis, TimeUnit.MILLISECONDS);
            } catch (RuntimeException rejected) {
                scheduled.set(false);
            }
        }
    }

    /** Saves now if anything changed since the last save. */
    public void flush() {
        saveIfDirty();
    }

    private synchronized void saveIfDirty() {
        if (!dirty.compareAndSet(true, false)) {
            return;
        }
        try {
            action.save();
            saves.incrementAndGet();
        } catch (Exception e) {
            dirty.set(true); // retried on the next change or flush
            LOG.warn("Auto-save '{}' failed: {}", name, e.toString());
            errors.report("autosave:" + name, e);
        }
    }

    public int saveCount() {
        return saves.get();
    }

    public boolean isDirty() {
        return dirty.get();
    }

    @Override
    public void close() {
        closed = true;
        executor.shutdown();
        saveIfDirty();
    }
}
