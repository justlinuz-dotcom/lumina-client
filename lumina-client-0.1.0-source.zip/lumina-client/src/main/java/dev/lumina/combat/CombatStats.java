package dev.lumina.combat;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.MathUtil;

/**
 * Local combat statistics: a per-session set and a lifetime set (stored on this machine only).
 *
 * <p>"Attacks" are attack actions this client sent against an entity; they are not confirmed damage
 * dealt. "Damage taken" is the health the local player visibly lost, in half-hearts.
 */
public final class CombatStats {

    /** Immutable view of one set of counters. */
    public record Counters(long attacks, long hitsTaken, double damageTaken, int maxCombo, long leftClicks, long rightClicks) {
    }

    private long attacks;
    private long hitsTaken;
    private double damageTaken;
    private int maxCombo;
    private long leftClicks;
    private long rightClicks;

    private Counters base = new Counters(0, 0, 0, 0, 0, 0);

    public synchronized void onAttack() {
        attacks++;
    }

    public synchronized void onDamageTaken(float amount) {
        if (!MathUtil.isFinite(amount) || amount <= 0) {
            return;
        }
        hitsTaken++;
        damageTaken += amount;
    }

    public synchronized void onCombo(int combo) {
        maxCombo = Math.max(maxCombo, combo);
    }

    public synchronized void onClick(int button) {
        if (button == CpsCounter.LEFT) {
            leftClicks++;
        } else if (button == CpsCounter.RIGHT) {
            rightClicks++;
        }
    }

    public synchronized Counters session() {
        return new Counters(attacks, hitsTaken, damageTaken, maxCombo, leftClicks, rightClicks);
    }

    /** Lifetime totals = stored totals loaded from disk + this session. */
    public synchronized Counters lifetime() {
        return new Counters(base.attacks() + attacks, base.hitsTaken() + hitsTaken, base.damageTaken() + damageTaken,
                Math.max(base.maxCombo(), maxCombo), base.leftClicks() + leftClicks, base.rightClicks() + rightClicks);
    }

    public synchronized void resetSession() {
        attacks = 0;
        hitsTaken = 0;
        damageTaken = 0;
        maxCombo = 0;
        leftClicks = 0;
        rightClicks = 0;
    }

    /** Clears both the session and the stored lifetime totals. */
    public synchronized void resetAll() {
        resetSession();
        base = new Counters(0, 0, 0, 0, 0, 0);
    }

    public synchronized JsonObject toJson() {
        Counters c = lifetime();
        JsonObject o = new JsonObject();
        o.addProperty("attacksSent", c.attacks());
        o.addProperty("hitsTaken", c.hitsTaken());
        o.addProperty("damageTaken", c.damageTaken());
        o.addProperty("maxCombo", c.maxCombo());
        o.addProperty("leftClicks", c.leftClicks());
        o.addProperty("rightClicks", c.rightClicks());
        return o;
    }

    /** Loads stored lifetime totals (invalid or negative values count as zero) and clears the session. */
    public synchronized void loadJson(JsonObject o) {
        base = new Counters(nonNegative(o, "attacksSent"), nonNegative(o, "hitsTaken"), nonNegativeDouble(o, "damageTaken"),
                (int) Math.min(Integer.MAX_VALUE, nonNegative(o, "maxCombo")), nonNegative(o, "leftClicks"),
                nonNegative(o, "rightClicks"));
        resetSession();
    }

    private static long nonNegative(JsonObject o, String key) {
        JsonElement e = o.get(key);
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) {
            double v = e.getAsDouble();
            if (MathUtil.isFinite(v) && v > 0) {
                return v >= Long.MAX_VALUE ? Long.MAX_VALUE / 2 : (long) v;
            }
        }
        return 0;
    }

    private static double nonNegativeDouble(JsonObject o, String key) {
        JsonElement e = o.get(key);
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) {
            double v = e.getAsDouble();
            if (MathUtil.isFinite(v) && v > 0) {
                return v;
            }
        }
        return 0;
    }
}
