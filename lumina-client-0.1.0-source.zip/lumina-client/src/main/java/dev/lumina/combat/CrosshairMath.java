package dev.lumina.combat;

import dev.lumina.utils.MathUtil;

/** Pure maths behind the dynamic crosshair: how wide the gap is and how smoothly it moves. */
public final class CrosshairMath {
    private CrosshairMath() {
    }

    /**
     * Gap between the crosshair centre and its arms.
     *
     * @param baseGap      resting gap in GUI pixels
     * @param maxExpansion largest extra gap the dynamics may add
     * @param cooldown     attack cooldown progress in [0, 1], or a negative value when unknown
     * @param moving       the player is moving horizontally
     * @param sprinting    the player is sprinting
     * @param airborne     the player is not on the ground
     * @param sneaking     the player is sneaking (tightens the crosshair)
     */
    public static float gap(float baseGap, float maxExpansion, float cooldown, boolean moving, boolean sprinting,
                            boolean airborne, boolean sneaking) {
        float add = 0f;
        if (cooldown >= 0f) {
            add += (1f - MathUtil.clamp(cooldown, 0f, 1f)) * maxExpansion * 0.5f;
        }
        if (moving) {
            add += (sprinting ? 0.5f : 0.25f) * maxExpansion;
        }
        if (airborne) {
            add += 0.25f * maxExpansion;
        }
        if (sneaking) {
            add -= 0.25f * maxExpansion;
        }
        return baseGap + MathUtil.clamp(add, 0f, maxExpansion);
    }

    /**
     * Frame-rate independent exponential smoothing from {@code current} towards {@code target}.
     * A larger {@code speed} reaches the target faster; {@code dtSeconds <= 0} leaves the value unchanged.
     */
    public static float approach(float current, float target, float dtSeconds, float speed) {
        if (dtSeconds <= 0f || speed <= 0f) {
            return current;
        }
        float factor = 1f - (float) Math.exp(-speed * dtSeconds);
        return current + (target - current) * factor;
    }
}
