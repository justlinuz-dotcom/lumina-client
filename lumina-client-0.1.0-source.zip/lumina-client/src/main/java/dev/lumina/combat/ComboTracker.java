package dev.lumina.combat;

/**
 * Counts consecutive attacks. The combo continues while attacks arrive within {@code timeoutMillis}
 * of each other and breaks when the local player takes damage. It counts attacks sent by this client,
 * not confirmed hits on the target.
 */
public final class ComboTracker {
    private final long timeoutMillis;
    private int combo;
    private int maxCombo;
    private long lastAttack;

    public ComboTracker(long timeoutMillis) {
        if (timeoutMillis <= 0) {
            throw new IllegalArgumentException("timeout must be positive");
        }
        this.timeoutMillis = timeoutMillis;
    }

    /** Registers an attack and returns the combo length including it. */
    public synchronized int onAttack(long nowMillis) {
        if (combo > 0 && nowMillis - lastAttack > timeoutMillis) {
            combo = 0;
        }
        combo++;
        lastAttack = nowMillis;
        maxCombo = Math.max(maxCombo, combo);
        return combo;
    }

    /** Taking damage ends the combo. */
    public synchronized void onDamageTaken() {
        combo = 0;
    }

    /** Current combo, or 0 when the last attack is older than the timeout. */
    public synchronized int combo(long nowMillis) {
        return combo > 0 && nowMillis - lastAttack > timeoutMillis ? 0 : combo;
    }

    public synchronized int maxCombo() {
        return maxCombo;
    }

    public synchronized void reset() {
        combo = 0;
        maxCombo = 0;
        lastAttack = 0;
    }
}
