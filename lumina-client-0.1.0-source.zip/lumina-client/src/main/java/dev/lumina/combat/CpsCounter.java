package dev.lumina.combat;

import java.util.ArrayDeque;

/**
 * Clicks per second over a sliding one-second window, tracked separately for the left (0) and right (1)
 * mouse button. The value is an exact count of the clicks inside the window. It is information only:
 * nothing here generates, delays or alters clicks.
 */
public final class CpsCounter {
    public static final int LEFT = 0;
    public static final int RIGHT = 1;
    static final long WINDOW_MILLIS = 1000;
    /** No human clicks faster than this; also caps memory when a macro floods events. */
    static final int MAX_TRACKED = 256;

    private final ArrayDeque<Long> leftWindow = new ArrayDeque<>();
    private final ArrayDeque<Long> rightWindow = new ArrayDeque<>();
    private final long[] totals = new long[2];
    private final int[] peaks = new int[2];

    private ArrayDeque<Long> window(int button) {
        return button == LEFT ? leftWindow : rightWindow;
    }

    private static boolean valid(int button) {
        return button == LEFT || button == RIGHT;
    }

    public synchronized void click(int button, long nowMillis) {
        if (!valid(button)) {
            return;
        }
        ArrayDeque<Long> w = window(button);
        prune(w, nowMillis);
        if (w.size() >= MAX_TRACKED) {
            w.pollFirst();
        }
        w.addLast(nowMillis);
        totals[button]++;
        peaks[button] = Math.max(peaks[button], w.size());
    }

    /** Clicks of the button during the last second. */
    public synchronized int cps(int button, long nowMillis) {
        if (!valid(button)) {
            return 0;
        }
        ArrayDeque<Long> w = window(button);
        prune(w, nowMillis);
        return w.size();
    }

    /** Highest one-second count seen since the last reset. */
    public synchronized int peak(int button) {
        return valid(button) ? peaks[button] : 0;
    }

    public synchronized long total(int button) {
        return valid(button) ? totals[button] : 0;
    }

    public synchronized void reset() {
        leftWindow.clear();
        rightWindow.clear();
        totals[0] = 0;
        totals[1] = 0;
        peaks[0] = 0;
        peaks[1] = 0;
    }

    private static void prune(ArrayDeque<Long> w, long now) {
        while (!w.isEmpty() && now - w.peekFirst() >= WINDOW_MILLIS) {
            w.pollFirst();
        }
    }
}
