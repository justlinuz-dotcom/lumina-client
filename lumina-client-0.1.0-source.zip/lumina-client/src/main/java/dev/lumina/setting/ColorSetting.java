package dev.lumina.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

/** ARGB colour setting, stored as a {@code #AARRGGBB} string ({@code #RRGGBB} is accepted on load). */
public final class ColorSetting extends Setting<Integer> {

    public ColorSetting(String id, String name, String description, int argbDefault) {
        super(id, name, description, argbDefault);
    }

    public int argb() {
        return get();
    }

    public static String format(int argb) {
        return String.format(Locale.ROOT, "#%08X", argb);
    }

    /** Parses {@code #RRGGBB} (opaque) or {@code #AARRGGBB}; returns null when malformed. */
    public static Integer parse(String text) {
        if (text == null) {
            return null;
        }
        String hex = text.trim();
        if (hex.startsWith("#")) {
            hex = hex.substring(1);
        }
        if (hex.length() != 6 && hex.length() != 8) {
            return null;
        }
        for (int i = 0; i < hex.length(); i++) {
            if (Character.digit(hex.charAt(i), 16) < 0) {
                return null;
            }
        }
        long v = Long.parseLong(hex, 16);
        if (hex.length() == 6) {
            v |= 0xFF000000L;
        }
        return (int) v;
    }

    @Override
    protected Integer coerce(Integer candidate) {
        return candidate;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(format(get()));
    }

    @Override
    public LoadStatus loadJson(JsonElement json) {
        if (json == null || !json.isJsonPrimitive() || !json.getAsJsonPrimitive().isString()) {
            return LoadStatus.INVALID;
        }
        String text = json.getAsString();
        Integer parsed = parse(text);
        if (parsed == null) {
            return LoadStatus.INVALID;
        }
        set(parsed);
        return text.trim().length() == 9 && text.trim().startsWith("#") && text.trim().equals(format(parsed))
                ? LoadStatus.OK : LoadStatus.ADJUSTED;
    }

    @Override
    public String display() {
        return format(get());
    }
}
