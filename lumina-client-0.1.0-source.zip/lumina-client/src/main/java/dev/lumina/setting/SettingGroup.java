package dev.lumina.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumina.utils.LoadReport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/** A named set of settings that is not owned by a module (theme, UI preferences, ...). */
public final class SettingGroup {
    private final String id;
    private final List<Setting<?>> settings = new ArrayList<>();
    private volatile Runnable changeListener = () -> {
    };

    public SettingGroup(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    public <S extends Setting<?>> S add(S setting) {
        for (Setting<?> existing : settings) {
            if (existing.id().equals(setting.id())) {
                throw new IllegalArgumentException("Duplicate setting '" + setting.id() + "' in group " + id);
            }
        }
        settings.add(setting);
        setting.onChange(v -> changeListener.run());
        return setting;
    }

    public List<Setting<?>> settings() {
        return Collections.unmodifiableList(settings);
    }

    public Optional<Setting<?>> find(String settingId) {
        return settings.stream().filter(s -> s.id().equals(settingId)).findFirst();
    }

    /** Called after any setting of the group changes (used to trigger auto-save). */
    public void onAnyChange(Runnable listener) {
        this.changeListener = listener;
    }

    public void reset() {
        settings.forEach(Setting::reset);
    }

    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        for (Setting<?> s : settings) {
            o.add(s.id(), s.toJson());
        }
        return o;
    }

    /** Missing values become defaults; invalid ones become defaults and are reported; unknown keys are reported. */
    public LoadReport loadJson(JsonObject json) {
        LoadReport report = new LoadReport();
        for (Setting<?> s : settings) {
            JsonElement v = json.get(s.id());
            if (v == null) {
                s.reset();
                continue;
            }
            LoadStatus status = s.loadJson(v);
            if (status == LoadStatus.INVALID) {
                s.reset();
                report.add("Invalid value for '" + id + "." + s.id() + "'; default used");
            } else if (status == LoadStatus.ADJUSTED) {
                report.add("Value for '" + id + "." + s.id() + "' was " + status.name().toLowerCase(Locale.ROOT)
                        + " to " + s.display());
            }
        }
        for (String key : json.keySet()) {
            if (find(key).isEmpty()) {
                report.add("Unknown setting '" + id + "." + key + "' ignored");
            }
        }
        return report;
    }
}
