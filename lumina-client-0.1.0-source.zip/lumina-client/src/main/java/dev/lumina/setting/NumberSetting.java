package dev.lumina.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.lumina.utils.MathUtil;

/**
 * Numeric setting bounded by {@code [min, max]} and optionally snapped to {@code step}.
 * With {@code integer = true} the value is always whole.
 */
public final class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;
    private final boolean integer;
    private final String unit;

    public NumberSetting(String id, String name, String description,
                         double defaultValue, double min, double max, double step, boolean integer, String unit) {
        super(id, name, description, normalise(defaultValue, min, max, step, integer));
        this.min = min;
        this.max = max;
        this.step = step;
        this.integer = integer;
        this.unit = unit == null ? "" : unit;
    }

    public static NumberSetting ofInt(String id, String name, String description,
                                      int defaultValue, int min, int max) {
        return new NumberSetting(id, name, description, defaultValue, min, max, 1, true, "");
    }

    public static NumberSetting ofDouble(String id, String name, String description,
                                         double defaultValue, double min, double max, double step) {
        return new NumberSetting(id, name, description, defaultValue, min, max, step, false, "");
    }

    private static Double normalise(double v, double min, double max, double step, boolean integer) {
        if (min > max) {
            throw new IllegalArgumentException("min > max");
        }
        double r = MathUtil.clamp(v, min, max);
        if (integer) {
            r = Math.round(r);
        } else if (step > 0) {
            r = MathUtil.clamp(MathUtil.snap(r - min, step) + min, min, max);
        }
        return r;
    }

    public double min() {
        return min;
    }

    public double max() {
        return max;
    }

    public double step() {
        return step;
    }

    public boolean isInteger() {
        return integer;
    }

    public double getDouble() {
        return get();
    }

    public float getFloat() {
        return get().floatValue();
    }

    public int getInt() {
        return (int) Math.round(get());
    }

    @Override
    protected Double coerce(Double candidate) {
        if (!MathUtil.isFinite(candidate)) {
            return null;
        }
        return normalise(candidate, min, max, step, integer);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(integer ? (Number) Long.valueOf(Math.round(get())) : (Number) get());
    }

    @Override
    public LoadStatus loadJson(JsonElement json) {
        if (json == null || !json.isJsonPrimitive() || !json.getAsJsonPrimitive().isNumber()) {
            return LoadStatus.INVALID;
        }
        double raw = json.getAsDouble();
        Double fixed = coerce(raw);
        if (fixed == null) {
            return LoadStatus.INVALID;
        }
        set(fixed);
        return Double.compare(fixed, raw) == 0 ? LoadStatus.OK : LoadStatus.ADJUSTED;
    }

    @Override
    public String display() {
        String text = integer ? Integer.toString(getInt()) : trim(get());
        return unit.isEmpty() ? text : text + " " + unit;
    }

    private static String trim(double v) {
        String s = String.format(java.util.Locale.ROOT, "%.2f", v);
        if (s.contains(".")) {
            s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        return s;
    }
}
