package dev.lumina.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Choice setting backed by an enum; stored in JSON by constant name. */
public final class EnumSetting<E extends Enum<E>> extends Setting<E> {
    private final Class<E> type;

    public EnumSetting(String id, String name, String description, E defaultValue) {
        super(id, name, description, defaultValue);
        this.type = defaultValue.getDeclaringClass();
    }

    public E[] options() {
        return type.getEnumConstants();
    }

    /** Selects the next option, wrapping around. */
    public void cycle() {
        E[] all = options();
        set(all[(get().ordinal() + 1) % all.length]);
    }

    @Override
    protected E coerce(E candidate) {
        return candidate;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(get().name());
    }

    @Override
    public LoadStatus loadJson(JsonElement json) {
        if (json == null || !json.isJsonPrimitive() || !json.getAsJsonPrimitive().isString()) {
            return LoadStatus.INVALID;
        }
        String text = json.getAsString().trim();
        for (E option : options()) {
            if (option.name().equals(text)) {
                set(option);
                return LoadStatus.OK;
            }
        }
        for (E option : options()) {
            if (option.name().equalsIgnoreCase(text)) {
                set(option);
                return LoadStatus.ADJUSTED;
            }
        }
        return LoadStatus.INVALID;
    }
}
