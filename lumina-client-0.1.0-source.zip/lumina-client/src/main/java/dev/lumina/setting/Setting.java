package dev.lumina.setting;

import com.google.gson.JsonElement;
import dev.lumina.utils.Log;

import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * A single configurable value of a module. Values are always validated by {@link #coerce}, so a
 * setting can never hold something outside its declared domain, whether the change came from the UI,
 * a profile import or a hand-edited file.
 *
 * <p>The value is volatile: background threads (auto-save, diagnostics) may read it while the game
 * thread writes it.
 */
public abstract class Setting<T> {
    private static final Pattern ID = Pattern.compile("[a-z][a-z0-9_]{0,47}");

    private final String id;
    private final String name;
    private final String description;
    private final T defaultValue;
    private volatile T value;
    private final CopyOnWriteArrayList<Consumer<T>> listeners = new CopyOnWriteArrayList<>();
    private volatile BooleanSupplier visibility = () -> true;

    /** {@code defaultValue} must already be valid for this setting's domain. */
    protected Setting(String id, String name, String description, T defaultValue) {
        if (id == null || !ID.matcher(id).matches()) {
            throw new IllegalArgumentException("Invalid setting id: " + id);
        }
        this.id = id;
        this.name = Objects.requireNonNull(name, "name");
        this.description = Objects.requireNonNull(description, "description");
        this.defaultValue = Objects.requireNonNull(defaultValue, "defaultValue");
        this.value = defaultValue;
    }

    public final String id() {
        return id;
    }

    public final String name() {
        return name;
    }

    public final String description() {
        return description;
    }

    public final T defaultValue() {
        return defaultValue;
    }

    public final T get() {
        return value;
    }

    /**
     * Sets a new value after validation.
     *
     * @return true when the stored value changed
     */
    public final boolean set(T candidate) {
        T coerced = candidate == null ? null : coerce(candidate);
        if (coerced == null) {
            return false;
        }
        T old = this.value;
        if (Objects.equals(old, coerced)) {
            return false;
        }
        this.value = coerced;
        for (Consumer<T> l : listeners) {
            try {
                l.accept(coerced);
            } catch (RuntimeException e) {
                Log.of("setting").warn("Listener of setting '{}' failed: {}", id, e.toString());
            }
        }
        return true;
    }

    public final void reset() {
        set(defaultValue);
    }

    public final boolean isDefault() {
        return Objects.equals(value, defaultValue);
    }

    /** Registers a listener invoked after every successful change. */
    public final void onChange(Consumer<T> listener) {
        listeners.add(Objects.requireNonNull(listener));
    }

    /** UI hint: the setting is only relevant while the condition holds (it is still persisted). */
    public final void visibleWhen(BooleanSupplier condition) {
        this.visibility = Objects.requireNonNull(condition);
    }

    public final boolean isVisible() {
        return visibility.getAsBoolean();
    }

    /**
     * Normalises a candidate into the domain of this setting (clamp, snap, ...).
     *
     * @return the valid value, or {@code null} when the candidate cannot be repaired
     */
    protected abstract T coerce(T candidate);

    public abstract JsonElement toJson();

    /** Loads a value from JSON. On {@link LoadStatus#INVALID} the current value is left untouched. */
    public abstract LoadStatus loadJson(JsonElement json);

    /** Human-readable value for tooltips and the UI. */
    public String display() {
        return String.valueOf(value);
    }
}
