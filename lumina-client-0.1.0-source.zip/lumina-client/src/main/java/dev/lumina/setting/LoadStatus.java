package dev.lumina.setting;

/** Outcome of loading a setting value from JSON. */
public enum LoadStatus {
    /** Value accepted exactly as stored. */
    OK,
    /** Value was usable but had to be corrected (clamped, snapped, case-folded). */
    ADJUSTED,
    /** Value was unusable; the setting keeps its previous value. */
    INVALID
}
