package dev.lumina.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class BooleanSetting extends Setting<Boolean> {

    public BooleanSetting(String id, String name, String description, boolean defaultValue) {
        super(id, name, description, defaultValue);
    }

    public boolean isOn() {
        return get();
    }

    public void toggle() {
        set(!get());
    }

    @Override
    protected Boolean coerce(Boolean candidate) {
        return candidate;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(get());
    }

    @Override
    public LoadStatus loadJson(JsonElement json) {
        if (json != null && json.isJsonPrimitive() && json.getAsJsonPrimitive().isBoolean()) {
            set(json.getAsBoolean());
            return LoadStatus.OK;
        }
        return LoadStatus.INVALID;
    }
}
