package dev.lumina.profile;

import com.google.gson.JsonObject;
import dev.lumina.module.ModuleManager;
import dev.lumina.utils.LoadReport;

/** Profile section holding module states, settings, key bindings and favourites. */
public final class ModulesSection implements ProfileParticipant {
    public static final String KEY = "modules";
    private final ModuleManager manager;

    public ModulesSection(ModuleManager manager) {
        this.manager = manager;
    }

    @Override
    public String sectionKey() {
        return KEY;
    }

    @Override
    public JsonObject save() {
        return manager.toJson().getAsJsonObject("modules");
    }

    @Override
    public LoadReport load(JsonObject section) {
        JsonObject root = new JsonObject();
        root.add("modules", section);
        return manager.loadJson(root);
    }
}
