package dev.lumina.profile;

import com.google.gson.JsonObject;
import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.NumberSetting;
import dev.lumina.setting.SettingGroup;
import dev.lumina.utils.LoadReport;

/** Interface preferences and global hot keys; part of every profile. */
public final class UiPreferences implements ProfileParticipant {
    public static final String KEY = "ui";
    /** GLFW_KEY_RIGHT_SHIFT. */
    public static final int DEFAULT_CLICK_GUI_KEY = 344;

    private final SettingGroup group = new SettingGroup(KEY);

    public final BooleanSetting showTooltips = group.add(new BooleanSetting("show_tooltips", "Tooltips",
            "Show explanations when hovering modules and settings.", true));
    public final BooleanSetting compactLists = group.add(new BooleanSetting("compact_lists", "Compact lists",
            "Use tighter spacing between the rows of every menu page.", false));
    public final NumberSetting clickGuiKey = group.add(new NumberSetting("click_gui_key", "Click GUI key",
            "Key that opens the Click GUI (-1 = unbound; default Right Shift).",
            DEFAULT_CLICK_GUI_KEY, -1, 348, 1, true, ""));
    public final NumberSetting hudEditorKey = group.add(new NumberSetting("hud_editor_key", "HUD editor key",
            "Key that opens the HUD editor (-1 = unbound; it is always reachable from the Click GUI).",
            -1, -1, 348, 1, true, ""));
    public final BooleanSetting notifications = group.add(new BooleanSetting("notifications", "Notifications",
            "Show on-screen notifications for module and profile changes.", true));

    public SettingGroup group() {
        return group;
    }

    @Override
    public String sectionKey() {
        return KEY;
    }

    @Override
    public JsonObject save() {
        return group.toJson();
    }

    @Override
    public LoadReport load(JsonObject section) {
        return group.loadJson(section);
    }
}
