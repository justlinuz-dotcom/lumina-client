package dev.lumina.profile;

import com.google.gson.JsonObject;
import dev.lumina.setting.ColorSetting;
import dev.lumina.setting.NumberSetting;
import dev.lumina.setting.SettingGroup;
import dev.lumina.utils.LoadReport;

/** Visual theme of the client UI; part of every profile. */
public final class ThemeSettings implements ProfileParticipant {
    public static final String KEY = "theme";

    private final SettingGroup group = new SettingGroup(KEY);

    public final ColorSetting accent = group.add(new ColorSetting("accent", "Accent colour",
            "Highlight colour used for toggles, sliders and selections.", 0xFF5B8CFF));
    public final ColorSetting background = group.add(new ColorSetting("background", "Panel background",
            "Background colour of menus and HUD panels (alpha controls transparency).", 0xE6121419));
    public final NumberSetting cornerRadius = group.add(new NumberSetting("corner_radius", "Corner radius",
            "Roundness of the menu panel's corners, in GUI pixels.", 4, 0, 10, 1, true, "px"));
    public final NumberSetting uiScale = group.add(new NumberSetting("ui_scale", "Menu scale",
            "Extra scale applied to the client menus on top of Minecraft's GUI scale.", 1.0, 0.75, 2.0, 0.05, false, "x"));

    public SettingGroup group() {
        return group;
    }

    @Override
    public String sectionKey() {
        return KEY;
    }

    @Override
    public JsonObject save() {
        return group.toJson();
    }

    @Override
    public LoadReport load(JsonObject section) {
        return group.loadJson(section);
    }
}
