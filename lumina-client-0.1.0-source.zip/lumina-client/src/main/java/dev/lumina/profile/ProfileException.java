package dev.lumina.profile;

/** A profile operation was refused; the message is suitable for showing to the user. */
public final class ProfileException extends Exception {
    private static final long serialVersionUID = 1L;

    public ProfileException(String message) {
        super(message);
    }

    public ProfileException(String message, Throwable cause) {
        super(message, cause);
    }
}
