package dev.lumina.profile;

import com.google.gson.JsonObject;
import dev.lumina.utils.LoadReport;

/**
 * A part of the client whose state is stored in a profile (modules, HUD layout, theme, UI
 * preferences). Loading an empty object must restore defaults. Participants only ever touch this
 * client's own state; profile data can never reach other mods' files.
 */
public interface ProfileParticipant {

    /** Stable key of the section inside the profile file. */
    String sectionKey();

    JsonObject save();

    LoadReport load(JsonObject section);
}
