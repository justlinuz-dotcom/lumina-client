package dev.lumina.profile;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.lumina.config.ClientPaths;
import dev.lumina.config.GlobalConfigStore;
import dev.lumina.config.GlobalSettings;
import dev.lumina.config.SafeJsonFile;
import dev.lumina.event.ClientEvents;
import dev.lumina.event.EventBus;
import dev.lumina.utils.ErrorSink;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import dev.lumina.utils.Log;
import dev.lumina.utils.NameRules;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.LongSupplier;
import java.util.stream.Stream;

/**
 * Creates, stores and switches profiles. A profile is one JSON file made of sections contributed by
 * {@link ProfileParticipant}s. Switching only replaces this client's own state; it never writes
 * outside the client's folder and never runs anything contained in a profile.
 *
 * <p>Importing is deliberately narrow: only files placed in the {@code imports} folder are read, only
 * known sections are kept, and size / nesting limits apply.
 */
public final class ProfileManager {
    private static final Logger LOG = Log.of("profile");

    public static final String FORMAT = "lumina-profile";
    public static final int SCHEMA = 1;
    private static final int MAX_BACKUPS = 10;
    private static final long BACKUP_INTERVAL_MILLIS = 10 * 60_000L;

    /** {@code damaged} files are listed too, so they are never mistaken for "no profile" and overwritten. */
    public record ProfileInfo(String id, String name, long modifiedMillis, boolean damaged) {
    }

    private final ClientPaths paths;
    private final GlobalConfigStore globalStore;
    private final List<ProfileParticipant> participants;
    private final EventBus bus;
    private final ErrorSink errors;
    private final LongSupplier clock;
    private final Map<String, SafeJsonFile> files = new HashMap<>();

    public ProfileManager(ClientPaths paths, GlobalConfigStore globalStore, List<ProfileParticipant> participants,
                          EventBus bus, ErrorSink errors, LongSupplier clock) {
        this.paths = paths;
        this.globalStore = globalStore;
        this.participants = List.copyOf(participants);
        this.bus = bus;
        this.errors = errors;
        this.clock = clock;
    }

    private GlobalSettings global() {
        return globalStore.settings();
    }

    private SafeJsonFile file(String id) {
        return files.computeIfAbsent(id, k -> new SafeJsonFile(paths.profiles().resolve(k + ".json"),
                paths.backups(), SCHEMA, MAX_BACKUPS, BACKUP_INTERVAL_MILLIS, clock));
    }

    private Path profilePath(String id) {
        return paths.profiles().resolve(id + ".json");
    }

    public synchronized String activeId() {
        return global().activeProfile();
    }

    public synchronized boolean exists(String id) {
        return Files.isRegularFile(profilePath(id));
    }

    // ---- listing -------------------------------------------------------------------------------

    public synchronized List<ProfileInfo> list() {
        List<ProfileInfo> out = new ArrayList<>();
        if (!Files.isDirectory(paths.profiles())) {
            return out;
        }
        try (Stream<Path> s = Files.list(paths.profiles())) {
            for (Path p : (Iterable<Path>) s::iterator) {
                String fn = p.getFileName().toString();
                if (!fn.endsWith(".json") || !Files.isRegularFile(p)) {
                    continue;
                }
                String id = fn.substring(0, fn.length() - 5);
                try {
                    long modified = Files.getLastModifiedTime(p).toMillis();
                    try {
                        JsonObject o = Json.parseObject(Json.readLimited(p, Json.MAX_CONFIG_BYTES), Json.MAX_DEPTH);
                        out.add(new ProfileInfo(id, Json.string(o, "name", id), modified, false));
                    } catch (IOException | JsonParseException | IllegalStateException e) {
                        LOG.warn("Profile file {} is damaged: {}", fn, e.toString());
                        out.add(new ProfileInfo(id, id, modified, true));
                    }
                } catch (IOException e) {
                    LOG.warn("Cannot stat profile file {}: {}", fn, e.toString());
                }
            }
        } catch (IOException e) {
            errors.report("profile:list", e);
        }
        out.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
        return out;
    }

    // ---- startup / save ------------------------------------------------------------------------

    /**
     * Makes sure a profile exists and applies the active one. If no profile exists yet, a profile named
     * "Default" is created from the current (default) state.
     */
    public synchronized LoadReport loadActive() {
        LoadReport report = new LoadReport();
        try {
            paths.ensureCreated();
            if (list().isEmpty()) {
                writeProfile(GlobalSettings.DEFAULT_PROFILE_ID, "Default", captureSections());
                global().setActiveProfile(GlobalSettings.DEFAULT_PROFILE_ID);
                globalStore.save();
            }
        } catch (IOException e) {
            errors.report("profile:init", e);
            report.add("Could not prepare the profile folder: " + e.getMessage());
            return report;
        }
        String id = global().activeProfile();
        if (!exists(id)) {
            List<ProfileInfo> all = list();
            String fallback = all.isEmpty() ? GlobalSettings.DEFAULT_PROFILE_ID : all.get(0).id();
            report.add("Active profile '" + id + "' not found; using '" + fallback + "'");
            id = fallback;
            global().setActiveProfile(id);
            globalStore.save();
        }
        report.addAll(applyFromDisk(id));
        return report;
    }

    /** Writes the live state into the active profile file. */
    public synchronized void saveActive() throws IOException {
        String id = global().activeProfile();
        writeProfile(id, nameOf(id), captureSections());
    }

    private String nameOf(String id) {
        SafeJsonFile.ReadResult r = file(id).read();
        return Json.string(r.data(), "name", id);
    }

    // ---- create / rename / duplicate / delete --------------------------------------------------

    /**
     * Creates a profile.
     *
     * @param copyCurrent true to store the live state, false to store pure defaults
     */
    public synchronized String create(String name, boolean copyCurrent) throws ProfileException {
        String id = requireFreeId(name);
        JsonObject sections = copyCurrent ? captureSections() : emptySections();
        try {
            writeProfile(id, name, sections);
        } catch (IOException e) {
            throw new ProfileException("Could not write profile: " + e.getMessage(), e);
        }
        return id;
    }

    public synchronized String rename(String id, String newName) throws ProfileException {
        requireExists(id);
        String problem = NameRules.validate(newName);
        if (problem != null) {
            throw new ProfileException(problem);
        }
        String newId = NameRules.toId(newName);
        if (!newId.equals(id) && exists(newId)) {
            throw new ProfileException("A profile named '" + newName + "' already exists");
        }
        SafeJsonFile.ReadResult read = file(id).read();
        if (read.status() == SafeJsonFile.Status.CORRUPT_DEFAULTED || read.status() == SafeJsonFile.Status.INCOMPATIBLE) {
            throw new ProfileException("Profile file is unreadable: " + read.detail());
        }
        JsonObject data = read.data();
        data.addProperty("name", newName);
        try {
            file(newId).write(data);
            if (!newId.equals(id)) {
                Files.deleteIfExists(profilePath(id));
                files.remove(id);
                if (id.equals(global().activeProfile())) {
                    global().setActiveProfile(newId);
                    globalStore.save();
                }
                retargetServerBindings(id, newId);
            }
        } catch (IOException e) {
            throw new ProfileException("Could not rename profile: " + e.getMessage(), e);
        }
        return newId;
    }

    public synchronized String duplicate(String id, String newName) throws ProfileException {
        requireExists(id);
        String newId = requireFreeId(newName);
        SafeJsonFile.ReadResult read = file(id).read();
        if (read.status() == SafeJsonFile.Status.CORRUPT_DEFAULTED || read.status() == SafeJsonFile.Status.INCOMPATIBLE) {
            throw new ProfileException("Profile file is unreadable: " + read.detail());
        }
        // Duplicating the active profile copies the live state, not the last saved one.
        JsonObject data = id.equals(global().activeProfile()) ? buildProfile(newName, captureSections()) : read.data();
        data.addProperty("name", newName);
        try {
            file(newId).write(data);
        } catch (IOException e) {
            throw new ProfileException("Could not duplicate profile: " + e.getMessage(), e);
        }
        return newId;
    }

    /** Deletes a profile. The file is kept in the backup folder so an accidental delete is recoverable. */
    public synchronized void delete(String id) throws ProfileException {
        requireExists(id);
        if (id.equals(global().activeProfile())) {
            throw new ProfileException("The active profile cannot be deleted; switch to another one first");
        }
        try {
            Files.createDirectories(paths.backups());
            Files.move(profilePath(id), paths.backups().resolve("deleted-" + id + "-" + clock.getAsLong() + ".json"),
                    StandardCopyOption.REPLACE_EXISTING);
            files.remove(id);
        } catch (IOException e) {
            throw new ProfileException("Could not delete profile: " + e.getMessage(), e);
        }
        for (Map.Entry<String, String> binding : global().serverProfiles().entrySet()) {
            if (binding.getValue().equals(id)) {
                global().unbindServer(binding.getKey());
            }
        }
        globalStore.save();
    }

    private void retargetServerBindings(String oldId, String newId) {
        for (Map.Entry<String, String> binding : global().serverProfiles().entrySet()) {
            if (binding.getValue().equals(oldId)) {
                global().bindServer(binding.getKey(), newId);
            }
        }
        globalStore.save();
    }

    // ---- switching -----------------------------------------------------------------------------

    /** Saves the current profile, then loads and applies {@code id}. */
    public synchronized LoadReport switchTo(String id) throws ProfileException {
        requireExists(id);
        String previous = global().activeProfile();
        if (id.equals(previous)) {
            return new LoadReport();
        }
        try {
            saveActive();
        } catch (IOException e) {
            throw new ProfileException("Could not save the current profile before switching: " + e.getMessage(), e);
        }
        LoadReport report = applyFromDisk(id);
        global().setActiveProfile(id);
        globalStore.save();
        bus.post(new ClientEvents.ProfileSwitched(previous, id));
        return report;
    }

    /** Restores defaults for everything in the active profile and saves the result. */
    public synchronized LoadReport resetActiveToDefaults() throws ProfileException {
        LoadReport report = applySections(emptySections());
        try {
            saveActive();
        } catch (IOException e) {
            throw new ProfileException("Could not save the reset profile: " + e.getMessage(), e);
        }
        return report;
    }

    /** Profile bound to a server address, if the user enabled automatic switching and the profile exists. */
    public synchronized String resolveForServer(String address) {
        if (!global().autoSwitchProfiles()) {
            return null;
        }
        String id = global().profileForServer(address);
        return id != null && exists(id) ? id : null;
    }

    // ---- export / import -----------------------------------------------------------------------

    /** Exports the profile to {@code <client folder>/exports/<id>.json} and returns the path. */
    public synchronized Path export(String id) throws ProfileException {
        requireExists(id);
        JsonObject data = id.equals(global().activeProfile())
                ? buildProfile(nameOf(id), captureSections())
                : file(id).read().data();
        data.addProperty("format", FORMAT);
        try {
            Files.createDirectories(paths.exports());
            Path target = paths.exports().resolve(id + ".json");
            SafeJsonFile.writeAtomically(target, Json.GSON.toJson(data));
            return target;
        } catch (IOException e) {
            throw new ProfileException("Could not export profile: " + e.getMessage(), e);
        }
    }

    /** Imports a profile file placed in the {@code imports} folder. Only a plain file name is accepted. */
    public synchronized String importFile(String fileName) throws ProfileException {
        if (fileName == null || fileName.isBlank() || fileName.contains("/") || fileName.contains("\\")
                || fileName.contains("..") || !fileName.toLowerCase(java.util.Locale.ROOT).endsWith(".json")) {
            throw new ProfileException("Choose a .json file from the imports folder");
        }
        Path dir = paths.imports().toAbsolutePath().normalize();
        Path source = dir.resolve(fileName).normalize();
        if (!source.startsWith(dir)) {
            throw new ProfileException("File is outside the imports folder");
        }
        if (!Files.isRegularFile(source, LinkOption.NOFOLLOW_LINKS)) {
            throw new ProfileException("File not found in the imports folder (links are not followed)");
        }
        String text;
        try {
            text = Json.readLimited(source, Json.MAX_IMPORT_BYTES);
        } catch (IOException e) {
            throw new ProfileException("Cannot read file: " + e.getMessage(), e);
        }
        String base = fileName.substring(0, fileName.length() - 5);
        return importProfile(text, base);
    }

    /** Validates and stores profile JSON as a new profile; returns its id. Nothing is executed. */
    public synchronized String importProfile(String jsonText, String fallbackName) throws ProfileException {
        if (jsonText == null || jsonText.getBytes(StandardCharsets.UTF_8).length > Json.MAX_IMPORT_BYTES) {
            throw new ProfileException("Profile is empty or larger than " + (Json.MAX_IMPORT_BYTES / 1024) + " KB");
        }
        JsonObject o;
        try {
            o = Json.parseObject(jsonText, Json.MAX_DEPTH);
        } catch (JsonParseException e) {
            throw new ProfileException("Not a valid profile file: " + e.getMessage(), e);
        }
        if (!FORMAT.equals(Json.string(o, "format", ""))) {
            throw new ProfileException("Not a " + FORMAT + " file");
        }
        int schema = Json.integer(o, SafeJsonFile.SCHEMA_KEY, 1);
        if (schema > SCHEMA) {
            throw new ProfileException("Profile was created by a newer version (schema " + schema + ")");
        }
        if (schema < 1) {
            throw new ProfileException("Invalid schema version " + schema);
        }
        String name = sanitiseName(Json.string(o, "name", fallbackName), fallbackName);
        name = uniqueName(name);
        JsonObject known = new JsonObject();
        JsonObject sections = Json.object(o, "sections");
        for (ProfileParticipant p : participants) {
            JsonElement s = sections.get(p.sectionKey());
            known.add(p.sectionKey(), s != null && s.isJsonObject() ? s.getAsJsonObject() : new JsonObject());
        }
        String id = NameRules.toId(name);
        try {
            writeProfile(id, name, known);
        } catch (IOException e) {
            throw new ProfileException("Could not store imported profile: " + e.getMessage(), e);
        }
        return id;
    }

    static String sanitiseName(String raw, String fallback) {
        String candidate = raw == null ? "" : raw.trim();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < candidate.length() && sb.length() < NameRules.MAX_LENGTH; i++) {
            char c = candidate.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
                    || c == ' ' || c == '_' || c == '-' || c == '.';
            sb.append(ok ? c : '_');
        }
        String name = sb.toString().trim().replace("..", "_");
        while (name.endsWith(".")) {
            name = name.substring(0, name.length() - 1).trim();
        }
        if (NameRules.validate(name) == null) {
            return name;
        }
        if (fallback != null && !fallback.equals(raw)) {
            return sanitiseName(fallback, null);
        }
        return "Imported";
    }

    private String uniqueName(String base) {
        if (!exists(NameRules.toId(base))) {
            return base;
        }
        for (int n = 2; n < 1000; n++) {
            String suffix = " " + n;
            String trimmed = base.length() + suffix.length() > NameRules.MAX_LENGTH
                    ? base.substring(0, NameRules.MAX_LENGTH - suffix.length()).trim() : base;
            String candidate = trimmed + suffix;
            if (!exists(NameRules.toId(candidate))) {
                return candidate;
            }
        }
        return base + " " + clock.getAsLong() % 100000;
    }

    // ---- internals -----------------------------------------------------------------------------

    private String requireFreeId(String name) throws ProfileException {
        String problem = NameRules.validate(name);
        if (problem != null) {
            throw new ProfileException(problem);
        }
        String id = NameRules.toId(name);
        if (exists(id)) {
            throw new ProfileException("A profile named '" + name + "' already exists");
        }
        return id;
    }

    private void requireExists(String id) throws ProfileException {
        if (id == null || NameRules.validate(id) != null || !id.equals(NameRules.toId(id)) || !exists(id)) {
            throw new ProfileException("Profile not found: " + id);
        }
    }

    private JsonObject captureSections() {
        JsonObject sections = new JsonObject();
        for (ProfileParticipant p : participants) {
            sections.add(p.sectionKey(), p.save());
        }
        return sections;
    }

    private JsonObject emptySections() {
        JsonObject sections = new JsonObject();
        for (ProfileParticipant p : participants) {
            sections.add(p.sectionKey(), new JsonObject());
        }
        return sections;
    }

    private JsonObject buildProfile(String name, JsonObject sections) {
        JsonObject o = new JsonObject();
        o.addProperty("format", FORMAT);
        o.addProperty("name", name);
        o.addProperty("savedAt", clock.getAsLong());
        o.add("sections", sections);
        return o;
    }

    private void writeProfile(String id, String name, JsonObject sections) throws IOException {
        file(id).write(buildProfile(name, sections));
    }

    private LoadReport applyFromDisk(String id) {
        SafeJsonFile.ReadResult read = file(id).read();
        LoadReport report = new LoadReport();
        if (read.status() != SafeJsonFile.Status.LOADED) {
            report.add("Profile '" + id + "': " + read.detail());
        }
        report.addAll(applySections(Json.object(read.data(), "sections")));
        if (read.status() == SafeJsonFile.Status.CORRUPT_DEFAULTED || read.status() == SafeJsonFile.Status.INCOMPATIBLE) {
            // The bad file was moved to quarantine; re-establish a valid profile with the defaults just applied.
            try {
                writeProfile(id, id, captureSections());
            } catch (IOException e) {
                errors.report("profile:recreate", e);
            }
        }
        return report;
    }

    private LoadReport applySections(JsonObject sections) {
        LoadReport report = new LoadReport();
        for (ProfileParticipant p : participants) {
            try {
                report.addAll(p.load(Json.object(sections, p.sectionKey())));
            } catch (RuntimeException e) {
                LOG.error("Section '{}' failed to load", p.sectionKey(), e);
                errors.report("profile:load:" + p.sectionKey(), e);
                report.add("Section '" + p.sectionKey() + "' could not be applied: " + e.getMessage());
            }
        }
        return report;
    }
}
