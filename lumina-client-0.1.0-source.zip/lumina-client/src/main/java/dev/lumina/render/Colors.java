package dev.lumina.render;

import dev.lumina.utils.MathUtil;

/** ARGB colour helpers. */
public final class Colors {
    private Colors() {
    }

    /** Multiplies the alpha channel by {@code factor} (clamped to [0, 1]); RGB is unchanged. */
    public static int scaleAlpha(int argb, float factor) {
        int a = (argb >>> 24) & 0xFF;
        int scaled = Math.round(a * MathUtil.clamp(factor, 0f, 1f));
        return (scaled << 24) | (argb & 0x00FFFFFF);
    }

    /** Replaces the alpha channel (0..255). */
    public static int withAlpha(int argb, int alpha) {
        return (MathUtil.clamp(alpha, 0, 255) << 24) | (argb & 0x00FFFFFF);
    }

    /** Linear interpolation between two ARGB colours; {@code t} is clamped to [0, 1]. */
    public static int lerp(int from, int to, float t) {
        float k = MathUtil.clamp(t, 0f, 1f);
        int a = mix((from >>> 24) & 0xFF, (to >>> 24) & 0xFF, k);
        int r = mix((from >>> 16) & 0xFF, (to >>> 16) & 0xFF, k);
        int g = mix((from >>> 8) & 0xFF, (to >>> 8) & 0xFF, k);
        int b = mix(from & 0xFF, to & 0xFF, k);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int mix(int a, int b, float t) {
        return Math.round(a + (b - a) * t);
    }
}
