package dev.lumina.render;

import java.util.ArrayList;
import java.util.List;

/**
 * Splits a rectangle with rounded corners into plain rectangles (one per horizontal band), so the Minecraft
 * layer can draw it with ordinary fill calls and no special rendering code. The bands never overlap, so a
 * colour with transparency looks the same everywhere.
 */
public final class RoundedRect {
    private RoundedRect() {
    }

    /** The radius actually used: never negative and never more than half of the shorter side. */
    public static int effectiveRadius(int w, int h, int radius) {
        return Math.max(0, Math.min(radius, Math.min(w, h) / 2));
    }

    /**
     * @param radius corner radius in GUI pixels; reduced when the rectangle is too small for it
     * @return the bands, top to bottom: the rounded top rows, the full-width middle, the rounded bottom rows
     */
    public static List<Rect> bands(int x, int y, int w, int h, int radius, int argb) {
        List<Rect> out = new ArrayList<>();
        if (w <= 0 || h <= 0) {
            return out;
        }
        int r = effectiveRadius(w, h, radius);
        for (int i = 0; i < r; i++) {
            int inset = insetAtRow(r, i);
            out.add(new Rect(x + inset, y + i, w - 2 * inset, 1, argb));
        }
        out.add(new Rect(x, y + r, w, h - 2 * r, argb));
        for (int i = r - 1; i >= 0; i--) {
            int inset = insetAtRow(r, i);
            out.add(new Rect(x + inset, y + h - 1 - i, w - 2 * inset, 1, argb));
        }
        return out;
    }

    /** How far the row at distance {@code row} from the edge is pulled in, for a circle of radius {@code r}. */
    static int insetAtRow(int r, int row) {
        double dy = r - row - 0.5;
        return r - (int) Math.floor(Math.sqrt((double) r * r - dy * dy));
    }
}
