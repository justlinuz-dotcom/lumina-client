package dev.lumina.render;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds crosshair geometry as rectangles so rendering needs nothing but filled rectangles.
 *
 * <p>The centre cell is the {@code thickness x thickness} square whose top-left corner is
 * {@code (cx - thickness/2, cy - thickness/2)}; arms start {@code gap} pixels away from that square, so the
 * shape is symmetric around it.
 */
public final class CrosshairShape {

    public enum Style { CROSS, T_SHAPE, DOT, SQUARE }

    private static final int OUTLINE_COLOR = 0xFF000000;

    private CrosshairShape() {
    }

    /**
     * @param cx        centre x in GUI pixels
     * @param cy        centre y in GUI pixels
     * @param armLength length of each arm (or distance from the gap to the square's edge), in pixels
     * @param gap       distance between the centre cell and the start of each arm
     * @param thickness line thickness in pixels (at least 1)
     * @param dot       add a centre dot to CROSS / T_SHAPE / SQUARE
     * @param outline   draw a 1 px black outline behind every rectangle
     */
    public static List<Rect> build(Style style, int cx, int cy, int armLength, int gap, int thickness,
                                   int argb, boolean dot, boolean outline) {
        int t = Math.max(1, thickness);
        int len = Math.max(1, armLength);
        int g = Math.max(0, gap);
        int left = cx - t / 2;
        int top = cy - t / 2;
        List<Rect> fills = new ArrayList<>();

        switch (style) {
            case DOT -> fills.add(new Rect(left, top, t, t, argb));
            case SQUARE -> {
                int r = g + len;
                int x0 = left - r;
                int y0 = top - r;
                int size = t + 2 * r;
                fills.add(new Rect(x0, y0, size, t, argb));
                fills.add(new Rect(x0, y0 + size - t, size, t, argb));
                fills.add(new Rect(x0, y0 + t, t, size - 2 * t, argb));
                fills.add(new Rect(x0 + size - t, y0 + t, t, size - 2 * t, argb));
            }
            case CROSS, T_SHAPE -> {
                fills.add(new Rect(left - g - len, top, len, t, argb));          // left arm
                fills.add(new Rect(left + t + g, top, len, t, argb));            // right arm
                fills.add(new Rect(left, top + t + g, t, len, argb));            // bottom arm
                if (style == Style.CROSS) {
                    fills.add(new Rect(left, top - g - len, t, len, argb));      // top arm
                }
            }
            default -> throw new IllegalStateException("Unhandled style " + style);
        }
        if (dot && style != Style.DOT) {
            fills.add(new Rect(left, top, t, t, argb));
        }
        if (!outline) {
            return fills;
        }
        List<Rect> all = new ArrayList<>(fills.size() * 2);
        for (Rect r : fills) {
            all.add(new Rect(r.x() - 1, r.y() - 1, r.w() + 2, r.h() + 2, OUTLINE_COLOR));
        }
        all.addAll(fills);
        return all;
    }
}
