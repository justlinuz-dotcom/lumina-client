package dev.lumina.render;

/** A filled axis-aligned rectangle in GUI pixels. The Minecraft layer draws these with one fill call each. */
public record Rect(int x, int y, int w, int h, int argb) {

    public int right() {
        return x + w;
    }

    public int bottom() {
        return y + h;
    }
}
