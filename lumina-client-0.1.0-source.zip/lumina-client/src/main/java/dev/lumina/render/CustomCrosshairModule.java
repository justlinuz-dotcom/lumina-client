package dev.lumina.render;

import dev.lumina.client.GameState;
import dev.lumina.combat.CrosshairMath;
import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.ColorSetting;
import dev.lumina.setting.EnumSetting;
import dev.lumina.setting.NumberSetting;

import java.util.List;

/**
 * Replaces the look of the crosshair. It is purely cosmetic: the point the player is aiming at, the
 * reach and every hit check are decided by the game and are not touched. With the dynamic option the gap
 * opens and closes with movement and the attack cooldown, which only visualises information the player
 * already has.
 */
public final class CustomCrosshairModule extends ClientModule {
    private static final float MOVING_SPEED = 0.3f;
    private static final float SMOOTHING_SPEED = 14f;

    final EnumSetting<CrosshairShape.Style> style = add(new EnumSetting<>("style", "Style", "Shape of the crosshair.",
            CrosshairShape.Style.CROSS));
    final NumberSetting length = add(NumberSetting.ofInt("length", "Arm length", "Length of each arm in pixels.", 5, 1, 24));
    final NumberSetting gap = add(NumberSetting.ofInt("gap", "Gap", "Space between the centre and the arms in pixels.", 2, 0, 16));
    final NumberSetting thickness = add(NumberSetting.ofInt("thickness", "Thickness", "Line thickness in pixels.", 1, 1, 6));
    final ColorSetting color = add(new ColorSetting("color", "Colour", "Crosshair colour (#RRGGBB or #AARRGGBB).", 0xFFFFFFFF));
    final BooleanSetting dot = add(new BooleanSetting("dot", "Centre dot", "Adds a dot in the centre.", false));
    final BooleanSetting outline = add(new BooleanSetting("outline", "Outline", "Adds a thin black outline so it stays visible on any background.", true));
    final BooleanSetting dynamic = add(new BooleanSetting("dynamic", "Dynamic gap",
            "Opens the gap while moving, jumping or recharging the attack, and tightens it while sneaking.", false));
    final NumberSetting expansion = add(NumberSetting.ofInt("expansion", "Dynamic spread", "Largest extra gap of the dynamic mode, in pixels.", 6, 1, 16));
    final BooleanSetting hideVanilla = add(new BooleanSetting("hide_vanilla", "Hide vanilla crosshair",
            "Hides the vanilla crosshair while this one is shown. Turn off to draw on top of it.", true));

    private float smoothedGap = Float.NaN;

    public CustomCrosshairModule() {
        super("custom_crosshair", "Custom Crosshair", "Draws your own crosshair: shape, size, colour, outline and optional dynamic gap.",
                Category.VISUALS);
        expansion.visibleWhen(dynamic::isOn);
    }

    @Override
    protected void onDisable() {
        smoothedGap = Float.NaN;
    }

    /** True when the Minecraft layer should skip the vanilla crosshair this frame. */
    public boolean replacesVanilla() {
        return isEnabled() && hideVanilla.isOn();
    }

    /**
     * Rectangles to draw for this frame, centred on ({@code cx}, {@code cy}).
     *
     * @param dtSeconds time since the previous frame, used for smoothing the dynamic gap
     */
    public List<Rect> rects(GameState state, int cx, int cy, float dtSeconds) {
        if (!state.inWorld()) {
            return List.of();
        }
        float target = gap.getInt();
        if (dynamic.isOn()) {
            boolean moving = state.speedBlocksPerSecond() > MOVING_SPEED;
            target = CrosshairMath.gap(gap.getInt(), expansion.getInt(), state.attackCooldown(), moving,
                    state.sprinting(), !state.onGround(), state.sneaking());
            smoothedGap = Float.isNaN(smoothedGap) ? target : CrosshairMath.approach(smoothedGap, target, dtSeconds, SMOOTHING_SPEED);
        } else {
            smoothedGap = Float.NaN;
            return build(cx, cy, Math.round(target));
        }
        return build(cx, cy, Math.round(smoothedGap));
    }

    /** Static picture for settings screens and the HUD editor (never dynamic). */
    public List<Rect> previewRects(int cx, int cy) {
        return build(cx, cy, gap.getInt());
    }

    private List<Rect> build(int cx, int cy, int gapPixels) {
        return CrosshairShape.build(style.get(), cx, cy, length.getInt(), gapPixels, thickness.getInt(),
                color.argb(), dot.isOn(), outline.isOn());
    }
}
