package dev.lumina.compat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Reads the list of loaded mods and the runtime and tells the player what is missing or untested.
 * It only reports; it never downloads or installs anything. Recommended mods are separate projects by
 * other authors: this client does not bundle, copy or re-implement them.
 */
public final class CompatChecker {
    public static final int REQUIRED_JAVA = 21;

    public enum Level { OK, INFO, WARNING, ERROR }

    public record Note(Level level, String topic, String message) {
    }

    private record Recommended(String modId, String name, String purpose) {
    }

    private static final List<Recommended> RECOMMENDED = List.of(
            new Recommended("sodium", "Sodium", "a rendering engine for Minecraft; usually the biggest single change to frame rate"),
            new Recommended("lithium", "Lithium", "optimises game logic such as ticking and pathfinding"),
            new Recommended("ferritecore", "FerriteCore", "reduces memory use"));

    private CompatChecker() {
    }

    /**
     * @param loadedModIds   ids of every loaded mod
     * @param javaFeature    the running Java feature version (for example 21)
     * @param runningMc      the Minecraft version in use
     * @param targetMc       the Minecraft version this client was built for
     */
    public static List<Note> check(Set<String> loadedModIds, int javaFeature, String runningMc, String targetMc) {
        List<Note> notes = new ArrayList<>();
        if (javaFeature < REQUIRED_JAVA) {
            notes.add(new Note(Level.ERROR, "Java", "Java " + REQUIRED_JAVA + " or newer is required; this is Java " + javaFeature + "."));
        }
        if (runningMc != null && targetMc != null && !runningMc.equals(targetMc)) {
            notes.add(new Note(Level.WARNING, "Minecraft",
                    "Built for Minecraft " + targetMc + " but running " + runningMc + ". It has not been tested on this version."));
        }
        if (!loadedModIds.contains("fabric-api")) {
            notes.add(new Note(Level.ERROR, "Fabric API", "Fabric API is required and was not found. Install the version for your Minecraft release."));
        }
        for (Recommended r : RECOMMENDED) {
            if (loadedModIds.contains(r.modId())) {
                notes.add(new Note(Level.OK, r.name(), r.name() + " is installed. Lumina works alongside it and does not replace it."));
            } else {
                notes.add(new Note(Level.INFO, r.name(), r.name() + " is not installed. It is " + r.purpose()
                        + ". Optional: install it from its own page if it is available for your Minecraft version."));
            }
        }
        return notes;
    }

    /** True when at least one note is an error (the client should stay passive). */
    public static boolean hasBlockingProblem(List<Note> notes) {
        for (Note n : notes) {
            if (n.level() == Level.ERROR) {
                return true;
            }
        }
        return false;
    }
}
