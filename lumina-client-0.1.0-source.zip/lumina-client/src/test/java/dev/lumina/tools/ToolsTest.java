package dev.lumina.tools;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.tools.Timers.Kind;
import dev.lumina.utils.LoadReport;
import org.junit.Test;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class ToolsTest {

    // ---- calculator ----------------------------------------------------------------------------

    private static void calc(String expression, double expected) {
        Calculator.Result r = Calculator.evaluate(expression);
        assertTrue(expression + " -> " + r.error(), r.ok());
        assertEquals(expression, expected, r.value(), 1e-9);
    }

    private static void calcFails(String expression) {
        Calculator.Result r = Calculator.evaluate(expression);
        assertFalse(expression + " should fail but gave " + r.value(), r.ok());
        assertFalse(r.error().isBlank());
    }

    @Test
    public void calculatorFollowsPrecedenceAndAssociativity() {
        calc("1 + 2 * 3", 7);
        calc("(1 + 2) * 3", 9);
        calc("2 ^ 3 ^ 2", 512);
        calc("-2 ^ 2", -4);
        calc("2 ^ -1", 0.5);
        calc("(-2) ^ 2", 4);
        calc("-3 * -3", 9);
        calc("2 * 3 ^ 2", 18);
        calc("-(2 + 3)", -5);
        calc("10 - 4 - 3", 3);
        calc("100 / 10 / 5", 2);
        calc("17 % 5", 2);
        calc("--3", 3);
        calc("2 * -3", -6);
        calc(".5 + 1.25", 1.75);
        calc("64 * 36", 2304);
    }

    @Test
    public void calculatorFunctionsAndConstants() {
        calc("sqrt(144)", 12);
        calc("abs(-7.5)", 7.5);
        calc("floor(2.9) + ceil(2.1) + round(2.5)", 2 + 3 + 2);
        calc("min(3, 9) + max(3, 9)", 12);
        calc("pi * 2", Math.PI * 2);
        calc("E", Math.E);
        calc("  SQRT( 16 )  ", 4);
    }

    @Test
    public void calculatorRefusesBadInputWithAMessage() {
        calcFails("");
        calcFails("   ");
        calcFails("1 +");
        calcFails("(1 + 2");
        calcFails("1 + 2)");
        calcFails("1 / 0");
        calcFails("5 % 0");
        calcFails("sqrt(-1)");
        calcFails("foo(1)");
        calcFails("bar");
        calcFails("min(1)");
        calcFails("abs(1, 2)");
        calcFails("1 2");
        calcFails("2 $ 3");
        calcFails("10 ^ 1000");
        calcFails("1..2");
        calcFails("Runtime.getRuntime()");
    }

    @Test
    public void calculatorIsBounded() {
        calcFails("1+".repeat(150) + "1");
        calcFails("(".repeat(100) + "1" + ")".repeat(100));
        calc("(".repeat(30) + "1" + ")".repeat(30), 1);
        assertTrue(Calculator.evaluate(null).error().length() > 0);
    }

    @Test
    public void calculatorDisplayIsReadable() {
        assertEquals("7", Calculator.evaluate("3.5 * 2").display());
        assertEquals("0.333333", Calculator.evaluate("1 / 3").display());
        assertEquals("-2.5", Calculator.evaluate("-5 / 2").display());
        assertEquals("Division by zero", Calculator.evaluate("1/0").display());
    }

    // ---- coordinates ---------------------------------------------------------------------------

    @Test
    public void netherAndChunkConversions() {
        assertEquals(12.5, CoordinateTools.overworldToNether(100), 1e-9);
        assertEquals(800, CoordinateTools.netherToOverworld(100), 1e-9);
        assertEquals(0, CoordinateTools.chunkOf(15.9));
        assertEquals(1, CoordinateTools.chunkOf(16));
        assertEquals(-1, CoordinateTools.chunkOf(-0.1));
        assertEquals(-2, CoordinateTools.chunkOf(-17));
        assertEquals(15, CoordinateTools.offsetInChunk(-1));
        assertEquals(0, CoordinateTools.offsetInChunk(32));
        assertEquals(5, CoordinateTools.offsetInChunk(-27));
        assertEquals("12, 64, -31", CoordinateTools.format(12.9, 64.0, -30.2));
    }

    @Test
    public void yawFollowsTheMinecraftConvention() {
        assertEquals(0f, CoordinateTools.yawTowards(0, 10), 1e-3);
        assertEquals(90f, CoordinateTools.yawTowards(-10, 0), 1e-3);
        assertEquals(180f, CoordinateTools.yawTowards(0, -10), 1e-3);
        assertEquals(270f, CoordinateTools.yawTowards(10, 0), 1e-3);
        assertEquals(0f, CoordinateTools.yawTowards(0, 0), 0);
        assertEquals(45f, CoordinateTools.yawTowards(-5, 5), 1e-3);
    }

    @Test
    public void turnToFacePicksTheShortestSignedAngle() {
        assertEquals(90f, CoordinateTools.turnToFace(0, 90), 1e-3);
        assertEquals(-90f, CoordinateTools.turnToFace(0, 270), 1e-3);
        assertEquals(20f, CoordinateTools.turnToFace(350, 10), 1e-3);
        assertEquals(-20f, CoordinateTools.turnToFace(10, 350), 1e-3);
        assertEquals(180f, CoordinateTools.turnToFace(0, 180), 1e-3);
        assertEquals(0f, CoordinateTools.turnToFace(-720, 0), 1e-3);
    }

    @Test
    public void distancesAndStacks() {
        assertEquals(5, CoordinateTools.distance(0, 0, 3, 4), 1e-9);
        assertEquals(7, CoordinateTools.distance3d(0, 0, 0, 2, 3, 6), 1e-9);
        assertEquals("2 stacks + 22", CoordinateTools.stacks(150, 64));
        assertEquals("1 stack", CoordinateTools.stacks(64, 64));
        assertEquals("1 item", CoordinateTools.stacks(1, 64));
        assertEquals("0 items", CoordinateTools.stacks(0, 64));
        assertEquals("10 stacks", CoordinateTools.stacks(160, 16));
        assertEquals("--", CoordinateTools.stacks(-1, 64));
        assertEquals("--", CoordinateTools.stacks(5, 0));
    }

    // ---- timers --------------------------------------------------------------------------------

    @Test
    public void stopwatchCountsPausesAndResets() {
        AtomicLong now = new AtomicLong(1000);
        Timers t = new Timers(now::get);
        Timers.Timer s = t.start(Kind.STOPWATCH, "", 0);
        assertEquals("Stopwatch", s.label());
        now.addAndGet(5_000);
        assertEquals(5_000, s.displayMillis(now.get()));
        t.pause(s.id());
        now.addAndGet(60_000);
        assertEquals("paused timers keep their value", 5_000, s.displayMillis(now.get()));
        t.resume(s.id());
        now.addAndGet(1_000);
        assertEquals(6_000, s.displayMillis(now.get()));
        t.reset(s.id());
        assertEquals(0, s.displayMillis(now.get()));
        assertTrue(s.running());
    }

    @Test
    public void countdownFinishesOnceAndStopsAtZero() {
        AtomicLong now = new AtomicLong(0);
        Timers t = new Timers(now::get);
        Timers.Timer c = t.start(Kind.COUNTDOWN, "Furnace", 10_000);
        now.set(4_000);
        assertEquals(6_000, c.displayMillis(now.get()));
        assertTrue(t.pollFinished().isEmpty());
        now.set(10_500);
        List<Timers.Timer> done = t.pollFinished();
        assertEquals(1, done.size());
        assertEquals("Furnace", done.get(0).label());
        assertTrue(t.pollFinished().isEmpty());
        now.set(99_000);
        assertEquals(0, c.displayMillis(now.get()));
        t.resume(c.id());
        assertFalse("a finished countdown cannot resume", c.running());
        t.reset(c.id());
        assertTrue("reset restarts a finished countdown", c.running());
        assertEquals(10_000, c.displayMillis(now.get()));
        now.addAndGet(1_000);
        assertEquals(9_000, c.displayMillis(now.get()));
        assertTrue(t.pollFinished().isEmpty());
        now.addAndGet(9_000);
        assertEquals("it can finish (and be reported) again after a reset", 1, t.pollFinished().size());
    }

    @Test
    public void timersAreBoundedAndSanitised() {
        AtomicLong now = new AtomicLong(0);
        Timers t = new Timers(now::get);
        Timers.Timer c = t.start(Kind.COUNTDOWN, "x\ny".repeat(30), Long.MAX_VALUE);
        assertEquals(24, c.label().length());
        assertEquals(24L * 3600_000, c.displayMillis(0));
        Timers.Timer tiny = t.start(Kind.COUNTDOWN, "t", -5);
        assertEquals(1000, tiny.displayMillis(0));
        for (int i = 2; i < Timers.MAX_TIMERS; i++) {
            assertNotNull(t.start(Kind.STOPWATCH, "s", 0));
        }
        assertNull(t.start(Kind.STOPWATCH, "overflow", 0));
        assertTrue(t.remove(c.id()));
        assertFalse(t.remove(c.id()));
        assertNotNull(t.start(Kind.STOPWATCH, "again", 0));
    }

    // ---- waypoints -----------------------------------------------------------------------------

    @Test
    public void waypointValidation() {
        Waypoints w = new Waypoints();
        assertNull(w.add("Home", "overworld", 10.7, 64, -3.2, 0x00FF00));
        assertNotNull("duplicate, case-insensitive", w.add("home", "overworld", 0, 0, 0, 0));
        assertNotNull(w.add("  ", "overworld", 0, 0, 0, 0));
        assertNotNull(w.add("far", "overworld", 3e9, 0, 0, 0));
        assertNotNull(w.add("nan", "overworld", Double.NaN, 0, 0, 0));
        assertNotNull(w.add("sky", "overworld", 0, 99999, 0, 0));
        Waypoints.Waypoint h = w.list().get(0);
        assertEquals(10, h.x());
        assertEquals(-4, h.z());
        assertEquals("colour is always opaque", 0xFF00FF00, h.argb());
        assertNull(w.add("Strange dimension", "../../etc", 0, 0, 0, 0));
        assertEquals("unsafe dimension ids fall back", "overworld",
                w.list().stream().filter(p -> p.name().startsWith("Strange")).findFirst().orElseThrow().dimension());
    }

    @Test
    public void nearestOnlyConsidersTheSameDimensionAndSortsByDistance() {
        Waypoints w = new Waypoints();
        w.add("far", "overworld", 500, 64, 0, 0);
        w.add("near", "overworld", 20, 64, 0, 0);
        w.add("mid", "overworld", 100, 64, 0, 0);
        w.add("nether base", "the_nether", 1, 64, 0, 0);
        assertEquals(List.of("near", "mid"), w.nearest("overworld", 0, 0, 2).stream().map(Waypoints.Waypoint::name).toList());
        assertEquals(List.of("nether base"), w.nearest("the_nether", 0, 0, 5).stream().map(Waypoints.Waypoint::name).toList());
        assertTrue(w.nearest("overworld", 0, 0, 0).isEmpty());
    }

    @Test
    public void waypointsRoundTripAndReportBadEntries() {
        Waypoints w = new Waypoints();
        w.add("Home", "overworld", 1, 2, 3, 0xFF112233);
        w.add("Mine", "the_nether", -10, 11, 12, 0xFFAA0000);
        Waypoints copy = new Waypoints();
        assertTrue(copy.loadJson(w.toJson()).isClean());
        assertEquals(w.list(), copy.list());

        JsonObject bad = JsonParser.parseString("""
                {"waypoints": [ {"name": "ok", "x": 1, "y": 2, "z": 3}, {"name": "", "x": 1, "y": 2, "z": 3},
                                {"name": "nopos"}, "x", {"name": "OK", "x": 1, "y": 2, "z": 3} ]}""").getAsJsonObject();
        Waypoints g = new Waypoints();
        LoadReport r = g.loadJson(bad);
        assertEquals(1, g.list().size());
        assertEquals(4, r.warnings().size());
    }
}
