package dev.lumina.ui;

import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.ColorSetting;
import dev.lumina.setting.EnumSetting;
import dev.lumina.setting.NumberSetting;
import dev.lumina.ui.UiLayout.Placed;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class UiFrameworkTest {
    private final UiState state = new UiState();
    private final List<Integer> captured = new ArrayList<>();
    private final UiController controller = new UiController(state, captured::add);

    private static List<Placed> place(Row... rows) {
        return UiLayout.place(List.of(rows), 10, 20, 200, 0);
    }

    private static double midX(Placed p) {
        return p.x() + p.w() / 2.0;
    }

    private static double midY(Placed p) {
        return p.y() + p.h() / 2.0;
    }

    @Test
    public void layoutStacksRowsWithGapsAndScrolls() {
        List<Placed> p = UiLayout.place(List.of(new Row.Heading("h"), new Row.Spacer(10), new Row.Label("l")), 10, 20, 200, 0);
        assertEquals(20, p.get(0).y());
        assertEquals(20 + 22 + Row.GAP, p.get(1).y());
        assertEquals(20 + 22 + Row.GAP + 10 + Row.GAP, p.get(2).y());
        assertEquals(22 + 10 + 13 + 3 * Row.GAP, UiLayout.contentHeight(List.of(new Row.Heading("h"), new Row.Spacer(10), new Row.Label("l"))));
        List<Placed> scrolled = UiLayout.place(List.of(new Row.Heading("h")), 10, 20, 200, 15);
        assertEquals(5, scrolled.get(0).y());
        assertEquals(1, new Row.Spacer(0).height());
    }

    @Test
    public void buttonsRespectTheEnabledFlagAndOnlyReactToTheLeftButton() {
        AtomicInteger runs = new AtomicInteger();
        List<Placed> on = place(new Row.Button("go", "", true, "", runs::incrementAndGet));
        assertTrue(controller.click(on, midX(on.get(0)), midY(on.get(0)), UiController.LEFT));
        assertFalse(controller.click(on, midX(on.get(0)), midY(on.get(0)), UiController.RIGHT));
        List<Placed> off = place(new Row.Button("go", "", false, "", runs::incrementAndGet));
        assertFalse(controller.click(off, midX(off.get(0)), midY(off.get(0)), UiController.LEFT));
        assertEquals(1, runs.get());
    }

    @Test
    public void togglesChoicesAndColoursUseLeftAndRightClicks() {
        AtomicInteger a = new AtomicInteger();
        AtomicInteger b = new AtomicInteger();
        List<Placed> p = place(
                new Row.Toggle("t", false, "", () -> a.addAndGet(1), () -> a.addAndGet(100), 0),
                new Row.Choice("c", "v", "", () -> b.addAndGet(1), () -> b.addAndGet(10), 0),
                new Row.ColorChoice("k", 0xFFFFFFFF, "", () -> b.addAndGet(1000), () -> b.addAndGet(10000), 0),
                new Row.Toggle("no secondary", false, "", () -> a.addAndGet(5)));
        controller.click(p, midX(p.get(0)), midY(p.get(0)), UiController.LEFT);
        controller.click(p, midX(p.get(0)), midY(p.get(0)), UiController.RIGHT);
        controller.click(p, midX(p.get(1)), midY(p.get(1)), UiController.LEFT);
        controller.click(p, midX(p.get(1)), midY(p.get(1)), UiController.RIGHT);
        controller.click(p, midX(p.get(2)), midY(p.get(2)), UiController.LEFT);
        controller.click(p, midX(p.get(2)), midY(p.get(2)), UiController.RIGHT);
        assertFalse(controller.click(p, midX(p.get(3)), midY(p.get(3)), UiController.RIGHT));
        assertEquals(101, a.get());
        assertEquals(11011, b.get());
    }

    @Test
    public void slidersFollowTheMouseAndStayInRange() {
        List<Double> values = new ArrayList<>();
        List<Placed> p = place(new Row.Slider("s", 0.5, "50", "", values::add, 0));
        Placed s = p.get(0);
        controller.click(p, s.trackX() + s.trackWidth() * 0.25, midY(s), UiController.LEFT);
        assertEquals(0.25, values.get(0), 0.02);
        assertTrue(controller.drag(s.trackX() + s.trackWidth() * 5.0));
        assertEquals(1.0, values.get(1), 0);
        assertTrue(controller.drag(s.trackX() - 500.0));
        assertEquals(0.0, values.get(2), 0);
        controller.release();
        assertFalse("not dragging any more", controller.drag(0));
    }

    @Test
    public void typingGoesToTheFocusedInputOnly() {
        List<Placed> p = place(new Row.Input("name", "n", "", ""), new Row.Button("b", () -> {
        }));
        assertFalse(controller.character('x'));
        assertFalse(controller.isTyping());
        controller.click(p, midX(p.get(0)), midY(p.get(0)), UiController.LEFT);
        assertTrue(controller.isTyping());
        assertTrue(controller.character('a'));
        assertTrue(controller.character('é'));
        assertFalse("control characters are refused", controller.character(7));
        assertFalse(controller.character(0x378));
        assertEquals("aé", state.input("n"));
        assertTrue(controller.key(UiController.KEY_BACKSPACE));
        assertEquals("a", state.input("n"));
        assertTrue(controller.key(UiController.KEY_BACKSPACE));
        assertTrue("backspace on empty text is harmless", controller.key(UiController.KEY_BACKSPACE));
        assertEquals("", state.input("n"));
        assertFalse("other keys fall through to the game", controller.key(65));
        assertTrue(controller.key(UiController.KEY_ENTER));
        assertNull(state.focusedInput());
        controller.click(p, midX(p.get(0)), midY(p.get(0)), UiController.LEFT);
        controller.click(p, midX(p.get(1)), midY(p.get(1)), UiController.LEFT);
        assertNull("clicking something else removes the focus", state.focusedInput());
        controller.click(p, 5000, 5000, UiController.LEFT);
        assertFalse(controller.isTyping());
    }

    @Test
    public void inputLengthIsBounded() {
        List<Placed> p = place(new Row.Input("name", "n", "", ""));
        controller.click(p, midX(p.get(0)), midY(p.get(0)), UiController.LEFT);
        for (int i = 0; i < 200; i++) {
            controller.character('z');
        }
        assertEquals(UiState.MAX_INPUT, state.input("n").length());
        state.setInput("n", "q".repeat(500));
        assertEquals(UiState.MAX_INPUT, state.input("n").length());
        state.setInput("n", null);
        assertEquals("", state.input("n"));
    }

    @Test
    public void keyCaptureTakesPriorityOverTyping() {
        state.listeningModule = "m";
        assertTrue(controller.isTyping());
        assertTrue(controller.key(70));
        assertEquals(List.of(70), captured);
    }

    @Test
    public void scrollingIsClamped() {
        controller.scroll(-5, 1000, 300);
        assertEquals(300, state.scroll());
        controller.scroll(100, 1000, 300);
        assertEquals(0, state.scroll());
        controller.scroll(-1, 100, 300);
        assertEquals("content shorter than the view never scrolls", 0, state.scroll());
        state.setScroll(-50);
        assertEquals(0, state.scroll());
    }

    @Test
    public void changingPageResetsPageState() {
        state.setScroll(40);
        state.focus("x");
        state.listeningModule = "m";
        state.pendingConfirm = "c";
        state.setPage(2);
        assertEquals(0, state.scroll());
        assertNull(state.focusedInput());
        assertNull(state.listeningModule);
        assertNull(state.pendingConfirm);
        state.setScroll(9);
        state.setPage(2);
        assertEquals("same page keeps its scroll", 9, state.scroll());
    }

    @Test
    public void settingsBecomeTheRightRows() {
        List<Row> rows = new ArrayList<>();
        BooleanSetting flag = new BooleanSetting("f", "Flag", "tip", false);
        NumberSetting number = NumberSetting.ofInt("n", "Number", "tip", 5, 0, 10);
        EnumSetting<Thread.State> choice = new EnumSetting<>("e", "Mode", "tip", Thread.State.NEW);
        ColorSetting colour = new ColorSetting("c", "Colour", "tip", 0x80FFFFFF);
        BooleanSetting hidden = new BooleanSetting("h", "Hidden", "tip", false);
        hidden.visibleWhen(() -> false);
        for (var s : List.of(flag, number, choice, colour, hidden)) {
            SettingRows.add(rows, s, 1);
        }
        assertEquals(4, rows.size());

        ((Row.Toggle) rows.get(0)).action().run();
        assertTrue(flag.isOn());
        ((Row.Slider) rows.get(1)).onChange().accept(1.0);
        assertEquals(10, number.getInt());
        ((Row.Slider) rows.get(1)).onChange().accept(0.0);
        assertEquals(0, number.getInt());
        assertEquals("the row shows the value it was built with (5 of 0..10)", 0.5, ((Row.Slider) rows.get(1)).fraction(), 1e-9);
        Row.Choice c = (Row.Choice) rows.get(2);
        assertEquals("New", c.value());
        c.previous().run();
        assertEquals("wraps around to the last value", Thread.State.TERMINATED, choice.get());
        c.next().run();
        assertEquals(Thread.State.NEW, choice.get());
        Row.ColorChoice k = (Row.ColorChoice) rows.get(3);
        k.next().run();
        assertEquals("alpha is kept, colour follows the palette", 0x80E5594F, colour.argb());
        k.previous().run();
        k.previous().run();
        assertEquals(0x80000000, colour.argb());
        assertEquals("Moving forward", SettingRows.pretty("MOVING_FORWARD"));
    }

    @Test
    public void keyNames() {
        assertEquals("A", KeyNames.of('A'));
        assertEquals("F5", KeyNames.of(294));
        assertEquals("Right Shift", KeyNames.of(344));
        assertEquals("None", KeyNames.of(-1));
        assertEquals("Key 999", KeyNames.of(999));
        assertEquals("Numpad 4", KeyNames.of(324));
    }
}
