package dev.lumina.ui;

import dev.lumina.client.GameState.TrackedKey;
import dev.lumina.cosmetics.PngTestData;
import dev.lumina.cosmetics.Slot;
import dev.lumina.module.ClientModule;
import dev.lumina.options.VideoOption;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

import static dev.lumina.ui.UiTestSupport.button;
import static dev.lumina.ui.UiTestSupport.choice;
import static dev.lumina.ui.UiTestSupport.input;
import static dev.lumina.ui.UiTestSupport.label;
import static dev.lumina.ui.UiTestSupport.slider;
import static dev.lumina.ui.UiTestSupport.toggle;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/** Drives every page of the menu with simulated clicks and typing. */
public class UiPagesTest {
    private UiTestSupport ui;

    @Before
    public void setUp() throws IOException {
        ui = new UiTestSupport();
    }

    @After
    public void tearDown() {
        ui.close();
    }

    private ClientModule module(String id) {
        return ui.ctx.modules.get(id).orElseThrow();
    }

    // ---- all pages -----------------------------------------------------------------------------

    @Test
    public void everyPageBuildsRowsAndTitlesAreUnique() {
        Set<String> titles = new HashSet<>();
        for (int i = 0; i < ui.app.pages().size(); i++) {
            ui.app.state.setPage(i);
            assertTrue(ui.app.page().title(), ui.app.rows().size() > 3);
            assertTrue(titles.add(ui.app.page().title()));
        }
        assertEquals(8, titles.size());
        ui.app.goTo("Nope");
        assertEquals("unknown titles leave the page alone", 7, ui.app.state.pageIndex());
        ui.app.goTo("Home");
        assertEquals(0, ui.app.state.pageIndex());
    }

    @Test
    public void pagesStillBuildWhenNoWorldIsLoaded() {
        ui.game.inWorld = false;
        for (int i = 0; i < ui.app.pages().size(); i++) {
            ui.app.state.setPage(i);
            assertFalse(ui.app.rows().isEmpty());
        }
    }

    // ---- home ----------------------------------------------------------------------------------

    @Test
    public void homeShowsStatusAndShortcutsWork() {
        assertTrue(ui.has(label("Profile: default")));
        assertTrue(ui.has(label("Modules on: 1 of " + ui.ctx.allModules().size())));
        ui.click(button("Edit HUD layout"));
        assertEquals(1, ui.hudEditorOpened);
        ui.click(button("Performance Lab"));
        assertEquals("Performance", ui.app.page().title());
        ui.app.goTo("Home");
        ui.click(button("Browse modules"));
        assertEquals("Modules", ui.app.page().title());
    }

    // ---- modules -------------------------------------------------------------------------------

    @Test
    public void modulesCanBeSearchedFilteredAndToggled() {
        ui.app.goTo("Modules");
        int all = (int) ui.layout().stream().filter(p -> p.row() instanceof Row.Toggle).count();
        assertEquals(ui.ctx.allModules().size(), all);

        ui.type("module_search", "toggle sprint");
        assertEquals(1, ui.layout().stream().filter(p -> p.row() instanceof Row.Toggle).count());
        assertFalse(module("toggle_sprint").isEnabled());
        ui.click(toggle("Toggle Sprint"));
        assertTrue(module("toggle_sprint").isEnabled());
        ui.click(toggle("Toggle Sprint"));
        assertFalse(module("toggle_sprint").isEnabled());

        ui.type("module_search", "zzz-nothing");
        // typing appended to the old text, so nothing matches
        assertTrue(ui.has(label("No module matches")));
        ui.app.state.setInput("module_search", "");
        ui.click(choice("Show"));
        assertEquals("Enabled filter", 1, ui.layout().stream().filter(p -> p.row() instanceof Row.Toggle).count());
        ui.rightClick(choice("Show"));
        ui.rightClick(choice("Show"));
        assertTrue("right click wraps to the last category",
                ui.has(r -> r instanceof Row.Choice c && c.label().equals("Show") && c.value().equals("Settings")));
    }

    @Test
    public void rightClickOpensSettingsAndTheyCanBeEdited() {
        ui.app.goTo("Modules");
        ui.type("module_search", "render distance");
        ui.rightClick(toggle("Render Distance"));
        assertEquals("render_distance", ui.app.state.expandedModule);
        ui.dragSlider(slider("Value"), 0.5);
        int value = ((Number) module("render_distance").setting("value").orElseThrow().get()).intValue();
        assertTrue("about half of 2..32 but within the range", value >= 15 && value <= 18);
        ui.click(toggle("Render Distance"));
        assertEquals(value, ui.options.value(VideoOption.RENDER_DISTANCE));
        ui.rightClick(toggle("Render Distance"));
        assertNull("right click again closes it", ui.app.state.expandedModule);
    }

    @Test
    public void choiceSettingsCycle() {
        ui.app.goTo("Modules");
        ui.type("module_search", "toggle sprint");
        ui.rightClick(toggle("Toggle Sprint"));
        assertTrue(ui.has(choice("Mode")));
        ui.click(choice("Mode"));
        assertEquals("WHILE_MOVING_FORWARD", String.valueOf(module("toggle_sprint").setting("mode").orElseThrow().get()));
        ui.rightClick(choice("Mode"));
        assertEquals("TOGGLE", String.valueOf(module("toggle_sprint").setting("mode").orElseThrow().get()));
    }

    @Test
    public void keyBindingFlow() {
        ui.app.goTo("Modules");
        ui.type("module_search", "crosshair");
        ui.rightClick(toggle("Custom Crosshair"));
        ui.click(button("Key: None"));
        assertTrue(ui.app.controller.isTyping());
        ui.app.controller.key(71);
        assertEquals(71, module("custom_crosshair").keyCode());
        assertTrue(ui.has(button("Key: G")));

        ui.click(button("Key: G"));
        ui.app.controller.key(UiController.KEY_ESCAPE);
        assertEquals("escape cancels", 71, module("custom_crosshair").keyCode());

        ui.click(button("Key: G"));
        ui.app.controller.key(UiController.KEY_BACKSPACE);
        assertEquals("backspace clears", ClientModule.KEY_UNBOUND, module("custom_crosshair").keyCode());

        ui.click(button("Key: None"));
        ui.app.controller.key(ui.ctx.ui.clickGuiKey.getInt());
        assertEquals("the menu key cannot be taken", ClientModule.KEY_UNBOUND, module("custom_crosshair").keyCode());
        assertTrue(ui.notificationTitles().stream().anyMatch(t -> t.startsWith("Custom Crosshair")));
    }

    @Test
    public void favoritesAndResetNeedConfirmation() {
        ui.app.goTo("Modules");
        ui.type("module_search", "crosshair");
        ui.rightClick(toggle("Custom Crosshair"));
        ui.click(toggle("Favorite"));
        assertTrue(module("custom_crosshair").isFavorite());
        ui.app.state.setInput("module_search", "");
        ui.app.state.expandedModule = null;
        ui.click(choice("Show"));
        ui.click(choice("Show"));
        assertEquals("Favorites filter", 1, ui.layout().stream().filter(p -> p.row() instanceof Row.Toggle && !((Row.Toggle) p.row()).label().equals("Favorite")).count());

        ui.app.state.filterIndex = 0;
        ui.type("module_search", "crosshair");
        ui.rightClick(toggle("Custom Crosshair"));
        ui.dragSlider(slider("Arm length"), 1.0);
        int length = ((Number) module("custom_crosshair").setting("length").orElseThrow().get()).intValue();
        assertEquals(24, length);
        ui.click(button("Reset this module"));
        assertEquals("first click only asks", 24, ((Number) module("custom_crosshair").setting("length").orElseThrow().get()).intValue());
        ui.click(button("Click again to reset this module"));
        assertEquals(5, ((Number) module("custom_crosshair").setting("length").orElseThrow().get()).intValue());
    }

    // ---- profiles ------------------------------------------------------------------------------

    @Test
    public void profilesCanBeCreatedSwitchedRenamedAndDeleted() {
        ui.app.goTo("Profiles");
        assertTrue(ui.has(button("● Default")));
        ui.type("profile_name", "PvP");
        ui.click(button("Create from current settings"));
        assertEquals(2, ui.ctx.profiles.list().size());
        assertTrue(ui.has(button("PvP")));
        ui.click(button("PvP"));
        assertEquals("pvp", ui.ctx.global.settings().activeProfile());

        ui.app.state.setInput("profile_name", "");
        ui.type("profile_name", "Ranked");
        ui.click(button("Rename the active profile"));
        assertTrue(ui.has(button("Ranked")));

        ui.click(button("Delete the active profile"));
        assertEquals("needs a second click", 2, ui.ctx.profiles.list().size());
        ui.click(button("Click again to delete"));
        assertEquals(1, ui.ctx.profiles.list().size());
        assertEquals("default", ui.ctx.global.settings().activeProfile());
    }

    @Test
    public void hudLayoutsCanBeSavedLoadedAndDeletedFromTheProfilesPage() {
        ui.app.goTo("Profiles");
        float original = ui.ctx.hudLayout.state("fps_counter").scale();

        ui.type("layout_name", "Ranked PvP");
        ui.click(button("Save the current HUD as a layout"));
        assertEquals(java.util.List.of("ranked_pvp"), ui.ctx.hudLayouts.list());
        assertTrue(ui.has(button("Load layout: ranked_pvp")));

        ui.ctx.hudLayout.state("fps_counter").setScale(original + 0.5f);
        ui.click(button("Load layout: ranked_pvp"));
        assertEquals("loading restores what was saved", original, ui.ctx.hudLayout.state("fps_counter").scale(), 1e-6);

        ui.click(button("Delete layout: ranked_pvp"));
        assertEquals("needs a second click", 1, ui.ctx.hudLayouts.list().size());
        ui.click(button("Click again to delete layout"));
        assertTrue(ui.ctx.hudLayouts.list().isEmpty());
    }

    @Test
    public void compactListsPreferenceChangesRowSpacing() {
        ui.app.goTo("Settings");
        assertEquals(Row.GAP, ui.app.gap());
        int before = ui.app.contentHeight();
        java.util.List<UiLayout.Placed> normal = ui.layout();
        int normalStep = normal.get(1).y() - normal.get(0).y();

        ui.click(toggle("Compact lists"));
        assertTrue(ui.ctx.ui.compactLists.isOn());
        assertEquals(UiLayout.COMPACT_GAP, ui.app.gap());
        assertTrue("the page gets shorter", ui.app.contentHeight() < before);
        java.util.List<UiLayout.Placed> compact = ui.layout();
        assertEquals(normalStep - Row.GAP + UiLayout.COMPACT_GAP, compact.get(1).y() - compact.get(0).y());
    }

    @Test
    public void invalidHudLayoutNamesAreRefusedWithANotification() {
        ui.app.goTo("Profiles");
        ui.type("layout_name", "../evil");
        ui.click(button("Save the current HUD as a layout"));
        assertTrue(ui.ctx.hudLayouts.list().isEmpty());
        assertFalse(ui.notificationTitles().isEmpty());
    }

    @Test
    public void invalidProfileNamesGiveANotificationNotACrash() {
        ui.app.goTo("Profiles");
        ui.type("profile_name", "../evil");
        ui.click(button("Create from current settings"));
        assertEquals(1, ui.ctx.profiles.list().size());
        assertFalse(ui.notificationTitles().isEmpty());
    }

    @Test
    public void profileExportImportAndServerBinding() throws IOException {
        ui.app.goTo("Profiles");
        ui.click(button("Export the active profile"));
        assertTrue(Files.isRegularFile(ui.ctx.paths.exports().resolve("default.json")));
        Files.copy(ui.ctx.paths.exports().resolve("default.json"), ui.ctx.paths.imports().resolve("shared.json"));
        assertTrue(ui.has(button("Import shared.json")));
        ui.click(button("Import shared.json"));
        assertEquals(2, ui.ctx.profiles.list().size());

        ui.click(toggle("Switch profile automatically"));
        assertTrue(ui.ctx.global.settings().autoSwitchProfiles());
        ui.type("profile_server", "Play.Example.com:25565");
        ui.click(button("Use the active profile on this server"));
        assertEquals("default", ui.ctx.global.settings().serverProfiles().get("play.example.com"));
        ui.click(button("play.example.com"));
        assertTrue(ui.ctx.global.settings().serverProfiles().isEmpty());
    }

    @Test
    public void resettingTheActiveProfileNeedsConfirmation() {
        ui.ctx.modules.setEnabled(module("custom_crosshair"), true);
        ui.app.goTo("Profiles");
        ui.click(button("Reset the active profile"));
        assertTrue(module("custom_crosshair").isEnabled());
        ui.click(button("Click again to reset"));
        assertFalse(module("custom_crosshair").isEnabled());
    }

    // ---- performance ---------------------------------------------------------------------------

    @Test
    public void performancePresetsLabAndReport() throws IOException {
        ui.app.goTo("Performance");
        ui.click(button("Apply: Low-end"));
        assertEquals(8, ui.options.value(VideoOption.RENDER_DISTANCE));
        ui.click(button("Apply: Vanilla"));
        assertEquals(20, ui.options.value(VideoOption.RENDER_DISTANCE));

        ui.click(button("Start measuring"));
        assertTrue(ui.has(button("Stop and save")));
        for (int i = 0; i < 400; i++) {
            ui.ctx.frames.record(8.0);
        }
        ui.click(button("Stop and save"));
        assertEquals(1, ui.ctx.performanceHistory.runs("default").size());
        assertTrue(ui.has(label("Latest: 125 FPS average")));
        assertFalse("one run cannot be compared", ui.has(label("averaged")));

        ui.click(button("Start measuring"));
        for (int i = 0; i < 400; i++) {
            ui.ctx.frames.record(16.0);
        }
        ui.click(button("Stop and save"));
        assertTrue(ui.has(label("The previous run averaged")));
        assertTrue(ui.has(label("Average FPS")));

        ui.click(button("Export a report"));
        try (var files = Files.list(ui.ctx.paths.diagnostics())) {
            assertTrue(files.anyMatch(p -> p.getFileName().toString().startsWith("report-")));
        }
        assertTrue(ui.has(label("Sodium is installed")));
    }

    @Test
    public void stoppingTheLabWithoutFramesSaysSo() {
        ui.app.goTo("Performance");
        ui.click(button("Start measuring"));
        ui.click(button("Stop and save"));
        assertTrue(ui.notificationTitles().stream().anyMatch(t -> t.contains("Nothing was measured")));
        assertTrue(ui.ctx.performanceHistory.runs("default").isEmpty());
    }

    // ---- cosmetics -----------------------------------------------------------------------------

    @Test
    public void cosmeticsWearSaveAndImport() throws IOException {
        ui.app.goTo("Cosmetics");
        assertTrue(ui.has(label("only visible to you")));
        ui.click(choice("Cape"));
        assertEquals("slate", ui.ctx.cosmetics.worn(Slot.CAPE).orElseThrow().id());
        ui.click(choice("Cape"));
        assertEquals("forest", ui.ctx.cosmetics.worn(Slot.CAPE).orElseThrow().id());
        ui.rightClick(choice("Cape"));
        ui.rightClick(choice("Cape"));
        assertTrue("right click walks back to nothing", ui.ctx.cosmetics.worn(Slot.CAPE).isEmpty());

        ui.click(choice("Cape"));
        ui.type("cosmetic_loadout", "Daily");
        ui.click(button("Save what I am wearing"));
        ui.rightClick(choice("Cape"));
        assertTrue(ui.ctx.cosmetics.worn(Slot.CAPE).isEmpty());
        ui.click(button("Wear: Daily"));
        assertEquals("slate", ui.ctx.cosmetics.worn(Slot.CAPE).orElseThrow().id());
        ui.click(button("Delete: Daily"));
        ui.click(button("Click again to delete Daily"));
        assertTrue(ui.ctx.cosmetics.presets().isEmpty());

        ui.click(toggle("Show my cosmetics"));
        assertTrue(ui.ctx.cosmetics.toRender().isEmpty());

        Files.write(ui.ctx.paths.imports().resolve("night.png"), PngTestData.png(64, 32));
        ui.type("cosmetic_name", "Night Sky");
        ui.click(button("Import night.png"));
        assertTrue(ui.ctx.cosmeticCatalog.get("night_sky").isPresent());
        ui.ctx.cosmetics.equip(Slot.CAPE, "night_sky");
        ui.click(button("Remove imported"));
        ui.click(button("Click again to remove"));
        assertTrue(ui.ctx.cosmeticCatalog.get("night_sky").isEmpty());
        assertTrue("a removed item is no longer worn", ui.ctx.cosmetics.worn(Slot.CAPE).isEmpty());
    }

    @Test
    public void importingABadFileExplainsWhy() throws IOException {
        ui.app.goTo("Cosmetics");
        Files.write(ui.ctx.paths.imports().resolve("bad.png"), new byte[100]);
        ui.type("cosmetic_name", "Bad");
        ui.click(button("Import bad.png"));
        assertTrue(ui.notificationTitles().stream().anyMatch(t -> t.startsWith("Import|")));
        assertEquals(0, ui.ctx.cosmeticCatalog.importedCount());
    }

    // ---- social --------------------------------------------------------------------------------

    @Test
    public void friendsNotesAndHistory() {
        ui.app.goTo("Social");
        ui.type("friend_name", "Alex");
        ui.type("friend_note", "builder");
        ui.click(button("Add friend"));
        assertTrue(ui.ctx.friends.contains("Alex"));
        assertTrue(ui.has(button("Alex")));
        assertEquals("fields are cleared after adding", "", ui.app.state.input("friend_name"));
        ui.type("friend_name", "x");
        ui.click(button("Add friend"));
        assertTrue(ui.notificationTitles().stream().anyMatch(t -> t.startsWith("Friends|")));
        ui.click(button("Alex"));
        assertFalse(ui.ctx.friends.contains("Alex"));

        ui.type("note_title", "Base");
        ui.type("note_text", "x=1 z=2");
        ui.click(button("Add note"));
        assertEquals(1, ui.ctx.notes.size());
        ui.click(button("Base"));
        assertEquals(0, ui.ctx.notes.size());

        assertFalse(ui.ctx.global.settings().keepServerHistory());
        ui.click(toggle("Remember the servers"));
        assertTrue(ui.ctx.global.settings().keepServerHistory());
        ui.ctx.onWorldJoin("play.example.com");
        ui.clock.addAndGet(65_000);
        ui.ctx.onWorldLeave();
        assertTrue(ui.has(label("play.example.com")));
        ui.click(button("Clear server history"));
        assertEquals(1, ui.ctx.serverHistory.list().size());
        ui.click(button("Click again to clear"));
        assertTrue(ui.ctx.serverHistory.list().isEmpty());

        ui.click(toggle("Mute for now"));
        assertTrue(ui.ctx.notifications.isMuted());
    }

    // ---- tools ---------------------------------------------------------------------------------

    @Test
    public void toolsCalculatorWaypointsAndTimers() {
        ui.app.goTo("Tools");
        ui.type("calc_expression", "(64*9)+12");
        assertTrue(ui.has(label("= 588")));
        ui.app.state.setInput("calc_expression", "");
        ui.type("calc_expression", "1/0");
        assertTrue(ui.has(label("= Division by zero")));
        ui.type("stack_items", "150");
        assertTrue(ui.has(label("2 stacks + 22")));
        ui.app.state.setInput("stack_items", "abc");
        assertTrue(ui.has(label("whole number")));

        ui.game.x = 100;
        ui.game.z = -0.5;
        assertTrue(ui.has(label("You: 100, 64, -1")));
        assertTrue(ui.has(label("Chunk: 6, -1")));
        ui.type("waypoint_name", "Home");
        ui.click(button("Save my position"));
        assertEquals(1, ui.ctx.waypoints.list().size());
        ui.game.x = 100;
        ui.game.z = -1;
        assertTrue(ui.has(button("Home  ·  0 blocks")));
        ui.click(button("Home"));
        assertTrue(ui.ctx.waypoints.list().isEmpty());

        ui.type("timer_minutes", "0.5");
        ui.click(button("Start countdown"));
        ui.click(button("Start stopwatch"));
        assertEquals(2, ui.ctx.timers.list().size());
        ui.clock.addAndGet(31_000);
        ui.ctx.onTick();
        assertTrue(ui.notificationTitles().stream().anyMatch(t -> t.startsWith("Timer|Timer finished")));
        assertTrue(ui.has(toggle("Stopwatch  00:00:31")));
        ui.click(toggle("Stopwatch"));
        assertFalse(ui.ctx.timers.list().get(1).running());
        ui.rightClick(toggle("Stopwatch"));
        assertEquals(1, ui.ctx.timers.list().size());
    }

    @Test
    public void invalidTimerInputIsRejectedPolitely() {
        ui.app.goTo("Tools");
        ui.type("timer_minutes", "abc");
        ui.click(button("Start countdown"));
        ui.app.state.setInput("timer_minutes", "-3");
        ui.click(button("Start countdown"));
        assertTrue(ui.ctx.timers.list().isEmpty());
        assertFalse(ui.notificationTitles().isEmpty());
    }

    @Test
    public void waypointSavingIsDisabledOutsideAWorld() {
        ui.game.inWorld = false;
        ui.app.goTo("Tools");
        assertFalse(((Row.Button) ui.find(button("Save my position")).row()).enabled());
        assertFalse(ui.click(button("Save my position")));
        assertTrue(ui.has(label("Join a world")));
    }

    // ---- settings ------------------------------------------------------------------------------

    @Test
    public void settingsEditThemeAndPrivacyAndExportDiagnostics() throws IOException {
        ui.app.goTo("Settings");
        int before = ui.ctx.theme.accent.argb();
        ui.click(r -> r instanceof Row.ColorChoice c && c.label().contains("Accent"));
        assertTrue(before != ui.ctx.theme.accent.argb());
        ui.dragSlider(slider("Corner radius"), 1.0);
        assertEquals(10, ui.ctx.theme.cornerRadius.getInt());

        assertTrue(ui.ctx.global.settings().keepErrorHistory());
        ui.click(toggle("Keep a local error history"));
        assertFalse(ui.ctx.global.settings().keepErrorHistory());
        assertTrue(ui.has(label("no telemetry")));

        ui.click(button("Export a diagnostics file"));
        Path file;
        try (var files = Files.list(ui.ctx.paths.diagnostics())) {
            file = files.filter(p -> p.getFileName().toString().startsWith("diagnostics-")).findFirst().orElseThrow();
        }
        String text = Files.readString(file);
        assertTrue(text.contains("Lumina diagnostics"));
        assertTrue(text.contains("Active profile: default"));
        assertFalse("no account name or home folder", text.contains("tester"));
        assertFalse(text.contains("/home/"));
    }

    @Test
    public void typingInAnInputBlocksNothingElseAndKeyCaptureIsOnlyForModules() {
        ui.game.keys.add(TrackedKey.FORWARD);
        ui.app.goTo("Modules");
        assertFalse(ui.app.controller.isTyping());
        ui.click(input("module_search"));
        assertTrue(ui.app.controller.isTyping());
        ui.app.controller.key(UiController.KEY_ESCAPE);
        assertFalse(ui.app.controller.isTyping());
    }
}
