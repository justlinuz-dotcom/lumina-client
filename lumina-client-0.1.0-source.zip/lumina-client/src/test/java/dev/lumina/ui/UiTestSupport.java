package dev.lumina.ui;

import dev.lumina.ClientContext;
import dev.lumina.hud.FakeGameState;
import dev.lumina.options.FakeGameOptions;
import dev.lumina.ui.UiLayout.Placed;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;

/** Starts the client without Minecraft and lets tests click rows of the menu like a player would. */
final class UiTestSupport implements UiHost, AutoCloseable {
    final Path gameDir;
    final AtomicLong clock = new AtomicLong(1_700_000_000_000L);
    final FakeGameState game = new FakeGameState();
    final FakeGameOptions options = new FakeGameOptions();
    final ClientContext ctx;
    final UiApp app;
    int hudEditorOpened;
    int closed;

    UiTestSupport() throws IOException {
        gameDir = Files.createTempDirectory("lumina-ui");
        ctx = ClientContext.start(new ClientContext.Environment(gameDir, game, options, hold -> {
        }, clock::get, Set.of("fabric-api", "sodium"), "1.21.11", 21, "/home/tester", "tester", ZoneOffset.UTC));
        app = new UiApp(ctx, this);
    }

    @Override
    public void openHudEditor() {
        hudEditorOpened++;
    }

    @Override
    public void closeScreen() {
        closed++;
    }

    @Override
    public void close() {
        ctx.close();
    }

    List<Placed> layout() {
        return app.layout(0, 0, 400, 100_000);
    }

    Placed find(Predicate<Row> match) {
        for (Placed p : layout()) {
            if (match.test(p.row())) {
                return p;
            }
        }
        throw new AssertionError("No row matched on page " + app.page().title() + ". Rows: " + describe());
    }

    boolean has(Predicate<Row> match) {
        return layout().stream().anyMatch(p -> match.test(p.row()));
    }

    static Predicate<Row> button(String text) {
        return r -> r instanceof Row.Button b && b.label().contains(text);
    }

    static Predicate<Row> toggle(String text) {
        return r -> r instanceof Row.Toggle t && t.label().contains(text);
    }

    static Predicate<Row> choice(String text) {
        return r -> r instanceof Row.Choice c && c.label().contains(text);
    }

    static Predicate<Row> slider(String text) {
        return r -> r instanceof Row.Slider s && s.label().contains(text);
    }

    static Predicate<Row> input(String id) {
        return r -> r instanceof Row.Input i && i.id().equals(id);
    }

    static Predicate<Row> label(String text) {
        return r -> r instanceof Row.Label l && l.text().contains(text);
    }

    boolean click(Predicate<Row> match, int mouseButton) {
        Placed p = find(match);
        return app.controller.click(layout(), p.x() + p.w() / 2.0, p.y() + p.h() / 2.0, mouseButton);
    }

    boolean click(Predicate<Row> match) {
        return click(match, UiController.LEFT);
    }

    boolean rightClick(Predicate<Row> match) {
        return click(match, UiController.RIGHT);
    }

    /** Clicks an input row and types the text. */
    void type(String inputId, String text) {
        click(input(inputId));
        for (int i = 0; i < text.length(); i++) {
            app.controller.character(text.charAt(i));
        }
        app.controller.key(UiController.KEY_ENTER);
    }

    /** Drags a slider to a fraction of its track. */
    void dragSlider(Predicate<Row> match, double fraction) {
        Placed p = find(match);
        double x = p.trackX() + fraction * p.trackWidth();
        app.controller.click(layout(), x, p.y() + 5, UiController.LEFT);
        app.controller.drag(x);
        app.controller.release();
    }

    String describe() {
        List<String> out = new ArrayList<>();
        for (Placed p : layout()) {
            out.add(p.row().getClass().getSimpleName() + ":" + p.row());
        }
        return String.join("\n", out);
    }

    List<String> notificationTitles() {
        return ctx.notifications.visible(clock.get()).stream().map(n -> n.title() + "|" + n.message()).toList();
    }
}
