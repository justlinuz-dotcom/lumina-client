package dev.lumina.client;

import org.junit.Test;

import java.util.Properties;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ClientInfoTest {

    @Test
    public void unexpandedPlaceholdersFallBackToDefaults() {
        Properties p = new Properties();
        p.setProperty("name", "${client_name}");
        p.setProperty("version", "${version}");
        ClientInfo info = ClientInfo.from(p);
        assertEquals("Lumina", info.name());
        assertEquals("dev", info.version());
        assertEquals("lumina", info.modId());
    }

    @Test
    public void expandedValuesAreUsedAndNameIsConfigurable() {
        Properties p = new Properties();
        p.setProperty("name", " Aurora ");
        p.setProperty("tagline", "Fast");
        p.setProperty("mod.id", "aurora");
        p.setProperty("version", "2.0.1");
        p.setProperty("target.minecraft", "1.21.11");
        ClientInfo info = ClientInfo.from(p);
        assertEquals("Aurora", info.name());
        assertEquals("Aurora 2.0.1", info.displayName());
        assertEquals("1.21.11", info.targetMinecraft());
    }

    @Test
    public void globalInstanceAlwaysExists() {
        assertNotNull(ClientInfo.get().name());
        assertNotNull(ClientInfo.get().displayName());
    }
}
