package dev.lumina.module;

import dev.lumina.setting.BooleanSetting;
import dev.lumina.setting.NumberSetting;

import java.util.ArrayList;
import java.util.List;

/** Configurable module used across tests; records its lifecycle calls. */
final class TestModule extends ClientModule {
    final List<String> log;
    final BooleanSetting flag = add(new BooleanSetting("flag", "Flag", "A flag", false));
    final NumberSetting amount = add(NumberSetting.ofInt("amount", "Amount", "An amount", 5, 0, 10));
    RuntimeException failOnEnable;
    RuntimeException failOnTick;
    RuntimeException failOnDisable;
    boolean ticks;
    int tickCalls;

    TestModule(String id, Category category, List<String> sharedLog) {
        super(id, "Module " + id, "Description of " + id, category);
        this.log = sharedLog == null ? new ArrayList<>() : sharedLog;
    }

    TestModule deps(String... ids) {
        requires(ids);
        return this;
    }

    TestModule conflicts(String... ids) {
        conflictsWith(ids);
        return this;
    }

    TestModule onByDefault() {
        defaultEnabled(true);
        return this;
    }

    TestModule key(int key) {
        defaultKey(key);
        return this;
    }

    @Override
    protected void onEnable() {
        if (failOnEnable != null) {
            throw failOnEnable;
        }
        log.add("+" + id());
    }

    @Override
    protected void onDisable() {
        log.add("-" + id());
        if (failOnDisable != null) {
            throw failOnDisable;
        }
    }

    @Override
    protected boolean wantsTick() {
        return ticks;
    }

    @Override
    protected void onTick() {
        tickCalls++;
        if (failOnTick != null) {
            throw failOnTick;
        }
    }
}
