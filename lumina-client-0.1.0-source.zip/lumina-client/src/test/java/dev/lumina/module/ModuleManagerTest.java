package dev.lumina.module;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.utils.LoadReport;
import dev.lumina.event.ClientEvents;
import dev.lumina.event.EventBus;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class ModuleManagerTest {
    private static final int KEY_R = 82;
    private static final int KEY_G = 71;
    private static final int KEY_H = 72;

    private final List<String> lifecycle = new ArrayList<>();
    private final List<String> errors = new ArrayList<>();
    private final List<ClientEvents.ModuleToggled> events = new ArrayList<>();
    private EventBus bus;
    private ModuleManager manager;

    @Before
    public void setUp() {
        bus = new EventBus((src, err) -> errors.add(src + ": " + err.getMessage()));
        bus.subscribe(ClientEvents.ModuleToggled.class, events::add);
        manager = new ModuleManager(bus, (src, err) -> errors.add(src + ": " + err.getMessage()), k -> k == KEY_R);
    }

    private TestModule add(String id, Category cat) {
        TestModule m = new TestModule(id, cat, lifecycle);
        manager.register(m);
        return m;
    }

    private TestModule add(TestModule m) {
        manager.register(m);
        return m;
    }

    @Test
    public void rejectsDuplicateIds() {
        add("fps", Category.HUD);
        assertThrows(IllegalArgumentException.class, () -> add("fps", Category.HUD));
    }

    @Test
    public void rejectsInvalidModuleId() {
        assertThrows(IllegalArgumentException.class, () -> new TestModule("Bad Id", Category.HUD, null));
        assertThrows(IllegalArgumentException.class, () -> new TestModule("../x", Category.HUD, null));
    }

    @Test
    public void enableAndDisableRunHooksAndPostEvents() {
        TestModule m = add("fps", Category.HUD);
        ToggleResult on = manager.setEnabled(m, true);
        assertEquals(ToggleResult.Status.CHANGED, on.status());
        assertTrue(m.isEnabled());
        assertEquals(List.of("+fps"), lifecycle);
        assertEquals(new ClientEvents.ModuleToggled("fps", true), events.get(0));

        assertEquals(ToggleResult.Status.UNCHANGED, manager.setEnabled(m, true).status());
        assertEquals(ToggleResult.Status.CHANGED, manager.setEnabled(m, false).status());
        assertFalse(m.isEnabled());
        assertEquals(List.of("+fps", "-fps"), lifecycle);
        assertEquals(2, events.size());
    }

    @Test
    public void enablingAutoEnablesDependenciesInOrder() {
        TestModule base = add("base", Category.UTILITY);
        TestModule mid = add(new TestModule("mid", Category.UTILITY, lifecycle).deps("base"));
        TestModule top = add(new TestModule("top", Category.UTILITY, lifecycle).deps("mid"));

        ToggleResult r = manager.setEnabled(top, true);
        assertEquals(ToggleResult.Status.CHANGED, r.status());
        assertEquals(List.of("+base", "+mid", "+top"), lifecycle);
        assertEquals(List.of("base", "mid"), r.alsoChanged());
        assertTrue(base.isEnabled() && mid.isEnabled() && top.isEnabled());
    }

    @Test
    public void disablingDisablesDependentsFirst() {
        TestModule base = add("base", Category.UTILITY);
        TestModule mid = add(new TestModule("mid", Category.UTILITY, lifecycle).deps("base"));
        TestModule top = add(new TestModule("top", Category.UTILITY, lifecycle).deps("mid"));
        manager.setEnabled(top, true);
        lifecycle.clear();

        ToggleResult r = manager.setEnabled(base, false);
        assertEquals(List.of("-top", "-mid", "-base"), lifecycle);
        assertEquals(List.of("top", "mid"), r.alsoChanged());
        assertFalse(top.isEnabled());
        assertFalse(mid.isEnabled());
    }

    @Test
    public void conflictsBlockEnablingInEitherDirection() {
        TestModule a = add(new TestModule("a", Category.VISUALS, lifecycle).conflicts("b"));
        TestModule b = add("b", Category.VISUALS);
        manager.setEnabled(a, true);

        ToggleResult r = manager.setEnabled(b, true);
        assertEquals(ToggleResult.Status.BLOCKED_BY_CONFLICT, r.status());
        assertFalse(b.isEnabled());

        manager.setEnabled(a, false);
        manager.setEnabled(b, true);
        assertEquals(ToggleResult.Status.BLOCKED_BY_CONFLICT, manager.setEnabled(a, true).status());
    }

    @Test
    public void conflictInsideDependencyChainBlocksWholeActivation() {
        TestModule blocker = add("blocker", Category.VISUALS);
        add(new TestModule("dep", Category.VISUALS, lifecycle).conflicts("blocker"));
        TestModule top = add(new TestModule("top", Category.VISUALS, lifecycle).deps("dep"));
        manager.setEnabled(blocker, true);
        lifecycle.clear();

        ToggleResult r = manager.setEnabled(top, true);
        assertEquals(ToggleResult.Status.BLOCKED_BY_CONFLICT, r.status());
        assertTrue("nothing may have been started", lifecycle.isEmpty());
    }

    @Test
    public void missingDependencyIsReported() {
        TestModule m = add(new TestModule("m", Category.UTILITY, lifecycle).deps("ghost"));
        ToggleResult r = manager.setEnabled(m, true);
        assertEquals(ToggleResult.Status.MISSING_DEPENDENCY, r.status());
        assertFalse(m.isEnabled());
    }

    @Test
    public void failingOnEnableRollsBackAndReports() {
        TestModule base = add("base", Category.UTILITY);
        TestModule bad = add(new TestModule("bad", Category.UTILITY, lifecycle).deps("base"));
        bad.failOnEnable = new IllegalStateException("boom");

        ToggleResult r = manager.setEnabled(bad, true);
        assertEquals(ToggleResult.Status.FAILED, r.status());
        assertFalse(bad.isEnabled());
        assertFalse("dependency started for the failed module must be rolled back", base.isEnabled());
        assertTrue(errors.get(0).contains("module:bad:enable"));
        assertTrue(errors.get(0).contains("boom"));
    }

    @Test
    public void failingOnDisableStillDisables() {
        TestModule m = add("m", Category.UTILITY);
        manager.setEnabled(m, true);
        m.failOnDisable = new IllegalStateException("cleanup failed");
        assertEquals(ToggleResult.Status.CHANGED, manager.setEnabled(m, false).status());
        assertFalse(m.isEnabled());
        assertEquals(1, errors.size());
    }

    @Test
    public void crashingTickDisablesOnlyThatModule() {
        TestModule good = add("good", Category.UTILITY);
        TestModule bad = add("bad", Category.UTILITY);
        good.ticks = true;
        bad.ticks = true;
        bad.failOnTick = new IllegalArgumentException("tick failure");
        manager.setEnabled(good, true);
        manager.setEnabled(bad, true);

        manager.tick();
        assertFalse(bad.isEnabled());
        assertTrue(good.isEnabled());
        assertEquals(1, good.tickCalls);
        assertTrue(errors.get(0).contains("module:bad:tick"));

        manager.tick();
        assertEquals("a disabled module must not tick again", 1, bad.tickCalls);
        assertEquals(2, good.tickCalls);
    }

    @Test
    public void tickRecordsMeasuredDurations() {
        TestModule m = add("m", Category.UTILITY);
        m.ticks = true;
        manager.setEnabled(m, true);
        manager.tick();
        manager.tick();
        assertEquals(2, m.measuredTicks());
        assertTrue(m.averageTickMicros() >= 0.0);
    }

    @Test
    public void modulesThatDoNotWantTicksAreNotTimed() {
        TestModule m = add("m", Category.UTILITY);
        manager.setEnabled(m, true);
        manager.tick();
        assertEquals(0, m.measuredTicks());
    }

    @Test
    public void keyBindingRejectsReservedConflictingAndInvalidKeys() {
        TestModule a = add("a", Category.UTILITY);
        TestModule b = add("b", Category.UTILITY);

        assertFalse(manager.bindKey(a, KEY_R).success());
        assertTrue(manager.bindKey(a, KEY_G).success());
        assertEquals(KEY_G, a.keyCode());
        assertFalse(manager.bindKey(b, KEY_G).success());
        assertFalse(manager.bindKey(b, 9999).success());
        assertFalse(manager.bindKey(b, -5).success());
        assertTrue(manager.bindKey(a, ClientModule.KEY_UNBOUND).success());
        assertTrue(manager.bindKey(b, KEY_G).success());
    }

    @Test
    public void handleKeyTogglesBoundModules() {
        TestModule a = add(new TestModule("a", Category.UTILITY, lifecycle).key(KEY_H));
        List<ToggleResult> first = manager.handleKey(KEY_H);
        assertEquals(1, first.size());
        assertTrue(a.isEnabled());
        manager.handleKey(KEY_H);
        assertFalse(a.isEnabled());
        assertTrue(manager.handleKey(ClientModule.KEY_UNBOUND).isEmpty());
        assertTrue(manager.handleKey(KEY_G).isEmpty());
    }

    @Test
    public void searchRanksNamePrefixAboveDescriptionAndSupportsFuzzy() {
        manager.register(new TestModule("fps_counter", Category.HUD, null));
        manager.register(new ClientModule("coords", "Coordinates", "Shows position, not fps", Category.HUD) {
        });
        manager.register(new ClientModule("zoom", "Camera Zoom", "Zooms", Category.VISUALS) {
        });

        List<ClientModule> r = manager.search("fps");
        assertEquals("fps_counter", r.get(0).id());
        assertEquals("coords", r.get(1).id());
        assertEquals(2, r.size());

        assertEquals("zoom", manager.search("zm").get(0).id());
        assertEquals("zoom", manager.search("CAMERA").get(0).id());
        assertTrue(manager.search("nothing-matches-this").isEmpty());
        assertEquals(3, manager.search("").size());
    }

    @Test
    public void queryFiltersByCategoryEnabledAndFavorites() {
        TestModule a = add("a", Category.HUD);
        TestModule b = add("b", Category.HUD);
        TestModule c = add("c", Category.VISUALS);
        manager.setEnabled(a, true);
        c.setFavorite(true);

        assertEquals(2, manager.query(new ModuleFilter("", Category.HUD, false, false)).size());
        assertEquals(List.of(a), manager.query(new ModuleFilter("", null, true, false)));
        assertEquals(List.of(c), manager.query(new ModuleFilter("", null, false, true)));
        assertEquals(List.of(c), manager.favorites());
        assertEquals(List.of(a), manager.enabled());
        assertEquals(List.of(a, b), manager.byCategory(Category.HUD));
    }

    @Test
    public void jsonRoundTripRestoresEverything() {
        TestModule a = add(new TestModule("a", Category.HUD, lifecycle));
        TestModule b = add("b", Category.HUD);
        manager.setEnabled(a, true);
        a.amount.set(8.0);
        a.flag.set(true);
        a.setFavorite(true);
        manager.bindKey(b, KEY_G);
        JsonObject saved = manager.toJson();

        manager.resetAll();
        assertFalse(a.isEnabled());
        assertEquals(5, a.amount.getInt());
        assertEquals(ClientModule.KEY_UNBOUND, b.keyCode());

        LoadReport report = manager.loadJson(saved);
        assertTrue(report.toString(), report.isClean());
        assertTrue(a.isEnabled());
        assertEquals(8, a.amount.getInt());
        assertTrue(a.flag.isOn());
        assertTrue(a.isFavorite());
        assertEquals(KEY_G, b.keyCode());
    }

    @Test
    public void loadingRepairsInvalidDataAndReportsIt() {
        TestModule a = add("a", Category.HUD);
        JsonObject bad = JsonParser.parseString("""
                {"modules": {
                  "a": {"enabled": true, "key": 99999, "favorite": "yes",
                        "settings": {"amount": 500, "flag": "maybe", "stale": 1}},
                  "ghost": {"enabled": true}
                }}""").getAsJsonObject();

        LoadReport r = manager.loadJson(bad);
        assertEquals("out-of-range number is clamped", 10, a.amount.getInt());
        assertFalse("wrong type falls back to default", a.flag.isOn());
        assertEquals("invalid key is unbound", ClientModule.KEY_UNBOUND, a.keyCode());
        assertFalse("favorite had the wrong type", a.isFavorite());
        assertTrue(a.isEnabled());
        String text = r.warnings().toString();
        assertTrue(text, text.contains("a.amount"));
        assertTrue(text, text.contains("a.flag"));
        assertTrue(text, text.contains("a.stale"));
        assertTrue(text, text.contains("ghost"));
        assertTrue(text, text.contains("invalid key"));
    }

    @Test
    public void loadingResolvesDuplicateAndReservedKeys() {
        TestModule a = add("a", Category.HUD);
        TestModule b = add("b", Category.HUD);
        TestModule c = add("c", Category.HUD);
        JsonObject json = JsonParser.parseString("""
                {"modules": {"a": {"key": 71}, "b": {"key": 71}, "c": {"key": 82}}}""").getAsJsonObject();
        LoadReport r = manager.loadJson(json);
        assertEquals(KEY_G, a.keyCode());
        assertEquals(ClientModule.KEY_UNBOUND, b.keyCode());
        assertEquals("reserved key removed", ClientModule.KEY_UNBOUND, c.keyCode());
        assertEquals(2, r.warnings().size());
        assertTrue(manager.findKeyConflicts().isEmpty());
    }

    @Test
    public void findKeyConflictsDetectsSharedKeys() {
        add(new TestModule("a", Category.HUD, lifecycle).key(KEY_G));
        add(new TestModule("b", Category.HUD, lifecycle).key(KEY_G));
        Map<Integer, List<ClientModule>> conflicts = manager.findKeyConflicts();
        assertEquals(1, conflicts.size());
        assertEquals(2, conflicts.get(KEY_G).size());
    }

    @Test
    public void loadingEnablesDependenciesEvenIfFileOmitsThem() {
        TestModule base = add("base", Category.UTILITY);
        TestModule top = add(new TestModule("top", Category.UTILITY, lifecycle).deps("base"));
        LoadReport r = manager.loadJson(JsonParser.parseString(
                "{\"modules\": {\"top\": {\"enabled\": true}, \"base\": {\"enabled\": false}}}").getAsJsonObject());
        assertTrue(top.isEnabled());
        assertTrue(base.isEnabled());
        assertFalse(r.isClean());
    }

    @Test
    public void modulesAbsentFromFileGetDefaults() {
        TestModule defaultOn = add(new TestModule("on", Category.UTILITY, lifecycle).onByDefault());
        manager.loadJson(new JsonObject());
        assertTrue(defaultOn.isEnabled());
        manager.setEnabled(defaultOn, false);
        manager.loadJson(new JsonObject());
        assertTrue("absent modules return to their default state", defaultOn.isEnabled());
    }

    @Test
    public void resetModuleRestoresSettingsKeyAndDefaultState() {
        TestModule m = add(new TestModule("m", Category.UTILITY, lifecycle).onByDefault().key(KEY_G));
        manager.resetAll();
        m.amount.set(1.0);
        manager.bindKey(m, KEY_H);
        manager.setEnabled(m, false);

        manager.resetModule(m);
        assertEquals(5, m.amount.getInt());
        assertEquals(KEY_G, m.keyCode());
        assertTrue(m.isEnabled());
    }

    @Test
    public void resetAllClearsFavoritesAndRestoresDefaults() {
        TestModule m = add(new TestModule("m", Category.UTILITY, lifecycle).onByDefault());
        TestModule n = add("n", Category.UTILITY);
        manager.setEnabled(n, true);
        n.setFavorite(true);
        n.flag.set(true);
        manager.resetAll();
        assertTrue(m.isEnabled());
        assertFalse(n.isEnabled());
        assertFalse(n.isFavorite());
        assertFalse(n.flag.isOn());
    }

    @Test
    public void validateFindsUnknownReferencesAndCycles() {
        add(new TestModule("a", Category.UTILITY, lifecycle).deps("b"));
        add(new TestModule("b", Category.UTILITY, lifecycle).deps("a"));
        add(new TestModule("c", Category.UTILITY, lifecycle).deps("nope").conflicts("zzz"));
        String problems = String.join("\n", manager.validate());
        assertTrue(problems, problems.contains("cycle"));
        assertTrue(problems, problems.contains("unknown module 'nope'"));
        assertTrue(problems, problems.contains("unknown module 'zzz'"));
    }

    @Test
    public void validateFlagsRequiredModuleThatAlsoConflicts() {
        add(new TestModule("a", Category.UTILITY, lifecycle).deps("b").conflicts("b"));
        add("b", Category.UTILITY);
        assertTrue(String.join("\n", manager.validate()).contains("they conflict"));
    }

    @Test
    public void validateFlagsConflictingDefaults() {
        add(new TestModule("a", Category.UTILITY, lifecycle).onByDefault().conflicts("b"));
        add(new TestModule("b", Category.UTILITY, lifecycle).onByDefault());
        assertTrue(String.join("\n", manager.validate()).contains("Default-enabled modules conflict"));
    }

    @Test
    public void validateIsCleanForConsistentRegistry() {
        add("a", Category.UTILITY);
        add(new TestModule("b", Category.UTILITY, lifecycle).deps("a"));
        assertTrue(manager.validate().isEmpty());
    }

    @Test
    public void presetAppliesSettingsBeforeEnablingAndReportsUnknowns() {
        TestModule m = add("m", Category.PERFORMANCE);
        Preset preset = new Preset("low", "Low-end",
                Map.of("m", true, "ghost", true),
                Map.of("m", Map.of("amount", 3, "flag", true, "missing", 1), "other", Map.of("x", 1)));

        LoadReport r = manager.applyPreset(preset);
        assertTrue(m.isEnabled());
        assertEquals(3, m.amount.getInt());
        assertTrue(m.flag.isOn());
        String text = r.warnings().toString();
        assertTrue(text, text.contains("m.missing"));
        assertTrue(text, text.contains("ghost"));
        assertTrue(text, text.contains("other"));
    }

    @Test
    public void presetReportsInvalidValues() {
        add("m", Category.PERFORMANCE);
        Preset preset = new Preset("p", "P", Map.of(), Map.of("m", Map.of("flag", 12, "amount", "x")));
        assertEquals(2, manager.applyPreset(preset).warnings().size());
    }

    @Test
    public void shutdownDisablesDependentsFirstWithoutChangingSavedState() {
        TestModule base = add("base", Category.UTILITY);
        TestModule top = add(new TestModule("top", Category.UTILITY, lifecycle).deps("base"));
        manager.setEnabled(top, true);
        JsonObject saved = manager.toJson();
        lifecycle.clear();

        manager.shutdown();
        assertEquals(List.of("-top", "-base"), lifecycle);
        assertFalse(base.isEnabled() || top.isEnabled());
        assertTrue("serialised state captured before shutdown still says enabled",
                saved.getAsJsonObject("modules").getAsJsonObject("top").get("enabled").getAsBoolean());
    }

    @Test
    public void unregisterDisablesDependentsAndRemoves() {
        TestModule base = add("base", Category.UTILITY);
        TestModule top = add(new TestModule("top", Category.UTILITY, lifecycle).deps("base"));
        manager.setEnabled(top, true);
        assertTrue(manager.unregister("base"));
        assertFalse(top.isEnabled());
        assertFalse(manager.get("base").isPresent());
        assertFalse(manager.unregister("base"));
    }

    @Test
    public void changeListenerFiresForStateKeySettingAndFavouriteChanges() {
        int[] count = {0};
        manager.setChangeListener(() -> count[0]++);
        TestModule m = add("m", Category.UTILITY);
        manager.setEnabled(m, true);
        int afterEnable = count[0];
        assertTrue(afterEnable > 0);
        m.amount.set(9.0);
        assertTrue("setting change must trigger autosave", count[0] > afterEnable);
        int afterSetting = count[0];
        manager.bindKey(m, KEY_G);
        assertTrue(count[0] > afterSetting);
    }

    @Test
    public void tooltipResolvesNames() {
        add("base", Category.UTILITY);
        add("other", Category.UTILITY);
        TestModule m = add(new TestModule("m", Category.UTILITY, lifecycle).deps("base").conflicts("other"));
        String tip = manager.tooltip(m);
        assertTrue(tip, tip.contains("Requires: Module base"));
        assertTrue(tip, tip.contains("Conflicts with: Module other"));
        assertNotNull(m.description());
        assertSame(m, manager.get("m").orElseThrow());
    }
}
