package dev.lumina.config;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.utils.LoadReport;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class GlobalSettingsTest {

    @Test
    public void privacyDefaultsAreTheMostRestrictive() {
        GlobalSettings g = new GlobalSettings();
        assertFalse("server history is opt-in", g.keepServerHistory());
        assertFalse(g.autoSwitchProfiles());
        assertEquals(GlobalSettings.DEFAULT_PROFILE_ID, g.activeProfile());
        g.setKeepServerHistory(true);
        GlobalSettings copy = new GlobalSettings();
        copy.loadJson(g.toJson());
        assertTrue(copy.keepServerHistory());
    }

    @Test
    public void hostNormalisation() {
        assertEquals("example.com", GlobalSettings.normaliseHost("Example.COM"));
        assertEquals("example.com", GlobalSettings.normaliseHost("example.com:25565"));
        assertEquals("example.com", GlobalSettings.normaliseHost(" example.com. "));
        assertEquals("::1", GlobalSettings.normaliseHost("[::1]:25565"));
        assertEquals("", GlobalSettings.normaliseHost(null));
        assertEquals("", GlobalSettings.normaliseHost("  "));
    }

    @Test
    public void serverBindingsMatchRegardlessOfPortAndCase() {
        GlobalSettings g = new GlobalSettings();
        g.bindServer("Play.Example.com", "pvp");
        assertEquals("pvp", g.profileForServer("play.example.com:25565"));
        assertEquals("pvp", g.profileForServer("PLAY.EXAMPLE.COM"));
        assertNull(g.profileForServer("other.example.com"));
        assertNull(g.profileForServer(null));
        g.unbindServer("play.example.com:1234");
        assertNull(g.profileForServer("play.example.com"));
        assertThrows(IllegalArgumentException.class, () -> g.bindServer("  ", "x"));
    }

    @Test
    public void jsonRoundTrip() {
        GlobalSettings g = new GlobalSettings();
        g.setActiveProfile("pvp");
        g.setAutoSwitchProfiles(true);
        g.setLastSeenVersion("0.1.0");
        g.setKeepServerHistory(true);
        g.setKeepErrorHistory(false);
        g.bindServer("hypixel.net", "pvp");

        GlobalSettings loaded = new GlobalSettings();
        LoadReport r = loaded.loadJson(g.toJson());
        assertTrue(r.toString(), r.isClean());
        assertEquals("pvp", loaded.activeProfile());
        assertTrue(loaded.autoSwitchProfiles());
        assertEquals("0.1.0", loaded.lastSeenVersion());
        assertTrue(loaded.keepServerHistory());
        assertFalse(loaded.keepErrorHistory());
        assertEquals("pvp", loaded.profileForServer("hypixel.net"));
    }

    @Test
    public void invalidDataFallsBackSafelyAndIsReported() {
        JsonObject bad = JsonParser.parseString("""
                {"activeProfile": "../../etc/passwd",
                 "autoSwitchProfiles": "yes",
                 "privacy": {"keepErrorHistory": "false"},
                 "serverProfiles": {"": "x", "ok.net": 5, "fine.net": "p"}}""").getAsJsonObject();
        GlobalSettings g = new GlobalSettings();
        LoadReport r = g.loadJson(bad);
        assertEquals(GlobalSettings.DEFAULT_PROFILE_ID, g.activeProfile());
        assertFalse(g.autoSwitchProfiles());
        assertTrue("a malformed value keeps the default", g.keepErrorHistory());
        assertEquals("p", g.profileForServer("fine.net"));
        assertNull(g.profileForServer("ok.net"));
        assertEquals(3, r.warnings().size());
    }

    @Test
    public void activeProfileMustBeACanonicalId() {
        GlobalSettings g = new GlobalSettings();
        g.loadJson(JsonParser.parseString("{\"activeProfile\": \"Has Caps\"}").getAsJsonObject());
        assertEquals("only lower-case ids are valid file ids", GlobalSettings.DEFAULT_PROFILE_ID, g.activeProfile());
    }
}
