package dev.lumina.config;

import com.google.gson.JsonObject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class SafeJsonFileTest {
    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    private final AtomicLong now = new AtomicLong(1_700_000_000_000L);
    private Path dir;
    private Path backups;
    private Path target;

    @Before
    public void setUp() throws IOException {
        dir = tmp.newFolder("cfg").toPath();
        backups = dir.resolve("backups");
        target = dir.resolve("settings.json");
    }

    private SafeJsonFile file(int schema, int maxBackups, long interval) {
        return new SafeJsonFile(target, backups, schema, maxBackups, interval, now::get);
    }

    private static JsonObject obj(String key, int value) {
        JsonObject o = new JsonObject();
        o.addProperty(key, value);
        return o;
    }

    private long count(Path folder, String contains) throws IOException {
        if (!Files.isDirectory(folder)) {
            return 0;
        }
        try (Stream<Path> s = Files.list(folder)) {
            return s.filter(p -> p.getFileName().toString().contains(contains)).count();
        }
    }

    @Test
    public void missingFileIsReportedAsFirstRun() {
        SafeJsonFile.ReadResult r = file(1, 3, 0).read();
        assertEquals(SafeJsonFile.Status.MISSING, r.status());
        assertEquals(0, r.data().size());
    }

    @Test
    public void writeThenReadRoundTripsAndStampsSchema() throws IOException {
        SafeJsonFile f = file(3, 3, 0);
        f.write(obj("a", 7));
        SafeJsonFile.ReadResult r = f.read();
        assertEquals(SafeJsonFile.Status.LOADED, r.status());
        assertEquals(7, r.data().get("a").getAsInt());
        assertEquals(3, r.data().get("schemaVersion").getAsInt());
        assertEquals("schemaVersion must come first", "schemaVersion", r.data().keySet().iterator().next());
    }

    @Test
    public void writeLeavesNoTemporaryFile() throws IOException {
        file(1, 3, 0).write(obj("a", 1));
        assertEquals(0, count(dir, ".tmp"));
        assertTrue(Files.exists(target));
    }

    @Test
    public void corruptFileIsRestoredFromNewestValidBackup() throws IOException {
        SafeJsonFile f = file(1, 5, 0);
        f.write(obj("v", 1));
        now.addAndGet(1000);
        f.write(obj("v", 2));
        now.addAndGet(1000);
        f.write(obj("v", 3));
        Files.writeString(target, "{\"v\": 4, ");

        SafeJsonFile.ReadResult r = f.read();
        assertEquals(SafeJsonFile.Status.RECOVERED_FROM_BACKUP, r.status());
        assertEquals("newest backup holds the previous write", 2, r.data().get("v").getAsInt());
        assertEquals("main file is repaired on disk", 2, f.read().data().get("v").getAsInt());
        assertEquals(SafeJsonFile.Status.LOADED, f.read().status());
        assertEquals("corrupt file kept for inspection", 1, count(backups.resolve("quarantine"), "corrupt"));
    }

    @Test
    public void corruptFileWithoutBackupFallsBackToDefaults() throws IOException {
        Files.writeString(target, "not json at all");
        SafeJsonFile.ReadResult r = file(1, 3, 0).read();
        assertEquals(SafeJsonFile.Status.CORRUPT_DEFAULTED, r.status());
        assertEquals(0, r.data().size());
        assertFalse("corrupt file moved out of the way", Files.exists(target));
        assertEquals(1, count(backups.resolve("quarantine"), "corrupt"));
    }

    @Test
    public void corruptBackupsAreSkipped() throws IOException {
        SafeJsonFile f = file(1, 5, 0);
        f.write(obj("v", 1));
        now.addAndGet(1000);
        f.write(obj("v", 2)); // backup of v=1 created
        now.addAndGet(1000);
        f.write(obj("v", 3)); // backup of v=2 created
        Path newest = f.listBackups().get(0);
        Files.writeString(newest, "garbage");
        Files.writeString(target, "[1,2,3]");

        SafeJsonFile.ReadResult r = f.read();
        assertEquals(SafeJsonFile.Status.RECOVERED_FROM_BACKUP, r.status());
        assertEquals("falls through to the older valid backup", 1, r.data().get("v").getAsInt());
    }

    @Test
    public void rootThatIsNotAnObjectIsCorrupt() throws IOException {
        Files.writeString(target, "[1, 2]");
        assertEquals(SafeJsonFile.Status.CORRUPT_DEFAULTED, file(1, 3, 0).read().status());
    }

    @Test
    public void absurdNestingIsTreatedAsCorruptNotAsACrash() throws IOException {
        Files.writeString(target, "{\"a\":" + "[".repeat(100_000) + "]".repeat(100_000) + "}");
        assertEquals(SafeJsonFile.Status.CORRUPT_DEFAULTED, file(1, 3, 0).read().status());
    }

    @Test
    public void oversizedFileIsTreatedAsCorrupt() throws IOException {
        byte[] big = new byte[5 * 1024 * 1024];
        java.util.Arrays.fill(big, (byte) ' ');
        Files.write(target, big);
        assertEquals(SafeJsonFile.Status.CORRUPT_DEFAULTED, file(1, 3, 0).read().status());
    }

    @Test
    public void emptyFileIsTreatedAsCorrupt() throws IOException {
        Files.write(target, new byte[0]);
        assertEquals(SafeJsonFile.Status.CORRUPT_DEFAULTED, file(1, 3, 0).read().status());
    }

    @Test
    public void invalidUtf8IsHandled() throws IOException {
        Files.write(target, new byte[]{'{', '"', 'a', '"', ':', (byte) 0xC3, (byte) 0x28, '}'});
        SafeJsonFile.ReadResult r = file(1, 3, 0).read();
        assertTrue(r.status() == SafeJsonFile.Status.LOADED || r.status() == SafeJsonFile.Status.CORRUPT_DEFAULTED);
    }

    @Test
    public void fileFromNewerSchemaIsPreservedAndNeverOverwritten() throws IOException {
        Files.writeString(target, "{\"schemaVersion\": 9, \"fancy\": true}", StandardCharsets.UTF_8);
        SafeJsonFile f = file(2, 3, 0);
        SafeJsonFile.ReadResult r = f.read();
        assertEquals(SafeJsonFile.Status.INCOMPATIBLE, r.status());
        assertEquals(0, r.data().size());
        assertEquals("original kept aside", 1, count(backups.resolve("quarantine"), "newer-schema-v9"));
        f.write(obj("x", 1));
        assertEquals(2, f.read().data().get("schemaVersion").getAsInt());
        assertEquals("the newer file is still preserved", 1, count(backups.resolve("quarantine"), "newer-schema-v9"));
    }

    @Test
    public void backupsArePrunedToTheConfiguredCount() throws IOException {
        SafeJsonFile f = file(1, 3, 0);
        for (int i = 0; i < 12; i++) {
            now.addAndGet(1000);
            f.write(obj("v", i));
        }
        assertEquals(3, f.listBackups().size());
        assertEquals("newest backup holds the second-to-last write", 10,
                com.google.gson.JsonParser.parseString(Files.readString(f.listBackups().get(0)))
                        .getAsJsonObject().get("v").getAsInt());
    }

    @Test
    public void backupIntervalLimitsHowOftenBackupsAreMade() throws IOException {
        SafeJsonFile f = file(1, 10, 10 * 60_000L);
        f.write(obj("v", 0));
        for (int i = 1; i < 20; i++) {
            now.addAndGet(1000);
            f.write(obj("v", i));
        }
        assertEquals("only the first overwrite inside the interval creates a backup", 1, f.listBackups().size());
        now.addAndGet(11 * 60_000L);
        f.write(obj("v", 99));
        assertEquals(2, f.listBackups().size());
    }

    @Test
    public void corruptFilesAreNeverBackedUp() throws IOException {
        SafeJsonFile f = file(1, 5, 0);
        Files.writeString(target, "{broken");
        f.write(obj("v", 1));
        assertEquals(0, f.listBackups().size());
        assertEquals(1, f.read().data().get("v").getAsInt());
    }

    @Test
    public void writeCreatesMissingDirectories() throws IOException {
        Path deep = dir.resolve("a/b/c/file.json");
        new SafeJsonFile(deep, dir.resolve("bk"), 1, 3, 0, now::get).write(obj("v", 1));
        assertTrue(Files.exists(deep));
    }

    @Test
    public void unrelatedBackupsOfOtherFilesAreNotUsed() throws IOException {
        SafeJsonFile other = new SafeJsonFile(dir.resolve("other.json"), backups, 1, 5, 0, now::get);
        other.write(obj("o", 1));
        now.addAndGet(1000);
        other.write(obj("o", 2));
        Files.writeString(target, "broken");
        assertEquals(SafeJsonFile.Status.CORRUPT_DEFAULTED, file(1, 5, 0).read().status());
    }
}
