package dev.lumina.config;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class AutoSaverTest {

    private static void waitFor(java.util.function.BooleanSupplier condition) throws InterruptedException {
        long deadline = System.currentTimeMillis() + 3000;
        while (!condition.getAsBoolean() && System.currentTimeMillis() < deadline) {
            Thread.sleep(5);
        }
        assertTrue("condition not reached in time", condition.getAsBoolean());
    }

    @Test
    public void manyChangesProduceASingleDebouncedSave() throws Exception {
        AtomicInteger saves = new AtomicInteger();
        try (AutoSaver saver = new AutoSaver("t", 40, (s, e) -> {
        }, saves::incrementAndGet)) {
            for (int i = 0; i < 500; i++) {
                saver.markDirty();
            }
            waitFor(() -> saves.get() >= 1);
            Thread.sleep(150);
            assertEquals(1, saves.get());
            assertFalse(saver.isDirty());
        }
    }

    @Test
    public void flushSavesImmediatelyOnlyWhenDirty() {
        AtomicInteger saves = new AtomicInteger();
        try (AutoSaver saver = new AutoSaver("t", 60_000, (s, e) -> {
        }, saves::incrementAndGet)) {
            saver.flush();
            assertEquals("nothing changed, nothing saved", 0, saves.get());
            saver.markDirty();
            saver.flush();
            assertEquals(1, saves.get());
            saver.flush();
            assertEquals(1, saves.get());
            assertEquals(1, saver.saveCount());
        }
    }

    @Test
    public void closeFlushesPendingChanges() {
        AtomicInteger saves = new AtomicInteger();
        AutoSaver saver = new AutoSaver("t", 60_000, (s, e) -> {
        }, saves::incrementAndGet);
        saver.markDirty();
        saver.close();
        assertEquals(1, saves.get());
        saver.markDirty();
        saver.close();
        assertEquals("a closed saver never schedules new work but close still flushes", 2, saves.get());
    }

    @Test
    public void failedSaveIsReportedKeptDirtyAndRetried() {
        List<String> errors = Collections.synchronizedList(new ArrayList<>());
        AtomicBoolean failing = new AtomicBoolean(true);
        AtomicInteger saves = new AtomicInteger();
        try (AutoSaver saver = new AutoSaver("cfg", 60_000, (s, e) -> errors.add(s + ":" + e.getMessage()), () -> {
            if (failing.get()) {
                throw new java.io.IOException("disk full");
            }
            saves.incrementAndGet();
        })) {
            saver.markDirty();
            saver.flush();
            assertEquals(List.of("autosave:cfg:disk full"), errors);
            assertTrue(saver.isDirty());
            assertEquals(0, saves.get());

            failing.set(false);
            saver.flush();
            assertEquals(1, saves.get());
            assertFalse(saver.isDirty());
        }
    }

    @Test
    public void changesMadeDuringASaveTriggerAnotherSave() throws Exception {
        AtomicInteger saves = new AtomicInteger();
        AutoSaver[] ref = new AutoSaver[1];
        ref[0] = new AutoSaver("t", 20, (s, e) -> {
        }, () -> {
            if (saves.incrementAndGet() == 1) {
                ref[0].markDirty();
            }
        });
        try (AutoSaver saver = ref[0]) {
            saver.markDirty();
            waitFor(() -> saves.get() >= 2);
            assertEquals(2, saves.get());
        }
    }
}
