package dev.lumina;

import com.google.gson.JsonPrimitive;
import dev.lumina.event.ClientEvents;
import dev.lumina.hud.FakeGameState;
import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.options.FakeGameOptions;
import dev.lumina.options.VideoOption;
import dev.lumina.performance.ProfileRun;
import dev.lumina.profile.ProfileException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/** Starts the whole client without Minecraft, the way the Fabric adapter does, and restarts it. */
public class ClientContextTest {
    private Path gameDir;
    private final AtomicLong clock = new AtomicLong(1_700_000_000_000L);
    private final FakeGameState game = new FakeGameState();
    private final FakeGameOptions options = new FakeGameOptions();
    private final List<Boolean> sprintCalls = new ArrayList<>();
    private final List<ClientContext> started = new ArrayList<>();

    @Before
    public void setUp() throws IOException {
        gameDir = Files.createTempDirectory("lumina-ctx");
    }

    @After
    public void tearDown() {
        started.forEach(ClientContext::close);
    }

    private ClientContext start(Set<String> mods) {
        ClientContext c = ClientContext.start(new ClientContext.Environment(gameDir, game, options, sprintCalls::add, clock::get,
                mods, "1.21.11", 21, "/home/tester", "tester", ZoneOffset.UTC));
        started.add(c);
        return c;
    }

    private ClientContext start() {
        return start(Set.of("fabric-api", "sodium"));
    }

    private static void set(ClientModule m, String setting, Object value) {
        m.setting(setting).orElseThrow().loadJson(value instanceof Boolean b ? new JsonPrimitive(b)
                : value instanceof Number n ? new JsonPrimitive(n) : new JsonPrimitive(String.valueOf(value)));
    }

    private static void set0(dev.lumina.setting.NumberSetting setting, int value) {
        setting.loadJson(new JsonPrimitive(value));
    }

    private ClientModule module(ClientContext c, String id) {
        return c.modules.get(id).orElseThrow();
    }

    @Test
    public void aFreshStartCreatesTheFolderAndADefaultProfile() {
        ClientContext c = start();
        assertTrue(c.isUsable());
        assertTrue(c.startupWarnings().toString(), c.startupWarnings().isEmpty());
        assertTrue(Files.isDirectory(gameDir.resolve("lumina").resolve("profiles")));
        assertTrue(Files.isRegularFile(gameDir.resolve("lumina").resolve("profiles").resolve("default.json")));
        assertEquals("default", c.global.settings().activeProfile());
        assertEquals(List.of("fps_counter"), c.modules.enabled().stream().map(ClientModule::id).toList());
        assertTrue(c.modules.validate().isEmpty());
        assertEquals(12 + 16 + 2, c.allModules().size());
        assertEquals("Lumina", c.info.name());
    }

    @Test
    public void everyCategoryUsedByTheModulesIsKnownAndTheBuiltInSetIsConsistent() {
        ClientContext c = start();
        assertTrue(c.allModules().stream().anyMatch(m -> m.category() == Category.PERFORMANCE));
        assertTrue(c.allModules().stream().anyMatch(m -> m.category() == Category.HUD));
        assertTrue(c.allModules().stream().anyMatch(m -> m.category() == Category.VISUALS));
        assertTrue(c.allModules().stream().anyMatch(m -> m.category() == Category.MOVEMENT));
        assertEquals(c.allModules().size(), c.allModules().stream().map(ClientModule::id).distinct().count());
    }

    @Test
    public void enabledModulesAndSettingsSurviveARestartAndGameOptionsAreGivenBack() {
        ClientContext first = start();
        set(module(first, "render_distance"), "value", 8);
        assertTrue(first.modules.setEnabled(module(first, "render_distance"), true).isSuccess());
        assertEquals(8, options.value(VideoOption.RENDER_DISTANCE));
        first.close();
        assertEquals("closing the client gives the game option back", 20, options.value(VideoOption.RENDER_DISTANCE));

        ClientContext second = start();
        assertTrue("the module is on again, as saved", module(second, "render_distance").isEnabled());
        assertEquals(8, options.value(VideoOption.RENDER_DISTANCE));
        assertTrue(second.modules.setEnabled(module(second, "render_distance"), false).isSuccess());
        assertEquals(20, options.value(VideoOption.RENDER_DISTANCE));
    }

    @Test
    public void aCrashWhileATweakIsActiveStillLetsTheNextStartRestoreTheRealValue() {
        ClientContext first = start();
        set(module(first, "render_distance"), "value", 8);
        first.modules.setEnabled(module(first, "render_distance"), true);
        first.flush();
        // The game process dies here: no close(). options.txt holds 8.
        assertEquals(8, options.value(VideoOption.RENDER_DISTANCE));

        ClientContext second = start();
        assertTrue(module(second, "render_distance").isEnabled());
        second.modules.setEnabled(module(second, "render_distance"), false);
        assertEquals("the value from before the crash, not the tweaked one", 20, options.value(VideoOption.RENDER_DISTANCE));
    }

    @Test
    public void tweakWhoseModuleWasTurnedOffInTheSavedProfileIsRestoredAtStartup() {
        ClientContext first = start();
        set(module(first, "fov_changer"), "value", 100);
        first.modules.setEnabled(module(first, "fov_changer"), true);
        first.flush();
        // Simulate: the profile on disk says the module is off, but the leftover record remains.
        first.modules.setEnabled(module(first, "fov_changer"), false);
        options.set(VideoOption.FOV, 100);
        first.videoOriginals.put(VideoOption.FOV, 70);
        first.flush();

        start();
        assertEquals(70, options.value(VideoOption.FOV));
    }

    @Test
    public void friendsNotesWaypointsAndStatsPersist() {
        ClientContext first = start();
        assertNull(first.friends.add("Alex", "builder", clock.get()));
        first.notes.add("Base", "x=1", clock.get());
        assertNull(first.waypoints.add("Home", "overworld", 10, 64, 10, 0xFF00FF00));
        first.onAttack();
        first.onAttack();
        first.onDamaged(4f);
        first.onMouseClick(0);
        first.close();

        ClientContext second = start();
        assertTrue(second.friends.contains("alex"));
        assertEquals(1, second.notes.size());
        assertEquals(1, second.waypoints.list().size());
        assertEquals(2, second.combatStats.lifetime().attacks());
        assertEquals(1, second.combatStats.lifetime().hitsTaken());
        assertEquals("the session counters start from zero", 0, second.combatStats.session().attacks());
    }

    @Test
    public void serverHistoryIsOffUntilTheSwitchIsTurnedOn() {
        ClientContext c = start();
        c.onWorldJoin("play.example.com");
        clock.addAndGet(30_000);
        c.onWorldLeave();
        assertTrue(c.serverHistory.list().isEmpty());

        c.global.settings().setKeepServerHistory(true);
        c.onWorldJoin("play.example.com:25565");
        clock.addAndGet(60_000);
        c.onWorldLeave();
        assertEquals(1, c.serverHistory.list().size());
        assertEquals(60, c.serverHistory.list().get(0).totalSeconds());
    }

    @Test
    public void joiningABoundServerSwitchesProfileWhenAutoSwitchIsOn() throws ProfileException {
        ClientContext c = start();
        String pvp = c.profiles.create("PvP", true);
        c.global.settings().setAutoSwitchProfiles(true);
        c.global.settings().bindServer("play.example.com", pvp);
        List<String> events = new ArrayList<>();
        c.bus.subscribe(ClientEvents.ProfileSwitched.class, e -> events.add(e.previousId() + "->" + e.newId()));

        c.onWorldJoin("Play.Example.com:25565");
        assertEquals(pvp, c.global.settings().activeProfile());
        assertEquals(List.of("default->" + pvp), events);
        assertTrue(c.notifications.visible(clock.get()).stream().anyMatch(n -> n.title().equals("Profile switched")));

        c.onWorldJoin("other.example.com");
        assertEquals("unbound servers leave the profile alone", pvp, c.global.settings().activeProfile());
    }

    @Test
    public void autoSwitchDoesNothingUnlessEnabled() throws ProfileException {
        ClientContext c = start();
        String pvp = c.profiles.create("PvP", true);
        c.global.settings().bindServer("play.example.com", pvp);
        c.onWorldJoin("play.example.com");
        assertEquals("default", c.global.settings().activeProfile());
    }

    @Test
    public void performanceLabStoresRunsPerProfileAndKeepsThemAcrossRestarts() {
        ClientContext c = start();
        assertNull("nothing measured yet", c.finishLab());
        c.startLab();
        assertTrue(c.isLabRunning());
        for (int i = 0; i < 600; i++) {
            c.frames.record(8.0);
        }
        ProfileRun run = c.finishLab();
        assertNotNull(run);
        assertFalse(c.isLabRunning());
        assertEquals("default", run.profileId());
        assertEquals(125.0, run.avgFps(), 0.5);
        assertSame(run, c.lastLabRun());
        c.close();

        ClientContext again = start();
        assertEquals(1, again.performanceHistory.runs("default").size());
    }

    private static void assertSame(Object expected, Object actual) {
        org.junit.Assert.assertSame(expected, actual);
    }

    @Test
    public void presetsApplyThroughTheContext() {
        ClientContext c = start();
        assertTrue(c.applyPerformancePreset("low_end").isClean());
        assertEquals(8, options.value(VideoOption.RENDER_DISTANCE));
        assertTrue(c.applyPerformancePreset("vanilla").isClean());
        assertEquals(20, options.value(VideoOption.RENDER_DISTANCE));
        assertFalse(c.applyPerformancePreset("nonsense").isClean());
    }

    @Test
    public void aMissingRequirementMakesTheClientPassiveAndSaysSo() {
        ClientContext c = start(Set.of("sodium"));
        assertFalse(c.isUsable());
        assertTrue(c.notifications.visible(clock.get()).stream().anyMatch(n -> n.title().equals("Fabric API")));
    }

    private static final class Exploding extends ClientModule {
        Exploding() {
            super("exploding", "Exploding", "Throws on every tick.", Category.UTILITY);
        }

        @Override
        protected boolean wantsTick() {
            return true;
        }

        @Override
        protected void onTick() {
            throw new IllegalStateException("bug in /home/tester/secret/path");
        }
    }

    @Test
    public void aCrashingModuleIsTurnedOffReportedWithoutPersonalPathsAndTheGameKeepsRunning() {
        ClientContext c = start();
        Exploding m = new Exploding();
        c.modules.register(m);
        c.modules.setEnabled(m, true);
        c.onTick();
        assertFalse(m.isEnabled());
        assertEquals(1, c.errors.entries().size());
        assertFalse(c.errors.toText(), c.errors.toText().contains("tester"));
        assertTrue(c.notifications.visible(clock.get()).stream().anyMatch(n -> n.title().equals("A module was turned off")));
        c.onTick();
        assertEquals(1, c.errors.entries().size());
    }

    @Test
    public void moduleKeysWorkAndTheMenuKeysAreReserved() {
        ClientContext c = start();
        ClientModule crosshair = module(c, "custom_crosshair");
        assertTrue(c.modules.bindKey(crosshair, 71).success());
        assertFalse(crosshair.isEnabled());
        assertTrue(c.onKey(71));
        assertTrue(crosshair.isEnabled());
        assertFalse("unbound keys are not consumed", c.onKey(72));
        assertFalse("the Click GUI key cannot be bound to a module", c.modules.bindKey(module(c, "toggle_sprint"), c.ui.clickGuiKey.getInt()).success());
        set0(c.ui.hudEditorKey, 73);
        assertFalse("nor the HUD editor key once it is set", c.modules.bindKey(module(c, "toggle_sprint"), 73).success());
    }

    @Test
    public void toggleSprintTicksThroughTheContext() {
        ClientContext c = start();
        c.modules.setEnabled(module(c, "toggle_sprint"), true);
        game.keys.add(dev.lumina.client.GameState.TrackedKey.FORWARD);
        game.keys.add(dev.lumina.client.GameState.TrackedKey.SPRINT);
        c.onTick();
        assertEquals(Boolean.TRUE, sprintCalls.get(sprintCalls.size() - 1));
    }

    @Test
    public void damagedFilesAreRepairedAndReportedInsteadOfStoppingTheStart() throws IOException {
        start().close();
        Files.writeString(gameDir.resolve("lumina").resolve("data").resolve("friends.json"), "{ nope");
        Files.writeString(gameDir.resolve("lumina").resolve("client.json"), "garbage");
        Files.writeString(gameDir.resolve("lumina").resolve("profiles").resolve("default.json"), "[1,2");
        ClientContext c = start();
        assertTrue(c.isUsable());
        assertFalse(c.startupWarnings().isEmpty());
        assertTrue(c.notifications.visible(clock.get()).stream().anyMatch(n -> n.message().contains("repaired")));
        assertTrue(c.modules.validate().isEmpty());
    }

    @Test
    public void closeIsIdempotentAndStopsTheClient() {
        ClientContext c = start();
        c.close();
        c.close();
        c.onTick();
        c.onFrame();
        assertFalse(c.onKey(70));
    }

    @Test
    public void framesAreRecordedForThePerformanceFeatures() {
        ClientContext c = start();
        int before = c.frames.frameCount();
        for (int i = 0; i < 5; i++) {
            c.onFrame();
        }
        assertTrue(c.frames.frameCount() >= before);
        assertNotNull(c.frames.snapshot());
    }
}
