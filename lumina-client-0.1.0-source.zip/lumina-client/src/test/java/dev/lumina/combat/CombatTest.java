package dev.lumina.combat;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.render.CrosshairShape;
import dev.lumina.render.Rect;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class CombatTest {

    // ---- CPS -----------------------------------------------------------------------------------

    @Test
    public void cpsCountsExactlyTheClicksInTheLastSecond() {
        CpsCounter c = new CpsCounter();
        for (int i = 0; i < 10; i++) {
            c.click(CpsCounter.LEFT, 1000 + i * 100L); // 1000..1900
        }
        assertEquals(10, c.cps(CpsCounter.LEFT, 1900));
        assertEquals("click at 1000 is exactly 1000 ms old and leaves the window", 9, c.cps(CpsCounter.LEFT, 2000));
        assertEquals(5, c.cps(CpsCounter.LEFT, 2400));
        assertEquals(0, c.cps(CpsCounter.LEFT, 5000));
        assertEquals(10, c.total(CpsCounter.LEFT));
        assertEquals(10, c.peak(CpsCounter.LEFT));
    }

    @Test
    public void buttonsAreTrackedIndependentlyAndUnknownButtonsIgnored() {
        CpsCounter c = new CpsCounter();
        c.click(CpsCounter.LEFT, 0);
        c.click(CpsCounter.RIGHT, 0);
        c.click(CpsCounter.RIGHT, 10);
        c.click(2, 10);
        c.click(-1, 10);
        assertEquals(1, c.cps(CpsCounter.LEFT, 20));
        assertEquals(2, c.cps(CpsCounter.RIGHT, 20));
        assertEquals(0, c.cps(2, 20));
        assertEquals(0, c.total(7));
    }

    @Test
    public void cpsMemoryIsBoundedAgainstEventFloods() {
        CpsCounter c = new CpsCounter();
        for (int i = 0; i < 100_000; i++) {
            c.click(CpsCounter.LEFT, 5);
        }
        assertEquals(CpsCounter.MAX_TRACKED, c.cps(CpsCounter.LEFT, 5));
        assertEquals(100_000, c.total(CpsCounter.LEFT));
    }

    @Test
    public void peakSurvivesTheWindowButResetClearsIt() {
        CpsCounter c = new CpsCounter();
        for (int i = 0; i < 7; i++) {
            c.click(CpsCounter.LEFT, i * 10L);
        }
        assertEquals(0, c.cps(CpsCounter.LEFT, 10_000));
        assertEquals(7, c.peak(CpsCounter.LEFT));
        c.reset();
        assertEquals(0, c.peak(CpsCounter.LEFT));
        assertEquals(0, c.total(CpsCounter.LEFT));
    }

    // ---- combo ---------------------------------------------------------------------------------

    @Test
    public void comboGrowsWhileAttacksStayWithinTheTimeout() {
        ComboTracker t = new ComboTracker(2000);
        assertEquals(1, t.onAttack(0));
        assertEquals(2, t.onAttack(1500));
        assertEquals(3, t.onAttack(3500));
        assertEquals(3, t.combo(3500));
        assertEquals(3, t.maxCombo());
    }

    @Test
    public void comboBreaksOnTimeoutAndOnDamage() {
        ComboTracker t = new ComboTracker(2000);
        t.onAttack(0);
        t.onAttack(100);
        assertEquals(0, t.combo(2101));
        assertEquals("a late attack starts a new combo", 1, t.onAttack(5000));
        t.onAttack(5100);
        t.onDamageTaken();
        assertEquals(0, t.combo(5100));
        assertEquals("max combo is remembered", 2, t.maxCombo());
        t.reset();
        assertEquals(0, t.maxCombo());
    }

    @Test
    public void comboRejectsNonPositiveTimeout() {
        assertThrows(IllegalArgumentException.class, () -> new ComboTracker(0));
    }

    // ---- stats ---------------------------------------------------------------------------------

    @Test
    public void statsAccumulateAndLifetimeIncludesStoredTotals() {
        CombatStats s = new CombatStats();
        s.onAttack();
        s.onAttack();
        s.onDamageTaken(3.5f);
        s.onDamageTaken(1.0f);
        s.onCombo(4);
        s.onCombo(2);
        s.onClick(CpsCounter.LEFT);
        s.onClick(CpsCounter.RIGHT);
        s.onClick(9);
        CombatStats.Counters c = s.session();
        assertEquals(2, c.attacks());
        assertEquals(2, c.hitsTaken());
        assertEquals(4.5, c.damageTaken(), 1e-9);
        assertEquals(4, c.maxCombo());
        assertEquals(1, c.leftClicks());
        assertEquals(1, c.rightClicks());

        JsonObject saved = s.toJson();
        CombatStats next = new CombatStats();
        next.loadJson(saved);
        assertEquals("session starts empty", 0, next.session().attacks());
        next.onAttack();
        assertEquals(3, next.lifetime().attacks());
        assertEquals(4, next.lifetime().maxCombo());
        assertEquals(4.5, next.lifetime().damageTaken(), 1e-9);
    }

    @Test
    public void invalidDamageValuesAreIgnored() {
        CombatStats s = new CombatStats();
        s.onDamageTaken(Float.NaN);
        s.onDamageTaken(-2f);
        s.onDamageTaken(0f);
        s.onDamageTaken(Float.POSITIVE_INFINITY);
        assertEquals(0, s.session().hitsTaken());
    }

    @Test
    public void loadingTolerantOfGarbage() {
        JsonObject bad = JsonParser.parseString("""
                {"attacksSent": -5, "hitsTaken": "many", "damageTaken": 1e999, "maxCombo": 99999999999,
                 "leftClicks": 12.9, "rightClicks": null}""").getAsJsonObject();
        CombatStats s = new CombatStats();
        s.loadJson(bad);
        CombatStats.Counters c = s.lifetime();
        assertEquals(0, c.attacks());
        assertEquals(0, c.hitsTaken());
        assertEquals(0, c.damageTaken(), 0);
        assertEquals(Integer.MAX_VALUE, c.maxCombo());
        assertEquals(12, c.leftClicks());
        assertEquals(0, c.rightClicks());
    }

    @Test
    public void resetSessionKeepsLifetimeAndResetAllClearsEverything() {
        CombatStats s = new CombatStats();
        s.onAttack();
        s.resetSession();
        assertEquals(0, s.session().attacks());
        assertEquals("the lifetime view still contains only stored totals", 0, s.lifetime().attacks());
        s.onAttack();
        JsonObject saved = s.toJson();
        s.loadJson(saved);
        s.onAttack();
        assertEquals(2, s.lifetime().attacks());
        s.resetAll();
        assertEquals(0, s.lifetime().attacks());
    }

    // ---- crosshair maths -----------------------------------------------------------------------

    @Test
    public void gapStaysAtBaseWhenIdleWithFullCooldown() {
        assertEquals(3f, CrosshairMath.gap(3f, 8f, 1f, false, false, false, false), 1e-6);
        assertEquals("unknown cooldown contributes nothing", 3f, CrosshairMath.gap(3f, 8f, -1f, false, false, false, false), 1e-6);
    }

    @Test
    public void gapExpandsWithCooldownMovementAndAirtime() {
        float idle = CrosshairMath.gap(3f, 8f, 1f, false, false, false, false);
        float charging = CrosshairMath.gap(3f, 8f, 0f, false, false, false, false);
        float walking = CrosshairMath.gap(3f, 8f, 1f, true, false, false, false);
        float sprinting = CrosshairMath.gap(3f, 8f, 1f, true, true, false, false);
        float jumping = CrosshairMath.gap(3f, 8f, 1f, false, false, true, false);
        assertTrue(charging > idle);
        assertTrue(walking > idle);
        assertTrue(sprinting > walking);
        assertTrue(jumping > idle);
        assertEquals(3f + 4f, charging, 1e-6);
    }

    @Test
    public void gapNeverExceedsBasePlusMaxExpansionNorShrinksBelowBase() {
        assertEquals(11f, CrosshairMath.gap(3f, 8f, 0f, true, true, true, false), 1e-6);
        assertEquals(3f, CrosshairMath.gap(3f, 8f, 1f, false, false, false, true), 1e-6);
        assertEquals(3f, CrosshairMath.gap(3f, 0f, 0f, true, true, true, false), 1e-6);
    }

    @Test
    public void approachConvergesAndIsFramerateIndependent() {
        float a = 0f;
        for (int i = 0; i < 60; i++) {
            a = CrosshairMath.approach(a, 10f, 1f / 60f, 12f);
        }
        float b = 0f;
        for (int i = 0; i < 240; i++) {
            b = CrosshairMath.approach(b, 10f, 1f / 240f, 12f);
        }
        assertEquals("same real time gives the same result at any frame rate", a, b, 1e-3);
        assertTrue(a > 9.9f && a <= 10f);
        assertEquals(5f, CrosshairMath.approach(5f, 10f, 0f, 12f), 0f);
        assertEquals(5f, CrosshairMath.approach(5f, 10f, 0.1f, 0f), 0f);
    }

    // ---- crosshair shape -----------------------------------------------------------------------

    @Test
    public void crossHasFourArmsSymmetricAroundTheCentre() {
        List<Rect> r = CrosshairShape.build(CrosshairShape.Style.CROSS, 100, 100, 5, 3, 1, 0xFFFFFFFF, false, false);
        assertEquals(4, r.size());
        Rect left = r.get(0);
        Rect right = r.get(1);
        Rect bottom = r.get(2);
        Rect top = r.get(3);
        assertEquals("distance from centre cell to left arm equals right arm", 100 - left.right(), right.x() - 101);
        assertEquals(100 - top.bottom(), bottom.y() - 101);
        assertEquals(3, 100 - left.right());
        assertEquals(5, left.w());
        assertEquals(5, top.h());
        assertEquals(1, left.h());
        assertEquals(1, top.w());
    }

    @Test
    public void tShapeOmitsTheTopArm() {
        List<Rect> r = CrosshairShape.build(CrosshairShape.Style.T_SHAPE, 50, 50, 4, 2, 2, 0xFFFF0000, false, false);
        assertEquals(3, r.size());
        assertTrue(r.stream().noneMatch(x -> x.bottom() <= 49 && x.w() == 2));
    }

    @Test
    public void dotIsASingleRectangleAndDotOptionAddsOneToOtherStyles() {
        assertEquals(1, CrosshairShape.build(CrosshairShape.Style.DOT, 10, 10, 5, 2, 3, 1, false, false).size());
        assertEquals(1, CrosshairShape.build(CrosshairShape.Style.DOT, 10, 10, 5, 2, 3, 1, true, false).size());
        assertEquals(5, CrosshairShape.build(CrosshairShape.Style.CROSS, 10, 10, 5, 2, 3, 1, true, false).size());
    }

    @Test
    public void squareFormsAClosedFrame() {
        List<Rect> r = CrosshairShape.build(CrosshairShape.Style.SQUARE, 100, 100, 4, 2, 1, 1, false, false);
        assertEquals(4, r.size());
        int minX = r.stream().mapToInt(Rect::x).min().orElseThrow();
        int maxX = r.stream().mapToInt(Rect::right).max().orElseThrow();
        int minY = r.stream().mapToInt(Rect::y).min().orElseThrow();
        int maxY = r.stream().mapToInt(Rect::bottom).max().orElseThrow();
        assertEquals(maxX - minX, maxY - minY);
        assertEquals("frame is centred on the crosshair centre", 100 - minX, maxX - 101);
        long area = r.stream().mapToLong(x -> (long) x.w() * x.h()).sum();
        long side = maxX - minX;
        assertEquals("a 1 px frame covers 4*(side-1) pixels without overlap", 4 * (side - 1), area);
    }

    @Test
    public void outlineAddsABlackBackingRectangleForEveryShape() {
        List<Rect> plain = CrosshairShape.build(CrosshairShape.Style.CROSS, 10, 10, 4, 2, 1, 0xFF00FF00, false, false);
        List<Rect> outlined = CrosshairShape.build(CrosshairShape.Style.CROSS, 10, 10, 4, 2, 1, 0xFF00FF00, false, true);
        assertEquals(plain.size() * 2, outlined.size());
        assertEquals("outline is drawn first", 0xFF000000, outlined.get(0).argb());
        assertEquals(plain.get(0).w() + 2, outlined.get(0).w());
        assertEquals("shapes are drawn on top", plain, outlined.subList(plain.size(), outlined.size()));
    }

    @Test
    public void degenerateInputsAreClamped() {
        List<Rect> r = CrosshairShape.build(CrosshairShape.Style.CROSS, 0, 0, -5, -3, 0, 1, false, false);
        assertEquals(4, r.size());
        assertTrue(r.stream().allMatch(x -> x.w() >= 1 && x.h() >= 1));
    }
}
