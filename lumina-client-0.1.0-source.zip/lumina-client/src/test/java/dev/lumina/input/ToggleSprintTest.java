package dev.lumina.input;

import com.google.gson.JsonPrimitive;
import dev.lumina.client.GameState.TrackedKey;
import dev.lumina.event.EventBus;
import dev.lumina.hud.FakeGameState;
import dev.lumina.input.SprintLogic.Mode;
import dev.lumina.module.ModuleManager;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ToggleSprintTest {
    private final SprintLogic logic = new SprintLogic();

    private boolean tick(Mode mode, boolean sprintKey, boolean forward, boolean sneaking) {
        return logic.update(mode, sprintKey, forward, sneaking, true);
    }

    @Test
    public void togglePressSwitchesSprintOnAndOff() {
        assertFalse(tick(Mode.TOGGLE, false, true, false));
        assertTrue("press -> on", tick(Mode.TOGGLE, true, true, false));
        assertTrue("key released, still on", tick(Mode.TOGGLE, false, true, false));
        assertTrue(tick(Mode.TOGGLE, false, true, false));
        assertFalse("second press -> off", tick(Mode.TOGGLE, true, true, false));
        assertFalse(tick(Mode.TOGGLE, false, true, false));
    }

    @Test
    public void holdingTheKeyDoesNotFlipTheLatchEveryTick() {
        tick(Mode.TOGGLE, true, true, false);
        for (int i = 0; i < 20; i++) {
            assertTrue(tick(Mode.TOGGLE, true, true, false));
        }
        assertTrue(logic.latched());
    }

    @Test
    public void neverSprintsWithoutForwardEvenWhenLatched() {
        tick(Mode.TOGGLE, true, true, false);
        assertFalse("backwards or sideways only: forward is up", tick(Mode.TOGGLE, false, false, false));
        assertTrue("forward again resumes", tick(Mode.TOGGLE, false, true, false));
        assertFalse(tick(Mode.WHILE_MOVING_FORWARD, false, false, false));
    }

    @Test
    public void sneakingAlwaysWins() {
        tick(Mode.TOGGLE, true, true, false);
        assertFalse(tick(Mode.TOGGLE, false, true, true));
        assertTrue(tick(Mode.TOGGLE, false, true, false));
        assertFalse(tick(Mode.WHILE_MOVING_FORWARD, false, true, true));
    }

    @Test
    public void whileMovingForwardModeNeedsNoKey() {
        assertTrue(tick(Mode.WHILE_MOVING_FORWARD, false, true, false));
        assertFalse(tick(Mode.WHILE_MOVING_FORWARD, false, false, false));
    }

    @Test
    public void notAllowedMeansNothingHappensAndTheLatchIsCleared() {
        tick(Mode.TOGGLE, true, true, false);
        assertFalse(logic.update(Mode.TOGGLE, true, true, false, false));
        assertFalse(logic.latched());
        assertFalse(logic.update(Mode.WHILE_MOVING_FORWARD, false, true, false, false));
    }

    // ---- module --------------------------------------------------------------------------------

    private FakeGameState game;
    private final List<Boolean> calls = new ArrayList<>();
    private ToggleSprintModule module;
    private ModuleManager manager;

    @Before
    public void setUp() {
        game = new FakeGameState();
        module = new ToggleSprintModule(game, calls::add);
        manager = new ModuleManager(new EventBus((s, e) -> {
        }), (s, e) -> {
        }, k -> false);
        manager.register(module);
        manager.setEnabled(module, true);
    }

    private boolean lastCall() {
        return calls.get(calls.size() - 1);
    }

    @Test
    public void moduleHoldsSprintAfterAPressInSingleplayer() {
        game.keys.add(TrackedKey.FORWARD);
        game.keys.add(TrackedKey.SPRINT);
        manager.tick();
        assertTrue(lastCall());
        game.keys.remove(TrackedKey.SPRINT);
        manager.tick();
        assertTrue(lastCall());
        assertTrue(module.isLatched());
    }

    @Test
    public void onAServerItDoesNothingUnlessAllowed() {
        game.server = "play.example.com";
        game.keys.add(TrackedKey.FORWARD);
        game.keys.add(TrackedKey.SPRINT);
        manager.tick();
        assertFalse(lastCall());
        assertFalse(module.isLatched());

        module.setting("allow_multiplayer").orElseThrow().loadJson(new JsonPrimitive(true));
        game.keys.remove(TrackedKey.SPRINT);
        manager.tick();
        game.keys.add(TrackedKey.SPRINT);
        manager.tick();
        assertTrue(lastCall());
    }

    @Test
    public void leavingTheWorldResetsAndDisablingReleases() {
        game.keys.add(TrackedKey.FORWARD);
        game.keys.add(TrackedKey.SPRINT);
        manager.tick();
        assertTrue(module.isLatched());
        game.inWorld = false;
        manager.tick();
        assertFalse(module.isLatched());

        game.inWorld = true;
        game.keys.remove(TrackedKey.SPRINT);
        manager.tick();
        assertFalse(lastCall());
        manager.setEnabled(module, false);
        assertFalse(lastCall());
    }

    @Test
    public void sneakKeyCountsEvenBeforeTheGameReportsSneaking() {
        game.keys.add(TrackedKey.FORWARD);
        game.keys.add(TrackedKey.SPRINT);
        game.keys.add(TrackedKey.SNEAK);
        manager.tick();
        assertFalse(lastCall());
    }
}
