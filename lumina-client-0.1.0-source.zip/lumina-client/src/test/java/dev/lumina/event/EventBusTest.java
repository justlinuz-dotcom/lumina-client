package dev.lumina.event;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class EventBusTest {

    @Test
    public void deliversToSubscribersOfTheExactType() {
        List<String> errors = new ArrayList<>();
        EventBus bus = new EventBus((s, e) -> errors.add(s));
        List<Object> got = new ArrayList<>();
        bus.subscribe(ClientEvents.PlayerAttacked.class, got::add);
        bus.post(new ClientEvents.PlayerAttacked(5));
        bus.post(new ClientEvents.MouseClicked(1, 0));
        assertEquals(List.of(new ClientEvents.PlayerAttacked(5)), got);
        assertTrue(errors.isEmpty());
    }

    @Test
    public void failingListenerDoesNotStopOthersAndIsReported() {
        List<String> errors = new ArrayList<>();
        EventBus bus = new EventBus((s, e) -> errors.add(s + "/" + e.getMessage()));
        List<Integer> got = new ArrayList<>();
        bus.subscribe(ClientEvents.MouseClicked.class, e -> {
            throw new IllegalStateException("bad listener");
        });
        bus.subscribe(ClientEvents.MouseClicked.class, e -> got.add(e.button()));
        bus.post(new ClientEvents.MouseClicked(1, 1));
        assertEquals(List.of(1), got);
        assertEquals(List.of("event:MouseClicked/bad listener"), errors);
    }

    @Test
    public void cancelStopsDelivery() {
        EventBus bus = new EventBus((s, e) -> {
        });
        List<Integer> got = new ArrayList<>();
        EventBus.Subscription sub = bus.subscribe(ClientEvents.MouseClicked.class, e -> got.add(e.button()));
        bus.post(new ClientEvents.MouseClicked(0, 0));
        sub.cancel();
        bus.post(new ClientEvents.MouseClicked(0, 1));
        assertEquals(List.of(0), got);
        assertEquals(0, bus.listenerCount(ClientEvents.MouseClicked.class));
    }

    @Test
    public void rejectsNulls() {
        EventBus bus = new EventBus((s, e) -> {
        });
        assertThrows(NullPointerException.class, () -> bus.post(null));
        assertThrows(NullPointerException.class, () -> bus.subscribe(null, x -> {
        }));
        assertThrows(NullPointerException.class, () -> bus.subscribe(String.class, null));
    }

    @Test
    public void listenersMayUnsubscribeWhileDispatching() {
        EventBus bus = new EventBus((s, e) -> {
        });
        List<String> got = new ArrayList<>();
        EventBus.Subscription[] self = new EventBus.Subscription[1];
        self[0] = bus.subscribe(ClientEvents.MouseClicked.class, e -> {
            got.add("once");
            self[0].cancel();
        });
        bus.post(new ClientEvents.MouseClicked(0, 0));
        bus.post(new ClientEvents.MouseClicked(0, 0));
        assertEquals(List.of("once"), got);
    }
}
