package dev.lumina.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class JsonAndNameTest {
    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    @Test
    public void parsesObjectsAndRejectsOtherRoots() {
        JsonObject o = Json.parseObject("{\"a\": 1}", 8);
        assertEquals(1, o.get("a").getAsInt());
        assertThrows(JsonParseException.class, () -> Json.parseObject("[1,2]", 8));
        assertThrows(JsonParseException.class, () -> Json.parseObject("42", 8));
        assertThrows(JsonParseException.class, () -> Json.parseObject("", 8));
        assertThrows(JsonParseException.class, () -> Json.parseObject("   ", 8));
        assertThrows(JsonParseException.class, () -> Json.parseObject(null, 8));
        assertThrows(JsonParseException.class, () -> Json.parseObject("{\"a\": ", 8));
    }

    @Test
    public void depthGuardRejectsDeepNestingButIgnoresBracketsInStrings() {
        String deep = "[".repeat(200) + "]".repeat(200);
        assertThrows(JsonParseException.class, () -> Json.checkDepth("{\"x\":" + deep + "}", 48));
        // brackets inside strings, including escaped quotes, must not count
        String tricky = "{\"s\": \"" + "[".repeat(500) + "\\\" [[[[ \"}";
        Json.checkDepth(tricky, 4);
        Json.parseObject(tricky, 4);
    }

    @Test
    public void readLimitedEnforcesSize() throws IOException {
        Path small = tmp.newFile("small.json").toPath();
        Files.writeString(small, "{}");
        assertEquals("{}", Json.readLimited(small, 10));
        Path big = tmp.newFile("big.json").toPath();
        Files.write(big, "x".repeat(100).getBytes(StandardCharsets.UTF_8));
        assertThrows(IOException.class, () -> Json.readLimited(big, 50));
    }

    @Test
    public void typedGettersFallBackOnWrongTypes() {
        JsonObject o = Json.parseObject("{\"s\":\"v\",\"i\":3,\"b\":true,\"o\":{\"k\":1},\"bad\":[1]}", 8);
        assertEquals("v", Json.string(o, "s", "x"));
        assertEquals("x", Json.string(o, "i", "x"));
        assertEquals(3, Json.integer(o, "i", 0));
        assertEquals(0, Json.integer(o, "s", 0));
        assertTrue(Json.bool(o, "b", false));
        assertTrue(Json.bool(o, "s", true));
        assertEquals(1, Json.object(o, "o").get("k").getAsInt());
        assertEquals(0, Json.object(o, "bad").size());
        assertEquals(0, Json.object(o, "missing").size());
    }

    @Test
    public void nameRulesAcceptNormalNames() {
        assertNull(NameRules.validate("PvP 1.8"));
        assertNull(NameRules.validate("low-end_pc"));
        assertNull(NameRules.validate("A"));
        assertEquals("pvp_1.8", NameRules.toId("PvP 1.8"));
    }

    @Test
    public void nameRulesRejectDangerousNames() {
        for (String bad : new String[]{null, "", " ", " x", "x ", "../etc", "a/b", "a\\b", "..", "a..b", "x.",
                "con", "NUL", "com1", "lpt9.txt", "-start", ".hidden", "a".repeat(33), "tab\tname", "emoji😀",
                "semi;colon", "colon:name"}) {
            assertNotNull("should reject: " + bad, NameRules.validate(bad));
        }
    }
}
