package dev.lumina.hud;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.utils.LoadReport;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class HudLayoutTest {
    private HudLayout layout;
    private int changes;

    @Before
    public void setUp() {
        layout = new HudLayout();
        layout.register("fps", Anchor.TOP_LEFT, 4, 4);
        layout.register("clock", Anchor.TOP_RIGHT, -4, 4);
        layout.setChangeListener(() -> changes++);
    }

    @Test
    public void registrationRules() {
        assertThrows(IllegalArgumentException.class, () -> layout.register("fps", Anchor.CENTER, 0, 0));
        assertThrows(IllegalArgumentException.class, () -> layout.state("ghost"));
        assertTrue(layout.has("fps"));
        assertFalse(layout.has("ghost"));
        assertEquals(java.util.List.of("fps", "clock"), layout.ids());
    }

    @Test
    public void elementsAreIndependent() {
        layout.state("fps").setScale(2f);
        layout.state("fps").setVisible(false);
        assertEquals(1f, layout.state("clock").scale(), 0);
        assertTrue(layout.state("clock").visible());
    }

    @Test
    public void everythingRoundTripsThroughJson() {
        HudElementState s = layout.state("fps");
        s.setPosition(Anchor.BOTTOM_RIGHT, -12.5f, -7f);
        s.setScale(1.5f);
        s.setOpacity(0.6f);
        s.setTextColor(0xFF33CC99);
        s.setVisible(false);
        s.setBackground(false);
        layout.setGridEnabled(true);
        layout.setSnapToGrid(true);
        layout.setGridSize(16);

        JsonObject saved = layout.save();
        HudLayout other = new HudLayout();
        other.register("fps", Anchor.TOP_LEFT, 4, 4);
        other.register("clock", Anchor.TOP_RIGHT, -4, 4);
        LoadReport r = other.load(saved);
        assertTrue(r.toString(), r.isClean());

        HudElementState t = other.state("fps");
        assertEquals(Anchor.BOTTOM_RIGHT, t.anchor());
        assertEquals(-12.5f, t.offsetX(), 0);
        assertEquals(-7f, t.offsetY(), 0);
        assertEquals(1.5f, t.scale(), 0);
        assertEquals(0.6f, t.opacity(), 1e-6);
        assertEquals(0xFF33CC99, t.textColor());
        assertFalse(t.visible());
        assertFalse(t.background());
        assertTrue(other.gridEnabled());
        assertTrue(other.snapToGrid());
        assertEquals(16, other.gridSize());
        assertEquals(16, other.effectiveSnap());
        assertEquals(Anchor.TOP_RIGHT, other.state("clock").anchor());
    }

    @Test
    public void invalidValuesAreRepairedAndReported() {
        JsonObject bad = JsonParser.parseString("""
                {"grid": {"size": 9999},
                 "elements": {
                   "fps": {"scale": 99, "opacity": 0, "anchor": "NOWHERE", "color": "blue", "x": "far", "y": 1e30},
                   "clock": "oops",
                   "ghost": {"x": 1}
                 }}""").getAsJsonObject();
        LoadReport r = layout.load(bad);
        HudElementState s = layout.state("fps");
        assertEquals(HudElementState.MAX_SCALE, s.scale(), 0);
        assertEquals(0.1f, s.opacity(), 1e-6);
        assertEquals("unknown anchor keeps the default", Anchor.TOP_LEFT, s.anchor());
        assertEquals("invalid colour keeps the default", 0xFFFFFFFF, s.textColor());
        assertEquals("non-number keeps the default", 4f, s.offsetX(), 0);
        assertEquals(HudElementState.MAX_OFFSET, s.offsetY(), 0);
        assertEquals(HudLayout.MAX_GRID, layout.gridSize());
        assertEquals(Anchor.TOP_RIGHT, layout.state("clock").anchor());
        String text = r.warnings().toString();
        assertTrue(text, text.contains("scale"));
        assertTrue(text, text.contains("opacity"));
        assertTrue(text, text.contains("anchor"));
        assertTrue(text, text.contains("colour"));
        assertTrue(text, text.contains("'x' must be a number"));
        assertTrue(text, text.contains("clock"));
        assertTrue(text, text.contains("ghost"));
        assertTrue(text, text.contains("grid size"));
    }

    @Test
    public void loadingAnEmptySectionRestoresDefaults() {
        layout.state("fps").setScale(2f);
        layout.state("fps").setPosition(Anchor.CENTER, 50, 50);
        layout.setGridEnabled(true);
        LoadReport r = layout.load(new JsonObject());
        assertTrue(r.isClean());
        assertEquals(1f, layout.state("fps").scale(), 0);
        assertEquals(Anchor.TOP_LEFT, layout.state("fps").anchor());
        assertFalse(layout.gridEnabled());
    }

    @Test
    public void resetAllAndResetOne() {
        layout.state("fps").setScale(2f);
        layout.state("clock").setScale(3f);
        layout.setSnapToGrid(true);
        layout.reset("fps");
        assertEquals(1f, layout.state("fps").scale(), 0);
        assertEquals(3f, layout.state("clock").scale(), 0);
        layout.resetAll();
        assertEquals(1f, layout.state("clock").scale(), 0);
        assertFalse(layout.snapToGrid());
        layout.reset("ghost");
    }

    @Test
    public void gridSizeIsClampedAndSnapDependsOnTheSwitch() {
        layout.setGridSize(1);
        assertEquals(HudLayout.MIN_GRID, layout.gridSize());
        layout.setGridSize(500);
        assertEquals(HudLayout.MAX_GRID, layout.gridSize());
        layout.setSnapToGrid(false);
        assertEquals(0, layout.effectiveSnap());
    }

    @Test
    public void editorChangesNotifyTheListener() {
        int before = changes;
        layout.setGridEnabled(true);
        layout.setSnapToGrid(true);
        layout.setGridSize(10);
        layout.reset("fps");
        layout.resetAll();
        assertEquals(before + 5, changes);
        layout.notifyChanged();
        assertEquals(before + 6, changes);
    }

    @Test
    public void stateSettersRejectNonFiniteValues() {
        HudElementState s = layout.state("fps");
        s.setScale(Float.NaN);
        s.setOpacity(Float.POSITIVE_INFINITY);
        s.setPosition(Anchor.TOP_LEFT, Float.NaN, Float.NEGATIVE_INFINITY);
        assertEquals(1f, s.scale(), 0);
        assertEquals(1f, s.opacity(), 0);
        assertEquals(0f, s.offsetX(), 0);
        assertEquals(0f, s.offsetY(), 0);
    }

    @Test
    public void copyProducesAnIndependentState() {
        HudElementState a = layout.state("fps");
        HudElementState copy = a.copy();
        copy.setScale(2.5f);
        assertEquals(1f, a.scale(), 0);
        assertEquals("fps", copy.id());
    }

    @Test
    public void sectionKeyIsHud() {
        assertEquals("hud", layout.sectionKey());
    }
}
