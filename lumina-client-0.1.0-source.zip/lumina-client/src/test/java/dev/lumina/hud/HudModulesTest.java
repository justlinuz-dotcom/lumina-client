package dev.lumina.hud;

import com.google.gson.JsonPrimitive;
import dev.lumina.client.ArmorPiece;
import dev.lumina.client.EffectInfo;
import dev.lumina.client.GameState.TrackedKey;
import dev.lumina.combat.CombatStats;
import dev.lumina.combat.ComboTracker;
import dev.lumina.combat.CpsCounter;
import dev.lumina.event.EventBus;
import dev.lumina.module.Category;
import dev.lumina.module.ModuleManager;
import dev.lumina.performance.FrameStats;
import dev.lumina.performance.MemorySampler;
import dev.lumina.world.SessionInfo;
import org.junit.Before;
import org.junit.Test;

import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class HudModulesTest {
    private final AtomicLong clock = new AtomicLong(java.time.Instant.parse("2026-01-01T14:32:00Z").toEpochMilli());
    private final AtomicLong nanos = new AtomicLong();
    private FakeGameState game;
    private HudServices services;
    private Map<String, HudModule> modules;

    @Before
    public void setUp() {
        game = new FakeGameState();
        services = new HudServices(new CpsCounter(), new ComboTracker(2000), new CombatStats(),
                new FrameStats(1000, nanos::get, clock::get), new MemorySampler(clock::get),
                new SessionInfo(clock::get), clock::get, ZoneOffset.UTC);
        modules = new HashMap<>();
        for (HudModule m : BuiltInHud.create(services)) {
            modules.put(m.id(), m);
        }
    }

    private HudModule m(String id) {
        return modules.get(id);
    }

    private void set(String moduleId, String settingId, Object value) {
        JsonPrimitive json = value instanceof Boolean b ? new JsonPrimitive(b)
                : value instanceof Number n ? new JsonPrimitive(n) : new JsonPrimitive(String.valueOf(value));
        m(moduleId).setting(settingId).orElseThrow().loadJson(json);
    }

    private List<String> lines(String id) {
        HudContent c = m(id).content(game, clock.get());
        assertNotNull(id + " produced no content", c);
        return ((HudContent.Text) c).lines();
    }

    private String line(String id) {
        List<String> l = lines(id);
        assertEquals(1, l.size());
        return l.get(0);
    }

    // ---- registry ------------------------------------------------------------------------------

    @Test
    public void registrationIsConsistent() {
        ModuleManager manager = new ModuleManager(new EventBus((s, e) -> {
        }), (s, e) -> {
        }, k -> false);
        HudLayout layout = new HudLayout();
        List<HudModule> registered = BuiltInHud.register(manager, layout, services);
        assertEquals(16, registered.size());
        assertTrue(manager.validate().isEmpty());
        Set<String> ids = new HashSet<>();
        for (HudModule h : registered) {
            assertTrue("duplicate id " + h.id(), ids.add(h.id()));
            assertEquals(Category.HUD, h.category());
            assertTrue(layout.has(h.id()));
            assertEquals(h.defaultAnchor(), layout.state(h.id()).anchor());
        }
        assertEquals(ids, new HashSet<>(layout.ids()));
        manager.resetAll();
        assertEquals("only the FPS counter is on by default", List.of("fps_counter"),
                manager.enabled().stream().map(x -> x.id()).toList());
    }

    @Test
    public void everyModuleHasAComposablePreviewAndDescription() {
        for (HudModule h : modules.values()) {
            assertFalse(h.name().isBlank());
            assertFalse(h.description().isBlank());
            HudPlan plan = HudComposer.compose(h.id(), h.previewContent(), new HudElementState(h.id(), h.defaultAnchor(), h.defaultX(), h.defaultY()),
                    new TextMeasurer() {
                        @Override
                        public int width(String t) {
                            return t.length() * 6;
                        }

                        @Override
                        public int lineHeight() {
                            return 9;
                        }
                    }, 854, 480, 0xFF5B8CFF, 0xE6121419);
            assertNotNull("preview of " + h.id(), plan);
        }
    }

    @Test
    public void defaultPositionsStayOnScreenForSmallWindows() {
        for (HudModule h : modules.values()) {
            HudGeometry.Box b = HudGeometry.place(new HudElementState(h.id(), h.defaultAnchor(), h.defaultX(), h.defaultY()),
                    120, 60, 427, 240);
            assertTrue(h.id(), b.x() >= 0 && b.y() >= 0 && b.right() <= 427 && b.bottom() <= 240);
        }
    }

    // ---- info modules --------------------------------------------------------------------------

    @Test
    public void fps() {
        assertEquals("FPS: 120", line("fps_counter"));
        set("fps_counter", "show_frametime", true);
        assertEquals("FPS: 120 (8.3 ms)", line("fps_counter"));
        game.fps = 0;
        assertEquals("FPS: --", line("fps_counter"));
    }

    @Test
    public void ping() {
        assertEquals("Ping: 42 ms", line("ping_display"));
        game.ping = -1;
        assertEquals("Ping: n/a", line("ping_display"));
    }

    @Test
    public void coordinates() {
        assertEquals("XYZ: 10.3 / 64.0 / -3.8", line("coordinates"));
        set("coordinates", "decimals", 0);
        assertEquals("XYZ: 10 / 64 / -4", line("coordinates"));
        set("coordinates", "decimals", 2);
        set("coordinates", "multiline", true);
        assertEquals(List.of("X: 10.25", "Y: 64.00", "Z: -3.75"), lines("coordinates"));
    }

    @Test
    public void direction() {
        game.yaw = 180;
        assertEquals("Facing: N (0°)", line("direction_display"));
        game.yaw = 0;
        assertEquals("Facing: S (180°)", line("direction_display"));
        set("direction_display", "show_degrees", false);
        assertEquals("Facing: S", line("direction_display"));
    }

    @Test
    public void clock() {
        assertEquals("Time: 14:32", line("clock_display"));
        set("clock_display", "use_24h", false);
        assertEquals("Time: 2:32 PM", line("clock_display"));
        set("clock_display", "source", "GAME");
        game.timeOfDay = 6000;
        assertEquals("Day time: 12:00 PM", line("clock_display"));
        set("clock_display", "use_24h", true);
        assertEquals("Day time: 12:00", line("clock_display"));
    }

    @Test
    public void sessionNeverShowsTheServerUnlessAskedTo() {
        clock.addAndGet(754_000);
        game.server = "play.example.com";
        assertEquals("Session: 12:34", line("session_info"));
        set("session_info", "show_server", true);
        assertEquals(List.of("Session: 12:34", "Server: play.example.com"), lines("session_info"));
        game.server = null;
        assertEquals("singleplayer has no server line", List.of("Session: 12:34"), lines("session_info"));
    }

    @Test
    public void memory() {
        String text = line("memory_usage");
        assertTrue(text, text.matches("Mem: \\d+ / \\d+ MB \\(\\d+%\\)"));
    }

    // ---- combat / state modules ----------------------------------------------------------------

    @Test
    public void cps() {
        long now = clock.get();
        for (int i = 0; i < 5; i++) {
            services.cps().click(CpsCounter.LEFT, now - i * 50L);
        }
        services.cps().click(CpsCounter.RIGHT, now);
        services.cps().click(CpsCounter.RIGHT, now - 10);
        assertEquals("CPS: 5", line("cps_counter"));
        set("cps_counter", "show_right", true);
        assertEquals("CPS: 5 | 2", line("cps_counter"));
    }

    @Test
    public void combatInfoShowsOnlyWhatIsEnabledAndAvailable() {
        game.cooldown = 0.85f;
        long now = clock.get();
        services.combo().onAttack(now - 100);
        services.combo().onAttack(now - 50);
        services.stats().onAttack();
        services.stats().onAttack();
        services.stats().onAttack();
        assertEquals(List.of("Attack: 85%", "Combo: 2", "Attacks: 3"), lines("combat_info"));

        game.cooldown = -1f;
        set("combat_info", "show_damage_taken", true);
        services.stats().onDamageTaken(5f);
        assertEquals(List.of("Combo: 2", "Attacks: 3", "Damage taken: 2.5 hearts"), lines("combat_info"));

        for (String s : List.of("show_cooldown", "show_combo", "show_attacks", "show_damage_taken")) {
            set("combat_info", s, false);
        }
        assertNull(m("combat_info").content(game, clock.get()));
    }

    @Test
    public void armorShowsOnlyDamageableArmourPieces() {
        game.armor.add(new ArmorPiece("head", "diamond_helmet", 300, 363));
        game.armor.add(new ArmorPiece("feet", "leather_boots", 10, 65));
        game.armor.add(new ArmorPiece("chest", "elytra_dummy", 0, 0));
        game.armor.add(new ArmorPiece("mainhand", "diamond_sword", 1200, 1561));
        assertEquals(List.of("Helmet: Diamond Helmet 300/363 (83%)", "Boots: Leather Boots 10/65 (15%)"), lines("armor_status"));
        set("armor_status", "show_percent", false);
        assertEquals("Helmet: Diamond Helmet 300/363", lines("armor_status").get(0));
        game.armor.clear();
        assertNull(m("armor_status").content(game, clock.get()));
    }

    @Test
    public void itemDurabilityShowsHeldItemsOnly() {
        game.armor.add(new ArmorPiece("head", "diamond_helmet", 300, 363));
        assertNull(m("item_durability").content(game, clock.get()));
        game.armor.add(new ArmorPiece("mainhand", "diamond_sword", 1200, 1561));
        game.armor.add(new ArmorPiece("offhand", "shield", 100, 336));
        assertEquals(List.of("Main hand: Diamond Sword 1200/1561 (77%)", "Off hand: Shield 100/336 (30%)"),
                lines("item_durability"));
    }

    @Test
    public void effectsAreSortedFormattedAndHandleInfiniteDurations() {
        game.effects.add(new EffectInfo("speed", 1, 1500, false));
        game.effects.add(new EffectInfo("fire_resistance", 0, 0, true));
        game.effects.add(new EffectInfo("strength", 0, 400, false));
        assertEquals(List.of("Strength  0:20", "Speed II  1:15", "Fire Resistance  inf"), lines("potion_effects"));
        set("potion_effects", "shortest_first", false);
        assertEquals("Speed II  1:15", lines("potion_effects").get(0));
        set("potion_effects", "show_level", false);
        assertEquals("Speed  1:15", lines("potion_effects").get(0));
        game.effects.clear();
        assertNull(m("potion_effects").content(game, clock.get()));
    }

    @Test
    public void keystrokesReflectPressedKeysAndOptions() {
        game.keys.add(TrackedKey.FORWARD);
        game.keys.add(TrackedKey.ATTACK);
        HudContent.Keys keys = (HudContent.Keys) m("keystrokes").content(game, clock.get());
        assertEquals(7, keys.cells().size());
        assertTrue(keys.cells().stream().filter(c -> c.label().equals("W")).findFirst().orElseThrow().pressed());
        assertTrue(keys.cells().stream().filter(c -> c.label().equals("LMB")).findFirst().orElseThrow().pressed());
        assertFalse(keys.cells().stream().filter(c -> c.label().equals("RMB")).findFirst().orElseThrow().pressed());
        assertFalse(keys.cells().stream().filter(c -> c.label().equals("S")).findFirst().orElseThrow().pressed());

        set("keystrokes", "show_jump", false);
        set("keystrokes", "show_mouse", false);
        assertEquals(4, ((HudContent.Keys) m("keystrokes").content(game, clock.get())).cells().size());
    }

    @Test
    public void sprintIndicator() {
        assertNull(m("sprint_indicator").content(game, 0));
        game.sprinting = true;
        assertEquals("Sprinting", line("sprint_indicator"));
        game.sneaking = true;
        assertEquals("sneaking wins", "Sneaking", line("sprint_indicator"));
        game.sneaking = false;
        game.sprinting = false;
        set("sprint_indicator", "show_walking", true);
        assertEquals("Standing", line("sprint_indicator"));
        game.speed = 3;
        assertEquals("Walking", line("sprint_indicator"));
    }

    @Test
    public void counterCountsTheChosenSource() {
        services.stats().onAttack();
        services.stats().onAttack();
        services.stats().onDamageTaken(1f);
        services.stats().onClick(CpsCounter.LEFT);
        services.stats().onClick(CpsCounter.RIGHT);
        services.stats().onClick(CpsCounter.RIGHT);
        services.stats().onCombo(6);
        assertEquals("Attacks: 2", line("counter"));
        set("counter", "source", "HITS_TAKEN");
        assertEquals("Times hurt: 1", line("counter"));
        set("counter", "source", "LEFT_CLICKS");
        assertEquals("Left clicks: 1", line("counter"));
        set("counter", "source", "RIGHT_CLICKS");
        assertEquals("Right clicks: 2", line("counter"));
        set("counter", "source", "MAX_COMBO");
        assertEquals("Best combo: 6", line("counter"));
    }

    // ---- performance graph ---------------------------------------------------------------------

    @Test
    public void performanceGraphUsesRecentFrames() {
        assertNull(m("performance_graph").content(game, 0));
        for (int i = 0; i < 200; i++) {
            services.frames().record(10.0);
        }
        HudContent.Graph g = (HudContent.Graph) m("performance_graph").content(game, 0);
        assertEquals("Frame time  avg 10.0 ms", g.title());
        assertEquals(120, g.values().length);
        assertEquals(34f, g.maxValue(), 0);
        set("performance_graph", "samples", 40);
        assertEquals(40, ((HudContent.Graph) m("performance_graph").content(game, 0)).values().length);
    }

    @Test
    public void worldDependentFlagsMatchTheirData() {
        assertFalse(m("fps_counter").requiresWorld());
        assertFalse(m("session_info").requiresWorld());
        assertTrue(m("coordinates").requiresWorld());
        assertTrue(m("keystrokes").requiresWorld());
    }
}
