package dev.lumina.hud;

import dev.lumina.client.ArmorPiece;
import dev.lumina.client.EffectInfo;
import dev.lumina.client.GameState;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/** Mutable game state for tests. */
public final class FakeGameState implements GameState {
    public boolean inWorld = true;
    public int fps = 120;
    public double x = 10.25;
    public double y = 64;
    public double z = -3.75;
    public float yaw = 0;
    public int ping = 42;
    public double speed = 0;
    public boolean sprinting;
    public boolean sneaking;
    public boolean onGround = true;
    public float fallDistance;
    public long timeOfDay = 0;
    public float cooldown = 1f;
    public final Set<TrackedKey> keys = EnumSet.noneOf(TrackedKey.class);
    public final List<ArmorPiece> armor = new ArrayList<>();
    public final List<EffectInfo> effects = new ArrayList<>();
    public String server;

    @Override
    public boolean inWorld() {
        return inWorld;
    }

    @Override
    public int fps() {
        return fps;
    }

    @Override
    public double x() {
        return x;
    }

    @Override
    public double y() {
        return y;
    }

    @Override
    public double z() {
        return z;
    }

    @Override
    public float yaw() {
        return yaw;
    }

    @Override
    public int pingMs() {
        return ping;
    }

    @Override
    public double speedBlocksPerSecond() {
        return speed;
    }

    @Override
    public boolean sprinting() {
        return sprinting;
    }

    @Override
    public boolean sneaking() {
        return sneaking;
    }

    @Override
    public boolean onGround() {
        return onGround;
    }

    @Override
    public float fallDistance() {
        return fallDistance;
    }

    @Override
    public long timeOfDayTicks() {
        return timeOfDay;
    }

    @Override
    public float attackCooldown() {
        return cooldown;
    }

    @Override
    public boolean keyDown(TrackedKey key) {
        return keys.contains(key);
    }

    @Override
    public List<ArmorPiece> armor() {
        return armor;
    }

    @Override
    public List<EffectInfo> effects() {
        return effects;
    }

    @Override
    public String serverAddress() {
        return server;
    }
}
