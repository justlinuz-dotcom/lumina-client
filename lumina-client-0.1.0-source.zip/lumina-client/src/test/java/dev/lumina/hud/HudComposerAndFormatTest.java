package dev.lumina.hud;

import org.junit.Test;

import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class HudComposerAndFormatTest {
    private static final TextMeasurer FONT = new TextMeasurer() {
        @Override
        public int width(String text) {
            return text.length() * 6;
        }

        @Override
        public int lineHeight() {
            return 9;
        }
    };
    private static final int ACCENT = 0xFF5B8CFF;
    private static final int PANEL = 0xE6121419;

    private static HudElementState state(Anchor a, float x, float y) {
        return new HudElementState("e", a, x, y);
    }

    private static HudContent text(String... lines) {
        return new HudContent.Text(List.of(lines));
    }

    private static HudPlan compose(HudContent c, HudElementState s) {
        return HudComposer.compose("e", c, s, FONT, 400, 300, ACCENT, PANEL);
    }

    // ---- composer ------------------------------------------------------------------------------

    @Test
    public void textSizeAndOps() {
        HudPlan p = compose(text("FPS: 100"), state(Anchor.TOP_LEFT, 4, 4));
        assertEquals(4, p.x(), 0);
        assertEquals(4, p.y(), 0);
        assertEquals(54, p.w(), 0);
        assertEquals(15, p.h(), 0);
        assertEquals(new DrawOp.Fill(0, 0, 54, 15, PANEL), p.ops().get(0));
        assertEquals(new DrawOp.Text(3, 3, "FPS: 100", 0xFFFFFFFF), p.ops().get(1));
        assertEquals(2, p.ops().size());
    }

    @Test
    public void multipleLinesStackWithLineGap() {
        HudPlan p = compose(text("ab", "abcd"), state(Anchor.TOP_LEFT, 0, 0));
        assertEquals(30, p.w(), 0);
        assertEquals(25, p.h(), 0);
        assertEquals(new DrawOp.Text(3, 3, "ab", 0xFFFFFFFF), p.ops().get(1));
        assertEquals(new DrawOp.Text(3, 13, "abcd", 0xFFFFFFFF), p.ops().get(2));
    }

    @Test
    public void opacityScalesPanelAndTextAlpha() {
        HudElementState s = state(Anchor.TOP_LEFT, 0, 0);
        s.setOpacity(0.5f);
        s.setTextColor(0xFF00FF00);
        HudPlan p = compose(text("x"), s);
        assertEquals(0x73121419, ((DrawOp.Fill) p.ops().get(0)).argb());
        assertEquals(0x8000FF00, ((DrawOp.Text) p.ops().get(1)).argb());
    }

    @Test
    public void backgroundCanBeDisabled() {
        HudElementState s = state(Anchor.TOP_LEFT, 0, 0);
        s.setBackground(false);
        HudPlan p = compose(text("x"), s);
        assertEquals(1, p.ops().size());
        assertTrue(p.ops().get(0) instanceof DrawOp.Text);
    }

    @Test
    public void emptyContentProducesNoPlan() {
        HudElementState s = state(Anchor.TOP_LEFT, 0, 0);
        assertNull(compose(null, s));
        assertNull(compose(new HudContent.Text(List.of()), s));
        assertNull(compose(new HudContent.Graph("t", new float[0], 30f), s));
        assertNull(compose(new HudContent.Keys(List.of()), s));
    }

    @Test
    public void placementFollowsAnchorAndScale() {
        HudPlan p = compose(text("FPS: 100"), state(Anchor.TOP_RIGHT, -4, 4));
        assertEquals(342, p.x(), 0);
        HudElementState big = state(Anchor.TOP_RIGHT, -4, 4);
        big.setScale(2f);
        HudPlan q = compose(text("FPS: 100"), big);
        assertEquals(2f, q.scale(), 0);
        assertEquals(108, q.w(), 0);
        assertEquals(288, q.x(), 0);
        assertEquals(q.x() + q.w() + 4, 400, 0);
        assertEquals(q.box().right(), q.x() + q.w(), 0);
    }

    private static List<DrawOp.Fill> fills(HudPlan p) {
        return p.ops().stream().filter(o -> o instanceof DrawOp.Fill).map(o -> (DrawOp.Fill) o).toList();
    }

    @Test
    public void graphDrawsOneBarPerFrameColouredByFrameTime() {
        float[] v = new float[100];
        java.util.Arrays.fill(v, 10f);
        v[10] = 25f;
        v[20] = 50f;
        v[30] = 0.1f;
        v[40] = 500f;
        HudPlan p = compose(new HudContent.Graph("T", v, 34f), state(Anchor.TOP_LEFT, 0, 0));
        assertEquals(106, p.w(), 0);
        assertEquals(49, p.h(), 0);
        List<DrawOp.Fill> bars = fills(p).subList(1, 101);
        assertEquals(100, bars.size());
        assertEquals(0xFF55D68A, bars.get(0).argb());
        assertEquals(0xFFE6C14D, bars.get(10).argb());
        assertEquals(0xFFE5594F, bars.get(20).argb());
        assertEquals(9, bars.get(0).h());
        assertEquals(1, bars.get(30).h());
        assertEquals(32, bars.get(40).h());
        assertTrue("bars stand on a common baseline", bars.stream().allMatch(b -> b.y() + b.h() == bars.get(0).y() + bars.get(0).h()));
    }

    @Test
    public void graphDownsamplesByKeepingTheWorstFrameOfEachBucket() {
        float[] v = new float[300];
        java.util.Arrays.fill(v, 10f);
        v[151] = 100f;
        HudPlan p = compose(new HudContent.Graph("T", v, 34f), state(Anchor.TOP_LEFT, 0, 0));
        List<DrawOp.Fill> bars = fills(p).subList(1, fills(p).size());
        assertEquals(100, bars.size());
        assertEquals("a single spike stays visible after downsampling", 1,
                bars.stream().filter(b -> b.argb() == 0xFFE5594F).count());
    }

    @Test
    public void graphWithFewFramesUsesWiderBars() {
        float[] v = new float[50];
        java.util.Arrays.fill(v, 10f);
        HudPlan p = compose(new HudContent.Graph("T", v, 34f), state(Anchor.TOP_LEFT, 0, 0));
        assertEquals(2, fills(p).get(1).w());
        assertEquals(50, fills(p).size() - 1);
    }

    @Test
    public void graphTitleCanWidenTheElement() {
        HudPlan p = compose(new HudContent.Graph("a very long graph title here", new float[]{1f}, 10f),
                state(Anchor.TOP_LEFT, 0, 0));
        assertEquals(28 * 6 + 6, p.w(), 0);
    }

    @Test
    public void keysDrawCapsHighlightingPressedOnes() {
        HudContent keys = new HudContent.Keys(List.of(
                new HudContent.KeyCell("W", 1, 0, 1, true),
                new HudContent.KeyCell("A", 0, 1, 1, false),
                new HudContent.KeyCell("SPACE", 0, 2, 3, false)));
        HudPlan p = compose(keys, state(Anchor.TOP_LEFT, 0, 0));
        assertEquals(70, p.w(), 0);
        assertEquals(6 + 3 * 20 + 2 * 2, p.h(), 0);
        List<DrawOp.Fill> f = fills(p);
        assertEquals(ACCENT, f.get(1).argb());
        assertTrue(f.get(2).argb() != ACCENT);
        assertEquals(64, f.get(3).w());
        DrawOp.Text space = (DrawOp.Text) p.ops().stream()
                .filter(o -> o instanceof DrawOp.Text t && t.text().equals("SPACE")).findFirst().orElseThrow();
        assertEquals("label centred inside the wide cap", 3 + (64 - 30) / 2, space.x());
    }

    // ---- format --------------------------------------------------------------------------------

    @Test
    public void decimalFormatting() {
        assertEquals("3.14", HudFormat.decimal(3.14159, 2));
        assertEquals("3", HudFormat.decimal(3.4, 0));
        assertEquals("-0.5", HudFormat.decimal(-0.5, 1));
        assertEquals("1.000000", HudFormat.decimal(1.0, 99));
        assertEquals("2", HudFormat.decimal(2.0, -3));
    }

    @Test
    public void cardinalDirectionsFollowMinecraftYaw() {
        assertEquals("S", HudFormat.cardinal(0));
        assertEquals("W", HudFormat.cardinal(90));
        assertEquals("N", HudFormat.cardinal(180));
        assertEquals("E", HudFormat.cardinal(270));
        assertEquals("E", HudFormat.cardinal(-90));
        assertEquals("N", HudFormat.cardinal(-180));
        assertEquals("SW", HudFormat.cardinal(45));
        assertEquals("NW", HudFormat.cardinal(135));
        assertEquals("NE", HudFormat.cardinal(-135));
        assertEquals("SE", HudFormat.cardinal(-45));
        assertEquals("S", HudFormat.cardinal(360));
        assertEquals("N", HudFormat.cardinal(540));
        assertEquals("S", HudFormat.cardinal(-720));
    }

    @Test
    public void headingIsNorthBased() {
        assertEquals(0f, HudFormat.heading(180), 1e-4);
        assertEquals(90f, HudFormat.heading(-90), 1e-4);
        assertEquals(270f, HudFormat.heading(90), 1e-4);
        assertEquals(180f, HudFormat.heading(0), 1e-4);
        for (float yaw = -1000; yaw < 1000; yaw += 7.3f) {
            float h = HudFormat.heading(yaw);
            assertTrue(yaw + " -> " + h, h >= 0 && h < 360);
        }
    }

    @Test
    public void gameClockStartsAtSixAm() {
        assertEquals("06:00", HudFormat.gameClock(0, true));
        assertEquals("06:30", HudFormat.gameClock(500, true));
        assertEquals("07:00", HudFormat.gameClock(1000, true));
        assertEquals("12:00", HudFormat.gameClock(6000, true));
        assertEquals("18:00", HudFormat.gameClock(12000, true));
        assertEquals("00:00", HudFormat.gameClock(18000, true));
        assertEquals("05:58", HudFormat.gameClock(23983, true));
        assertEquals("05:59", HudFormat.gameClock(23984, true));
        assertEquals("6:00 AM", HudFormat.gameClock(0, false));
        assertEquals("12:00 PM", HudFormat.gameClock(6000, false));
        assertEquals("12:00 AM", HudFormat.gameClock(18000, false));
        assertEquals("--:--", HudFormat.gameClock(-1, true));
        assertEquals("06:00", HudFormat.gameClock(24000, true));
    }

    @Test
    public void realClockUsesTheGivenZone() {
        long t = java.time.Instant.parse("2026-01-01T14:32:10Z").toEpochMilli();
        assertEquals("14:32", HudFormat.realClock(t, ZoneOffset.UTC, true));
        assertEquals("2:32 PM", HudFormat.realClock(t, ZoneOffset.UTC, false));
        assertEquals("11:32", HudFormat.realClock(t, ZoneId.of("America/Maceio"), true));
        long midnight = java.time.Instant.parse("2026-01-01T00:05:00Z").toEpochMilli();
        assertEquals("12:05 AM", HudFormat.realClock(midnight, ZoneOffset.UTC, false));
    }

    @Test
    public void durationFormatting() {
        assertEquals("0:00", HudFormat.duration(0));
        assertEquals("0:09", HudFormat.duration(9));
        assertEquals("1:05", HudFormat.duration(65));
        assertEquals("59:59", HudFormat.duration(3599));
        assertEquals("1:00:00", HudFormat.duration(3600));
        assertEquals("26:01:01", HudFormat.duration(26 * 3600 + 61));
        assertEquals("0:00", HudFormat.duration(-5));
    }

    @Test
    public void romanPercentAndNames() {
        assertEquals("I", HudFormat.roman(1));
        assertEquals("IV", HudFormat.roman(4));
        assertEquals("X", HudFormat.roman(10));
        assertEquals("11", HudFormat.roman(11));
        assertEquals("0", HudFormat.roman(0));
        assertEquals("50%", HudFormat.percent(50, 100));
        assertEquals("83%", HudFormat.percent(300, 363));
        assertEquals("100%", HudFormat.percent(500, 100));
        assertEquals("0%", HudFormat.percent(-5, 100));
        assertEquals("--", HudFormat.percent(5, 0));
        assertEquals("Fire Resistance", HudFormat.prettyName("fire_resistance"));
        assertEquals("Speed", HudFormat.prettyName("speed"));
        assertEquals("", HudFormat.prettyName(""));
        assertNotNull(HudFormat.prettyName("a_b_c"));
    }
}
