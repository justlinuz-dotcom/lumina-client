package dev.lumina.hud;

import dev.lumina.config.ClientPaths;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class HudLayoutStoreTest {
    private ClientPaths paths;
    private HudLayoutStore store;
    private HudLayout layout;
    private final AtomicLong clock = new AtomicLong(1_000_000);

    @Before
    public void setUp() throws IOException {
        Path root = Files.createTempDirectory("lumina-layouts");
        paths = ClientPaths.of(root, "lumina");
        paths.ensureCreated();
        store = new HudLayoutStore(paths, clock::get, (s, e) -> {
            throw new AssertionError(s, e);
        });
        layout = new HudLayout();
        layout.register("fps", Anchor.TOP_LEFT, 4, 4);
        layout.register("clock", Anchor.TOP_RIGHT, -4, 4);
    }

    @Test
    public void saveListLoadRoundTrip() {
        layout.state("fps").setScale(2f);
        layout.state("clock").setPosition(Anchor.BOTTOM_LEFT, 9, -9);
        assertTrue(store.save("Ranked PvP", layout).ok());
        assertTrue(store.save("Clean", layout).ok());
        assertEquals(List.of("clean", "ranked_pvp"), store.list());

        layout.resetAll();
        AtomicInteger notified = new AtomicInteger();
        layout.setChangeListener(notified::incrementAndGet);
        HudLayoutStore.Outcome loaded = store.load("ranked pvp", layout);
        assertTrue(loaded.message(), loaded.ok());
        assertTrue(loaded.report().isClean());
        assertEquals(2f, layout.state("fps").scale(), 0);
        assertEquals(Anchor.BOTTOM_LEFT, layout.state("clock").anchor());
        assertTrue("layout listeners are told", notified.get() > 0);
    }

    @Test
    public void unsafeNamesAndMissingLayoutsAreRefused() {
        for (String bad : new String[]{"../x", "a/b", "", " x", "con", "x".repeat(40)}) {
            assertFalse(bad, store.save(bad, layout).ok());
            assertFalse(bad, store.load(bad, layout).ok());
            assertFalse(bad, store.delete(bad).ok());
        }
        assertFalse(store.load("nothing", layout).ok());
        assertFalse(store.delete("nothing").ok());
        assertTrue(store.list().isEmpty());
    }

    @Test
    public void deleteKeepsACopyInBackups() throws IOException {
        store.save("Temp", layout);
        assertTrue(store.delete("Temp").ok());
        assertTrue(store.list().isEmpty());
        try (var files = Files.list(paths.backups())) {
            assertTrue(files.anyMatch(p -> p.getFileName().toString().startsWith("deleted-layout-temp-")));
        }
    }

    @Test
    public void layoutCountIsLimitedButOverwritingIsAllowed() {
        for (int i = 0; i < HudLayoutStore.MAX_LAYOUTS; i++) {
            assertTrue(store.save("L" + i, layout).ok());
        }
        assertFalse(store.save("extra", layout).ok());
        assertTrue(store.save("L0", layout).ok());
    }

    @Test
    public void damagedAndForeignFilesAreNotLoaded() throws IOException {
        Files.writeString(paths.layouts().resolve("broken.json"), "{ not json");
        assertFalse(store.load("broken", layout).ok());
        Files.writeString(paths.layouts().resolve("foreign.json"), "{\"schemaVersion\":1,\"something\":true}");
        HudLayoutStore.Outcome foreign = store.load("foreign", layout);
        assertFalse(foreign.ok());
        assertTrue(foreign.message(), foreign.message().contains("not a layout"));
    }

    @Test
    public void loadingReportsRepairsInsteadOfFailing() throws IOException {
        store.save("Odd", layout);
        Path file = paths.layouts().resolve("odd.json");
        String text = Files.readString(file).replace("\"scale\": 1.0", "\"scale\": 99");
        Files.writeString(file, text);
        HudLayoutStore.Outcome r = store.load("Odd", layout);
        assertTrue(r.ok());
        assertEquals(HudElementState.MAX_SCALE, layout.state("fps").scale(), 0);
        assertFalse(r.report().isClean());
    }
}
