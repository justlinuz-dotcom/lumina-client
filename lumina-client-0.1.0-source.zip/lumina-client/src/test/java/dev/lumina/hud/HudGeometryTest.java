package dev.lumina.hud;

import dev.lumina.hud.HudGeometry.AlignMode;
import dev.lumina.hud.HudGeometry.Box;
import dev.lumina.hud.HudGeometry.Placed;
import org.junit.Test;

import java.util.List;
import java.util.Random;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class HudGeometryTest {
    private static final float EPS = 1e-3f;

    private static HudElementState state(Anchor a, float x, float y) {
        return new HudElementState("e", a, x, y);
    }

    @Test
    public void nearestAnchorUsesScreenThirds() {
        assertEquals(Anchor.TOP_LEFT, Anchor.nearest(10, 10, 900, 600));
        assertEquals(Anchor.TOP_CENTER, Anchor.nearest(450, 10, 900, 600));
        assertEquals(Anchor.TOP_RIGHT, Anchor.nearest(890, 10, 900, 600));
        assertEquals(Anchor.CENTER, Anchor.nearest(450, 300, 900, 600));
        assertEquals(Anchor.MIDDLE_LEFT, Anchor.nearest(10, 300, 900, 600));
        assertEquals(Anchor.MIDDLE_RIGHT, Anchor.nearest(890, 300, 900, 600));
        assertEquals(Anchor.BOTTOM_LEFT, Anchor.nearest(10, 590, 900, 600));
        assertEquals(Anchor.BOTTOM_CENTER, Anchor.nearest(450, 590, 900, 600));
        assertEquals(Anchor.BOTTOM_RIGHT, Anchor.nearest(890, 590, 900, 600));
    }

    @Test
    public void topLeftPlacementIsTheOffset() {
        Box b = HudGeometry.place(state(Anchor.TOP_LEFT, 4, 6), 50, 20, 400, 300);
        assertEquals(4, b.x(), EPS);
        assertEquals(6, b.y(), EPS);
        assertEquals(50, b.w(), EPS);
        assertEquals(20, b.h(), EPS);
    }

    @Test
    public void rightAnchoredElementsKeepTheirDistanceFromTheRightEdgeAtAnyResolution() {
        HudElementState s = state(Anchor.TOP_RIGHT, -4, 4);
        Box small = HudGeometry.place(s, 50, 20, 400, 300);
        Box big = HudGeometry.place(s, 50, 20, 1920, 1080);
        assertEquals(4, 400 - small.right(), EPS);
        assertEquals(4, 1920 - big.right(), EPS);
        assertEquals(4, small.y(), EPS);
    }

    @Test
    public void bottomAndCentreAnchors() {
        Box c = HudGeometry.place(state(Anchor.BOTTOM_CENTER, 0, -10), 40, 10, 400, 300);
        assertEquals(180, c.x(), EPS);
        assertEquals(280, c.y(), EPS);
        Box mid = HudGeometry.place(state(Anchor.CENTER, 0, 0), 40, 10, 400, 300);
        assertEquals(180, mid.x(), EPS);
        assertEquals(145, mid.y(), EPS);
    }

    @Test
    public void scaleChangesTheBoxAndKeepsTheAnchorPoint() {
        HudElementState s = state(Anchor.TOP_RIGHT, -4, 4);
        s.setScale(2f);
        Box b = HudGeometry.place(s, 50, 20, 400, 300);
        assertEquals(100, b.w(), EPS);
        assertEquals(40, b.h(), EPS);
        assertEquals(396, b.right(), EPS);
    }

    @Test
    public void placementIsAlwaysClampedOnScreen() {
        Box off = HudGeometry.place(state(Anchor.TOP_LEFT, 5000, -300), 50, 20, 400, 300);
        assertEquals(350, off.x(), EPS);
        assertEquals(0, off.y(), EPS);
        Box huge = HudGeometry.place(state(Anchor.TOP_LEFT, 20, 20), 900, 700, 400, 300);
        assertEquals("a box larger than the screen starts at the origin", 0, huge.x(), EPS);
        assertEquals(0, huge.y(), EPS);
    }

    @Test
    public void movingNearTheRightEdgeSwitchesToARightAnchor() {
        HudElementState s = state(Anchor.TOP_LEFT, 0, 0);
        HudGeometry.moveTo(s, 50, 20, 340, 10, 400, 300, 0);
        assertEquals(Anchor.TOP_RIGHT, s.anchor());
        assertEquals(-10, s.offsetX(), EPS);
        assertEquals(10, s.offsetY(), EPS);
        Box after = HudGeometry.place(s, 50, 20, 800, 300);
        assertEquals("the 10 px gap to the right edge survives a window resize", 10, 800 - after.right(), EPS);
    }

    @Test
    public void snappingRoundsToTheGrid() {
        HudElementState s = state(Anchor.TOP_LEFT, 0, 0);
        HudGeometry.moveTo(s, 30, 10, 21, 37, 400, 300, 8);
        Box b = HudGeometry.place(s, 30, 10, 400, 300);
        assertEquals(24, b.x(), EPS);
        assertEquals(40, b.y(), EPS);
    }

    @Test
    public void moveThenPlaceRoundTripsForRandomPositionsSizesAndScreens() {
        Random rnd = new Random(42);
        for (int i = 0; i < 5000; i++) {
            int sw = 200 + rnd.nextInt(1800);
            int sh = 150 + rnd.nextInt(1000);
            float w = 10 + rnd.nextInt(Math.max(1, sw - 10));
            float h = 8 + rnd.nextInt(Math.max(1, sh - 8));
            float x = rnd.nextInt(sw + 100) - 50;
            float y = rnd.nextInt(sh + 100) - 50;
            int snap = rnd.nextBoolean() ? 0 : 1 + rnd.nextInt(16);
            HudElementState s = state(Anchor.TOP_LEFT, 0, 0);
            HudGeometry.moveTo(s, w, h, x, y, sw, sh, snap);
            Box b = HudGeometry.place(s, w, h, sw, sh);
            assertTrue("on screen", b.x() >= -EPS && b.y() >= -EPS && b.right() <= sw + EPS && b.bottom() <= sh + EPS);
            float expectedX = snap > 0 ? Math.round(x / snap) * snap : x;
            float expectedY = snap > 0 ? Math.round(y / snap) * snap : y;
            expectedX = Math.max(0, Math.min(sw - w, expectedX));
            expectedY = Math.max(0, Math.min(sh - h, expectedY));
            assertEquals("x for iteration " + i, expectedX, b.x(), 0.01f);
            assertEquals("y for iteration " + i, expectedY, b.y(), 0.01f);
        }
    }

    private List<Placed> group(HudElementState a, HudElementState b, HudElementState c) {
        return List.of(new Placed(a, HudGeometry.place(a, 40, 10, 400, 300)),
                new Placed(b, HudGeometry.place(b, 60, 20, 400, 300)),
                new Placed(c, HudGeometry.place(c, 20, 30, 400, 300)));
    }

    @Test
    public void alignLeftAndRight() {
        HudElementState a = state(Anchor.TOP_LEFT, 10, 10);
        HudElementState b = state(Anchor.TOP_LEFT, 50, 60);
        HudElementState c = state(Anchor.TOP_LEFT, 120, 120);
        HudGeometry.align(group(a, b, c), AlignMode.LEFT, 400, 300, 0);
        assertEquals(10, HudGeometry.place(a, 40, 10, 400, 300).x(), EPS);
        assertEquals(10, HudGeometry.place(b, 60, 20, 400, 300).x(), EPS);
        assertEquals(10, HudGeometry.place(c, 20, 30, 400, 300).x(), EPS);

        HudGeometry.align(group(a, b, c), AlignMode.RIGHT, 400, 300, 0);
        float right = HudGeometry.place(a, 40, 10, 400, 300).right();
        assertEquals(right, HudGeometry.place(b, 60, 20, 400, 300).right(), EPS);
        assertEquals(right, HudGeometry.place(c, 20, 30, 400, 300).right(), EPS);
    }

    @Test
    public void alignTopBottomAndCentres() {
        HudElementState a = state(Anchor.TOP_LEFT, 10, 10);
        HudElementState b = state(Anchor.TOP_LEFT, 80, 60);
        HudElementState c = state(Anchor.TOP_LEFT, 150, 120);
        HudGeometry.align(group(a, b, c), AlignMode.TOP, 400, 300, 0);
        assertEquals(10, HudGeometry.place(b, 60, 20, 400, 300).y(), EPS);

        HudGeometry.align(group(a, b, c), AlignMode.BOTTOM, 400, 300, 0);
        float bottom = HudGeometry.place(a, 40, 10, 400, 300).bottom();
        assertEquals(bottom, HudGeometry.place(c, 20, 30, 400, 300).bottom(), EPS);

        HudGeometry.align(group(a, b, c), AlignMode.CENTER_HORIZONTAL, 400, 300, 0);
        float cx = HudGeometry.place(a, 40, 10, 400, 300).centerX();
        assertEquals(cx, HudGeometry.place(b, 60, 20, 400, 300).centerX(), EPS);
        assertEquals(cx, HudGeometry.place(c, 20, 30, 400, 300).centerX(), EPS);

        HudGeometry.align(group(a, b, c), AlignMode.CENTER_VERTICAL, 400, 300, 0);
        float cy = HudGeometry.place(a, 40, 10, 400, 300).centerY();
        assertEquals(cy, HudGeometry.place(c, 20, 30, 400, 300).centerY(), EPS);
    }

    @Test
    public void aloneElementIsNotAligned() {
        HudElementState a = state(Anchor.TOP_LEFT, 30, 30);
        HudGeometry.align(List.of(new Placed(a, HudGeometry.place(a, 40, 10, 400, 300))), AlignMode.LEFT, 400, 300, 0);
        assertEquals(30, a.offsetX(), 0);
    }

    @Test
    public void boxHelpers() {
        Box b = new Box(10, 20, 30, 40);
        assertEquals(40, b.right(), 0);
        assertEquals(60, b.bottom(), 0);
        assertEquals(25, b.centerX(), 0);
        assertEquals(40, b.centerY(), 0);
        assertTrue(b.contains(10, 20));
        assertTrue(b.contains(39.9f, 59.9f));
        assertTrue(!b.contains(40, 30));
        assertTrue(!b.contains(9.9f, 30));
    }
}
