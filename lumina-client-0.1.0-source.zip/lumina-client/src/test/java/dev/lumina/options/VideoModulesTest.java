package dev.lumina.options;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.event.EventBus;
import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.module.ModuleManager;
import dev.lumina.module.Preset;
import dev.lumina.module.ToggleResult;
import dev.lumina.utils.LoadReport;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class VideoModulesTest {
    private FakeGameOptions game;
    private VideoOriginals originals;
    private ModuleManager manager;
    private Map<String, VideoTweakModule> modules;

    @Before
    public void setUp() {
        game = new FakeGameOptions();
        originals = new VideoOriginals();
        manager = newManager();
        modules = register(manager, game, originals);
    }

    private static ModuleManager newManager() {
        return new ModuleManager(new EventBus((s, e) -> {
        }), (s, e) -> {
        }, k -> false);
    }

    private static Map<String, VideoTweakModule> register(ModuleManager manager, GameOptions game, VideoOriginals originals) {
        Map<String, VideoTweakModule> map = new HashMap<>();
        for (VideoTweakModule m : VideoModules.register(manager, game, originals)) {
            map.put(m.id(), m);
        }
        return map;
    }

    private void set(String module, String setting, Object value) {
        JsonObject o = JsonParser.parseString("{\"v\":" + (value instanceof String ? "\"" + value + "\"" : value) + "}").getAsJsonObject();
        modules.get(module).setting(setting).orElseThrow().loadJson(o.get("v"));
    }

    private ToggleResult on(String id) {
        return manager.setEnabled(modules.get(id), true);
    }

    private ToggleResult off(String id) {
        return manager.setEnabled(modules.get(id), false);
    }

    // ---- registry ------------------------------------------------------------------------------

    @Test
    public void registryIsConsistent() {
        assertEquals(12, modules.size());
        assertTrue(manager.validate().isEmpty());
        Set<VideoOption> options = new HashSet<>();
        for (VideoTweakModule m : modules.values()) {
            assertTrue("one module per option", options.add(m.option()));
            assertFalse(m.isDefaultEnabled());
            assertFalse(m.isEnabled());
            assertEquals(1, m.settings().size());
            assertFalse(m.description().isBlank());
        }
        assertEquals(Set.of(VideoOption.values()), options);
        assertEquals(Category.VISUALS, modules.get("fov_changer").category());
        assertEquals(Category.PERFORMANCE, modules.get("render_distance").category());
    }

    @Test
    public void defaultsAreInsideEachOptionRange() {
        for (VideoTweakModule m : modules.values()) {
            int desired = m.setting("value").map(s -> s.get() instanceof Double d ? d.intValue()
                    : s.get() instanceof Boolean b ? (b ? 1 : 0) : ((Enum<?>) s.get()).ordinal()).orElseThrow();
            assertTrue(m.id(), desired >= m.option().min() && desired <= m.option().max());
        }
    }

    // ---- apply / restore -----------------------------------------------------------------------

    @Test
    public void enablingAppliesTheValueAndDisablingRestoresTheOriginal() {
        set("render_distance", "value", 8);
        assertTrue(on("render_distance").isSuccess());
        assertEquals(8, game.value(VideoOption.RENDER_DISTANCE));
        assertEquals(Integer.valueOf(20), originals.get(VideoOption.RENDER_DISTANCE));

        assertTrue(off("render_distance").isSuccess());
        assertEquals(20, game.value(VideoOption.RENDER_DISTANCE));
        assertNull(originals.get(VideoOption.RENDER_DISTANCE));
    }

    @Test
    public void changingTheSettingWhileEnabledReappliesButNotWhileDisabled() {
        set("render_distance", "value", 8);
        assertEquals("a disabled module never touches the game", 0, game.writes);
        assertEquals(20, game.value(VideoOption.RENDER_DISTANCE));

        on("render_distance");
        set("render_distance", "value", 6);
        assertEquals(6, game.value(VideoOption.RENDER_DISTANCE));
        assertEquals("the original is still the first one", Integer.valueOf(20), originals.get(VideoOption.RENDER_DISTANCE));
        off("render_distance");
        assertEquals(20, game.value(VideoOption.RENDER_DISTANCE));
    }

    @Test
    public void valuesAreClampedToTheVanillaRange() {
        set("render_distance", "value", 500);
        on("render_distance");
        assertEquals(32, game.value(VideoOption.RENDER_DISTANCE));
        set("brightness", "value", 400);
        on("brightness");
        assertEquals("brightness never exceeds the vanilla maximum", 100, game.value(VideoOption.BRIGHTNESS));
        set("fov_changer", "value", 1);
        on("fov_changer");
        assertEquals(30, game.value(VideoOption.FOV));
    }

    @Test
    public void aChangeMadeByThePlayerWhileEnabledIsRespectedOnDisable() {
        set("fov_changer", "value", 100);
        on("fov_changer");
        game.set(VideoOption.FOV, 85);
        off("fov_changer");
        assertEquals("the player's own choice is not overwritten", 85, game.value(VideoOption.FOV));
        assertNull(originals.get(VideoOption.FOV));
    }

    @Test
    public void whenTheGameAdjustsTheValueTheAdjustedValueIsWhatIsTracked() {
        game.set(VideoOption.RENDER_DISTANCE, 9);
        game.hardCap.put(VideoOption.RENDER_DISTANCE, 10);
        set("render_distance", "value", 16);
        on("render_distance");
        assertEquals("the game capped the request", 10, game.value(VideoOption.RENDER_DISTANCE));
        off("render_distance");
        assertEquals("the capped value was recognised as ours and the original came back", 9,
                game.value(VideoOption.RENDER_DISTANCE));
    }

    @Test
    public void choiceOptionsUseTheDocumentedEncoding() {
        set("particles_level", "value", "MINIMAL");
        set("cloud_mode", "value", "OFF");
        set("graphics_mode", "value", "FABULOUS");
        on("particles_level");
        on("cloud_mode");
        on("graphics_mode");
        assertEquals(2, game.value(VideoOption.PARTICLES));
        assertEquals(0, game.value(VideoOption.CLOUDS));
        assertEquals(2, game.value(VideoOption.GRAPHICS));
    }

    @Test
    public void booleanOptionsMapToZeroAndOne() {
        set("view_bobbing", "value", false);
        on("view_bobbing");
        assertEquals(0, game.value(VideoOption.VIEW_BOBBING));
        set("view_bobbing", "value", true);
        assertEquals(1, game.value(VideoOption.VIEW_BOBBING));
        off("view_bobbing");
        assertEquals(1, game.value(VideoOption.VIEW_BOBBING));
    }

    @Test
    public void anUnsupportedOptionRefusesToEnableAndLeavesNothingBehind() {
        game.unsupported.add(VideoOption.CLOUDS);
        ToggleResult r = on("cloud_mode");
        assertFalse(r.isSuccess());
        assertFalse(modules.get("cloud_mode").isEnabled());
        assertEquals(2, game.value(VideoOption.CLOUDS));
        assertNull(originals.get(VideoOption.CLOUDS));
    }

    // ---- shutdown, crash and leftovers ---------------------------------------------------------

    @Test
    public void shutdownGivesTheValueBackButKeepsTheRecord() {
        set("render_distance", "value", 8);
        on("render_distance");
        manager.shutdown();
        assertEquals(20, game.value(VideoOption.RENDER_DISTANCE));
        assertEquals("kept in case the game saved its options before the module was released",
                Integer.valueOf(20), originals.get(VideoOption.RENDER_DISTANCE));
    }

    @Test
    public void aCrashWhileActiveDoesNotLoseTheRealOriginalValue() {
        set("render_distance", "value", 8);
        on("render_distance");
        // The game dies here: options.txt holds 8, and the record was persisted.
        JsonObject persisted = originals.toJson();
        assertEquals(20, persisted.get("RENDER_DISTANCE").getAsInt());

        VideoOriginals reloaded = new VideoOriginals();
        assertTrue(reloaded.loadJson(persisted).isClean());
        ModuleManager manager2 = newManager();
        Map<String, VideoTweakModule> modules2 = register(manager2, game, reloaded);
        assertEquals("the game still holds the tweaked value", 8, game.value(VideoOption.RENDER_DISTANCE));

        assertTrue(manager2.setEnabled(modules2.get("render_distance"), true).isSuccess());
        assertTrue(manager2.setEnabled(modules2.get("render_distance"), false).isSuccess());
        assertEquals("restored the value from before the crash, not the tweaked one", 20, game.value(VideoOption.RENDER_DISTANCE));
        assertEquals(0, reloaded.size());
    }

    @Test
    public void leftoverRecordsOfDisabledModulesAreRestoredAtStartup() {
        game.set(VideoOption.RENDER_DISTANCE, 8);
        game.set(VideoOption.FOV, 100);
        originals.put(VideoOption.RENDER_DISTANCE, 20);
        originals.put(VideoOption.FOV, 70);
        on("fov_changer"); // this one is enabled again by the saved profile: its record must stay
        assertEquals("fov_changer applied its own value", 90, game.value(VideoOption.FOV));

        Set<VideoOption> restored = VideoModules.restoreLeftovers(game, originals, modules.values());
        assertEquals(Set.of(VideoOption.RENDER_DISTANCE), restored);
        assertEquals(20, game.value(VideoOption.RENDER_DISTANCE));
        assertNull(originals.get(VideoOption.RENDER_DISTANCE));
        assertEquals(Integer.valueOf(70), originals.get(VideoOption.FOV));
    }

    @Test
    public void leftoversForUnsupportedOptionsAreDroppedWithoutTouchingTheGame() {
        game.unsupported.add(VideoOption.CLOUDS);
        originals.put(VideoOption.CLOUDS, 1);
        int writes = game.writes;
        assertTrue(VideoModules.restoreLeftovers(game, originals, modules.values()).isEmpty());
        assertEquals(writes, game.writes);
        assertEquals(0, originals.size());
    }

    // ---- originals persistence -----------------------------------------------------------------

    @Test
    public void originalsRoundTripAndRejectGarbage() {
        originals.put(VideoOption.FOV, 70);
        originals.put(VideoOption.PARTICLES, 1);
        VideoOriginals copy = new VideoOriginals();
        assertTrue(copy.loadJson(originals.toJson()).isClean());
        assertEquals(Integer.valueOf(70), copy.get(VideoOption.FOV));
        assertEquals(Integer.valueOf(1), copy.get(VideoOption.PARTICLES));

        JsonObject bad = JsonParser.parseString("""
                {"FOV": 9999, "CLOUDS": "two", "NOPE": 1, "BIOME_BLEND": 2.5, "PARTICLES": 2}""").getAsJsonObject();
        VideoOriginals other = new VideoOriginals();
        LoadReport r = other.loadJson(bad);
        assertEquals(4, r.warnings().size());
        assertEquals(1, other.size());
        assertEquals(Integer.valueOf(2), other.get(VideoOption.PARTICLES));
    }

    @Test
    public void originalsNotifyTheirListenerOnlyOnRealChanges() {
        int[] calls = {0};
        originals.setChangeListener(() -> calls[0]++);
        originals.put(VideoOption.FOV, 70);
        originals.remove(VideoOption.FOV);
        originals.remove(VideoOption.FOV);
        assertEquals(2, calls[0]);
    }

    // ---- presets -------------------------------------------------------------------------------

    @Test
    public void everyPresetAppliesCleanlyAndSetsTheDocumentedValues() {
        for (Preset p : PerformancePresets.all()) {
            LoadReport r = manager.applyPreset(p);
            assertTrue(p.id() + ": " + r, r.isClean());
            assertTrue(manager.validate().isEmpty());
        }
    }

    @Test
    public void presetsSwitchWithoutLeavingModulesBehindAndVanillaGivesEverythingBack() {
        Map<VideoOption, Integer> before = new HashMap<>(game.values);
        manager.applyPreset(PerformancePresets.lowEnd());
        assertEquals(8, game.value(VideoOption.RENDER_DISTANCE));
        assertEquals(6, game.value(VideoOption.SIMULATION_DISTANCE));
        assertEquals(2, game.value(VideoOption.PARTICLES));
        assertEquals(0, game.value(VideoOption.CLOUDS));
        assertEquals(0, game.value(VideoOption.ENTITY_SHADOWS));
        assertEquals(0, game.value(VideoOption.BIOME_BLEND));
        assertEquals(50, game.value(VideoOption.ENTITY_DISTANCE));
        assertEquals(0, game.value(VideoOption.GRAPHICS));
        assertEquals("the FPS limit is not part of the presets", 260, game.value(VideoOption.FPS_LIMIT));

        manager.applyPreset(PerformancePresets.quality());
        assertEquals(16, game.value(VideoOption.RENDER_DISTANCE));
        assertEquals(0, game.value(VideoOption.PARTICLES));
        assertEquals(2, game.value(VideoOption.CLOUDS));
        assertEquals(1, game.value(VideoOption.ENTITY_SHADOWS));
        assertEquals("originals survive switching between presets", Integer.valueOf(20),
                originals.get(VideoOption.RENDER_DISTANCE));

        manager.applyPreset(PerformancePresets.vanilla());
        assertEquals(before, game.values);
        assertEquals(0, originals.size());
        assertTrue(manager.enabled().isEmpty());
    }

    @Test
    public void presetsOnlyManageExistingVideoModules() {
        for (Preset p : PerformancePresets.all()) {
            assertEquals(new HashSet<>(PerformancePresets.MANAGED), p.enabled().keySet());
            for (String id : p.enabled().keySet()) {
                ClientModule m = manager.get(id).orElseThrow();
                assertTrue(VideoModules.isVideoModule(m));
                assertEquals(Category.PERFORMANCE, m.category());
            }
        }
    }

    @Test
    public void presetValuesStayInsideTheOptionRanges() {
        for (Preset p : PerformancePresets.all()) {
            LoadReport r = manager.applyPreset(p);
            assertEquals(p.id(), List.of(), r.warnings());
        }
    }
}
