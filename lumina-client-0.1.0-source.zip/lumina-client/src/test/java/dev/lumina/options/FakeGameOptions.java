package dev.lumina.options;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/** In-memory game options that clamp to the vanilla ranges like the real game does (and may be more restrictive). */
public final class FakeGameOptions implements GameOptions {
    public final Map<VideoOption, Integer> values = new EnumMap<>(VideoOption.class);
    public final Set<VideoOption> unsupported = EnumSet.noneOf(VideoOption.class);
    public final Map<VideoOption, Integer> hardCap = new EnumMap<>(VideoOption.class);
    public int writes;

    public FakeGameOptions() {
        values.put(VideoOption.RENDER_DISTANCE, 20);
        values.put(VideoOption.SIMULATION_DISTANCE, 14);
        values.put(VideoOption.PARTICLES, 0);
        values.put(VideoOption.CLOUDS, 2);
        values.put(VideoOption.ENTITY_SHADOWS, 1);
        values.put(VideoOption.BIOME_BLEND, 5);
        values.put(VideoOption.ENTITY_DISTANCE, 100);
        values.put(VideoOption.FPS_LIMIT, 260);
        values.put(VideoOption.GRAPHICS, 1);
        values.put(VideoOption.FOV, 70);
        values.put(VideoOption.VIEW_BOBBING, 1);
        values.put(VideoOption.BRIGHTNESS, 50);
    }

    @Override
    public boolean supports(VideoOption option) {
        return !unsupported.contains(option);
    }

    @Override
    public int get(VideoOption option) {
        return values.get(option);
    }

    @Override
    public void set(VideoOption option, int value) {
        writes++;
        int v = option.clamp(value);
        Integer cap = hardCap.get(option);
        if (cap != null) {
            v = Math.min(v, cap);
        }
        values.put(option, v);
    }

    public int value(VideoOption option) {
        return values.get(option);
    }
}
