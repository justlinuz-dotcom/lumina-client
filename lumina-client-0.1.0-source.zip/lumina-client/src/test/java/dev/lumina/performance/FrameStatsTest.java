package dev.lumina.performance;

import org.junit.Test;

import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class FrameStatsTest {
    private final AtomicLong nanos = new AtomicLong(0);
    private final AtomicLong wall = new AtomicLong(1_000_000);

    private FrameStats stats(int capacity) {
        return new FrameStats(capacity, nanos::get, wall::get);
    }

    private static void feed(FrameStats s, int count, double ms) {
        for (int i = 0; i < count; i++) {
            s.record(ms);
        }
    }

    @Test
    public void steadyFramesGiveExactAveragesAndPerfectStability() {
        FrameStats s = stats(1000);
        feed(s, 600, 1000.0 / 60.0);
        FrameSnapshot snap = s.snapshot();
        assertEquals(600, snap.frames());
        // frame times are stored as float, so values are exact to ~1e-6 ms
        assertEquals(60.0, snap.avgFps(), 1e-4);
        assertEquals(1000.0 / 60.0, snap.avgMs(), 1e-4);
        assertEquals(1000.0 / 60.0, snap.p99Ms(), 1e-4);
        assertEquals(60.0, snap.low1PercentFps(), 1e-3);
        assertEquals(0, snap.hitches());
        assertEquals(100.0, snap.stability(), 1e-3);
        assertTrue(snap.low1Reliable());
        assertFalse(snap.low01Reliable());
    }

    @Test
    public void lowPercentilesUseTheSlowestFrames() {
        FrameStats s = stats(2000);
        feed(s, 990, 10.0);
        feed(s, 10, 100.0);
        FrameSnapshot snap = s.snapshot();
        assertEquals(1000, snap.frames());
        assertEquals(10.9, snap.avgMs(), 1e-6);
        assertEquals("1% of 1000 frames = the 10 slowest", 10.0, snap.low1PercentFps(), 1e-6);
        assertEquals("0.1% = the single slowest frame", 10.0, snap.low01PercentFps(), 1e-6);
        assertEquals(10.0, snap.minMs(), 0);
        assertEquals(100.0, snap.maxMs(), 0);
        assertTrue(snap.low01Reliable());
    }

    @Test
    public void reliabilityFlagsDependOnSampleCount() {
        FrameStats s = stats(2000);
        feed(s, 299, 10.0);
        assertFalse(s.snapshot().low1Reliable());
        feed(s, 1, 10.0);
        assertTrue(s.snapshot().low1Reliable());
        assertFalse(s.snapshot().low01Reliable());
        feed(s, 700, 10.0);
        assertTrue(s.snapshot().low01Reliable());
    }

    @Test
    public void invalidFrameTimesAreRejectedAndCounted() {
        FrameStats s = stats(100);
        s.record(Double.NaN);
        s.record(0);
        s.record(-5);
        s.record(Double.POSITIVE_INFINITY);
        s.record(70_000);
        s.record(16.0);
        assertEquals(1, s.frameCount());
        assertEquals(5, s.rejectedCount());
    }

    @Test
    public void emptyStatsGiveEmptySnapshot() {
        FrameStats s = stats(100);
        assertTrue(s.snapshot().isEmpty());
        assertEquals(0, s.currentFps(), 0);
        assertEquals(0, s.recent(10).length);
    }

    @Test
    public void aSuddenLongFrameIsRecordedAsAHitch() {
        FrameStats s = stats(1000);
        feed(s, 60, 10.0);
        wall.set(5_000_000);
        s.record(80.0);
        feed(s, 10, 10.0);
        assertEquals(1, s.stutters().size());
        StutterEvent e = s.stutters().get(0);
        assertEquals(80.0, e.frameMs(), 0);
        assertEquals(10.0, e.baselineMs(), 0.5);
        assertEquals(5_000_000, e.timeMillis());
        assertEquals(1, s.snapshot().hitches());
        assertTrue("a hitch lowers the stability index", s.snapshot().stability() < 100);
    }

    @Test
    public void smallVariationsAtHighFpsAreNotHitches() {
        FrameStats s = stats(1000);
        feed(s, 60, 2.0);
        s.record(7.0); // 3.5x the baseline but far below the 25 ms floor: invisible to a player
        assertEquals(0, s.stutters().size());
    }

    @Test
    public void nothingIsReportedDuringWarmup() {
        FrameStats s = stats(1000);
        for (int i = 0; i < FrameStats.WARMUP_FRAMES; i++) {
            s.record(i % 2 == 0 ? 5.0 : 200.0);
        }
        assertEquals(0, s.stutters().size());
    }

    @Test
    public void aSustainedChangeBecomesTheNewBaselineInsteadOfEndlessHitches() {
        FrameStats s = stats(1000);
        feed(s, 100, 8.0);
        feed(s, 200, 40.0);
        assertEquals("only the first 10 slow frames are reported", FrameStats.SUSTAINED_FRAMES, s.stutters().size());
        s.record(40.0);
        assertEquals(FrameStats.SUSTAINED_FRAMES, s.stutters().size());
        s.record(300.0);
        assertEquals("a real hitch on top of the new baseline is still caught", FrameStats.SUSTAINED_FRAMES + 1,
                s.stutters().size());
    }

    @Test
    public void hitchHistoryIsBounded() {
        FrameStats s = stats(5000);
        feed(s, 60, 10.0);
        for (int i = 0; i < 500; i++) {
            s.record(100.0);
            feed(s, 5, 10.0);
        }
        assertEquals(100, s.stutters().size());
    }

    @Test
    public void ringBufferKeepsTheNewestFramesInOrder() {
        FrameStats s = stats(50);
        for (int i = 1; i <= 120; i++) {
            s.record(i);
        }
        assertEquals(50, s.frameCount());
        assertArrayEquals(new float[]{118f, 119f, 120f}, s.recent(3), 0f);
        assertEquals(50, s.recent(500).length);
        FrameSnapshot snap = s.snapshot();
        assertEquals(71.0, snap.minMs(), 0);
        assertEquals(120.0, snap.maxMs(), 0);
    }

    @Test
    public void onFrameMeasuresTheTimeBetweenCalls() {
        FrameStats s = stats(100);
        s.onFrame();
        assertEquals("first call only sets the reference", 0, s.frameCount());
        nanos.addAndGet(16_000_000L);
        s.onFrame();
        nanos.addAndGet(20_000_000L);
        s.onFrame();
        assertArrayEquals(new float[]{16f, 20f}, s.recent(2), 1e-4f);
    }

    @Test
    public void discontinuityPreventsAGiantFrameAfterAPause() {
        FrameStats s = stats(100);
        s.onFrame();
        nanos.addAndGet(16_000_000L);
        s.onFrame();
        s.markDiscontinuity();
        nanos.addAndGet(30_000_000_000L); // 30 s loading screen
        s.onFrame();
        assertEquals(1, s.frameCount());
        nanos.addAndGet(16_000_000L);
        s.onFrame();
        assertEquals(2, s.frameCount());
    }

    @Test
    public void currentFpsUsesTheLastHalfSecondAndIsCached() {
        FrameStats s = stats(1000);
        feed(s, 200, 33.3333); // old slow frames
        feed(s, 60, 10.0);     // 0.6 s of fast frames
        assertEquals(100.0, s.currentFps(), 0.5);
        feed(s, 60, 50.0);
        assertEquals("cached for 100 ms", 100.0, s.currentFps(), 0.5);
        nanos.addAndGet(150_000_000L);
        assertEquals(20.0, s.currentFps(), 0.5);
    }

    @Test
    public void steadyIsMoreStableThanErratic() {
        FrameStats steady = stats(1000);
        FrameStats erratic = stats(1000);
        feed(steady, 300, 16.0);
        for (int i = 0; i < 300; i++) {
            erratic.record(i % 2 == 0 ? 8.0 : 24.0);
        }
        assertTrue(steady.snapshot().stability() > erratic.snapshot().stability());
        assertEquals(steady.snapshot().avgMs(), erratic.snapshot().avgMs(), 1e-9);
    }

    @Test
    public void clearResetsEverything() {
        FrameStats s = stats(100);
        feed(s, 60, 10.0);
        s.record(100.0);
        s.clear();
        assertEquals(0, s.frameCount());
        assertEquals(0, s.stutters().size());
        assertTrue(s.snapshot().isEmpty());
    }

    @Test
    public void rejectsTinyCapacity() {
        assertThrows(IllegalArgumentException.class, () -> stats(5));
    }

    @Test
    public void helpersComputePercentilesByNearestRank() {
        double[] v = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        assertEquals(10, FrameStats.percentile(v, 0.99), 0);
        assertEquals(10, FrameStats.percentile(v, 0.95), 0);
        assertEquals(5, FrameStats.percentile(v, 0.5), 0);
        assertEquals(1000.0 / 10.0, FrameStats.lowFps(v, 0.01), 1e-9);
        assertEquals(1000.0 / 9.5, FrameStats.lowFps(v, 0.2), 1e-9);
    }

    @Test
    public void concurrentRecordingAndSnapshotsDoNotFail() throws Exception {
        FrameStats s = new FrameStats(500, System::nanoTime, System::currentTimeMillis);
        Thread writer = new Thread(() -> {
            for (int i = 0; i < 50_000; i++) {
                s.record(5 + (i % 7));
            }
        });
        Thread reader = new Thread(() -> {
            for (int i = 0; i < 2_000; i++) {
                s.snapshot();
                s.currentFps();
                s.recent(100);
            }
        });
        writer.start();
        reader.start();
        writer.join();
        reader.join();
        assertEquals(500, s.frameCount());
    }
}
