package dev.lumina.performance;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.module.ModuleManager;
import dev.lumina.event.EventBus;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class PerformanceLabTest {
    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    private static ProfileRun run(String id, int frames, double fps, double low1, boolean reliable) {
        return new ProfileRun(id, 1L, frames, fps, 1000.0 / fps, low1, reliable, 90);
    }

    // ---- comparison ----------------------------------------------------------------------------

    @Test
    public void comparisonNamesTheFasterProfileOnlyWhenTheDifferenceIsClear() {
        ProfileComparison.Result r = ProfileComparison.compare(run("quality", 2000, 100, 70, true),
                run("low-end", 2000, 130, 90, true));
        assertTrue(r.verdict(), r.verdict().contains("low-end averaged 30.0% more FPS than quality"));
        assertEquals(4, r.rows().size());
        assertEquals(30.0, r.rows().get(0).deltaPercent(), 1e-9);

        ProfileComparison.Result zero = ProfileComparison.compare(run("a", 2000, 100, 70, true),
                new ProfileRun("b", 1L, 2000, 0, 0, 0, true, 0));
        assertTrue(zero.verdict(), zero.verdict().startsWith("Inconclusive"));

        ProfileComparison.Result reversed = ProfileComparison.compare(run("a", 2000, 130, 90, true),
                run("b", 2000, 100, 70, true));
        assertTrue(reversed.verdict(), reversed.verdict().contains("a averaged 30.0% more FPS than b"));
    }

    @Test
    public void comparisonRefusesToPickAWinnerInsideTheNoiseBand() {
        ProfileComparison.Result r = ProfileComparison.compare(run("a", 2000, 100, 80, true), run("b", 2000, 103, 81, true));
        assertTrue(r.verdict(), r.verdict().startsWith("No clear difference"));
    }

    @Test
    public void comparisonIsInconclusiveWithTooFewFrames() {
        ProfileComparison.Result r = ProfileComparison.compare(run("a", 100, 100, 80, false), run("b", 2000, 200, 150, true));
        assertTrue(r.verdict(), r.verdict().startsWith("Inconclusive"));
        assertTrue(r.caveats().stream().anyMatch(c -> c.contains("At least 300 frames")));
        assertTrue(r.caveats().stream().anyMatch(c -> c.contains("1% low")));
    }

    @Test
    public void comparisonAlwaysWarnsAboutComparableScenes() {
        ProfileComparison.Result r = ProfileComparison.compare(run("a", 2000, 100, 80, true), run("b", 2000, 100, 80, true));
        assertTrue(r.caveats().get(0).contains("same place"));
    }

    @Test
    public void percentChangeHandlesZeroBaseline() {
        assertEquals(0, ProfileComparison.percentChange(0, 50), 0);
        assertEquals(-50, ProfileComparison.percentChange(100, 50), 1e-9);
    }

    // ---- history -------------------------------------------------------------------------------

    @Test
    public void historyKeepsOnlyTheNewestRunsPerProfile() {
        PerformanceHistory h = new PerformanceHistory();
        for (int i = 0; i < 30; i++) {
            h.record(new ProfileRun("p", i, 1000, 100 + i, 10, 80, true, 90));
        }
        assertEquals(PerformanceHistory.MAX_RUNS_PER_PROFILE, h.runs("p").size());
        assertEquals(129, h.latest("p").avgFps(), 0);
        assertEquals(110, h.runs("p").get(0).avgFps(), 0);
        assertNull(h.latest("unknown"));
    }

    @Test
    public void historyRoundTripsThroughJson() {
        PerformanceHistory h = new PerformanceHistory();
        h.record(run("alpha", 500, 120, 90, true));
        h.record(run("beta", 600, 60, 40, false));
        PerformanceHistory loaded = new PerformanceHistory();
        assertEquals(0, loaded.loadJson(h.toJson()));
        assertEquals(h.latest("alpha"), loaded.latest("alpha"));
        assertEquals(h.latest("beta"), loaded.latest("beta"));
        assertEquals(List.of("alpha", "beta"), loaded.profileIds());
    }

    @Test
    public void historySkipsMalformedEntries() {
        JsonObject json = JsonParser.parseString("""
                {"profiles": {
                   "ok": [{"time":1,"frames":10,"avgFps":50,"avgMs":20,"low1Fps":30,"low1Reliable":false,"stability":80},
                          {"frames":-3,"avgFps":50,"avgMs":20,"low1Fps":30,"stability":80},
                          {"frames":10,"avgFps":"fast","avgMs":20,"low1Fps":30,"stability":80},
                          {"frames":10,"avgFps":50,"avgMs":20,"low1Fps":30,"stability":500},
                          "junk"],
                   "../bad": [],
                   "notarray": 5}}""").getAsJsonObject();
        PerformanceHistory h = new PerformanceHistory();
        assertEquals(6, h.loadJson(json));
        assertEquals(1, h.runs("ok").size());
        assertEquals(List.of("ok"), h.profileIds());
    }

    @Test
    public void historyLimitsTheNumberOfProfiles() {
        PerformanceHistory h = new PerformanceHistory();
        for (int i = 0; i < PerformanceHistory.MAX_PROFILES + 10; i++) {
            h.record(run("p" + i, 500, 100, 80, true));
        }
        assertEquals(PerformanceHistory.MAX_PROFILES, h.profileIds().size());
        assertFalse(h.profileIds().contains("p0"));
    }

    // ---- memory --------------------------------------------------------------------------------

    @Test
    public void memorySamplerKeepsABoundedHistoryOldestFirst() {
        AtomicLong clock = new AtomicLong(0);
        MemorySampler m = new MemorySampler(clock::incrementAndGet);
        for (int i = 0; i < MemorySampler.HISTORY + 30; i++) {
            m.sample();
        }
        List<MemorySample> h = m.history();
        assertEquals(MemorySampler.HISTORY, h.size());
        assertTrue(h.get(0).timeMillis() < h.get(h.size() - 1).timeMillis());
        assertEquals(h.get(h.size() - 1), m.latest());
        MemorySample s = m.latest();
        assertTrue(s.usedBytes() > 0 && s.usedBytes() <= s.committedBytes());
        assertTrue(s.usedFraction() > 0 && s.usedFraction() <= 1.0);
        assertTrue(s.usedMb() > 0);
        assertTrue(MemorySampler.gcCount() >= -1);
        assertTrue(MemorySampler.gcTimeMillis() >= -1);
    }

    @Test
    public void memorySampleFractionIsSafeWithUnknownMax() {
        assertEquals(0, new MemorySample(0, 100, 200, 0).usedFraction(), 0);
        assertEquals(1.0, new MemorySample(0, 300, 300, 200).usedFraction(), 0);
    }

    // ---- module cost + report ------------------------------------------------------------------

    static final class Ticker extends ClientModule {
        private final int spinMicros;

        Ticker(String id, int spinMicros) {
            super(id, id, "ticks", Category.UTILITY);
            this.spinMicros = spinMicros;
        }

        @Override
        protected boolean wantsTick() {
            return true;
        }

        @Override
        protected void onTick() {
            long end = System.nanoTime() + spinMicros * 1000L;
            while (System.nanoTime() < end) {
                Thread.onSpinWait();
            }
        }
    }

    @Test
    public void moduleCostsAreMeasuredAndSortedByAverage() {
        ModuleManager mm = new ModuleManager(new EventBus((s, e) -> {
        }), (s, e) -> {
        }, k -> false);
        Ticker cheap = new Ticker("cheap", 0);
        Ticker pricey = new Ticker("pricey", 2000);
        mm.register(cheap);
        mm.register(pricey);
        mm.setEnabled(cheap, true);
        mm.setEnabled(pricey, true);
        for (int i = 0; i < 5; i++) {
            mm.tick();
        }
        List<ModuleCost> costs = ModuleCost.measure(mm.all());
        assertEquals(2, costs.size());
        assertEquals("pricey", costs.get(0).moduleId());
        assertTrue(costs.get(0).avgMicros() >= 2000);
        assertTrue(costs.get(0).maxMicros() >= costs.get(0).avgMicros());
        assertEquals(5, costs.get(0).ticks());
    }

    private PerformanceReport.Data sampleData(FrameSnapshot frames, List<StutterEvent> stutters, List<ModuleCost> costs) {
        return new PerformanceReport.Data("Lumina", "0.1.0", "1.21.11", "21.0.12", "Linux", 8, 1_767_225_600_000L,
                "default", frames, stutters, new MemorySample(0, 800L << 20, 1024L << 20, 4096L << 20), 12, 340, costs);
    }

    @Test
    public void reportDescribesMeasurementsWithoutBlamingModules() {
        FrameStats fs = new FrameStats(2000, System::nanoTime, () -> 1_767_225_600_000L);
        for (int i = 0; i < 400; i++) {
            fs.record(10.0);
        }
        fs.record(90.0);
        String text = PerformanceReport.toText(sampleData(fs.snapshot(), fs.stutters(),
                List.of(new ModuleCost("fps_counter", 100, 3.5, 40.0))));
        assertTrue(text, text.contains("Lumina performance report"));
        assertTrue(text, text.contains("Active profile: default"));
        assertTrue(text, text.contains("Average          : "));
        assertTrue(text, text.contains("Hitches in window: 1"));
        assertTrue(text, text.contains("Heap used 800 MB of max 4096 MB"));
        assertTrue(text, text.contains("fps_counter"));
        assertTrue(text, text.contains("do not show that any module caused a drop in FPS"));
        assertTrue(text, text.contains("heuristic"));
    }

    @Test
    public void reportHandlesEmptyData() {
        String text = PerformanceReport.toText(sampleData(FrameSnapshot.EMPTY, List.of(), List.of()));
        assertTrue(text, text.contains("no frames recorded"));
        assertTrue(text, text.contains("no ticking module has run yet"));
    }

    @Test
    public void reportFlagsUnreliableLowPercentiles() {
        FrameStats fs = new FrameStats(2000, System::nanoTime, System::currentTimeMillis);
        for (int i = 0; i < 50; i++) {
            fs.record(10.0);
        }
        String text = PerformanceReport.toText(sampleData(fs.snapshot(), List.of(), List.of()));
        assertTrue(text, text.contains("too few frames to be reliable"));
    }

    @Test
    public void reportContainsNoPersonalData() {
        String user = System.getProperty("user.name");
        String home = System.getProperty("user.home");
        PerformanceReport.Data d = sampleData(FrameSnapshot.EMPTY, List.of(), List.of());
        String all = PerformanceReport.toText(d) + PerformanceReport.toJson(d);
        if (user != null && user.length() > 3) {
            assertFalse(all.contains(user));
        }
        assertFalse(all.contains(home));
        assertFalse(all.toLowerCase().contains("server"));
    }

    @Test
    public void exportWritesTextAndJsonFiles() throws Exception {
        Path dir = tmp.newFolder("diag").toPath();
        Path text = PerformanceReport.export(dir, sampleData(FrameSnapshot.EMPTY, List.of(), List.of()));
        assertTrue(text.getFileName().toString().matches("report-\\d{8}-\\d{6}\\.txt"));
        assertTrue(Files.size(text) > 100);
        Path json = dir.resolve(text.getFileName().toString().replace(".txt", ".json"));
        JsonObject o = JsonParser.parseString(Files.readString(json)).getAsJsonObject();
        assertEquals("1.21.11", o.get("minecraft").getAsString());
        assertNotNull(o.get("frameStats"));
        assertNotNull(o.get("note"));
    }

    @Test
    public void profileRunFromSnapshotCopiesTheKeyFigures() {
        FrameStats fs = new FrameStats(2000, System::nanoTime, System::currentTimeMillis);
        for (int i = 0; i < 500; i++) {
            fs.record(10.0);
        }
        ProfileRun r = ProfileRun.of("p", 7L, fs.snapshot());
        assertEquals(500, r.frames());
        assertEquals(100.0, r.avgFps(), 1e-6);
        assertTrue(r.low1Reliable());
        assertEquals("p", r.profileId());
    }
}
