package dev.lumina.social;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.social.NotificationCenter.Level;
import dev.lumina.utils.LoadReport;
import org.junit.Test;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class SocialTest {

    // ---- friends -------------------------------------------------------------------------------

    @Test
    public void friendsValidateNamesAndRejectDuplicatesCaseInsensitively() {
        Friends f = new Friends();
        assertNull(f.add("Steve_01", "builder", 10));
        assertNotNull(f.add("steve_01", "", 11));
        assertNotNull(f.add("ab", "", 0));
        assertNotNull(f.add("a name with spaces", "", 0));
        assertNotNull(f.add("this_name_is_way_too_long", "", 0));
        assertNotNull(f.add(null, "", 0));
        assertEquals(1, f.size());
        assertTrue(f.contains("STEVE_01"));
    }

    @Test
    public void friendsAreSortedAndNotesAreCleaned() {
        Friends f = new Friends();
        f.add("zed", "", 1);
        f.add("Alex", "line\nbreak\ttab " + "x".repeat(200), 2);
        List<Friends.Entry> list = f.list();
        assertEquals("Alex", list.get(0).name());
        assertEquals("zed", list.get(1).name());
        String note = list.get(0).note();
        assertEquals(Friends.MAX_NOTE, note.length());
        assertFalse(note.contains("\n"));
        assertTrue(f.setNote("zed", "hi"));
        assertFalse(f.setNote("nobody", "hi"));
        assertTrue(f.remove("ZED"));
        assertFalse(f.remove("zed"));
    }

    @Test
    public void friendsHaveACapacityLimit() {
        Friends f = new Friends();
        for (int i = 0; i < Friends.MAX_ENTRIES; i++) {
            assertNull(f.add("player" + String.format("%04d", i), "", i));
        }
        assertNotNull(f.add("one_more", "", 0));
    }

    @Test
    public void friendsRoundTripAndRepairGarbage() {
        Friends f = new Friends();
        f.add("Alex", "mine", 5);
        Friends copy = new Friends();
        assertTrue(copy.loadJson(f.toJson()).isClean());
        assertEquals(f.list(), copy.list());

        JsonObject bad = JsonParser.parseString("""
                {"friends": [ {"name": "ok_name", "note": 5, "added": "x"}, {"name": "bad name!"}, 7,
                              {"name": "OK_NAME"}, {"name": "x\\u0000y"} ]}""").getAsJsonObject();
        Friends g = new Friends();
        LoadReport r = g.loadJson(bad);
        assertEquals(1, g.size());
        assertEquals(4, r.warnings().size());
        assertTrue(new Friends().loadJson(JsonParser.parseString("{\"friends\": 3}").getAsJsonObject()).warnings().size() == 1);
        assertTrue(new Friends().loadJson(new JsonObject()).isClean());
    }

    @Test
    public void friendsNotifyOnRealChangesOnly() {
        AtomicInteger calls = new AtomicInteger();
        Friends f = new Friends();
        f.setChangeListener(calls::incrementAndGet);
        f.add("Alex", "", 1);
        f.add("Alex", "", 1);
        f.remove("nobody");
        f.setNote("Alex", "x");
        f.remove("Alex");
        f.clear();
        assertEquals(3, calls.get());
    }

    // ---- notes ---------------------------------------------------------------------------------

    @Test
    public void notesCrudAndSearch() {
        Notes n = new Notes();
        int a = n.add("Base coords", "x=100 z=-40", 100);
        int b = n.add("", "buy more\ntorches", 200);
        assertEquals(2, n.size());
        assertEquals("Untitled", n.list().get(0).title());
        assertEquals("newest first", b, n.list().get(0).id());
        assertEquals(List.of(a), n.search("COORDS").stream().map(Notes.Note::id).toList());
        assertEquals(List.of(b), n.search("torches").stream().map(Notes.Note::id).toList());
        assertEquals(2, n.search("  ").size());
        assertTrue(n.update(a, "Base", "moved", 300));
        assertEquals(a, n.list().get(0).id());
        assertEquals("created time is kept", 100, n.list().get(0).createdMillis());
        assertFalse(n.update(999, "x", "y", 1));
        assertTrue(n.remove(b));
        assertFalse(n.remove(b));
    }

    @Test
    public void notesAreBoundedAndControlCharactersAreRemoved() {
        Notes n = new Notes();
        n.add("t".repeat(500), "a\u0007b\nc" + "z".repeat(5000), 1);
        Notes.Note note = n.list().get(0);
        assertEquals(Notes.MAX_TITLE, note.title().length());
        assertEquals(Notes.MAX_TEXT, note.text().length());
        assertTrue(note.text().startsWith("a b\nc"));
        for (int i = 1; i < Notes.MAX_NOTES; i++) {
            assertTrue(n.add("n" + i, "", i) > 0);
        }
        assertEquals(-1, n.add("overflow", "", 0));
    }

    @Test
    public void notesRoundTripKeepIdsAndRepairBadOnes() {
        Notes n = new Notes();
        int a = n.add("A", "one", 1);
        int b = n.add("B", "two", 2);
        n.remove(a);
        Notes copy = new Notes();
        assertTrue(copy.loadJson(n.toJson()).isClean());
        assertEquals(b, copy.list().get(0).id());
        int c = copy.add("C", "", 3);
        assertTrue("ids never collide after loading", c > b);

        JsonObject odd = JsonParser.parseString("""
                {"notes": [ {"id": 4, "title": "x"}, {"id": 4, "title": "dup"}, {"id": -3, "title": "neg"}, "str" ]}""").getAsJsonObject();
        Notes g = new Notes();
        LoadReport r = g.loadJson(odd);
        assertEquals(3, g.size());
        assertEquals(3, g.list().stream().map(Notes.Note::id).distinct().count());
        assertEquals(1, r.warnings().size());
    }

    // ---- notifications -------------------------------------------------------------------------

    @Test
    public void notificationsExpireByLevelAndAreKeptInHistory() {
        NotificationCenter c = new NotificationCenter();
        c.post(Level.INFO, "Hello", "world", 0);
        c.post(Level.ERROR, "Oops", "bad", 0);
        assertEquals(2, c.visible(100).size());
        assertEquals(1, c.visible(4_500).size());
        assertEquals(0, c.visible(10_001).size());
        assertEquals(2, c.history().size());
        assertEquals("newest first", "Oops", c.history().get(0).title());
    }

    @Test
    public void identicalNotificationsMergeWithinTheDedupeWindow() {
        NotificationCenter c = new NotificationCenter();
        c.post(Level.WARNING, "Module disabled", "Foo crashed", 0);
        c.post(Level.WARNING, "Module disabled", "Foo crashed", 500);
        c.post(Level.WARNING, "Module disabled", "Foo crashed", 900);
        assertEquals(1, c.visible(1000).size());
        assertEquals(3, c.visible(1000).get(0).repeat());
        assertEquals(1, c.history().size());
        assertEquals(3, c.history().get(0).repeat());
        c.post(Level.WARNING, "Module disabled", "Foo crashed", 10_000);
        assertEquals(2, c.history().size());
    }

    @Test
    public void onlyTheNewestFewAreVisibleAndMutingHidesButKeepsHistory() {
        NotificationCenter c = new NotificationCenter();
        for (int i = 0; i < 10; i++) {
            c.post(Level.INFO, "n" + i, "", 0);
        }
        List<NotificationCenter.Notification> visible = c.visible(1);
        assertEquals(NotificationCenter.MAX_VISIBLE, visible.size());
        assertEquals("n9", visible.get(visible.size() - 1).title());

        c.dismissAll();
        c.setMuted(true);
        c.post(Level.ERROR, "quiet", "", 5);
        assertTrue(c.visible(6).isEmpty());
        assertEquals("quiet", c.history().get(0).title());
        for (int i = 0; i < 100; i++) {
            c.post(Level.INFO, "h" + i, "", 10_000L * (i + 1));
        }
        assertEquals(NotificationCenter.MAX_HISTORY, c.history().size());
    }

    @Test
    public void notificationTextIsCleanedAndBounded() {
        NotificationCenter c = new NotificationCenter();
        c.post(Level.INFO, "a\nb\u0000c", "m".repeat(500), 0);
        NotificationCenter.Notification n = c.visible(1).get(0);
        assertEquals("a b c", n.title());
        assertEquals(200, n.message().length());
        assertTrue(n.message().endsWith("…"));
    }

    // ---- server history ------------------------------------------------------------------------

    @Test
    public void serverHistoryRecordsNothingUnlessEnabled() {
        AtomicBoolean on = new AtomicBoolean(false);
        ServerHistory h = new ServerHistory(on::get);
        h.joined("play.example.com", 0);
        h.left(60_000);
        assertTrue(h.list().isEmpty());

        on.set(true);
        h.joined("Play.Example.com:25565", 100_000);
        h.left(160_000);
        h.joined("play.example.com", 200_000);
        h.left(230_000);
        h.joined(null, 300_000);
        h.joined("   ", 300_000);
        assertEquals(1, h.list().size());
        ServerHistory.Visit v = h.list().get(0);
        assertEquals("play.example.com", v.host());
        assertEquals(2, v.visits());
        assertEquals(90, v.totalSeconds());
        assertEquals(230_000, v.lastPlayedMillis());
    }

    @Test
    public void joiningAnotherServerClosesThePreviousSession() {
        ServerHistory h = new ServerHistory(() -> true);
        h.joined("a.example.com", 0);
        h.joined("b.example.com", 30_000);
        h.left(45_000);
        assertEquals(30, h.list().stream().filter(v -> v.host().equals("a.example.com")).findFirst().orElseThrow().totalSeconds());
        assertEquals(15, h.list().stream().filter(v -> v.host().equals("b.example.com")).findFirst().orElseThrow().totalSeconds());
        assertEquals("most recent first", "b.example.com", h.list().get(0).host());
    }

    @Test
    public void serverHistoryIsBoundedAndPersists() {
        ServerHistory h = new ServerHistory(() -> true);
        for (int i = 0; i < ServerHistory.MAX_SERVERS + 20; i++) {
            h.joined("s" + i + ".example.com", 1000L * i);
            h.left(1000L * i + 1000);
        }
        assertEquals(ServerHistory.MAX_SERVERS, h.list().size());
        assertTrue(h.list().stream().noneMatch(v -> v.host().equals("s0.example.com")));

        ServerHistory copy = new ServerHistory(() -> true);
        assertTrue(copy.loadJson(h.toJson()).isClean());
        assertEquals(h.list(), copy.list());
        h.clear();
        assertTrue(h.list().isEmpty());

        JsonObject bad = JsonParser.parseString("{\"servers\": [ {\"host\": \"\"}, 5, {\"host\": \"a.com\", \"visits\": -3, \"seconds\": \"x\"} ]}").getAsJsonObject();
        ServerHistory g = new ServerHistory(() -> true);
        assertEquals(2, g.loadJson(bad).warnings().size());
        assertEquals(0, g.list().get(0).visits());
    }
}
