package dev.lumina.setting;

import com.google.gson.JsonNull;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class SettingTest {

    enum Mode { FAST, FANCY, OFF }

    @Test
    public void rejectsBadIds() {
        assertThrows(IllegalArgumentException.class, () -> new BooleanSetting("Bad", "n", "d", false));
        assertThrows(IllegalArgumentException.class, () -> new BooleanSetting("1abc", "n", "d", false));
        assertThrows(IllegalArgumentException.class, () -> new BooleanSetting("", "n", "d", false));
    }

    @Test
    public void numberClampsAndSnaps() {
        NumberSetting s = NumberSetting.ofDouble("scale", "Scale", "d", 1.0, 0.5, 3.0, 0.25);
        assertTrue(s.set(10.0));
        assertEquals(3.0, s.getDouble(), 0);
        s.set(0.0);
        assertEquals(0.5, s.getDouble(), 0);
        s.set(1.13);
        assertEquals(1.25, s.getDouble(), 1e-9);
        s.set(1.1);
        assertEquals(1.0, s.getDouble(), 1e-9);
    }

    @Test
    public void numberRejectsNonFinite() {
        NumberSetting s = NumberSetting.ofInt("n", "N", "d", 5, 0, 10);
        assertFalse(s.set(Double.NaN));
        assertFalse(s.set(Double.POSITIVE_INFINITY));
        assertEquals(5, s.getInt());
    }

    @Test
    public void integerSettingRoundsAndDefaultIsNormalised() {
        NumberSetting s = new NumberSetting("n", "N", "d", 99.0, 0, 10, 1, true, "");
        assertEquals("default is clamped at construction", 10, s.getInt());
        s.set(3.6);
        assertEquals(4, s.getInt());
        assertEquals(new JsonPrimitive(4L), s.toJson());
    }

    @Test
    public void numberRejectsInvertedRange() {
        assertThrows(IllegalArgumentException.class, () -> NumberSetting.ofInt("n", "N", "d", 1, 10, 0));
    }

    @Test
    public void numberLoadReportsStatus() {
        NumberSetting s = NumberSetting.ofInt("n", "N", "d", 5, 0, 10);
        assertEquals(LoadStatus.OK, s.loadJson(new JsonPrimitive(7)));
        assertEquals(7, s.getInt());
        assertEquals(LoadStatus.ADJUSTED, s.loadJson(new JsonPrimitive(70)));
        assertEquals(10, s.getInt());
        assertEquals(LoadStatus.INVALID, s.loadJson(new JsonPrimitive("12")));
        assertEquals(LoadStatus.INVALID, s.loadJson(JsonNull.INSTANCE));
        assertEquals(LoadStatus.INVALID, s.loadJson(null));
        assertEquals("invalid input leaves the value alone", 10, s.getInt());
    }

    @Test
    public void numberDisplayIncludesUnitAndTrimsZeros() {
        NumberSetting s = new NumberSetting("d", "D", "d", 1.5, 0, 5, 0.1, false, "px");
        assertEquals("1.5 px", s.display());
        s.set(2.0);
        assertEquals("2 px", s.display());
    }

    @Test
    public void booleanLoadAndToggle() {
        BooleanSetting s = new BooleanSetting("b", "B", "d", false);
        assertEquals(LoadStatus.OK, s.loadJson(new JsonPrimitive(true)));
        assertTrue(s.isOn());
        assertEquals(LoadStatus.INVALID, s.loadJson(new JsonPrimitive("true")));
        assertEquals(LoadStatus.INVALID, s.loadJson(new JsonPrimitive(1)));
        s.toggle();
        assertFalse(s.isOn());
    }

    @Test
    public void enumLoadIsCaseTolerantAndRejectsUnknown() {
        EnumSetting<Mode> s = new EnumSetting<>("m", "M", "d", Mode.FAST);
        assertEquals(LoadStatus.OK, s.loadJson(new JsonPrimitive("OFF")));
        assertEquals(Mode.OFF, s.get());
        assertEquals(LoadStatus.ADJUSTED, s.loadJson(new JsonPrimitive("fancy")));
        assertEquals(Mode.FANCY, s.get());
        assertEquals(LoadStatus.INVALID, s.loadJson(new JsonPrimitive("TURBO")));
        assertEquals(Mode.FANCY, s.get());
        assertEquals(LoadStatus.INVALID, s.loadJson(new JsonPrimitive(3)));
        s.cycle();
        assertEquals(Mode.OFF, s.get());
        s.cycle();
        assertEquals(Mode.FAST, s.get());
        assertEquals(new JsonPrimitive("FAST"), s.toJson());
    }

    @Test
    public void colorParsesBothFormatsAndRejectsGarbage() {
        assertEquals(Integer.valueOf(0xFF112233), ColorSetting.parse("#112233"));
        assertEquals(Integer.valueOf(0x80112233), ColorSetting.parse("#80112233"));
        assertEquals(Integer.valueOf(0xFFABCDEF), ColorSetting.parse("abcdef"));
        assertNull(ColorSetting.parse("#12345"));
        assertNull(ColorSetting.parse("#GGGGGG"));
        assertNull(ColorSetting.parse(""));
        assertNull(ColorSetting.parse(null));
        assertNull(ColorSetting.parse("#1122334455"));
        assertEquals("#80112233", ColorSetting.format(0x80112233));
    }

    @Test
    public void colorSettingRoundTrip() {
        ColorSetting s = new ColorSetting("c", "C", "d", 0xFF00FF88);
        assertEquals("#FF00FF88", s.toJson().getAsString());
        assertEquals(LoadStatus.OK, s.loadJson(new JsonPrimitive("#80102030")));
        assertEquals(0x80102030, s.argb());
        assertEquals(LoadStatus.ADJUSTED, s.loadJson(new JsonPrimitive("#304050")));
        assertEquals(0xFF304050, s.argb());
        assertEquals(LoadStatus.INVALID, s.loadJson(new JsonPrimitive("red")));
        assertEquals(0xFF304050, s.argb());
        assertEquals(LoadStatus.INVALID, s.loadJson(JsonParser.parseString("12")));
    }

    @Test
    public void listenersFireOnlyOnRealChangesAndSurviveExceptions() {
        BooleanSetting s = new BooleanSetting("b", "B", "d", false);
        List<Boolean> seen = new ArrayList<>();
        s.onChange(v -> {
            throw new IllegalStateException("listener bug");
        });
        s.onChange(seen::add);
        assertTrue(s.set(true));
        assertFalse("same value is not a change", s.set(true));
        assertEquals(List.of(true), seen);
    }

    @Test
    public void resetRestoresDefaultAndIsDefaultTracksIt() {
        NumberSetting s = NumberSetting.ofInt("n", "N", "d", 5, 0, 10);
        assertTrue(s.isDefault());
        s.set(1.0);
        assertFalse(s.isDefault());
        s.reset();
        assertTrue(s.isDefault());
    }

    @Test
    public void visibilityConditionIsEvaluatedLive() {
        BooleanSetting master = new BooleanSetting("m", "M", "d", false);
        BooleanSetting child = new BooleanSetting("c", "C", "d", false);
        child.visibleWhen(master::isOn);
        assertFalse(child.isVisible());
        master.set(true);
        assertTrue(child.isVisible());
    }
}
