package dev.lumina.profile;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.config.ClientPaths;
import dev.lumina.config.GlobalConfigStore;
import dev.lumina.event.ClientEvents;
import dev.lumina.event.EventBus;
import dev.lumina.module.Category;
import dev.lumina.module.ClientModule;
import dev.lumina.module.ModuleManager;
import dev.lumina.setting.NumberSetting;
import dev.lumina.utils.Json;
import dev.lumina.utils.LoadReport;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class ProfileManagerTest {
    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    static final class LevelModule extends ClientModule {
        final NumberSetting level = add(NumberSetting.ofInt("level", "Level", "A level", 5, 0, 10));

        LevelModule(String id) {
            super(id, "Module " + id, "desc", Category.UTILITY);
        }
    }

    private final AtomicLong clock = new AtomicLong(1_700_000_000_000L);
    private final List<String> errors = new ArrayList<>();
    private final List<ClientEvents.ProfileSwitched> switches = new ArrayList<>();
    private Path gameDir;
    private ClientPaths paths;
    private GlobalConfigStore global;
    private ModuleManager modules;
    private LevelModule alpha;
    private LevelModule beta;
    private ThemeSettings theme;
    private UiPreferences ui;
    private ProfileManager profiles;

    @Before
    public void setUp() throws IOException {
        gameDir = tmp.newFolder("game").toPath();
        build();
    }

    private void build() {
        paths = ClientPaths.of(gameDir, "lumina");
        EventBus bus = new EventBus((s, e) -> errors.add(s));
        bus.subscribe(ClientEvents.ProfileSwitched.class, switches::add);
        global = new GlobalConfigStore(paths, clock::get, (s, e) -> errors.add(s));
        modules = new ModuleManager(bus, (s, e) -> errors.add(s), k -> false);
        alpha = new LevelModule("alpha");
        beta = new LevelModule("beta");
        modules.register(alpha);
        modules.register(beta);
        theme = new ThemeSettings();
        ui = new UiPreferences();
        profiles = new ProfileManager(paths, global, List.of(new ModulesSection(modules), theme, ui),
                bus, (s, e) -> errors.add(s), clock::get);
        global.load();
    }

    private void advance() {
        clock.addAndGet(11 * 60_000L);
    }

    private static void assertRefused(ThrowingCall call) {
        assertThrows(ProfileException.class, call::run);
    }

    private interface ThrowingCall {
        void run() throws Exception;
    }

    @Test
    public void firstRunCreatesADefaultProfile() throws Exception {
        LoadReport r = profiles.loadActive();
        assertTrue(r.toString(), r.isClean());
        assertEquals("default", profiles.activeId());
        assertEquals(1, profiles.list().size());
        assertEquals("Default", profiles.list().get(0).name());
        assertTrue(Files.exists(paths.profiles().resolve("default.json")));
        assertTrue(Files.exists(paths.globalConfig()));
    }

    @Test
    public void allClientFilesStayInsideTheClientFolder() throws Exception {
        Path other = gameDir.resolve("othermod.json");
        Files.writeString(other, "{\"keep\": true}");
        profiles.loadActive();
        profiles.create("Second", true);
        profiles.switchTo("second");
        profiles.export("second");
        profiles.duplicate("second", "Third");
        profiles.delete("default");
        try (Stream<Path> s = Files.list(gameDir)) {
            List<String> names = s.map(p -> p.getFileName().toString()).sorted().collect(Collectors.toList());
            assertEquals(List.of("lumina", "othermod.json"), names);
        }
        assertEquals("{\"keep\": true}", Files.readString(other));
    }

    @Test
    public void createFromCurrentVersusFromDefaults() throws Exception {
        profiles.loadActive();
        alpha.level.set(9.0);
        theme.cornerRadius.set(2.0);

        profiles.create("Mine", true);
        profiles.create("Clean", false);

        profiles.switchTo("mine");
        assertEquals(9, alpha.level.getInt());
        assertEquals(2, theme.cornerRadius.getInt());
        profiles.switchTo("clean");
        assertEquals(5, alpha.level.getInt());
        assertEquals(4, theme.cornerRadius.getInt());
    }

    @Test
    public void switchingSavesTheOutgoingProfileAndLoadsTheIncomingOne() throws Exception {
        profiles.loadActive();
        profiles.create("Pvp", false);
        alpha.level.set(2.0);
        ui.compactLists.set(true);

        LoadReport r = profiles.switchTo("pvp");
        assertTrue(r.toString(), r.isClean());
        assertEquals("pvp", profiles.activeId());
        assertEquals("pvp", global.settings().activeProfile());
        assertEquals(5, alpha.level.getInt());
        assertFalse(ui.compactLists.isOn());
        assertEquals(1, switches.size());
        assertEquals("default", switches.get(0).previousId());

        alpha.level.set(8.0);
        profiles.switchTo("default");
        assertEquals("default profile kept the state it had when we left it", 2, alpha.level.getInt());
        assertTrue(ui.compactLists.isOn());
        profiles.switchTo("pvp");
        assertEquals(8, alpha.level.getInt());
    }

    @Test
    public void switchingToTheActiveProfileIsANoOp() throws Exception {
        profiles.loadActive();
        profiles.switchTo("default");
        assertTrue(switches.isEmpty());
    }

    @Test
    public void activeProfileSurvivesARestart() throws Exception {
        profiles.loadActive();
        profiles.create("Pvp", false);
        profiles.switchTo("pvp");
        alpha.level.set(7.0);
        profiles.saveActive();

        build();
        LoadReport r = profiles.loadActive();
        assertTrue(r.toString(), r.isClean());
        assertEquals("pvp", profiles.activeId());
        assertEquals(7, alpha.level.getInt());
    }

    @Test
    public void nameValidationAndDuplicates() throws Exception {
        profiles.loadActive();
        assertRefused(() -> profiles.create("", true));
        assertRefused(() -> profiles.create("../evil", true));
        assertRefused(() -> profiles.create("con", true));
        assertRefused(() -> profiles.create("a".repeat(40), true));
        profiles.create("Pvp", true);
        assertRefused(() -> profiles.create("Pvp", true));
        assertRefused(() -> profiles.create("PVP", true));
        assertRefused(() -> profiles.create("pvp", true));
    }

    @Test
    public void renameMovesTheFileAndUpdatesActiveAndBindings() throws Exception {
        profiles.loadActive();
        profiles.create("Old", false);
        profiles.switchTo("old");
        global.settings().bindServer("play.example.com", "old");

        String newId = profiles.rename("old", "New Name");
        assertEquals("new_name", newId);
        assertEquals("new_name", profiles.activeId());
        assertFalse(Files.exists(paths.profiles().resolve("old.json")));
        assertTrue(Files.exists(paths.profiles().resolve("new_name.json")));
        assertEquals("new_name", global.settings().profileForServer("play.example.com"));
        assertTrue(profiles.list().stream().anyMatch(p -> p.name().equals("New Name")));
    }

    @Test
    public void renameRefusesCollisionsAndUnknownProfiles() throws Exception {
        profiles.loadActive();
        profiles.create("A", true);
        profiles.create("B", true);
        assertRefused(() -> profiles.rename("a", "B"));
        assertRefused(() -> profiles.rename("ghost", "Whatever"));
        assertRefused(() -> profiles.rename("a", "bad/name"));
        assertEquals("a", profiles.rename("a", "A"));
    }

    @Test
    public void duplicatingTheActiveProfileCopiesTheLiveState() throws Exception {
        profiles.loadActive();
        alpha.level.set(1.0);
        profiles.duplicate("default", "Copy");
        profiles.switchTo("copy");
        assertEquals(1, alpha.level.getInt());
    }

    @Test
    public void duplicatingAnInactiveProfileCopiesItsSavedState() throws Exception {
        profiles.loadActive();
        alpha.level.set(3.0);
        profiles.create("Saved", true);
        alpha.level.set(9.0);
        profiles.duplicate("saved", "Saved Copy");
        profiles.switchTo("saved_copy");
        assertEquals(3, alpha.level.getInt());
    }

    @Test
    public void deleteRefusesActiveProfileAndKeepsARecoverableCopy() throws Exception {
        profiles.loadActive();
        profiles.create("Temp", false);
        global.settings().bindServer("srv.example", "temp");
        assertRefused(() -> profiles.delete("default"));
        profiles.delete("temp");
        assertFalse(profiles.exists("temp"));
        assertNull(global.settings().profileForServer("srv.example"));
        try (Stream<Path> s = Files.list(paths.backups())) {
            assertTrue(s.anyMatch(p -> p.getFileName().toString().startsWith("deleted-temp-")));
        }
        assertRefused(() -> profiles.delete("ghost"));
    }

    @Test
    public void exportThenImportRoundTrips() throws Exception {
        profiles.loadActive();
        alpha.level.set(4.0);
        alpha.setFavorite(true);
        theme.accent.set(0xFF112233);
        profiles.saveActive();

        Path exported = profiles.export("default");
        JsonObject json = JsonParser.parseString(Files.readString(exported)).getAsJsonObject();
        assertEquals(ProfileManager.FORMAT, json.get("format").getAsString());

        Files.copy(exported, paths.imports().resolve("shared.json"));
        String id = profiles.importFile("shared.json");
        assertEquals("Default 2", profiles.list().stream().filter(p -> p.id().equals(id)).findFirst().orElseThrow().name());
        profiles.switchTo(id);
        assertEquals(4, alpha.level.getInt());
        assertTrue(alpha.isFavorite());
        assertEquals(0xFF112233, theme.accent.argb());
    }

    @Test
    public void importRejectsHostileOrInvalidInput() throws Exception {
        profiles.loadActive();
        assertRefused(() -> profiles.importProfile("not json", "x"));
        assertRefused(() -> profiles.importProfile("[1,2,3]", "x"));
        assertRefused(() -> profiles.importProfile("", "x"));
        assertRefused(() -> profiles.importProfile(null, "x"));
        assertRefused(() -> profiles.importProfile("{\"format\":\"other\"}", "x"));
        assertRefused(() -> profiles.importProfile("{\"format\":\"lumina-profile\",\"schemaVersion\":99}", "x"));
        assertRefused(() -> profiles.importProfile("{\"format\":\"lumina-profile\",\"schemaVersion\":0}", "x"));
        String deep = "{\"format\":\"lumina-profile\",\"sections\":" + "[".repeat(5000) + "]".repeat(5000) + "}";
        assertRefused(() -> profiles.importProfile(deep, "x"));
        String huge = "{\"format\":\"lumina-profile\",\"pad\":\"" + "a".repeat((int) Json.MAX_IMPORT_BYTES) + "\"}";
        assertRefused(() -> profiles.importProfile(huge, "x"));
        assertEquals("nothing was stored by the failed imports", 1, profiles.list().size());
    }

    @Test
    public void importKeepsOnlyKnownSectionsAndSanitisesTheName() throws Exception {
        profiles.loadActive();
        String id = profiles.importProfile("""
                {"format":"lumina-profile","schemaVersion":1,"name":"../../Evil <b>Name</b>",
                 "sections":{"modules":{"alpha":{"enabled":false,"settings":{"level":2}}},
                             "script":{"run":"rm -rf /"},
                             "theme":{"corner_radius":9}}}""", "fallback");
        String stored = Files.readString(paths.profiles().resolve(id + ".json"));
        assertFalse(stored, stored.contains("script"));
        assertFalse(stored, stored.contains("rm -rf"));
        assertTrue(NameRulesCheck.valid(id));
        profiles.switchTo(id);
        assertEquals(2, alpha.level.getInt());
        assertEquals(9, theme.cornerRadius.getInt());
    }

    @Test
    public void importFileOnlyReadsPlainFilesFromTheImportsFolder() throws Exception {
        profiles.loadActive();
        Path outside = gameDir.resolve("secret.json");
        Files.writeString(outside, "{\"format\":\"lumina-profile\"}");
        assertRefused(() -> profiles.importFile("../secret.json"));
        assertRefused(() -> profiles.importFile("..\\secret.json"));
        assertRefused(() -> profiles.importFile("sub/dir.json"));
        assertRefused(() -> profiles.importFile(outside.toAbsolutePath().toString()));
        assertRefused(() -> profiles.importFile("notes.txt"));
        assertRefused(() -> profiles.importFile("missing.json"));
        assertRefused(() -> profiles.importFile(""));
        assertRefused(() -> profiles.importFile(null));

        Path link = paths.imports().resolve("link.json");
        try {
            Files.createSymbolicLink(link, outside);
            assertRefused(() -> profiles.importFile("link.json"));
        } catch (UnsupportedOperationException | IOException skip) {
            // platform without symlink support: nothing to verify
        }
    }

    @Test
    public void autoSwitchResolvesOnlyWhenEnabledAndProfileExists() throws Exception {
        profiles.loadActive();
        profiles.create("Pvp", false);
        global.settings().bindServer("play.example.com", "pvp");
        assertNull("automatic switching is off by default", profiles.resolveForServer("play.example.com"));
        global.settings().setAutoSwitchProfiles(true);
        assertEquals("pvp", profiles.resolveForServer("play.example.com:25565"));
        assertNull(profiles.resolveForServer("other.example"));
        assertNull(profiles.resolveForServer(null));
        global.settings().bindServer("gone.example", "deleted_profile");
        assertNull(profiles.resolveForServer("gone.example"));
    }

    @Test
    public void corruptedActiveProfileIsRecoveredFromBackup() throws Exception {
        profiles.loadActive();
        alpha.level.set(6.0);
        advance();
        profiles.saveActive();
        alpha.level.set(7.0);
        advance();
        profiles.saveActive(); // backup now holds level=6
        Files.writeString(paths.profiles().resolve("default.json"), "{\"sections\": {\"modules\"");

        build();
        LoadReport r = profiles.loadActive();
        assertFalse("recovery is reported to the user", r.isClean());
        assertTrue(r.toString(), r.warnings().get(0).contains("Restored from"));
        assertEquals(6, alpha.level.getInt());
    }

    @Test
    public void corruptedProfileWithoutBackupFallsBackToDefaultsWithoutCrashing() throws Exception {
        profiles.loadActive();
        Files.writeString(paths.profiles().resolve("default.json"), "garbage");
        build();
        alpha.level.set(1.0);
        LoadReport r = profiles.loadActive();
        assertFalse(r.isClean());
        assertEquals(5, alpha.level.getInt());
    }

    @Test
    public void missingActiveProfileFallsBackToAnExistingOne() throws Exception {
        profiles.loadActive();
        profiles.create("Other", false);
        global.settings().setActiveProfile("vanished");
        LoadReport r = profiles.loadActive();
        assertFalse(r.isClean());
        assertTrue(profiles.exists(profiles.activeId()));
    }

    @Test
    public void resetActiveToDefaultsRestoresEverySection() throws Exception {
        profiles.loadActive();
        alpha.level.set(1.0);
        alpha.setFavorite(true);
        theme.uiScale.set(1.5);
        ui.showTooltips.set(false);
        profiles.resetActiveToDefaults();
        assertEquals(5, alpha.level.getInt());
        assertFalse(alpha.isFavorite());
        assertEquals(1.0, theme.uiScale.getDouble(), 0);
        assertTrue(ui.showTooltips.isOn());
        profiles.switchTo(profiles.activeId());
        build();
        profiles.loadActive();
        assertEquals("the reset was saved", 5, alpha.level.getInt());
    }

    @Test
    public void aFailingSectionDoesNotPreventTheOthersFromLoading() throws Exception {
        EventBus bus = new EventBus((s, e) -> {
        });
        ProfileParticipant exploding = new ProfileParticipant() {
            @Override
            public String sectionKey() {
                return "boom";
            }

            @Override
            public JsonObject save() {
                return new JsonObject();
            }

            @Override
            public LoadReport load(JsonObject section) {
                throw new IllegalStateException("section bug");
            }
        };
        ProfileManager pm = new ProfileManager(paths, global, List.of(exploding, theme), bus,
                (s, e) -> errors.add(s), clock::get);
        pm.loadActive(); // creates the default profile (theme at defaults)
        errors.clear();
        theme.cornerRadius.set(9.0);
        LoadReport r = pm.loadActive(); // re-applies it from disk
        assertTrue(r.toString(), r.warnings().stream().anyMatch(w -> w.contains("boom")));
        assertTrue(errors.contains("profile:load:boom"));
        assertEquals("sections after the failing one still load", 4, theme.cornerRadius.getInt());
    }

    /** Local helper so the test reads naturally. */
    private static final class NameRulesCheck {
        static boolean valid(String id) {
            return dev.lumina.utils.NameRules.validate(id) == null && id.equals(dev.lumina.utils.NameRules.toId(id));
        }
    }
}
