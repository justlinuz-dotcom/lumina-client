package dev.lumina.compat;

import dev.lumina.compat.CompatChecker.Level;
import dev.lumina.compat.CompatChecker.Note;
import org.junit.Test;

import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class CompatCheckerTest {

    private static Note find(List<Note> notes, String topic) {
        return notes.stream().filter(n -> n.topic().equals(topic)).findFirst().orElseThrow();
    }

    @Test
    public void aCompleteSetupHasNoProblemsAndNoDownloadsAreSuggested() {
        List<Note> notes = CompatChecker.check(Set.of("fabric-api", "sodium", "lithium", "ferritecore"), 21, "1.21.11", "1.21.11");
        assertEquals(3, notes.size());
        assertTrue(notes.stream().allMatch(n -> n.level() == Level.OK));
        assertFalse(CompatChecker.hasBlockingProblem(notes));
    }

    @Test
    public void missingRecommendedModsAreOnlyInformational() {
        List<Note> notes = CompatChecker.check(Set.of("fabric-api"), 21, "1.21.11", "1.21.11");
        assertEquals(Level.INFO, find(notes, "Sodium").level());
        assertTrue(find(notes, "Sodium").message().contains("Optional"));
        assertFalse(CompatChecker.hasBlockingProblem(notes));
    }

    @Test
    public void missingFabricApiOrOldJavaBlock() {
        List<Note> notes = CompatChecker.check(Set.of("sodium"), 17, "1.21.11", "1.21.11");
        assertEquals(Level.ERROR, find(notes, "Java").level());
        assertEquals(Level.ERROR, find(notes, "Fabric API").level());
        assertTrue(CompatChecker.hasBlockingProblem(notes));
    }

    @Test
    public void otherMinecraftVersionsAreAWarningNotAnError() {
        List<Note> notes = CompatChecker.check(Set.of("fabric-api"), 21, "1.21.10", "1.21.11");
        assertEquals(Level.WARNING, find(notes, "Minecraft").level());
        assertTrue(find(notes, "Minecraft").message().contains("not been tested"));
        assertFalse(CompatChecker.hasBlockingProblem(notes));
        assertTrue(CompatChecker.check(Set.of("fabric-api"), 21, null, "1.21.11").stream().noneMatch(n -> n.topic().equals("Minecraft")));
    }
}
