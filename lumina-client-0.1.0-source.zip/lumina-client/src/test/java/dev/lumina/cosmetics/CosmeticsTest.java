package dev.lumina.cosmetics;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumina.config.ClientPaths;
import dev.lumina.utils.LoadReport;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class CosmeticsTest {
    private Path root;
    private ClientPaths paths;
    private CosmeticCatalog catalog;
    private CosmeticImporter importer;

    @Before
    public void setUp() throws IOException {
        root = Files.createTempDirectory("lumina-cosmetics");
        paths = ClientPaths.of(root, "lumina");
        paths.ensureCreated();
        catalog = new CosmeticCatalog();
        importer = new CosmeticImporter(paths, catalog);
    }

    private void drop(String name, byte[] bytes) throws IOException {
        Files.write(paths.imports().resolve(name), bytes);
    }

    // ---- png validation ------------------------------------------------------------------------

    @Test
    public void validPngsAreAccepted() {
        PngValidator.Result r = PngValidator.validate(PngTestData.png(64, 32));
        assertTrue(r.problem(), r.valid());
        assertEquals(64, r.width());
        assertEquals(32, r.height());
        assertTrue(PngValidator.validate(PngTestData.png(128, 64, 8, 2, 0, 64L * (1 + 128 * 3))).valid());
        assertTrue(PngValidator.validate(PngTestData.png(64, 64, 8, 3, 0, 64L * 65)).valid());
    }

    private static void rejected(byte[] data, String fragment) {
        PngValidator.Result r = PngValidator.validate(data);
        assertFalse("expected rejection containing '" + fragment + "'", r.valid());
        assertTrue(r.problem(), r.problem().toLowerCase().contains(fragment.toLowerCase()));
    }

    @Test
    public void brokenPngsAreRejectedWithAReason() {
        rejected(null, "too small");
        rejected(new byte[10], "too small");
        byte[] notPng = new byte[200];
        Arrays.fill(notPng, (byte) 7);
        rejected(notPng, "not a PNG");

        byte[] good = PngTestData.png(64, 32);
        rejected(Arrays.copyOf(good, good.length - 5), "truncated");
        byte[] flipped = good.clone();
        flipped[8 + 12 + 3] ^= 0x40;
        rejected(flipped, "checksum");
        byte[] trailing = Arrays.copyOf(good, good.length + 3);
        rejected(trailing, "extra data");

        rejected(PngTestData.png(2000, 32, 8, 6, 0, 10), "pixels on each side");
        rejected(PngTestData.png(64, 32, 16, 6, 0, 10), "8-bit");
        rejected(PngTestData.png(64, 32, 8, 0, 0, 10), "RGB");
        rejected(PngTestData.png(64, 32, 8, 6, 1, 10), "interlaced");
        rejected(PngTestData.withExtraChunkBeforeIdat(good, "acTL"), "animated");
        rejected(PngTestData.withExtraChunkBeforeIdat(good, "XYZW"), "critical");
        assertTrue("ancillary chunks are fine", PngValidator.validate(PngTestData.withExtraChunkBeforeIdat(good, "tEXt")).valid());
    }

    @Test
    public void pixelDataMustMatchTheHeaderExactly() {
        rejected(PngTestData.png(64, 32, 8, 6, 0, 100), "smaller");
        rejected(PngTestData.png(64, 32, 8, 6, 0, 64L * 32 * 4 + 50_000), "larger");
    }

    @Test
    public void decompressionBombsAreStoppedEarly() {
        // ~60 MB of zeros compresses to a few tens of KB but the header promises only 8 KB.
        byte[] bomb = PngTestData.png(64, 32, 8, 6, 0, 60_000_000L);
        assertTrue("test data must itself be small", bomb.length < PngValidator.MAX_FILE_BYTES);
        long start = System.nanoTime();
        rejected(bomb, "larger");
        assertTrue("rejected quickly without expanding it", (System.nanoTime() - start) / 1_000_000 < 1000);
    }

    @Test
    public void oversizedFilesAreRejected() {
        byte[] big = new byte[PngValidator.MAX_FILE_BYTES + 1];
        rejected(big, "larger");
    }

    @Test
    public void slotSizeRules() {
        assertTrue(Slot.CAPE.acceptsSize(64, 32));
        assertTrue(Slot.CAPE.acceptsSize(512, 256));
        assertFalse(Slot.CAPE.acceptsSize(64, 64));
        assertFalse(Slot.CAPE.acceptsSize(1024, 512));
        assertTrue(Slot.HAT.acceptsSize(256, 256));
        assertFalse(Slot.HAT.acceptsSize(512, 512));
        assertEquals("64x32, 128x64, 256x128, 512x256", Slot.CAPE.sizeHint());
    }

    // ---- importer ------------------------------------------------------------------------------

    @Test
    public void importCopiesAValidatedFileUnderADerivedName() throws IOException {
        drop("my cape.png", PngTestData.png(64, 32));
        CosmeticImporter.ImportResult r = importer.importPng("my cape.png", "Night Sky", Slot.CAPE, Rarity.RARE);
        assertTrue(r.message(), r.ok());
        assertEquals("night_sky", r.item().id());
        assertEquals("night_sky.png", r.item().file());
        assertTrue(Files.isRegularFile(paths.cosmetics().resolve("night_sky.png")));
        assertEquals("the original stays untouched", 1, Files.list(paths.imports()).count());
        assertTrue(catalog.get("night_sky").isPresent());
        assertEquals(1, catalog.importedCount());
        assertEquals(paths.cosmetics().resolve("night_sky.png"), importer.textureFile(r.item()));
        assertNull(importer.textureFile(catalog.get("slate").orElseThrow()));
    }

    @Test
    public void importRefusesUnsafeOrWrongInput() throws IOException {
        drop("a.png", PngTestData.png(64, 32));
        for (String bad : new String[]{"../a.png", "sub/a.png", "sub\\a.png", "/etc/passwd.png", "a.txt", "a.png.exe", "", ".png",
                "a..b.png", "a\u0000.png"}) {
            assertFalse(bad, importer.importPng(bad, "Name", Slot.CAPE, null).ok());
        }
        assertFalse(importer.importPng(null, "Name", Slot.CAPE, null).ok());
        assertFalse("bad display name", importer.importPng("a.png", "../evil", Slot.CAPE, null).ok());
        assertFalse(importer.importPng("a.png", "", Slot.CAPE, null).ok());
        assertFalse("slot is required", importer.importPng("a.png", "Fine", null, null).ok());
        assertFalse("wrong size for the slot", importer.importPng("a.png", "Fine", Slot.HAT, null).ok());
        assertFalse("missing file", importer.importPng("nothere.png", "Fine", Slot.CAPE, null).ok());
        assertEquals("nothing was stored by the failed attempts", 0, Files.list(paths.cosmetics()).count());
        assertEquals(0, catalog.importedCount());
    }

    @Test
    public void importRefusesCorruptAndLinkedFiles() throws IOException {
        byte[] good = PngTestData.png(64, 32);
        drop("broken.png", Arrays.copyOf(good, good.length - 3));
        CosmeticImporter.ImportResult broken = importer.importPng("broken.png", "Broken", Slot.CAPE, null);
        assertFalse(broken.ok());
        assertTrue(broken.message(), broken.message().toLowerCase().contains("truncated"));

        Path outside = root.resolve("outside.png");
        Files.write(outside, good);
        try {
            Files.createSymbolicLink(paths.imports().resolve("link.png"), outside);
        } catch (UnsupportedOperationException | IOException | SecurityException e) {
            Assume.assumeNoException("symbolic links are not available here", e);
        }
        CosmeticImporter.ImportResult link = importer.importPng("link.png", "Linked", Slot.CAPE, null);
        assertFalse(link.ok());
        assertTrue(link.message(), link.message().toLowerCase().contains("links"));
    }

    @Test
    public void importRefusesDuplicatesAndBuiltInNames() throws IOException {
        drop("a.png", PngTestData.png(64, 32));
        assertTrue(importer.importPng("a.png", "Mine", Slot.CAPE, null).ok());
        assertFalse(importer.importPng("a.png", "mine", Slot.CAPE, null).ok());
        assertFalse("clashes with the built-in id 'slate'", importer.importPng("a.png", "Slate", Slot.CAPE, null).ok());
    }

    @Test
    public void importCountIsLimitedAndRemoveFreesTheSlot() throws IOException {
        drop("a.png", PngTestData.png(64, 32));
        for (int i = 0; i < CosmeticCatalog.MAX_IMPORTED; i++) {
            assertTrue("import " + i, importer.importPng("a.png", "Item " + i, Slot.CAPE, null).ok());
        }
        assertFalse(importer.importPng("a.png", "One too many", Slot.CAPE, null).ok());
        assertFalse(Files.exists(paths.cosmetics().resolve("one_too_many.png")));
        assertTrue(importer.remove("item_0"));
        assertFalse(Files.exists(paths.cosmetics().resolve("item_0.png")));
        assertFalse(importer.remove("item_0"));
        assertFalse("built-in items cannot be removed", importer.remove("slate"));
        assertTrue(importer.importPng("a.png", "One too many", Slot.CAPE, null).ok());
    }

    @Test
    public void importedListSurvivesARestartAndRejectsUnsafeEntries() throws IOException {
        drop("a.png", PngTestData.png(64, 64));
        assertTrue(importer.importPng("a.png", "Cool Hat", Slot.HAT, Rarity.EPIC).ok());
        CosmeticCatalog reloaded = new CosmeticCatalog();
        assertTrue(reloaded.loadJson(catalog.toJson()).isClean());
        assertEquals(catalog.get("cool_hat"), reloaded.get("cool_hat"));

        JsonObject evil = JsonParser.parseString("""
                {"imported": [
                  {"id": "../../evil", "name": "Evil", "slot": "CAPE", "rarity": "RARE", "file": "../../evil.png"},
                  {"id": "ok_one", "name": "Ok One", "slot": "CAPE", "rarity": "RARE", "file": "other.png"},
                  {"id": "fine", "name": "Fine", "slot": "SWORD", "file": "fine.png"},
                  {"id": "good", "name": "Good", "slot": "BACK", "rarity": "nonsense", "file": "good.png"},
                  {"id": "slate", "name": "Slate", "slot": "CAPE", "file": "slate.png"},
                  5 ]}""").getAsJsonObject();
        CosmeticCatalog c = new CosmeticCatalog();
        LoadReport r = c.loadJson(evil);
        assertEquals(5, r.warnings().size());
        assertEquals(1, c.importedCount());
        assertEquals(Rarity.COMMON, c.get("good").orElseThrow().rarity());
        assertTrue("built-in 'slate' was not replaced", !c.get("slate").orElseThrow().isImported());
    }

    // ---- loadout -------------------------------------------------------------------------------

    @Test
    public void equipValidatesTheItemAndTheSlot() {
        CosmeticLoadout l = new CosmeticLoadout(catalog);
        assertNull(l.equip(Slot.CAPE, "midnight"));
        assertEquals("midnight", l.worn(Slot.CAPE).orElseThrow().id());
        assertNotNull(l.equip(Slot.CAPE, "nope"));
        assertNotNull("a cape cannot be worn as a hat", l.equip(Slot.HAT, "midnight"));
        assertTrue(l.worn(Slot.HAT).isEmpty());
        l.unequip(Slot.CAPE);
        assertTrue(l.worn(Slot.CAPE).isEmpty());
    }

    @Test
    public void switchingCosmeticsOffHidesEverythingWithoutForgettingIt() {
        CosmeticLoadout l = new CosmeticLoadout(catalog);
        l.equip(Slot.CAPE, "ember");
        assertEquals(1, l.toRender().size());
        l.setVisible(false);
        assertTrue(l.toRender().isEmpty());
        l.setVisible(true);
        assertEquals("ember", l.toRender().get(Slot.CAPE).id());
    }

    @Test
    public void namedLoadoutsSaveApplyAndSkipMissingItems() throws IOException {
        drop("a.png", PngTestData.png(64, 32));
        importer.importPng("a.png", "Temp", Slot.CAPE, null);
        CosmeticLoadout l = new CosmeticLoadout(catalog);
        l.equip(Slot.CAPE, "temp");
        assertNull(l.savePreset("Mine"));
        assertNotNull(l.savePreset("../bad"));
        l.unequip(Slot.CAPE);
        l.equip(Slot.CAPE, "forest");
        assertNull(l.applyPreset("Mine"));
        assertEquals("temp", l.worn(Slot.CAPE).orElseThrow().id());

        importer.remove("temp");
        String warning = l.applyPreset("Mine");
        assertNotNull(warning);
        assertTrue(l.worn(Slot.CAPE).isEmpty());
        assertNotNull(l.applyPreset("nope"));
        assertTrue(l.deletePreset("Mine"));
        assertFalse(l.deletePreset("Mine"));
    }

    @Test
    public void presetCountIsLimited() {
        CosmeticLoadout l = new CosmeticLoadout(catalog);
        for (int i = 0; i < CosmeticLoadout.MAX_PRESETS; i++) {
            assertNull(l.savePreset("p" + i));
        }
        assertNotNull(l.savePreset("extra"));
        assertNull("overwriting an existing name is fine", l.savePreset("p0"));
    }

    @Test
    public void loadoutIsAProfileSectionAndRepairsBadData() {
        CosmeticLoadout l = new CosmeticLoadout(catalog);
        l.equip(Slot.CAPE, "aurora");
        l.savePreset("Show off");
        l.setVisible(false);
        CosmeticLoadout copy = new CosmeticLoadout(catalog);
        assertTrue(copy.load(l.save()).isClean());
        assertEquals("aurora", copy.worn(Slot.CAPE).orElseThrow().id());
        assertFalse(copy.visible());
        assertTrue(copy.presets().containsKey("Show off"));
        assertEquals("cosmetics", copy.sectionKey());

        JsonObject bad = JsonParser.parseString("""
                {"visible": "yes", "worn": {"CAPE": "ghost", "HAT": "midnight", "WINGS": "x", "BACK": 4},
                 "presets": {"../x": {}, "ok": {"CAPE": "slate"}, "bad": 3}}""").getAsJsonObject();
        CosmeticLoadout g = new CosmeticLoadout(catalog);
        LoadReport r = g.load(bad);
        assertTrue(g.visible());
        assertTrue(g.worn(Slot.CAPE).isEmpty());
        assertEquals(6, r.warnings().size());
        assertEquals("slate", g.presets().get("ok").get(Slot.CAPE));
        assertTrue(g.load(new JsonObject()).isClean());
        assertTrue(g.presets().isEmpty());
        assertTrue(CosmeticLoadout.NOTICE.contains("only visible to you"));
    }

    // ---- cache ---------------------------------------------------------------------------------

    @Test
    public void cacheEvictsTheLeastRecentlyUsedAndReleasesIt() {
        List<String> released = new ArrayList<>();
        ResourceCache<String, String> cache = new ResourceCache<>(2, released::add);
        assertEquals("A", cache.get("a", String::toUpperCase));
        cache.get("b", String::toUpperCase);
        cache.get("a", k -> "never");
        cache.get("c", String::toUpperCase);
        assertEquals(List.of("B"), released);
        assertEquals(2, cache.size());
        assertEquals("A", cache.get("a", k -> "reloaded"));
        cache.invalidate("a");
        assertEquals(List.of("B", "A"), released);
        cache.clear();
        assertEquals(0, cache.size());
        assertEquals(List.of("B", "A", "C"), released);
    }

    @Test
    public void cacheToleratesNullLoadsAndFailingReleases() {
        ResourceCache<String, String> cache = new ResourceCache<>(1, v -> {
            throw new IllegalStateException("boom");
        });
        assertNull(cache.get("x", k -> null));
        assertEquals(0, cache.size());
        cache.get("a", k -> "A");
        cache.get("b", k -> "B");
        assertEquals(1, cache.size());
        cache.clear();
        assertEquals(0, cache.size());
        assertTrue(Map.of().isEmpty());
    }
}
