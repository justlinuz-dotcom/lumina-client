package dev.lumina.cosmetics;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.CRC32;
import java.util.zip.Deflater;

/** Builds small PNG files (and broken variants) for tests. */
public final class PngTestData {
    private PngTestData() {
    }

    public static byte[] png(int w, int h) {
        return png(w, h, 8, 6, 0, (long) h * (1 + (long) w * 4));
    }

    public static byte[] png(int w, int h, int bitDepth, int colorType, int interlace, long rawBytes) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.writeBytes(new byte[]{(byte) 0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'});
        byte[] ihdr = new byte[13];
        put(ihdr, 0, w);
        put(ihdr, 4, h);
        ihdr[8] = (byte) bitDepth;
        ihdr[9] = (byte) colorType;
        ihdr[12] = (byte) interlace;
        chunk(out, "IHDR", ihdr);
        chunk(out, "IDAT", deflateZeros(rawBytes));
        chunk(out, "IEND", new byte[0]);
        return out.toByteArray();
    }

    static byte[] withExtraChunkBeforeIdat(byte[] png, String type) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int ihdrEnd = 8 + 12 + 13;
        out.write(png, 0, ihdrEnd);
        chunk(out, type, new byte[8]);
        out.write(png, ihdrEnd, png.length - ihdrEnd);
        return out.toByteArray();
    }

    static byte[] deflateZeros(long count) {
        Deflater d = new Deflater(9);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] zeros = new byte[8192];
        byte[] buf = new byte[8192];
        long left = count;
        while (left > 0) {
            int n = (int) Math.min(zeros.length, left);
            d.setInput(zeros, 0, n);
            while (!d.needsInput()) {
                out.write(buf, 0, d.deflate(buf));
            }
            left -= n;
        }
        d.finish();
        while (!d.finished()) {
            out.write(buf, 0, d.deflate(buf));
        }
        d.end();
        return out.toByteArray();
    }

    static void chunk(ByteArrayOutputStream out, String type, byte[] data) {
        byte[] t = type.getBytes(StandardCharsets.ISO_8859_1);
        byte[] len = new byte[4];
        put(len, 0, data.length);
        out.writeBytes(len);
        out.writeBytes(t);
        out.writeBytes(data);
        CRC32 crc = new CRC32();
        crc.update(t);
        crc.update(data);
        byte[] c = new byte[4];
        put(c, 0, (int) crc.getValue());
        out.writeBytes(c);
    }

    static void put(byte[] b, int off, int v) {
        b[off] = (byte) (v >>> 24);
        b[off + 1] = (byte) (v >>> 16);
        b[off + 2] = (byte) (v >>> 8);
        b[off + 3] = (byte) v;
    }
}
