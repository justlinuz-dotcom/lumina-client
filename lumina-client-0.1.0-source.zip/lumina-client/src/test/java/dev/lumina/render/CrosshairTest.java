package dev.lumina.render;

import com.google.gson.JsonPrimitive;
import dev.lumina.event.EventBus;
import dev.lumina.hud.FakeGameState;
import dev.lumina.module.ModuleManager;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class CrosshairTest {
    private CustomCrosshairModule module;
    private ModuleManager manager;
    private FakeGameState game;

    @Before
    public void setUp() {
        module = new CustomCrosshairModule();
        manager = new ModuleManager(new EventBus((s, e) -> {
        }), (s, e) -> {
        }, k -> false);
        manager.register(module);
        manager.setEnabled(module, true);
        game = new FakeGameState();
    }

    private void set(String id, Object value) {
        module.setting(id).orElseThrow().loadJson(value instanceof Boolean b ? new JsonPrimitive(b)
                : value instanceof Number n ? new JsonPrimitive(n) : new JsonPrimitive(String.valueOf(value)));
    }

    @Test
    public void defaultShapeIsASymmetricCrossWithOutline() {
        List<Rect> rects = module.rects(game, 100, 50, 0.016f);
        assertEquals(8, rects.size());
        List<Rect> fills = rects.subList(4, 8);
        assertEquals(new Rect(93, 50, 5, 1, 0xFFFFFFFF), fills.get(0));
        assertEquals(new Rect(103, 50, 5, 1, 0xFFFFFFFF), fills.get(1));
        assertEquals(new Rect(100, 53, 1, 5, 0xFFFFFFFF), fills.get(2));
        assertEquals(new Rect(100, 43, 1, 5, 0xFFFFFFFF), fills.get(3));
        assertEquals("outlines come first so fills are drawn on top", 0xFF000000, rects.get(0).argb());
    }

    @Test
    public void settingsChangeTheGeometry() {
        set("outline", false);
        set("dot", true);
        set("thickness", 2);
        set("color", "#FF00FF00");
        List<Rect> rects = module.rects(game, 100, 50, 0.016f);
        assertEquals(5, rects.size());
        assertTrue(rects.stream().allMatch(r -> r.argb() == 0xFF00FF00));
        set("style", "DOT");
        assertEquals(1, module.rects(game, 100, 50, 0.016f).size());
    }

    @Test
    public void nothingIsDrawnOutsideAWorld() {
        game.inWorld = false;
        assertTrue(module.rects(game, 100, 50, 0.016f).isEmpty());
        assertEquals("the editor preview still works", 8, module.previewRects(100, 50).size());
    }

    @Test
    public void vanillaIsOnlyHiddenWhileEnabledAndRequested() {
        assertTrue(module.replacesVanilla());
        set("hide_vanilla", false);
        assertFalse(module.replacesVanilla());
        set("hide_vanilla", true);
        manager.setEnabled(module, false);
        assertFalse(module.replacesVanilla());
    }

    private int leftArmDistance(List<Rect> rects) {
        Rect left = rects.get(4);
        Rect centreCell = new Rect(100, 50, 1, 1, 0);
        return centreCell.x() - left.right();
    }

    @Test
    public void dynamicGapOpensWhenMovingAndSettlesSmoothly() {
        set("dynamic", true);
        game.cooldown = 1f;
        int resting = leftArmDistance(module.rects(game, 100, 50, 0.016f));
        assertEquals(2, resting);

        game.speed = 5.6;
        game.sprinting = true;
        int first = leftArmDistance(module.rects(game, 100, 50, 0.016f));
        assertTrue("moves towards the target, not instantly", first >= resting);
        int last = first;
        for (int i = 0; i < 200; i++) {
            last = leftArmDistance(module.rects(game, 100, 50, 0.016f));
        }
        assertTrue("sprinting opens the gap", last > resting);

        game.speed = 0;
        game.sprinting = false;
        for (int i = 0; i < 400; i++) {
            last = leftArmDistance(module.rects(game, 100, 50, 0.016f));
        }
        assertEquals("returns to the resting gap", resting, last);
    }

    @Test
    public void dynamicGapTightensWhileSneakingButNeverBelowTheBaseGap() {
        set("dynamic", true);
        game.sneaking = true;
        for (int i = 0; i < 200; i++) {
            module.rects(game, 100, 50, 0.016f);
        }
        assertEquals(2, leftArmDistance(module.rects(game, 100, 50, 0.016f)));
    }

    @Test
    public void previewIgnoresDynamics() {
        set("dynamic", true);
        game.speed = 6;
        game.sprinting = true;
        for (int i = 0; i < 200; i++) {
            module.rects(game, 100, 50, 0.016f);
        }
        assertEquals(2, leftArmDistance(module.previewRects(100, 50)));
    }

    @Test
    public void spreadSettingIsOnlyVisibleForTheDynamicMode() {
        assertFalse(module.setting("expansion").orElseThrow().isVisible());
        set("dynamic", true);
        assertTrue(module.setting("expansion").orElseThrow().isVisible());
    }
}
