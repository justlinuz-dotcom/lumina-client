package dev.lumina.render;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RoundedRectTest {

    @Test
    public void radiusZeroIsOneFullRectangle() {
        List<Rect> bands = RoundedRect.bands(10, 20, 100, 50, 0, 0xFF112233);
        assertEquals(1, bands.size());
        assertEquals(new Rect(10, 20, 100, 50, 0xFF112233), bands.get(0));
    }

    @Test
    public void bandsCoverTheRectangleWithoutOverlapAndWithoutGaps() {
        for (int radius = 0; radius <= 10; radius++) {
            List<Rect> bands = RoundedRect.bands(5, 7, 60, 40, radius, 0xFFFFFFFF);
            int nextY = 7;
            for (Rect b : bands) {
                assertEquals("radius " + radius + ": bands stack top to bottom", nextY, b.y());
                assertTrue(b.w() > 0 && b.h() > 0);
                assertTrue(b.x() >= 5 && b.right() <= 65);
                nextY = b.bottom();
            }
            assertEquals("radius " + radius, 7 + 40, nextY);
        }
    }

    @Test
    public void cornersAreCutAndTheMiddleKeepsTheFullWidth() {
        List<Rect> bands = RoundedRect.bands(0, 0, 40, 30, 6, 0xFF000000);
        Rect top = bands.get(0);
        Rect bottom = bands.get(bands.size() - 1);
        assertTrue("the first row is narrower than the rectangle", top.w() < 40 && top.x() > 0);
        assertEquals("top and bottom rows are mirror images", top.x(), bottom.x());
        assertEquals(top.w(), bottom.w());
        Rect middle = bands.get(6);
        assertEquals(new Rect(0, 6, 40, 18, 0xFF000000), middle);
        for (int i = 1; i < 6; i++) {
            assertTrue("rows widen towards the middle", bands.get(i).x() <= bands.get(i - 1).x());
        }
    }

    @Test
    public void tooLargeRadiusIsReducedAndTinyOrEmptyRectanglesAreSafe() {
        assertEquals(5, RoundedRect.effectiveRadius(100, 10, 50));
        assertEquals(0, RoundedRect.effectiveRadius(100, 10, -3));
        List<Rect> small = RoundedRect.bands(0, 0, 4, 4, 10, 0xFF000000);
        assertEquals(4, small.stream().mapToInt(Rect::h).sum());
        assertTrue(RoundedRect.bands(0, 0, 0, 10, 4, 0).isEmpty());
        assertTrue(RoundedRect.bands(0, 0, 10, -1, 4, 0).isEmpty());
    }
}
