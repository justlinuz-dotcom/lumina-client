package dev.lumina.diagnostics;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ErrorHistoryTest {
    private final AtomicLong clock = new AtomicLong(1000);
    private final AtomicBoolean enabled = new AtomicBoolean(true);
    private final ErrorHistory history = new ErrorHistory(enabled::get, clock::get, "C:\\Users\\maria\\AppData", "maria");

    @Test
    public void personalPathsAndNamesNeverReachTheReport() {
        history.report("module:fps", new IllegalStateException("cannot read C:\\Users\\maria\\AppData\\x.json for maria"));
        history.report("module:fps2", new RuntimeException("/home/joao/.minecraft/options.txt and /Users/ana/Library"));
        String text = history.toText();
        assertFalse(text, text.contains("maria"));
        assertFalse(text, text.contains("joao"));
        assertFalse(text, text.contains("ana/"));
        assertTrue(text, text.contains("~"));
        assertTrue(text, text.contains("<user>"));
    }

    @Test
    public void messagesAreBoundedAndHaveNoControlCharacters() {
        history.report("x", new RuntimeException("a\nb\u0000c" + "z".repeat(1000)));
        ErrorHistory.Entry e = history.entries().get(0);
        assertTrue(e.message().length() <= 300);
        assertTrue(e.message().startsWith("a b c"));
        assertEquals("RuntimeException", e.type());
    }

    @Test
    public void repeatedErrorsMergeThenSeparateAfterTheWindow() {
        for (int i = 0; i < 5; i++) {
            history.report("module:a", new RuntimeException("same"));
            clock.addAndGet(100);
        }
        assertEquals(1, history.entries().size());
        assertEquals(5, history.entries().get(0).count());
        clock.addAndGet(ErrorHistory.MERGE_WINDOW_MILLIS);
        history.report("module:a", new RuntimeException("same"));
        assertEquals(2, history.entries().size());
        assertTrue(history.toText().contains("(x5)"));
    }

    @Test
    public void historyIsBoundedNewestFirstAndCanBeSwitchedOff() {
        for (int i = 0; i < 80; i++) {
            history.report("s" + i, new RuntimeException("m"));
            clock.addAndGet(10_000);
        }
        assertEquals(ErrorHistory.MAX_ENTRIES, history.entries().size());
        assertEquals("s79", history.entries().get(0).source());

        enabled.set(false);
        int before = history.entries().size();
        history.report("ignored", new RuntimeException("x"));
        assertEquals(before, history.entries().size());
        history.clear();
        assertEquals("No errors recorded.\n", history.toText());
    }

    @Test
    public void listenersSeeEntriesAndCannotBreakReporting() {
        List<String> seen = new ArrayList<>();
        history.setListener(e -> seen.add(e.source()));
        history.report("one", new RuntimeException("x"));
        history.setListener(e -> {
            throw new IllegalStateException("listener bug");
        });
        history.report("two", null);
        assertEquals(List.of("one"), seen);
        assertEquals(2, history.entries().size());
        assertEquals("Unknown", history.entries().get(0).type());
    }
}
