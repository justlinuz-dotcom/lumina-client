# Changelog

## 0.1.0 — first source release (not yet built against the real game)

* Core in plain Java: module system, typed settings, atomic JSON persistence with backups and quarantine of corrupt files, profiles (create, duplicate, rename, delete, export, import, server binding), HUD layout maths and named HUD layouts, FPS/frametime/memory/stutter statistics, Performance Lab with presets and run comparison, CPS/combo/combat statistics, Toggle Sprint, custom crosshair, video-option modules that restore the original value, local cosmetics (catalog, loadouts, validated PNG import, cache), friends/notes/history/notifications, calculator/timers/waypoints/coordinate conversion, compatibility checker, local error history and diagnostics export.
* 30 modules: 16 HUD, 9 Performance, 4 Visuals, 1 Movement.
* Menu model (8 pages) drawn by a Minecraft screen; HUD editor screen; HUD, crosshair and notification renderer; Fabric entrypoint; one observe-only keyboard mixin.
* 393 unit tests pass; the Minecraft layer (`dev.lumina.mc`) was only compiled against hand-written stubs, never against the real 1.21.11 jars.
* Gradle project for Minecraft 1.21.11 (Mojang mappings, Loom 1.14 remap plugin, Gradle 9.2 wrapper) and a GitHub Actions workflow. `./gradlew build` has not been run.
* Options without an implementation behind them were removed rather than left in the menu.
* Not implemented: see `docs/VERIFICATION.md`, section 7.
