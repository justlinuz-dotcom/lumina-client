# Verificação, testes e limitações (versão 0.1.0)

Este documento diz o que foi **executado de verdade**, o que **não** foi, e o que a especificação pedia e **não está implementado**. Nada aqui foi arredondado para parecer pronto.

## 1. Ambiente em que o código foi escrito

* Java 21 (OpenJDK 21.0.12) e Gradle 8.14.3 instalados localmente, **sem acesso à rede**: o proxy do ambiente responde `403` para `maven.fabricmc.net`, `repo.maven.apache.org`, `piston-meta.mojang.com`, `libraries.minecraft.net` e `services.gradle.org` (reconfirmado em 02/11/2026).
* Consequência: o Minecraft 1.21.11, o Fabric Loader/API, o Loom e o Gradle 9.2 **não puderam ser baixados**, então **`./gradlew build` nunca rodou** e não existe `.jar` do mod gerado aqui.

## 2. O que foi executado de verdade

| O quê | Como | Resultado |
|---|---|---|
| Compilação do núcleo (tudo menos `dev.lumina.mc`) | `javac --release 21 -Xlint:all -Werror` contra gson 2.10 e slf4j-api 1.7.36 | 208 classes, 0 erros, 0 avisos |
| Testes do núcleo | JUnit 4.13.2 (`JUnitCore`), 29 classes de teste | **393 testes, 0 falhas** |
| Camada `dev.lumina.mc` | `javac -Xlint:all -Werror` contra **stubs escritos por mim** das APIs que assumi (`docs/ASSUMED_API.md`) | 14 classes compiladas, 0 erros, 0 avisos |
| Gradle wrapper | `gradle wrapper --gradle-version 9.2.0` (offline) | scripts e `gradle-wrapper.properties` gerados; a distribuição 9.2.0 é baixada no primeiro uso, na sua máquina |

A compilação contra stubs **só prova que o meu código é coerente consigo mesmo**. Se uma assinatura do Minecraft real for diferente da que assumi, o stub não percebe.

Áreas cobertas pelos 393 testes: sistema de módulos (registro, ativar/desativar, dependências, conflitos, teclas, favoritos, reset), configurações tipadas, persistência (escrita atômica, backups, quarentena de arquivo corrompido ou de versão mais nova, restauração), salvamento automático, perfis (criar, duplicar, renomear, excluir, exportar, importar, vínculo a servidor, perfil danificado), cálculos do HUD (posição, escala, alinhamento, grade, encaixe, layouts nomeados), módulos de HUD, FPS/frametime/1% low/memória/travadas, Performance Lab e comparação, CPS/combo/estatísticas de combate, Toggle Sprint, mira personalizada, módulos de vídeo (restaurar o valor original, recuperar após queda), cosméticos (catálogo, equipar, conjuntos, validação de PNG, importação, cache), amigos/notas/históricos/notificações, calculadora/temporizadores/marcadores/conversão de coordenadas, verificação de compatibilidade, histórico de erros sem dados pessoais, e o comportamento de cada página das telas por cliques simulados (`UiPagesTest`, `UiFrameworkTest`).

## 3. O que NÃO foi executado

* `./gradlew build` / `gradlew.bat build` (Loom, remapeamento para o runtime, empacotamento do `.jar`).
* Compilação contra os jars reais do Minecraft 1.21.11 e do Fabric API.
* Carregar o mod no jogo; o mixin `KeyboardHandlerMixin` sendo aplicado; o entrypoint rodando.
* Qualquer desenho na tela: HUD, mira, notificações, menu, editor de HUD.
* Atalhos de teclado reais (menu, editor, módulos), arrastar/rolar no editor de HUD, digitação nos campos de texto.
* Leitura/escrita das opções de vídeo no jogo real (`McGameOptions`) e restauração após fechar o jogo.
* Compatibilidade com Sodium, Lithium, Mod Menu e outros mods.
* Qualquer medição de desempenho (FPS, frametime, custo do próprio cliente). **Nenhum ganho de FPS é afirmado.**
* Servidores reais (ping, endereço do servidor, troca automática de perfil).

## 4. Versões usadas e o quanto foram confirmadas

| Item | Valor em `gradle.properties` | Situação |
|---|---|---|
| Minecraft | 1.21.11 | pedido pela especificação; última versão ainda ofuscada |
| Mappings | Mojang oficiais (`loom.officialMojangMappings()`) | o Yarn foi descontinuado após o 1.21.11 |
| Loom | `1.14-SNAPSHOT`, plugin `net.fabricmc.fabric-loom-remap` | o id do plugin foi reconfirmado em 02/11/2026 em docs.fabricmc.net/develop/loom ("obfuscated versions, Minecraft 1.21.11 or older"); o Loom 1.14 exigir Gradle 9.2 está num issue de dezembro de 2025 do minecraft-dev/templates. **Não** foi resolvido pelo Gradle aqui. O exemplo oficial do Fabric já usa `1.17-SNAPSHOT` com o mesmo plugin: veja `docs/COMO_COMPILAR.md` se o 1.14 falhar |
| Gradle | 9.2.0 (wrapper) | exigido pelo Loom 1.14 segundo a nota de lançamento |
| Fabric Loader | 0.18.1 | mínimo exigido pelo mod; o exemplo oficial já usa 0.19.5, que também serve |
| Fabric API | 0.139.5+1.21.11 | existe segundo a newreleases.io; **não** confirmado como o mais novo |
| Java | 21 | requisito do 1.21.x |

## 5. APIs do Minecraft/Fabric

Todas as assinaturas usadas em `dev.lumina.mc` estão listadas em [`ASSUMED_API.md`](ASSUMED_API.md).
Conferidas na documentação do Fabric durante a escrita: `HudElementRegistry` (`attachElementBefore`, `replaceElement`), `VanillaHudElements`, `Identifier.fromNamespaceAndPath`, `KeyMapping.Category.register`, o construtor de `KeyMapping`, `KeyBindingHelper.registerKeyBinding`, `ClientTickEvents.END_CLIENT_TICK`, `GuiGraphics.fill` e os eventos de entrada do 1.21.9+ (`MouseButtonEvent`, `KeyEvent`, `CharacterEvent`).
**Não conferidas** (escritas de memória): o nome do método de renderização de `HudElement`, `Screen.mouseScrolled`, as chamadas de texto/pose/scissor/tooltip de `GuiGraphics`, `KeyboardHandler.keyPress`, os acessores de `Options`, `PlayerInfo.getLatency`, `ClientPacketListener.getPlayerInfo`, os acessores de `LocalPlayer`, e a forma dos callbacks de conexão/ciclo de vida do Fabric API.
Se `./gradlew build` falhar, a causa mais provável é uma dessas linhas, e o conserto é local ao pacote `dev.lumina.mc`.

## 6. Decisões e limitações conhecidas

* **Modo gráfico (`GRAPHICS`)** é declarado como não suportado: o 1.21.11 tem mais de uma opção parecida e não consegui confirmar qual controlar. O módulo recusa ligar em vez de adivinhar.
* **Hora do jogo** (`timeOfDayTicks`) devolve `-1` (desconhecido): o relógio de jogo do 1.21.11 mudou e não consegui confirmar o acessor. O elemento de HUD mostra "n/a"; o relógio real funciona.
* **Ping** é `-1` em mundo único (o jogo não mede latência ali).
* **Toggle Sprint:** ao parar de segurar a tecla, o módulo a solta mesmo que o jogador ainda esteja com ela pressionada fisicamente (é preciso apertar de novo). Ele só mexe na tecla de sprint que o jogador já tem.
* **Mixin único** (`KeyboardHandlerMixin`), só observa, `require = 0`. Se o nome do método mudar, o gancho é ignorado; o menu continua acessível pela tecla "Open menu" registrada em *Controles*, mas as teclas por módulo deixam de funcionar.
* **Sodium / Lithium / FerriteCore:** só são *detectados* (`CompatChecker`) e recomendados; nada é embutido nem reimplementado. A convivência com eles não foi testada.
* **Mundos/servidores:** a troca automática de perfil por servidor usa o endereço digitado, sem a porta.
* **Cosméticos:** só locais. Nenhuma sincronização multiplayer foi implementada (e a tela avisa que outros jogadores não os veem). Não há desenho no personagem nem pré-visualização 3D.

## 7. Especificação × estado

Legenda: **A** = implementado e testado no núcleo, ainda sem teste dentro do jogo · **B** = implementado, nem compilado contra o jogo real · **—** = não implementado.

| Seção | Item | Estado |
|---|---|---|
| 1.1 | `.jar` instalável gerado e testado no jogo | **—** (projeto pronto para gerar com um comando; ver README) |
| 2 | Nome configurável (`client_name`) | A |
| 2 | Tema escuro, cores de destaque, cantos arredondados, animações suaves | parcial: tema escuro, cor de destaque, fundo e raio dos cantos (só no painel do menu) funcionam; **sem animações** (a opção de animação foi removida por não ter efeito) |
| 3 | Sistema de módulos (nome, categoria, estado, tecla, configurações, auto-save, eventos, tooltips, dependências, conflitos, reset, pesquisa, favoritos) | A (UI: B) |
| 3 | As 10 categorias | existem no enum; só Performance, Visuals, HUD e Movement têm módulos |
| 4 | Distância de renderização/simulação, partículas, nuvens, sombras, bioma, entidades, limite de FPS | A (aplicação no jogo: B) |
| 4 | Medidor de FPS, frametime, gráfico, memória, diagnóstico de quedas, perfis fraco/equilibrado/qualidade | A (desenho: B) |
| 4 | Controle de animações, "ajustes de iluminação" além do brilho | **—** |
| 5 | CPS, recarga do ataque, combo, estatísticas locais, armadura/durabilidade, efeitos de poção (HUD) | A (leituras do jogo: B) |
| 5 | Indicador de alcance, status do escudo, contador de knockback, direção de ameaças, hit particles, sensibilidade, presets de PvP | **—** |
| 6 | Toggle Sprint, teclas pressionadas, indicador de sprint/velocidade/coordenadas/direção, FOV, view bobbing | A (jogo: B) |
| 6 | Auto Sprint, timer de movimento, animações de primeira pessoa, informações de salto/queda | **—** |
| 7 | Brilho, FOV, view bobbing, mira personalizada | A (jogo: B) |
| 7 | Clima, hora local, hit color, indicadores de dano, partículas, motion blur, camera shake, animações de mão/bloco, hurt cam, nametags, tracers, cores do ambiente, transições | **—** |
| 8 | Catálogo, equipar/remover, conjuntos, importação com validação, cache, aviso de "só local" | A (tela: B) |
| 8 | Desenho no personagem, pré-visualização 3D/rotação, pesquisa/favoritos/filtros, variantes de cor, partículas/efeitos/emotes cosméticos | **—** |
| 9 | Home, Mod Menu (pesquisa, filtros, favoritos, tooltips), Click GUI por tecla | A (tela: B) |
| 9.4 | Configurações: Aparência, Interface, Privacidade, Diagnóstico, Sobre; Perfis e Importação/Exportação na tela Perfis; Compatibilidade na tela Performance | parcial |
| 9.4 | Páginas Geral, Vídeo, Áudio e Controles separadas | **—** (vídeo é feito pelos módulos; teclas pelo menu de módulos) |
| 10 | Editor de HUD (arrastar, escala, cor, opacidade, visibilidade, alinhar, grade, restaurar, layouts nomeados) | A (cálculos e layouts) · B (a tela) |
| 11 | Coordenadas, relógio, durabilidade, histórico de sessões (servidores), temporizadores, calculadora, notas, marcadores, diagnóstico | A |
| 11 | Bússola dedicada, informações de bioma/bloco, screenshots, perfis por modo de jogo, atalhos personalizáveis além das teclas de módulo | **—** |
| 12 | Amigos, notas, notificações, histórico de erros, gerenciador de perfis | A |
| 12 | Histórico de jogadores encontrados, mensagens rápidas, sons de notificação, ocultar HUD em screenshots, tela de novidades, verificação de integridade de arquivos | **—** |
| 13 | Performance Lab: FPS, frametime, memória, quedas, índice de estabilidade, comparação de execuções, custo por módulo, exportação de diagnóstico | A (desenho: B) |
| 14 | Perfis (criar, renomear, duplicar, excluir, exportar/importar, restaurar, alternar, vincular a servidor) | A |
| 15 | Persistência (auto-save, backups, validação, restauração, importar/exportar, recuperação de corrompidos, reset por módulo e total) | A |
| 17 | Validação de entradas, exceções protegidas, logging, prevenção de conflitos de teclas, importação validada, desativação segura | A |
| 18 | Testes dentro do Minecraft (renderização, interface, desempenho, compatibilidade) | **—** não executados |

### Opções removidas por não terem efeito

Uma auditoria achou opções que existiam como dados mas não eram usadas por nada (a especificação proíbe isso). Foram **removidas**, não escondidas: *som de notificação*, *esconder o HUD em screenshots*, *reduzir movimento*, *velocidade de animação*, e as chaves de privacidade `cosmeticSync` e `updateCheck`. A opção *Compact lists* passou a controlar de fato o espaçamento das telas, e *Corner radius* o arredondamento do painel do menu. Se você adicionar um recurso novo (por exemplo, um som), traga a opção junto com a implementação.

## 8. Checklist para o primeiro teste dentro do jogo

1. `./gradlew build` passa? Se não, corrija as linhas de `dev.lumina.mc` apontadas pelo erro usando `ASSUMED_API.md`.
2. O jogo abre com Fabric API + o jar e o log mostra `Lumina 0.1.0 started (30 modules)`? Se aparecer "failed to start", o erro vem logo antes.
3. Dentro de um mundo: Right Shift abre o menu? Fechar com Esc volta ao jogo?
4. Ligar FPS Counter, CPS Counter e Coordinates: aparecem? Abrir o editor de HUD pelo menu e arrastar um elemento.
5. Ligar um módulo de vídeo (por exemplo, partículas), conferir em *Opções → Vídeo* e desligar: o valor original volta?
6. Toggle Sprint: apertar a tecla de sprint uma vez e andar para frente.
7. Fechar o jogo e reabrir: módulos, layout e perfil persistem? A pasta `lumina/` foi criada dentro da pasta do jogo?
8. Com Sodium instalado: o HUD aparece e nada quebra?
9. Informe o que falhou (texto do erro e `latest.log`); o conserto costuma ser pequeno e local.
