# Como gerar o `.jar` e colocar na pasta `mods`

> **Aviso honesto:** o ambiente onde este projeto foi escrito não consegue baixar o Minecraft, o Fabric nem o Gradle, então **o build real nunca rodou lá**. Este guia é o caminho para fazê-lo rodar na **sua** máquina (ou no GitHub). O primeiro build é o primeiro teste de verdade da camada que fala com o jogo: se aparecer erro de compilação, veja "Se der erro" no fim e me envie o `build-log.txt`.

Você só precisa de **um** dos dois caminhos.

---

## Caminho A — no seu computador (Windows, macOS ou Linux)

### 1. Instale o Java 21 (JDK, não só o JRE)

* Baixe o **Temurin 21 (LTS)** em <https://adoptium.net> e instale.
* No Windows, no instalador, deixe marcadas as opções **"Add to PATH"** e **"Set JAVA_HOME"**.
* Abra um terminal **novo** e confira: `java -version` deve mostrar `21` (ou mais novo).

### 2. Extraia o projeto

Extraia o `lumina-client-0.1.0-source.zip` numa pasta curta, **sem acentos nem espaços** e fora do OneDrive. Exemplo: `C:\lumina-client`.

### 3. Compile

**Windows:** dê dois cliques em **`build-windows.bat`**.
(Se preferir o terminal: abra a pasta, digite `cmd` na barra de endereço e rode `gradlew.bat build`.)

**macOS / Linux:** no terminal, dentro da pasta: `./build.sh`
(ou `chmod +x gradlew && ./gradlew build`).

* **Na primeira vez demora vários minutos** e precisa de internet: o Gradle baixa o Gradle 9.2, o Minecraft 1.21.11, os mappings e as bibliotecas (algumas centenas de MB) e depois remapeia tudo. As próximas compilações são bem mais rápidas.
* Os scripts guardam o log completo em **`build-log.txt`**.
* O `build-windows.bat` não foi testado em Windows (foi escrito sem acesso a um); o `build.sh` foi testado só até o ponto em que o Gradle precisa da internet. Se o `.bat` der algum problema, use o comando `gradlew.bat build` direto.

### 4. Pegue o arquivo certo

Quando terminar com "PRONTO" (ou `BUILD SUCCESSFUL`), o arquivo é:

```
build\libs\lumina-client-0.1.0.jar
```

Ignore `lumina-client-0.1.0-sources.jar` (é o código-fonte, não vai na pasta `mods`).

---

## Caminho B — sem instalar nada, usando o GitHub

1. Crie uma conta em <https://github.com> e um repositório novo (pode ser **privado**), por exemplo `lumina-client`.
2. Envie o conteúdo da pasta do projeto para ele. Com o Git instalado, dentro da pasta extraída:

   ```
   git init
   git add .
   git commit -m "Lumina"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/lumina-client.git
   git push -u origin main
   ```

   (Sem linha de comando: o aplicativo **GitHub Desktop** faz o mesmo em *File → Add local repository* e *Publish repository*. Pelo navegador o GitHub aceita poucos arquivos por vez e o projeto tem mais de 240, então prefira uma dessas duas formas.)
   A pasta oculta `.github` precisa ir junto: é ela que contém o workflow de build.
3. No GitHub, abra a aba **Actions**, escolha a execução **build** e espere ficar verde.
4. No fim da página da execução, em **Artifacts**, baixe **`lumina-client-jar`**. É um `.zip` com o `.jar` dentro; extraia.
   Se a execução ficar **vermelha**, abra-a, copie o texto do passo "Build and test" e me envie.

---

## Instalando no Minecraft

1. Instale o **Fabric Loader** para o Minecraft **1.21.11** com o instalador oficial: <https://fabricmc.net/use/installer/> (escolha 1.21.11 e instale). Abra o launcher e entre uma vez com o perfil `fabric-loader-1.21.11` para a pasta `mods` ser criada.
2. Baixe o **Fabric API** para **1.21.11** em <https://modrinth.com/mod/fabric-api> (filtre a versão do jogo por 1.21.11). Sem ele o Lumina não carrega.
3. Coloque na pasta `mods` **os dois arquivos**: `lumina-client-0.1.0.jar` e o jar do Fabric API.

   | Sistema | Pasta `mods` |
   |---|---|
   | Windows | `%appdata%\.minecraft\mods` (cole isso na barra do Explorer) |
   | macOS | `~/Library/Application Support/minecraft/mods` |
   | Linux | `~/.minecraft/mods` |

4. Abra o launcher, escolha o perfil **fabric-loader-1.21.11** e jogue.
5. Para saber se carregou: abra um mundo e aperte **Right Shift** (menu do Lumina). No arquivo `.minecraft/logs/latest.log` deve haver uma linha como `Lumina 0.1.0 started (30 modules)`.

Opcionais (outros projetos, não incluídos): Sodium e Lithium, se existirem para 1.21.11, e o Mod Menu.

---

## Se der erro

| O que aparece | O que fazer |
|---|---|
| `Java nao encontrado`, ou erro citando "Java 21", ou `Unsupported class file major version` | Instale o JDK 21 (passo 1) e abra um terminal novo. Se tiver vários Javas, aponte `JAVA_HOME` para o 21. |
| `Could not find net.fabricmc.fabric-api:fabric-api:0.139.5+1.21.11` | Essa versão do Fabric API não existe ou saiu do ar. Em <https://modrinth.com/mod/fabric-api>, veja uma versão que termine em `+1.21.11` e troque `fabric_api_version` em `gradle.properties`. |
| `Plugin ... net.fabricmc.fabric-loom-remap ... was not found` ou erro sobre `1.14-SNAPSHOT` | Troque `loom_version` em `gradle.properties` por `1.17-SNAPSHOT` (a versão que o projeto de exemplo oficial do Fabric usava quando conferi). Mantenha o plugin `net.fabricmc.fabric-loom-remap`: é o certo para 1.21.11. |
| `Minimum supported Gradle version is X` / `requires Gradle X` | Edite `gradle/wrapper/gradle-wrapper.properties` e troque o número em `gradle-9.2.0-bin.zip` pela versão que o erro pede. |
| `cannot find symbol`, `does not override`, `incompatible types` em arquivos de `dev/lumina/mc/` | É o tipo de erro esperado no primeiro build: algum nome do Minecraft que assumi está diferente do jogo real. Veja `docs/ASSUMED_API.md` e **me envie o `build-log.txt`**; o conserto fica dentro desse pacote. |
| Erros de download / `Connection refused` / `403` | Falta internet, ou rede de empresa/escola/antivírus bloqueando. Tente em outra rede. |
| Falha estranha com pasta com acento, espaço ou OneDrive | Mova o projeto para `C:\lumina-client` e tente de novo. |
| O jogo não abre, ou o mod não aparece | Confira: Minecraft **1.21.11**, Fabric Loader instalado, **Fabric API** na pasta `mods`, Java 21 no launcher. Veja o fim de `.minecraft/logs/latest.log` e procure por `Lumina`. |
| O jogo cai citando `KeyboardHandlerMixin` | Abra `src/main/resources/fabric.mod.json`, apague a linha `"mixins": [ "lumina.mixins.json" ],`, compile de novo. Sem o mixin, o menu continua abrindo pela tecla "Open menu" (*Controles → Lumina*), mas as teclas de cada módulo deixam de funcionar. |

**Para pedir ajuda**, envie: o `build-log.txt` (erro de compilação) ou o `latest.log` (erro dentro do jogo).
