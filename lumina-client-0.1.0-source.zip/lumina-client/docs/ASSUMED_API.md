# Assumed Minecraft / Fabric API surface

This file lists **every Minecraft, Fabric and Mixin signature that the `dev.lumina.mc` layer relies on**. It is the same set of declarations that the stubs used in the authoring environment contained.

**These signatures are assumptions.** They come from the Fabric documentation and Mojang-mapped sources as read at authoring time; they were *not* compiled against the real 1.21.11 jars (the authoring environment could not download them). If `./gradlew build` fails inside `dev.lumina.mc`, the cause is almost certainly a line below that does not match the real API, and the fix is local to that file.

Verified in the Fabric documentation at authoring time: `HudElementRegistry.attachElementBefore/replaceElement`, `VanillaHudElements.CHAT/CROSSHAIR`, `Identifier.fromNamespaceAndPath`, `KeyMapping.Category.register`, the `KeyMapping` constructor, `KeyBindingHelper.registerKeyBinding`, `ClientTickEvents.END_CLIENT_TICK`, `GuiGraphics.fill`, and the 1.21.9+ input events (`MouseButtonEvent`, `KeyEvent`, `CharacterEvent`).

Not verified (written from memory of the Mojang-mapped sources): the render method name of `HudElement`, `Screen.mouseScrolled`, `GuiGraphics.drawString`/`pose()`/scissor/tooltip calls, `KeyboardHandler.keyPress`, the `Options` accessor names, `PlayerInfo.getLatency`, `ClientPacketListener.getPlayerInfo`, `LocalPlayer` accessors, and the Fabric API v1 connection/lifecycle callback shapes.

```java
// com.mojang.blaze3d.platform.InputConstants
public class InputConstants { public enum Type { KEYSYM, MOUSE } }
// net.fabricmc.api.ClientModInitializer
public interface ClientModInitializer { void onInitializeClient(); }
// net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents
public final class ClientLifecycleEvents { public interface ClientStopping { void onClientStopping(Minecraft c); } public static final Event<ClientStopping> CLIENT_STOPPING = null; }
// net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
public final class ClientTickEvents { public interface EndTick { void onEndTick(Minecraft c); } public static final Event<EndTick> END_CLIENT_TICK = null; }
// net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper
public final class KeyBindingHelper { public static KeyMapping registerKeyBinding(KeyMapping k){return k;} }
// net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents
public final class ClientPlayConnectionEvents { public interface Join { void onPlayReady(ClientPacketListener h, Object sender, Minecraft c); }
 public interface Disconnect { void onPlayDisconnect(ClientPacketListener h, Minecraft c); }
 public static final Event<Join> JOIN = null; public static final Event<Disconnect> DISCONNECT = null; }
// net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement
@FunctionalInterface public interface HudElement { void render(GuiGraphics g, DeltaTracker t); }
// net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry
public final class HudElementRegistry { public static void attachElementBefore(Identifier a, Identifier b, HudElement e){}
 public static void replaceElement(Identifier a, Function<HudElement,HudElement> f){} }
// net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements
public final class VanillaHudElements { public static final Identifier CHAT = null; public static final Identifier CROSSHAIR = null; }
// net.fabricmc.fabric.api.event.Event
public class Event<T> { public void register(T listener){} }
// net.fabricmc.loader.api.FabricLoader
public interface FabricLoader { static FabricLoader getInstance(){return null;} Collection<ModContainer> getAllMods(); Optional<ModContainer> getModContainer(String id); Path getGameDir(); }
// net.fabricmc.loader.api.ModContainer
public interface ModContainer { ModMetadata getMetadata(); }
// net.fabricmc.loader.api.ModMetadata
public interface ModMetadata { String getId(); Version getVersion(); }
// net.fabricmc.loader.api.Version
public interface Version { String getFriendlyString(); }
// net.minecraft.client.DeltaTracker
public interface DeltaTracker { }
// net.minecraft.client.KeyMapping
public class KeyMapping { public static class Category { public static Category register(Identifier id){return null;} }
 public KeyMapping(String id, InputConstants.Type t, int code, Category c){} public boolean isDown(){return false;} public boolean consumeClick(){return false;} public void setDown(boolean b){} }
// net.minecraft.client.KeyboardHandler
public class KeyboardHandler { }
// net.minecraft.client.Minecraft
public class Minecraft { public static Minecraft getInstance(){return null;} public Options options; public Screen screen; public LocalPlayer player;
 public ClientLevel level; public Font font; public HitResult hitResult; public int getFps(){return 0;} public ServerData getCurrentServer(){return null;}
 public ClientPacketListener getConnection(){return null;} public void setScreen(Screen s){} }
// net.minecraft.client.OptionInstance
public class OptionInstance<T> { public T get(){return null;} public void set(T v){} }
// net.minecraft.client.Options
public class Options { public KeyMapping keyUp,keyDown,keyLeft,keyRight,keyJump,keyShift,keySprint,keyAttack,keyUse;
 public OptionInstance<Integer> renderDistance(){return null;} public OptionInstance<Integer> simulationDistance(){return null;}
 public OptionInstance<ParticleStatusX> particles(){return null;} public OptionInstance<CloudStatusX> cloudStatus(){return null;}
 public OptionInstance<Boolean> entityShadows(){return null;} public OptionInstance<Integer> biomeBlendRadius(){return null;}
 public OptionInstance<Double> entityDistanceScaling(){return null;} public OptionInstance<Integer> framerateLimit(){return null;}
 public OptionInstance<Integer> fov(){return null;} public OptionInstance<Boolean> bobView(){return null;} public OptionInstance<Double> gamma(){return null;}
 public enum ParticleStatusX {ALL,DECREASED,MINIMAL} public enum CloudStatusX {OFF,FAST,FANCY} }
// net.minecraft.client.gui.Font
public class Font { public final int lineHeight = 9; public int width(String s){return 0;} public List<FormattedCharSequence> split(FormattedText t,int w){return null;} }
// net.minecraft.client.gui.GuiGraphics
public class GuiGraphics { public void fill(int a,int b,int c,int d,int e){} public int drawString(Font f,String s,int x,int y,int c){return 0;}
 public int drawString(Font f,String s,int x,int y,int c,boolean sh){return 0;} public int guiWidth(){return 0;} public int guiHeight(){return 0;}
 public Matrix3x2fStack pose(){return null;} public void enableScissor(int a,int b,int c,int d){} public void disableScissor(){}
 public void setTooltipForNextFrame(List<FormattedCharSequence> l,int x,int y){} }
// net.minecraft.client.gui.screens.Screen
public abstract class Screen { public int width, height; protected final Font font = null; protected final Minecraft minecraft = null;
 protected Screen(Component title){} public void render(GuiGraphics g,int mx,int my,float pt){} public void onClose(){} public boolean isPauseScreen(){return true;}
 public boolean keyPressed(KeyEvent e){return false;} public boolean keyReleased(KeyEvent e){return false;} public boolean charTyped(CharacterEvent e){return false;}
 public boolean mouseClicked(MouseButtonEvent e,boolean d){return false;} public boolean mouseReleased(MouseButtonEvent e){return false;}
 public boolean mouseDragged(MouseButtonEvent e,double a,double b){return false;} public boolean mouseScrolled(double a,double b,double c,double d){return false;} }
// net.minecraft.client.input.CharacterEvent
public interface CharacterEvent { int codepoint(); int modifiers(); }
// net.minecraft.client.input.KeyEvent
public interface KeyEvent { int key(); int scancode(); int modifiers(); }
// net.minecraft.client.input.MouseButtonEvent
public interface MouseButtonEvent { double x(); double y(); int button(); int modifiers(); }
// net.minecraft.client.multiplayer.ClientLevel
public class ClientLevel extends net.minecraft.world.level.Level { }
// net.minecraft.client.multiplayer.ClientPacketListener
public class ClientPacketListener { public PlayerInfo getPlayerInfo(java.util.UUID id){return null;} }
// net.minecraft.client.multiplayer.PlayerInfo
public class PlayerInfo { public int getLatency(){return 0;} }
// net.minecraft.client.multiplayer.ServerData
public class ServerData { public String ip; }
// net.minecraft.client.player.LocalPlayer
public class LocalPlayer { public double xo, zo, fallDistance; public double getX(){return 0;} public double getY(){return 0;} public double getZ(){return 0;}
 public float getYRot(){return 0;} public UUID getUUID(){return null;} public boolean isSprinting(){return false;} public boolean isShiftKeyDown(){return false;}
 public boolean onGround(){return false;} public float getAttackStrengthScale(float f){return 0;} public ItemStack getItemBySlot(EquipmentSlot s){return null;}
 public Collection<MobEffectInstance> getActiveEffects(){return null;} public float getHealth(){return 0;} }
// net.minecraft.core.Holder
public interface Holder<T> { T value(); }
// net.minecraft.network.chat.Component
public interface Component extends FormattedText { static Component literal(String s){return null;} String getString(); }
// net.minecraft.network.chat.FormattedText
public interface FormattedText { }
// net.minecraft.resources.Identifier
public class Identifier { public static Identifier fromNamespaceAndPath(String a,String b){return null;} }
// net.minecraft.resources.ResourceKey
public class ResourceKey<T> { }
// net.minecraft.util.FormattedCharSequence
public interface FormattedCharSequence { }
// net.minecraft.world.effect.MobEffect
public class MobEffect { public Component getDisplayName(){return null;} }
// net.minecraft.world.effect.MobEffectInstance
public class MobEffectInstance { public Holder<MobEffect> getEffect(){return null;} public int getDuration(){return 0;} public int getAmplifier(){return 0;} }
// net.minecraft.world.entity.EquipmentSlot
public enum EquipmentSlot { HEAD, CHEST, LEGS, FEET, MAINHAND, OFFHAND, BODY }
// net.minecraft.world.item.ItemStack
public class ItemStack { public boolean isEmpty(){return false;} public boolean isDamageableItem(){return false;} public int getMaxDamage(){return 0;}
 public int getDamageValue(){return 0;} public Component getHoverName(){return null;} }
// net.minecraft.world.level.Level
public class Level { public ResourceKey<Level> dimension(){return null;} }
// net.minecraft.world.phys.HitResult
public class HitResult { public enum Type { MISS, BLOCK, ENTITY } public Type getType(){return null;} }
// org.joml.Matrix3x2fStack
public class Matrix3x2fStack { public Matrix3x2fStack pushMatrix(){return this;} public Matrix3x2fStack popMatrix(){return this;}
 public Matrix3x2fStack translate(float x,float y){return this;} public Matrix3x2fStack scale(float x,float y){return this;} }
// org.spongepowered.asm.mixin.Mixin
public @interface Mixin { Class<?>[] value() default {}; }
// org.spongepowered.asm.mixin.injection.At
public @interface At { String value(); }
// org.spongepowered.asm.mixin.injection.Inject
public @interface Inject { String[] method(); At at(); int require() default -1; }
// org.spongepowered.asm.mixin.injection.callback.CallbackInfo
public class CallbackInfo { }
```
