@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Compilar Lumina

where java >nul 2>nul
if errorlevel 1 (
  echo Java nao encontrado.
  echo Instale o JDK 21 em https://adoptium.net ^(marque "Add to PATH" e "Set JAVA_HOME"^) e abra esta janela de novo.
  pause
  exit /b 1
)

java -version
set "JV="
for /f "tokens=3" %%g in ('java -version 2^>^&1 ^| findstr /i /c:" version "') do if not defined JV set "JV=%%g"
set "JV=%JV:"=%"
set "JMAJOR="
for /f "delims=." %%a in ("%JV%") do set "JMAJOR=%%a"
if not defined JMAJOR (
  echo Nao consegui ler a versao do Java. Continuando mesmo assim...
) else if %JMAJOR% LSS 21 (
  echo.
  echo ERRO: este projeto precisa do Java 21 ou mais novo ^(encontrado: %JV%^).
  echo Instale o JDK 21 em https://adoptium.net e abra esta janela de novo.
  pause
  exit /b 1
)

echo.
echo Compilando. Na primeira vez isso baixa o Gradle, o Minecraft e as bibliotecas ^(varios minutos^).
echo O log completo fica em build-log.txt
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "& '.\gradlew.bat' build --stacktrace 2>&1 | Tee-Object -FilePath 'build-log.txt'; exit $LASTEXITCODE"
if errorlevel 1 (
  echo.
  echo O BUILD FALHOU. Envie o arquivo build-log.txt para quem esta ajudando.
  echo Dicas: docs\COMO_COMPILAR.md, secao "Se der erro".
  pause
  exit /b 1
)

echo.
echo PRONTO. O arquivo para colocar na pasta mods esta em:
echo   %~dp0build\libs\lumina-client-0.1.0.jar
echo ^(ignore o arquivo que termina em -sources.jar^).
echo Lembre-se: a pasta mods tambem precisa do Fabric API para o Minecraft 1.21.11.
explorer "%~dp0build\libs"
pause
