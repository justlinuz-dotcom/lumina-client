#!/usr/bin/env bash
# Builds the mod. Result: build/libs/lumina-client-<version>.jar
# Usage: ./build.sh        (needs JDK 21 and an internet connection the first time)
cd "$(dirname "$0")" || exit 1

if ! command -v java >/dev/null 2>&1; then
  echo "Java nao encontrado. Instale o JDK 21 (https://adoptium.net) e abra um terminal novo."
  exit 1
fi

java -version 2>&1 | head -n 3
major=$(java -version 2>&1 | sed -n 's/.* version "\([0-9]*\).*/\1/p' | head -n 1)
if [ -z "$major" ] || [ "$major" -lt 21 ]; then
  echo
  echo "ERRO: este projeto precisa do Java 21 ou mais novo (encontrado: ${major:-desconhecido})."
  echo "Instale o JDK 21 (https://adoptium.net) e tente de novo."
  exit 1
fi

chmod +x ./gradlew 2>/dev/null
echo
echo "Compilando. Na primeira vez isso baixa o Gradle, o Minecraft e as bibliotecas (varios minutos)."
echo "O log completo fica em build-log.txt"
echo
./gradlew build --stacktrace 2>&1 | tee build-log.txt
status=${PIPESTATUS[0]}

echo
if [ "$status" -ne 0 ]; then
  echo "O BUILD FALHOU. Envie o arquivo build-log.txt (ou o texto acima) para quem esta ajudando."
  echo "Dicas: docs/COMO_COMPILAR.md, secao 'Se der erro'."
  exit "$status"
fi

jar=$(ls build/libs/*.jar 2>/dev/null | grep -v -- '-sources.jar' | grep -v -- '-dev' | head -n 1)
echo "PRONTO. Arquivo para colocar na pasta mods:"
echo "  $(pwd)/${jar:-build/libs/(nao encontrado)}"
echo "Lembre-se: a pasta mods tambem precisa do Fabric API para o Minecraft 1.21.11."
