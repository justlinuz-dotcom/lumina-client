# Lumina — cliente Fabric para Minecraft Java 1.21.11

Cliente modular (HUD, desempenho, visuais, perfis, cosméticos locais e ferramentas) feito como **mod Fabric só do lado do cliente**.
O nome exibido vem de `client_name` em `gradle.properties`; para renomear, mude só esse valor (o `mod_id` deve ficar estável).

> **Estado honesto desta versão (0.1.0)**
>
> * O **núcleo** (módulos, configurações, perfis, HUD, desempenho, cosméticos locais, ferramentas, modelo das telas) é Java puro, compila com `-Xlint:all -Werror` e tem **393 testes JUnit passando**.
> * A **camada Minecraft** (`dev.lumina.mc`: entrypoint, telas, desenho do HUD, adaptadores do jogo, 1 mixin) foi escrita com os nomes Mojang do 1.21.11, mas **nunca foi compilada contra o Minecraft real** — o ambiente onde foi escrita não consegue baixar o Minecraft, o Fabric nem o Gradle. Só foi compilada contra *stubs* escritos à mão, o que prova a consistência do meu código, **não** que os nomes batem com o jogo.
> * Portanto **o `.jar` instalável ainda não existe**: ele é gerado por `./gradlew build` na sua máquina ou pelo GitHub Actions (abaixo). Nada foi testado dentro do jogo.
>
> Detalhes: [`docs/VERIFICATION.md`](docs/VERIFICATION.md) · lista das assinaturas do Minecraft que foram assumidas: [`docs/ASSUMED_API.md`](docs/ASSUMED_API.md).

## Requisitos para jogar

| Item | Versão |
|---|---|
| Minecraft Java Edition | 1.21.11 |
| Fabric Loader | 0.18.1 ou mais novo |
| Fabric API | 0.139.5+1.21.11 ou mais nova para 1.21.11 |
| Java | 21 |

Recomendados (**não** vêm embutidos, são projetos separados): Sodium e Lithium. O cliente não reimplementa o que eles fazem; confira se existe build deles para 1.21.11 antes de instalar.

## Como gerar o `.jar`

Guia completo, passo a passo (inclui instalação do Java, do Fabric e solução de erros): **[`docs/COMO_COMPILAR.md`](docs/COMO_COMPILAR.md)**.

Resumo, com JDK 21 instalado (o wrapper baixa o Gradle 9.2 sozinho; a primeira vez leva vários minutos e precisa de internet):

```
build-windows.bat        # Windows: dois cliques (ou: gradlew.bat build)
./build.sh               # Linux / macOS (ou: ./gradlew build)
```

O arquivo para instalar fica em `build/libs/lumina-client-0.1.0.jar` (o `-sources.jar` ao lado **não** é para instalar). O `build` também roda os testes unitários.

**Sem instalar nada:** envie esta pasta para um repositório no GitHub; o workflow `.github/workflows/build.yml` roda `./gradlew build` e publica o jar em *Actions → (execução) → Artifacts → lumina-client-jar*.

Se o Gradle reclamar da versão do Loom (`1.14-SNAPSHOT`) ou do Fabric API, a tabela "Se der erro" do guia diz o que trocar em `gradle.properties`. Se der erro de compilação em `dev.lumina.mc`, veja `docs/ASSUMED_API.md`: a linha que não bate com o jogo real está lá, e o conserto fica dentro desse pacote.

## Instalação

1. Instale o Fabric Loader para 1.21.11 (instalador oficial em fabricmc.net).
2. Coloque o **Fabric API** e o `lumina-client-0.1.0.jar` na pasta `mods` do jogo.
3. Abra o jogo com o perfil Fabric. Dentro de um mundo, **Right Shift** abre o menu (configurável). Também existem as teclas "Open menu" e "HUD editor" em *Controles → Lumina*.

Os dados ficam em `<pasta do jogo>/lumina/` (configurações, perfis, layouts, backups, importações, exportações, diagnósticos). Nada fora dessa pasta é alterado, nem arquivos de outros mods.

## O que o cliente tem

**30 módulos** (cada um com tecla, configurações próprias, tooltip, dependências/conflitos, favoritos, reset e salvamento automático):

* **HUD (16):** FPS, CPS, coordenadas, ping, direção, relógio, informações da sessão, uso de memória, gráfico de desempenho, informações de combate (recarga do ataque, combo, estatísticas), status de armadura, durabilidade de itens, efeitos de poção, teclas pressionadas, indicador de sprint, contador.
* **Performance (9):** distância de renderização e de simulação, partículas, nuvens, sombras de entidades, mistura de bioma, distância de entidades, limite de FPS, modo gráfico.
  Cada um *mantém* a opção do jogo no valor escolhido, devolve o valor original ao desligar e guarda um registro para restaurar mesmo após uma queda do jogo. O modo gráfico fica indisponível no 1.21.11 (ver `docs/VERIFICATION.md`).
* **Visuals (4):** FOV, view bobbing, brilho (limitado ao máximo do jogo), mira personalizada (formato, tamanho, cor, contorno, abertura dinâmica).
* **Movement (1):** Toggle Sprint (nunca corre para trás nem agachado).

**Telas:** Início, Módulos (pesquisa, filtros, favoritos, configurações por módulo, tecla), Perfis, Performance Lab, Cosméticos, Social, Ferramentas e Configurações, mais o **editor de HUD** (arrastar, rolar para escalar, selecionar vários e alinhar, botões de escala, opacidade, cor, fundo e visibilidade, grade e encaixe, restaurar). Layouts nomeados do HUD (salvar, carregar, excluir) ficam na tela **Perfis**.

**Performance Lab:** presets (computador fraco / equilibrado / qualidade / vanilla), medição de FPS e frametime com 1% / 0,1% low, histórico de travadas, memória, comparação entre execuções salvas e custo de tick por módulo. O texto evita culpar um módulo sem evidência; **nenhum ganho de FPS é prometido** — meça no seu computador.

**Perfis:** criar, renomear, duplicar, excluir, exportar/importar (JSON), vincular a servidores, com backups e recuperação de arquivos corrompidos.

**Cosméticos (locais):** catálogo por espaço (capa, chapéu, asas…) com raridade, escolher/remover o item de cada espaço, chave para esconder tudo, conjuntos (loadouts) salvos com nome, importação de textura PNG da pasta `imports/` com validação (assinatura, CRC, tamanho em bytes e pixels, sem animação) e cache de recursos. Aviso fixo na tela: *cosméticos só aparecem para você, outros jogadores não os veem, e nunca mudam o gameplay.*
**Ainda não existe:** desenho dos cosméticos no personagem dentro do jogo, pré-visualização 3D com rotação, pesquisa/favoritos/filtro de raridade e variantes de cor na tela de cosméticos (os dois primeiros exigem a API de renderização de entidades do 1.21.11, que não pude verificar aqui; escrever isso às cegas arriscaria travar o jogo). Os cosméticos embutidos são, por enquanto, entradas do catálogo sem modelo no jogo.

**Social / Ferramentas:** lista de amigos, notas, histórico de servidores, notificações (o histórico local de erros e o arquivo de diagnóstico ficam em *Configurações*); calculadora (analisador próprio, sem `eval`), temporizadores, marcadores de coordenadas, conversão Overworld ↔ Nether.

### O que a especificação pedia e **não** está implementado

Módulos de **Combat** além das informações no HUD (indicador de alcance, contador de knockback, direção de ameaças, hit particles), **Auto Sprint**, **Visuals** além dos 4 acima (clima, hora local, motion blur, camera shake, animações de mão/bloco, nametags, tracers, cores de ambiente), **World** (bioma, informações de bloco, screenshots), páginas **Áudio** e **Controles** separadas, **tela de novidades** e **verificação de integridade de arquivos**. As categorias Combat, Cosmetics, World, Utility, Social e Settings existem, mas seus recursos aparecem como telas ou como módulos de HUD, não como módulos próprios. Lista completa e motivos em `docs/VERIFICATION.md`.

## Segurança e privacidade

* Sem telemetria, sem verificador de atualização, sem download, sem rede. Nada é enviado para fora do computador.
* Sem automação de ataque, mira assistida, manipulação de pacotes ou qualquer coisa que um servidor proíba. O Toggle Sprint só segura a tecla de sprint que o jogador já tem.
* Arquivos importados são só dados: o JSON é lido com limites de tamanho e profundidade, nomes de arquivo passam por validação (sem `..`, nomes reservados do Windows, links simbólicos) e nada é executado.
* O arquivo de diagnóstico não inclui nome de jogador, chat, coordenadas nem endereço de servidor.
* O único mixin (`KeyboardHandlerMixin`) apenas observa teclas, não cancela nem altera nada, e tem `require = 0`: se o método mudar numa versão futura, o gancho é ignorado em vez de travar o jogo.

## Estrutura do código

```
src/main/java/dev/lumina/
  ClientContext      liga tudo; é a única porta de entrada do núcleo
  module/ setting/   sistema de módulos e configurações
  config/ profile/   persistência (JSON atômico, backups, quarentena) e perfis
  event/             barramento de eventos interno
  hud/ render/       cálculo do HUD e da mira (sem Minecraft)
  performance/       FPS, frametime, memória, travadas, comparação de execuções
  combat/ input/     CPS, combo, estatísticas, Toggle Sprint
  options/           módulos de vídeo + presets sobre a interface GameOptions
  cosmetics/ social/ tools/ world/ compat/ diagnostics/ utils/
  ui/                telas como dados (linhas e páginas) — testáveis sem o jogo
  mc/                ÚNICO pacote que toca o Minecraft/Fabric (entrypoint, telas, desenho, adaptadores, mixin)
src/test/java/       393 testes do núcleo e do modelo das telas
```

O núcleo só enxerga o jogo por três interfaces — `GameState`, `GameOptions`, `InputControl` — implementadas em `mc/`.

## Testes

Rodados de verdade no ambiente de desenvolvimento: compilação do núcleo com `javac --release 21 -Xlint:all -Werror` e 393 testes JUnit 4 (configuração, recuperação de arquivos corrompidos, módulos, perfis, cálculos do HUD, desempenho, cosméticos e validação de PNG, ferramentas, comportamento das páginas via cliques simulados).
**Não** rodados: `./gradlew build`, carregar o mod no jogo, renderização, atalhos de teclado reais, compatibilidade com Sodium/Lithium, medição de desempenho. Veja a lista em `docs/VERIFICATION.md`.

## Licença

MIT (arquivo `LICENSE`).
